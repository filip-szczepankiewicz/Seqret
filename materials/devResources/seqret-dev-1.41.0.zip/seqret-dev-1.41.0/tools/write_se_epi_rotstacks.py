#!/usr/bin/env python3
"""Multi-slice spin-echo single-shot EPI with rotated slice stacks, as used for super-resolution reconstruction.

11 stacks of 5 slices each. Stack k is the reference stack (axial: slice normal z, readout x, phase encoding y)
rotated about the phase-encoding axis (y) by k * 360/11 degrees. The phase-encoding direction is therefore the
same in every stack, and the slice normals of the stacks lie in the x-z plane.

Written with PyPulseq 1.5 (pip install pypulseq). The rotations are applied to the gradient events themselves
(pp.rotate), so the file needs no extension and runs on any Pulseq interpreter. Labels: SLC (slice in the stack),
SET (stack = rotation index), LIN (phase-encoding line).
"""
import math
import numpy as np
import pypulseq as pp

# ---------------- parameters ----------------
fov = 220e-3              # in-plane FOV (m), square
n = 64                    # matrix (readout samples and phase-encoding lines)
thk = 4e-3                # slice thickness (m)
gap = 0.0                 # gap between slices (m)
n_slices = 5              # slices per stack
n_stacks = 11             # rotations, evenly spread over the full circle
TE = 70e-3                # echo time (s)
TR = 2.0                  # time between excitations of the same slice (s); one stack per TR
dwell = 5e-6              # readout sample spacing (s); n * dwell must be a multiple of the 10 us gradient raster
fat_sat = True            # spectral fat saturation before each excitation
out = 'se_epi_rotstacks_11x5.seq'

sysd = pp.Opts(max_grad=32, grad_unit='mT/m', max_slew=130, slew_unit='T/m/s', rf_ringdown_time=20e-6,
               rf_dead_time=100e-6, adc_dead_time=10e-6, grad_raster_time=10e-6)
seq = pp.Sequence(sysd)
dk = 1 / fov

# ---------------- events (reference, unrotated stack) ----------------
rf90, gz90, gz90r = pp.make_sinc_pulse(flip_angle=math.pi / 2, duration=3e-3, slice_thickness=thk, apodization=0.5,
                                       time_bw_product=4, delay=sysd.rf_dead_time, system=sysd, return_gz=True,
                                       use='excitation')
rf180, gz180, _ = pp.make_sinc_pulse(flip_angle=math.pi, duration=3e-3, slice_thickness=thk * 1.2, apodization=0.5,
                                     time_bw_product=4, delay=sysd.rf_dead_time, system=sysd, return_gz=True,
                                     use='refocusing')
crush = pp.make_trapezoid('z', area=4 / thk, duration=1.6e-3, system=sysd)       # crushers around the 180
if fat_sat:
    rf_fs = pp.make_gauss_pulse(flip_angle=math.radians(110), duration=8e-3, bandwidth=abs(3.45e-6 * 42.576e6 * 3),
                                freq_ppm=-3.45, delay=sysd.rf_dead_time, system=sysd, use='saturation')
    gfs = pp.make_trapezoid('z', area=6 / thk, duration=2e-3, system=sysd)     # spoiler after the fat saturation

# EPI readout (flat-top sampling) and blips
# the ADC covers exactly the flat top, so the sample spacing in k is exactly 1/FOV
assert abs(n * dwell / 10e-6 - round(n * dwell / 10e-6)) < 1e-9, 'n * dwell must be a multiple of 10 us'
gx = pp.make_trapezoid('x', flat_area=n * dk, flat_time=n * dwell, system=sysd)
adc = pp.make_adc(n, duration=n * dwell, delay=gx.rise_time, system=sysd)
blip_dur = math.ceil(2 * math.sqrt(dk / sysd.max_slew) / 10e-6) * 10e-6
gy_blip = pp.make_trapezoid('y', area=dk, duration=blip_dur, system=sysd)
# prephasers, before the refocusing pulse (which mirrors k): afterwards the samples lie at k = (-n/2 ... n/2 - 1) dk
# in both directions, so that k = 0 is sampled, on the centre line (n/2) at its centre sample
pre_dur = 1.2e-3
gx_pre = pp.make_trapezoid('x', area=gx.area / 2 + dk / 2, duration=pre_dur, system=sysd)
gy_pre = pp.make_trapezoid('y', area=n / 2 * dk, duration=pre_dur, system=sysd)
gz_ref = pp.make_trapezoid('z', area=gz90r.area, duration=pre_dur, system=sysd)   # slice rephaser

# ---------------- timing ----------------
C = pp.calc_duration
t_exc_center = rf90.delay + pp.calc_rf_center(rf90)[0]                  # within the excitation block
t_ref_center = rf180.delay + pp.calc_rf_center(rf180)[0]
echo_line = n // 2                                                      # k-space centre line (0-based)
t_to_center = echo_line * (C(gx) + C(gy_blip)) + gx.rise_time + (n // 2 + 0.5) * dwell   # to the k = 0 sample
fill1 = TE / 2 - (C(gz90) - t_exc_center) - pre_dur - C(crush) - t_ref_center
fill2 = TE / 2 - (C(gz180) - t_ref_center) - C(crush) - t_to_center
fill1 = round(fill1 / 10e-6) * 10e-6; fill2 = round(fill2 / 10e-6) * 10e-6
if fill1 < 0 or fill2 < 0:
    raise SystemExit(f'TE too short: needs {TE - 2 * min(fill1, fill2):.4f} s or more')

# ---------------- sequence ----------------
order = list(range(0, n_slices, 2)) + list(range(1, n_slices, 2))       # interleaved
pos = [(i - (n_slices - 1) / 2) * (thk + gap) for i in range(n_slices)]  # along each stack's slice normal
angles = [2 * math.pi * k / n_stacks for k in range(n_stacks)]
R = lambda th, *ev: pp.rotate(*ev, angle=th, axis='y', system=sysd)       # rotate the gradients of a block about y

for k, th in enumerate(angles):
    for s in order:
        t_start = sum(seq.block_durations.values())
        if fat_sat:
            seq.add_block(rf_fs)
            seq.add_block(*R(th, gfs))
        rf90.freq_offset = gz90.amplitude * pos[s]
        rf90.phase_offset = -2 * math.pi * rf90.freq_offset * pp.calc_rf_center(rf90)[0]
        rf180.freq_offset = gz180.amplitude * pos[s]
        rf180.phase_offset = math.pi / 2 - 2 * math.pi * rf180.freq_offset * pp.calc_rf_center(rf180)[0]
        seq.add_block(rf90, *R(th, gz90), pp.make_label('SLC', 'SET', s), pp.make_label('SET', 'SET', k))
        seq.add_block(*R(th, gx_pre, gy_pre, gz_ref), pp.make_label('LIN', 'SET', 0))
        if fill1 > 0: seq.add_block(pp.make_delay(fill1))
        seq.add_block(*R(th, crush))
        seq.add_block(rf180, *R(th, gz180))
        seq.add_block(*R(th, crush))
        if fill2 > 0: seq.add_block(pp.make_delay(fill2))
        for i in range(n):
            g = gx if i % 2 == 0 else pp.scale_grad(gx, -1)
            seq.add_block(*R(th, g), adc)
            if i < n - 1:
                seq.add_block(gy_blip, pp.make_label('LIN', 'INC', 1))
        seq.add_block(pp.make_delay(2e-3))
        # fill to the slice period TR / n_slices, measured on the blocks actually written (rotated blocks included)
        fill_tr = round((TR / n_slices - (sum(seq.block_durations.values()) - t_start)) / 10e-6) * 10e-6
        if fill_tr < 0: raise SystemExit(f'TR too short by {-fill_tr * n_slices:.3f} s')
        if fill_tr > 0: seq.add_block(pp.make_delay(fill_tr))

ok, err = seq.check_timing()
print('timing check:', 'passed' if ok else err[:5])
seq.set_definition('FOV', [fov, fov, n_slices * thk + (n_slices - 1) * gap])
seq.set_definition('Name', 'se_epi_rotstacks')
seq.set_definition('SliceThickness', thk)
seq.set_definition('SlicesPerStack', n_slices)
seq.set_definition('Stacks', n_stacks)
seq.set_definition('StackRotationAxis', 'y')
seq.set_definition('StackRotationAnglesDeg', [round(math.degrees(a), 4) for a in angles])
seq.set_definition('TE', TE)
seq.set_definition('TR', TR)
seq.write(out)
print(f'{out}: {len(seq.block_events):,} blocks, {sum(seq.block_durations.values()):.2f} s, '
      f'fill before 180 {fill1 * 1e3:.2f} ms, after {fill2 * 1e3:.2f} ms')

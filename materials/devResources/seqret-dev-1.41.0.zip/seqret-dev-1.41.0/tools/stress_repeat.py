#!/usr/bin/env python3
"""Make a large stress-test .seq by repeating the [BLOCKS] table of a small one (Python 3 standard library only).

    python3 tools/stress_repeat.py src/demo.seq -n 300 -o stress_demo_x300.seq       # 300 copies
    python3 tools/stress_repeat.py src/demo.seq --blocks 1000000 -o stress_1M.seq     # about a million blocks
    python3 tools/stress_repeat.py src/demo.seq --mb 100 -o stress_100MB.seq          # about 100 MB

The events, shapes and extensions are shared, so the file grows only by its block rows (about 30 bytes per block);
the result is a valid Pulseq file with a fresh md5 signature. It is timing-consistent because each copy is
the whole sequence. Use it for the load path, the pyramids and drawing, shot and volume detection and the
stimulation pass at scale. It is NOT a realistic sequence: every copy repeats the same volumes and labels.
For realistic large files use tools/make_stress_seq.py (PyPulseq).
"""
import argparse, hashlib, re, sys

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument('src'); ap.add_argument('-o', '--out', required=True)
g = ap.add_mutually_exclusive_group(required=True)
g.add_argument('-n', type=int, help='number of copies of the block table')
g.add_argument('--blocks', type=float, help='target number of blocks')
g.add_argument('--mb', type=float, help='target file size in MB')
a = ap.parse_args()

text = open(a.src, encoding='utf-8', newline='').read().replace('\r\n', '\n')
text = text.split('\n[SIGNATURE]')[0].rstrip('\n') + '\n'           # drop the old signature
m = re.search(r'^\[BLOCKS\]\n', text, re.M)
if not m: sys.exit('no [BLOCKS] section')
start = m.end(); nxt = re.search(r'^\[', text[start:], re.M); end = start + (nxt.start() if nxt else len(text) - start)
head, body, tail = text[:start], text[start:end], text[end:]
rows, other = [], []
for line in body.split('\n'):
    s = line.strip()
    if s and not s.startswith('#'): rows.append(s.split())
    elif not rows: other.append(line)                                 # comment lines before the first row
nb = len(rows)
if a.n: n = a.n
elif a.blocks: n = max(1, round(a.blocks / nb))
else:
    per_copy = sum(len(' '.join(r)) + 1 for r in rows) + 4 * nb       # rough bytes per copy after renumbering
    n = max(1, round((a.mb * 1e6 - len(text)) / per_copy))
w = len(str(nb * n))
out = [head, '\n'.join(other).rstrip('\n') + ('\n' if other and any(o.strip() for o in other) else '')]
buf = []
for c in range(n):
    for i, r in enumerate(rows):
        buf.append(f'{c * nb + i + 1:>{w}} ' + ' '.join(r[1:]) + '\n')
    if len(buf) > 200000: out.append(''.join(buf)); buf = []
out.append(''.join(buf)); out.append('\n' + tail.lstrip('\n') if not tail.startswith('\n') else tail)
content = ''.join(out)
if not content.endswith('\n'): content += '\n'
# TotalDuration, when defined, must scale with the copies
def scale_dur(mm): return f'{mm.group(1)}{float(mm.group(2)) * n:.10g}'
content = re.sub(r'^(TotalDuration\s+)([0-9.eE+-]+)', scale_dur, content, flags=re.M)
content = content.rstrip('\n') + '\n'                                 # one blank line before [SIGNATURE]; the newline
h = hashlib.md5(content.encode('utf-8')).hexdigest()                  # directly before [SIGNATURE] is not hashed
with open(a.out, 'w', encoding='utf-8', newline='\n') as f:
    f.write(content + '\n[SIGNATURE]\n# md5 of the file up to (not including) the newline before [SIGNATURE]\nType md5\nHash ' + h + '\n')
print(f'{a.out}: {n} copies x {nb} blocks = {n * nb:,} blocks, {len(content) / 1e6:.1f} MB')

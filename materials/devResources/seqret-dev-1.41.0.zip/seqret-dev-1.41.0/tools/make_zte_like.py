#!/usr/bin/env python3
# Usage: python3 tools/make_zte_like.py [spokes]   (default 20000; writes zte_<spokes>.seq, about 2 blocks per spoke)
# ZTE-like 3D radial test sequence (PyPulseq 1.5): every spoke = a hard excitation pulse during a constant gradient + readout,
# spoke directions on a golden-angle spiral; small gradient ramps between spokes
import math, numpy as np, pypulseq as pp, sys, warnings
warnings.filterwarnings('ignore')
N = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
sysd = pp.Opts(max_grad=20, grad_unit='mT/m', max_slew=100, slew_unit='T/m/s', rf_dead_time=20e-6, rf_ringdown_time=20e-6, adc_dead_time=10e-6)
seq = pp.Sequence(sysd); fov = 0.22; n = 64; G = 0.8 * n / fov / 1.0e-3 / 0.6   # Hz/m: n samples over 0.6 ms
rf = pp.make_block_pulse(flip_angle=math.radians(3), duration=20e-6, system=sysd, use='excitation', delay=sysd.rf_dead_time)
adc = pp.make_adc(n, duration=0.6e-3, delay=sysd.rf_dead_time + 20e-6 + sysd.rf_ringdown_time + 30e-6, system=sysd); adc_dur = 0.6e-3
dur = math.ceil((adc.delay + adc_dur + 50e-6) / 10e-6) * 10e-6
ga = math.pi * (3 - math.sqrt(5)); prev = np.zeros(3)
for i in range(N):
    z = 1 - 2 * (i + 0.5) / N; r = math.sqrt(1 - z * z); th = ga * i
    d = np.array([r * math.cos(th), r * math.sin(th), z]) * G
    ramp = 200e-6   # move from the previous spoke's gradient to this one's
    evs = [pp.make_extended_trapezoid(ch, times=np.array([0, ramp]), amplitudes=np.array([prev[a], d[a]]), system=sysd) for a, ch in enumerate('xyz')]
    seq.add_block(*evs)
    evs = [pp.make_extended_trapezoid(ch, times=np.array([0, dur]), amplitudes=np.array([d[a], d[a]]), system=sysd) for a, ch in enumerate('xyz')]
    seq.add_block(rf, adc, *evs); prev = d
evs = [pp.make_extended_trapezoid(ch, times=np.array([0, 200e-6]), amplitudes=np.array([prev[a], 0]), system=sysd) for a, ch in enumerate('xyz')]
seq.add_block(*evs)
seq.set_definition('FOV', [fov] * 3); seq.set_definition('Name', 'zte_like')
seq.write(f'zte_{N}.seq'); print(len(seq.block_events), 'blocks', sum(seq.block_durations.values()), 's')

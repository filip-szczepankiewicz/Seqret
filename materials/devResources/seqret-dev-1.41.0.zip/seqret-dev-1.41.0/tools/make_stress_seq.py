#!/usr/bin/env python3
"""Realistic stress-test sequences for Seqret, written with PyPulseq 1.5 (pip install pypulseq numpy).

    python3 tools/make_stress_seq.py epi    -o stress_epi.seq    --slices 30 --volumes 100 --matrix 64
    python3 tools/make_stress_seq.py gre3d  -o stress_gre3d.seq  --matrix 128 --partitions 64
    python3 tools/make_stress_seq.py spiral -o stress_spiral.seq --interleaves 48 --slices 20 --volumes 10

epi     multi-slice, multi-volume blipped GRE-EPI (fMRI-like): many shots and volumes, SLC/LIN/REP labels,
        interleaved slice order. Blocks: about (2 x matrix + 4) per slice per volume.
gre3d   3D spoiled gradient echo with LIN/PAR labels and RF spoiling (a new RF phase every TR): very many
        short shots, many distinct RF events. Blocks: 4 x matrix x partitions.
spiral  multi-slice spiral-out GRE; every interleave is its own arbitrary gradient shape (large [SHAPES]
        section, non-Cartesian k-space and reconstruction). Blocks: 4 x interleaves x slices x volumes.

The defaults give files of a few to a few tens of MB. Scale the counts up for bigger files; PyPulseq needs
roughly 1-3 minutes per million blocks to write. These are plausible sequences, not validated protocols.
"""
import argparse, math, sys
import numpy as np
import pypulseq as pp

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument('kind', choices=['epi', 'gre3d', 'spiral'])
ap.add_argument('-o', '--out', required=True)
ap.add_argument('--matrix', type=int, default=None, help='in-plane matrix (epi 64, gre3d 128, spiral 128)')
ap.add_argument('--fov', type=float, default=220e-3, help='in-plane FOV in m')
ap.add_argument('--slices', type=int, default=None, help='epi 30, spiral 20')
ap.add_argument('--volumes', type=int, default=None, help='epi 100, spiral 10')
ap.add_argument('--partitions', type=int, default=64, help='gre3d only')
ap.add_argument('--interleaves', type=int, default=48, help='spiral only')
a = ap.parse_args()

sys_ = pp.Opts(max_grad=32, grad_unit='mT/m', max_slew=130, slew_unit='T/m/s', rf_ringdown_time=20e-6,
               rf_dead_time=100e-6, adc_dead_time=10e-6, grad_raster_time=10e-6)
seq = pp.Sequence(sys_)
thk = 3e-3


def slice_pulse(flip_deg, dur=2e-3, tbw=4):
    rf, gz, gzr = pp.make_sinc_pulse(flip_angle=math.radians(flip_deg), duration=dur, slice_thickness=thk,
                                     apodization=0.5, time_bw_product=tbw, delay=sys_.rf_dead_time, system=sys_, return_gz=True, use='excitation')
    return rf, gz, gzr


def epi():
    N = a.matrix or 64; nsl = a.slices or 30; nvol = a.volumes or 100
    rf, gz, gzr = slice_pulse(70)
    dk = 1 / a.fov
    gx = pp.make_trapezoid('x', flat_area=N * dk, flat_time=math.ceil(N * 5e-6 / 10e-6) * 10e-6, system=sys_)
    adc = pp.make_adc(N, duration=gx.flat_time, delay=gx.rise_time, system=sys_)
    pre_t = pp.calc_duration(gzr)
    gxp = pp.make_trapezoid('x', area=-gx.area / 2, duration=max(pre_t, 1e-3), system=sys_)
    gyp = pp.make_trapezoid('y', area=-N / 2 * dk, duration=max(pre_t, 1e-3), system=sys_)
    blip_dur = math.ceil(2 * math.sqrt(dk / sys_.max_slew) / 10e-6 / 2) * 10e-6 * 2
    gyb = pp.make_trapezoid('y', area=dk, duration=blip_dur, system=sys_)
    spoil = pp.make_trapezoid('z', area=4 / thk, system=sys_)
    C = pp.calc_duration
    used = C(rf, gz) + C(gxp, gyp, gzr) + N * C(gx, adc) + (N - 1) * C(gyb) + C(spoil)
    tr_slice = max(60e-3, math.ceil(used / 1e-3) * 1e-3); fill = round((tr_slice - used) / 10e-6) * 10e-6
    order = list(range(0, nsl, 2)) + list(range(1, nsl, 2))
    for v in range(nvol):
        seq.add_block(pp.make_label('REP', 'SET', v))
        for s in order:
            rf.freq_offset = gz.amplitude * thk * (s - (nsl - 1) / 2)
            seq.add_block(rf, gz, pp.make_label('SLC', 'SET', s))
            seq.add_block(gxp, gyp, gzr, pp.make_label('LIN', 'SET', 0))
            for i in range(N):
                gxi = pp.scale_grad(gx, -1 if i % 2 else 1)
                seq.add_block(gxi, adc)
                if i < N - 1: seq.add_block(gyb, pp.make_label('LIN', 'INC', 1))
            seq.add_block(spoil)
            if fill > 0: seq.add_block(pp.make_delay(fill))
    seq.set_definition('FOV', [a.fov, a.fov, thk * nsl]); seq.set_definition('Name', f'stress_epi_{N}_{nsl}sl_{nvol}vol')


def gre3d():
    N = a.matrix or 128; P = a.partitions
    slab = thk * P
    rf, gz, gzr = pp.make_sinc_pulse(flip_angle=math.radians(10), duration=1e-3, slice_thickness=slab, apodization=0.5,
                                     time_bw_product=2, delay=sys_.rf_dead_time, system=sys_, return_gz=True, use='excitation')
    dk, dkz = 1 / a.fov, 1 / slab
    gx = pp.make_trapezoid('x', flat_area=N * dk, flat_time=N * 10e-6 * 2, system=sys_)
    adc = pp.make_adc(N, duration=gx.flat_time, delay=gx.rise_time, system=sys_)
    gxp = pp.make_trapezoid('x', area=-gx.area / 2, duration=1e-3, system=sys_)
    gxs = pp.make_trapezoid('x', area=2 * N * dk, system=sys_)
    phase, inc = 0.0, 0.0
    for p in range(P):
        for i in range(N):
            gy = pp.make_trapezoid('y', area=(i - N / 2) * dk, duration=1e-3, system=sys_)
            gzp = pp.make_trapezoid('z', area=(p - P / 2) * dkz + gzr.area, duration=1e-3, system=sys_)
            inc += 117; phase = (phase + inc) % 360            # RF spoiling
            rf.phase_offset = math.radians(phase); adc.phase_offset = math.radians(phase)
            seq.add_block(rf, gz)
            seq.add_block(gxp, gy, gzp, pp.make_label('LIN', 'SET', i), pp.make_label('PAR', 'SET', p))
            seq.add_block(gx, adc)
            seq.add_block(gxs, pp.scale_grad(gy, -1), pp.scale_grad(gzp, -1))
    seq.set_definition('FOV', [a.fov, a.fov, slab]); seq.set_definition('Name', f'stress_gre3d_{N}x{N}x{P}')


def spiral_waveform(nint, N):
    """Time-optimal (gradient- and slew-limited) Archimedean spiral-out, ending at zero gradient. Returns G (Hz/m)
    on the gradient raster as a complex array (x + iy), starting and ending at 0."""
    gam = 42.576e6; dt = sys_.grad_raster_time
    gmax = 0.9 * sys_.max_grad; smax = 0.7 * sys_.max_slew             # Hz/m and Hz/m/s
    kmax = N / (2 * a.fov)
    th = np.linspace(0, 2 * math.pi * kmax * a.fov / nint, 20000)       # k = th * nint / (2 pi FOV) along the angle th
    c = nint / (2 * math.pi * a.fov); k = c * th * np.exp(1j * th)
    ds = np.abs(np.diff(k)); s = np.concatenate([[0], np.cumsum(ds)])
    d1 = np.gradient(k, s); d2 = np.gradient(d1, s); kap = np.abs(np.imag(np.conj(d1) * d2)) + 1e-12
    vmax = np.minimum(gmax, np.sqrt(smax / kap))                       # |dk/dt| in 1/m/s == Hz/m
    v = np.zeros_like(s); vb = np.zeros_like(s)
    for i in range(1, len(s)):                                          # forward (accelerate) and backward (brake) passes
        v[i] = min(vmax[i], math.sqrt(v[i - 1] ** 2 + 2 * smax * (s[i] - s[i - 1])))
    for i in range(len(s) - 2, -1, -1):
        vb[i] = min(v[i], math.sqrt(vb[i + 1] ** 2 + 2 * smax * (s[i + 1] - s[i])))
    vb[0] = 0
    t = np.concatenate([[0], np.cumsum(ds / np.maximum(0.5 * (vb[1:] + vb[:-1]), 1e-3))])
    tg = np.arange(0, t[-1], dt); kg = np.interp(tg, t, k.real) + 1j * np.interp(tg, t, k.imag)
    g = np.diff(kg) / dt
    g = np.concatenate([[0], g, [0]])
    return g


def spiral():
    N = a.matrix or 128; nint = a.interleaves; nsl = a.slices or 20; nvol = a.volumes or 10
    g0 = spiral_waveform(nint, N)
    rf, gz, gzr = slice_pulse(20)
    dur = (len(g0) - 1) * sys_.grad_raster_time
    nadc = int((dur - sys_.adc_dead_time) / 2e-6) // 2 * 2
    adc = pp.make_adc(nadc, duration=nadc * 2e-6, delay=sys_.adc_dead_time, system=sys_)
    spoil = pp.make_trapezoid('z', area=4 / thk, system=sys_)
    shots = []
    for j in range(nint):
        gj = g0 * np.exp(1j * 2 * math.pi * j / nint)
        shots.append((pp.make_arbitrary_grad('x', gj.real, first=0, last=0, system=sys_),
                      pp.make_arbitrary_grad('y', gj.imag, first=0, last=0, system=sys_)))
    for v in range(nvol):
        for s in range(nsl):
            rf.freq_offset = gz.amplitude * thk * (s - (nsl - 1) / 2)
            for j, (gx, gy) in enumerate(shots):
                seq.add_block(rf, gz, pp.make_label('SLC', 'SET', s), pp.make_label('REP', 'SET', v))
                seq.add_block(gzr, pp.make_label('LIN', 'SET', j))
                seq.add_block(gx, gy, adc)
                seq.add_block(spoil)
    seq.set_definition('FOV', [a.fov, a.fov, thk * nsl]); seq.set_definition('Name', f'stress_spiral_{nint}il_{nsl}sl_{nvol}vol')


{'epi': epi, 'gre3d': gre3d, 'spiral': spiral}[a.kind]()
ok, err = seq.check_timing()
if not ok:
    print('timing check failed:', err[:5]); sys.exit(1)
seq.write(a.out)
print(f'{a.out}: {len(seq.block_events):,} blocks, {sum(seq.block_durations.values()):.2f} s')

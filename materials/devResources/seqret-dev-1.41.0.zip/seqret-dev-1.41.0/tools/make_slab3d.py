"""Slab-selective 3D spoiled gradient echo, with every block rotated about one axis (pp.rotate), for testing the image
plane of 3D scans: the simulated image must lie in the readout / phase-encoding plane, never along the slab normal.

    python3 tools/make_slab3d.py ANGLE_DEG AXIS OUT.seq [--matrix 16] [--partitions 4]

tests/data/slab3d_16x4_rot20x.seq:  python3 tools/make_slab3d.py 20 x tests/data/slab3d_16x4_rot20x.seq
Partitions are 3 mm thick, FOV 220 mm. Needs PyPulseq (pip install pypulseq)."""
import argparse, math, pypulseq as pp
ap = argparse.ArgumentParser(); ap.add_argument('angle', type=float); ap.add_argument('axis', choices=['x', 'y', 'z']); ap.add_argument('out')
ap.add_argument('--matrix', type=int, default=16); ap.add_argument('--partitions', type=int, default=4); a = ap.parse_args()
ang, axis, out, N, P, thk, fov = a.angle, a.axis, a.out, a.matrix, a.partitions, 3e-3, 220e-3
sy = pp.Opts(max_grad=32, grad_unit='mT/m', max_slew=130, slew_unit='T/m/s', rf_ringdown_time=20e-6, rf_dead_time=100e-6, adc_dead_time=10e-6)
seq = pp.Sequence(sy); slab = thk * P
rf, gz, gzr = pp.make_sinc_pulse(flip_angle=math.radians(10), duration=1e-3, slice_thickness=slab, apodization=0.5, time_bw_product=2, delay=sy.rf_dead_time, system=sy, return_gz=True, use='excitation')
dk, dkz = 1 / fov, 1 / slab
gx = pp.make_trapezoid('x', flat_area=N * dk, flat_time=N * 20e-6, system=sy); adc = pp.make_adc(N, duration=gx.flat_time, delay=gx.rise_time, system=sy)
gxp = pp.make_trapezoid('x', area=-gx.area / 2, duration=1e-3, system=sy); gxs = pp.make_trapezoid('x', area=2 * N * dk, system=sy)
R = lambda *ev: pp.rotate(*ev, angle=math.radians(ang), axis=axis, system=sy) if ang else ev
for p in range(P):
  for i in range(N):
    gy = pp.make_trapezoid('y', area=(i - N / 2) * dk, duration=1e-3, system=sy)
    gzp = pp.make_trapezoid('z', area=(p - P / 2) * dkz + gzr.area, duration=1e-3, system=sy)
    seq.add_block(*R(rf, gz)); seq.add_block(*R(gxp, gy, gzp)); seq.add_block(*R(gx, adc)); seq.add_block(*R(gxs, pp.scale_grad(gy, -1), pp.scale_grad(gzp, -1)))
seq.set_definition('FOV', [fov, fov, slab]); seq.write(out)

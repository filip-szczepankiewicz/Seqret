# Claude Code

Read AGENTS.md (working rules) and DEVELOPMENT.md (architecture, performance, validation) before making changes.

function out = seqret(src, varargin)
% SEQRET  Open a Pulseq sequence in the Seqret viewer (MATLAB and Octave).
%
%   seqret('scan.seq')          open a .seq file
%   seqret(seq)                 open an mr.Sequence object (written to a temporary .seq first)
%   seqret(..., 'html', p)      use the viewer page at p (default: seqret.html next to this file,
%                               or ../dist/seqret.html in the development tree)
%   seqret(..., 'open', false)  only write the page, do not open a browser
%   f = seqret(...)             returns the path of the page that was written
%
% Seqret runs entirely in the browser; nothing is uploaded. This helper writes a copy of the page with
% the sequence embedded (base64, in a <script type="text/plain" id="autoSeq"> element before </body>),
% which the page loads on start. Files embedded this way have no Reload; open the file from the page
% (Open .seq) in Chrome or Edge to get a Reload that follows changes on disk.

p = inputParser;
addParameter(p, 'html', '');
addParameter(p, 'open', true);
parse(p, varargin{:});
opt = p.Results;

% the sequence as bytes
if ischar(src) || (exist('isstring', 'builtin') && isstring(src))
    fn = char(src);
    if ~exist(fn, 'file'), error('seqret:notFound', 'File not found: %s', fn); end
    [~, nm, ex] = fileparts(fn); name = [nm ex];
elseif isobject(src) && ismethod(src, 'write')
    fn = [tempname '.seq'];
    src.write(fn);
    name = 'sequence.seq';
    try, n = src.getDefinition('Name'); if ischar(n) && ~isempty(n), name = [n '.seq']; end, catch, end
else
    error('seqret:input', 'Input must be a .seq file name or an mr.Sequence object.');
end
fid = fopen(fn, 'r'); bytes = fread(fid, Inf, '*uint8')'; fclose(fid);

% the viewer page
here = fileparts(mfilename('fullpath'));
html = opt.html;
if isempty(html)
    cands = {fullfile(here, 'seqret.html'), fullfile(here, '..', 'dist', 'seqret.html')};
    for k = 1:numel(cands), if exist(cands{k}, 'file'), html = cands{k}; break; end, end
end
if isempty(html) || ~exist(html, 'file')
    error('seqret:noPage', 'seqret.html not found. Put it next to seqret.m or pass ''html'', path.');
end
fid = fopen(html, 'r', 'n', 'UTF-8'); page = fread(fid, Inf, '*char')'; fclose(fid);
k = strfind(page, '</body>');
if isempty(k), error('seqret:page', 'Not a Seqret page (no </body>): %s', html); end
k = k(end);

% embed: base64 in lines of 76 characters
b64 = local_base64(bytes);
L = 76; n = numel(b64); rows = ceil(n / L);
b64(end+1:rows*L) = ' ';
b64 = [reshape(b64, L, rows); repmat(char(10), 1, rows)];
b64 = strtrim(b64(:)');
safe = strrep(strrep(strrep(name, '&', '&amp;'), '"', '&quot;'), '<', '&lt;');
tag = sprintf('<script type="text/plain" id="autoSeq" data-name="%s">\n%s\n</script>\n', safe, b64);
page = [page(1:k-1) tag page(k:end)];

outFile = [tempname '_seqret.html'];
fid = fopen(outFile, 'w', 'n', 'UTF-8'); fwrite(fid, page, 'char'); fclose(fid);

if opt.open, local_open(outFile); end
if nargout, out = outFile; end
end

function s = local_base64(b)
% base64 of a uint8 row vector (RFC 4648), without toolboxes; the same in MATLAB and Octave
tbl = ['A':'Z' 'a':'z' '0':'9' '+/'];
b = double(b(:)'); n = numel(b); pad = mod(3 - mod(n, 3), 3);
b = [b zeros(1, pad)];
t = reshape(b, 3, []);
v = t(1,:) * 65536 + t(2,:) * 256 + t(3,:);
q = [floor(v / 262144); mod(floor(v / 4096), 64); mod(floor(v / 64), 64); mod(v, 64)];
s = tbl(q(:)' + 1);
if pad, s(end-pad+1:end) = '='; end
end

function local_open(f)
url = ['file://' strrep(f, '\', '/')];
if ispc, url = ['file:///' strrep(f, '\', '/')]; end
if exist('OCTAVE_VERSION', 'builtin')
    if ispc, system(['start "" "' f '"']);
    elseif ismac, system(['open "' f '"']);
    else, system(['xdg-open "' f '" >/dev/null 2>&1 &']);
    end
else
    web(url, '-browser');
end
end

/* ===== image simulation on the graphics card (WebGL2 fragment shaders as compute kernels) =====
   Kernels: evalPoints (the phantom at points), directSum (exact inverse Fourier sum), bubbleDirect (the air
   bubble near the sphere). Inputs go in RGBA32F textures, one output value per pixel of an RGBA32F render
   target, read back as floats. Long sums run in several passes, accumulated in double precision here. */
const SIMGL = (() => {
  let G = null; // state, or false when unavailable
  const HDR = `#version 300 es
precision highp float; precision highp int; precision highp sampler2D;
out vec4 o;
ivec2 at(int i, int w) { return ivec2(i % w, i / w); }
const float PI = 3.14159265358979;
`;
  // Bessel J1 (Abramowitz & Stegun 9.4.4 / 9.4.6: accurate in single precision)
  const J1 = `float J1(float x) { float ax = abs(x);
  if (ax <= 3.0) { float y = (x / 3.0) * (x / 3.0);
    return x * (0.5 + y * (-0.56249985 + y * (0.21093573 + y * (-0.03954289 + y * (0.00443319 + y * (-0.00031761 + y * 0.00001109)))))); }
  float z = 3.0 / ax, f = 0.79788456 + z * (0.00000156 + z * (0.01659667 + z * (0.00017105 + z * (-0.00249511 + z * (0.00113653 + z * -0.00020033)))));
  float th = ax - 2.35619449 + z * (0.12499612 + z * (0.00005650 + z * (-0.00637879 + z * (0.00074348 + z * (0.00079824 + z * -0.00029166)))));
  float r = f * cos(th) / sqrt(ax); return x < 0.0 ? -r : r; }
float sincPi(float x) { if (abs(x) < 1e-6) return 1.0; float p = PI * x; return sin(p) / p; }
`;
  const FS_EVAL = HDR + J1 + `
uniform sampler2D uPts, uSi, uReg, uShot; uniform int uN, uW, uNR, uNT, uT2on, uFatOn;
uniform float uT2[16], uFatHz[6], uFatAmp[6], uT2P, uFatT2;
void main() {
  int idx = int(gl_FragCoord.y) * uW + int(gl_FragCoord.x); if (idx >= uN) { o = vec4(0.0); return; }
  vec4 p = texelFetch(uPts, at(idx, uW), 0); float kx = p.x, ky = p.y, ts = p.z, tau = p.w;
  int si = int(texelFetch(uSi, at(idx, uW), 0).x + 0.5);
  float e2p = exp(-abs(tau) / uT2P), fr = 1.0, fi = 0.0;
  if (uFatOn == 1) { fr = 0.0; for (int q = 0; q < 6; q++) { float a = -2.0 * PI * uFatHz[q] * tau; fr += uFatAmp[q] * cos(a); fi += uFatAmp[q] * sin(a); } }
  float ef = uT2on == 1 ? exp(-ts / uFatT2) * e2p : 1.0;
  vec2 S[16];
  for (int i = 0; i < 16; i++) { if (i >= uNT) break; vec4 w = texelFetch(uShot, ivec2(i, si), 0); float ew = uT2on == 1 ? exp(-ts / uT2[i]) * e2p : 1.0;
    S[i] = vec2(w.x * ew + w.y * ef * fr, w.y * ef * fi); }
  float re = 0.0, im = 0.0;
  for (int r = 0; r < 4096; r++) { if (r >= uNR) break;
    vec4 g = texelFetch(uReg, ivec2(0, r), 0), h = texelFetch(uReg, ivec2(1, r), 0), q2 = texelFetch(uReg, ivec2(2, r), 0);
    int own = int(q2.x + 0.5), par = int(q2.y + 0.5) - 1;
    vec2 d = S[own] - (par >= 0 ? S[par] : vec2(0.0)); d *= h.z; if (d.x == 0.0 && d.y == 0.0) continue;
    float u = kx * h.x + ky * h.y, v = -kx * h.y + ky * h.x, A;
    if (h.w < 0.5) { float kap = length(vec2(g.z * u, g.w * v)); A = kap < 1e-9 ? PI * g.z * g.w : g.z * g.w * J1(2.0 * PI * kap) / kap; }
    else A = g.z * g.w * sincPi(g.z * u) * sincPi(g.w * v);
    float ph = -2.0 * PI * (kx * g.x + ky * g.y), cr = cos(ph) * A, ci = sin(ph) * A;
    re += d.x * cr - d.y * ci; im += d.x * ci + d.y * cr; }
  o = vec4(re, im, 0.0, 0.0);
}`;
  const FS_DIRECT = HDR + `
uniform sampler2D uS; uniform int uNx, uNy, uS0, uS1, uSW; uniform float uPx, uPy;
void main() {
  int i = int(gl_FragCoord.x), j = int(gl_FragCoord.y); if (i >= uNx || j >= uNy) { o = vec4(0.0); return; }
  float x = float(i - uNx / 2) * uPx, y = float(j - uNy / 2) * uPy, re = 0.0, im = 0.0;
  for (int q = uS0; q < uS1; q++) { vec4 s = texelFetch(uS, at(q, uSW), 0);
    // phase in cycles, reduced before multiplying by 2π (keeps single precision at large k·x)
    float c = fract(s.x * x + s.y * y) * 2.0 * PI, cr = cos(c), ci = sin(c);
    re += s.z * cr - s.w * ci; im += s.z * ci + s.w * cr; }
  o = vec4(re, im, 0.0, 0.0);
}`;
  const FS_BUBBLE = HDR + `
uniform sampler2D uQ, uNode, uTS; uniform int uN, uW, uN0, uN1, uNW, uNT, uTW;
void main() {
  int idx = int(gl_FragCoord.y) * uW + int(gl_FragCoord.x); if (idx >= uN) { o = vec4(0.0); return; }
  vec4 s = texelFetch(uQ, at(idx, uW), 0); float kx = s.x, ky = s.y, tau = s.z, re = 0.0, im = 0.0;
  for (int k = uN0; k < uN1; k++) {
    vec4 nd = texelFetch(uNode, at(2 * k, uNW), 0), nd2 = texelFetch(uNode, at(2 * k + 1, uNW), 0);
    int ti = int(nd2.x + 0.5); vec2 S = texelFetch(uTS, at(idx * uNT + ti, uTW), 0).xy * nd.w;
    float a = -2.0 * PI * fract(nd.z * tau), er = cos(a) - 1.0, ei = sin(a);      // e^{-i2πΔfτ} − 1
    float p = -2.0 * PI * fract(kx * nd.x + ky * nd.y), cr = cos(p), ci = sin(p);  // e^{-i2πk·r}
    float xr = S.x * er - S.y * ei, xi = S.x * ei + S.y * er;
    re += xr * cr - xi * ci; im += xr * ci + xi * cr; }
  o = vec4(re, im, 0.0, 0.0);
}`;
  function init() {
    if (G !== null) return G;
    try {
      const cv = document.createElement('canvas'), gl = cv.getContext('webgl2', { antialias: false });
      if (!gl || !gl.getExtension('EXT_color_buffer_float')) return (G = false);
      const dbg = gl.getExtension('WEBGL_debug_renderer_info'), renderer = String(dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
      if (/swiftshader|llvmpipe|softpipe|software|basic render/i.test(renderer) && !window.__simgl) { console.info('Image simulation: software WebGL (' + renderer + '), using the CPU'); return (G = false); }
      const sh = (type, src) => { const x = gl.createShader(type); gl.shaderSource(x, src); gl.compileShader(x); if (!gl.getShaderParameter(x, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(x)); return x; };
      const vs = '#version 300 es\nin vec2 p; void main() { gl_Position = vec4(p, 0.0, 1.0); }';
      const prog = fs => { const p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p)); return p; };
      const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      const P = { evalPoints: prog(FS_EVAL), directSum: prog(FS_DIRECT), bubbleDirect: prog(FS_BUBBLE) };
      for (const p of Object.values(P)) { const l = gl.getAttribLocation(p, 'p'); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, 2, gl.FLOAT, false, 0, 0); }
      const maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE);
      return (G = { gl, P, maxTex, renderer, fbo: gl.createFramebuffer() });
    } catch (e) { console.warn('Image simulation: WebGL2 unavailable, using the CPU', e); return (G = false); }
  }
  // helpers: an RGBA32F texture from packed floats (width w), a render into an RGBA32F target, read back
  function tex(data, w, h) {
    const gl = G.gl, t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    const full = new Float32Array(w * h * 4); full.set(data.subarray ? data.subarray(0, Math.min(data.length, full.length)) : data);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, w, h, 0, gl.RGBA, gl.FLOAT, full); return t;
  }
  function layout(n) { const w = Math.min(Math.max(1, n), 2048); return [w, Math.max(1, Math.ceil(n / w))]; }
  function render(prog, w, h, bind) {
    const gl = G.gl; gl.useProgram(prog);
    const out = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, out); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, w, h, 0, gl.RGBA, gl.FLOAT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.bindFramebuffer(gl.FRAMEBUFFER, G.fbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, out, 0);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('float render target not supported');
    gl.viewport(0, 0, w, h); bind(gl, prog); gl.drawArrays(gl.TRIANGLES, 0, 3);
    const px = new Float32Array(w * h * 4); gl.readPixels(0, 0, w, h, gl.RGBA, gl.FLOAT, px);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.deleteTexture(out); return px;
  }
  function bindTex(gl, prog, name, t, unit) { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t); gl.uniform1i(gl.getUniformLocation(prog, name), unit); }
  const U = (gl, p, n) => gl.getUniformLocation(p, n);
  const tasks = {
    evalPoints(a) {
      const m = a.m, n = a.kx.length, [w, h] = layout(n), gl = G.gl, nt = m.tis.length, nr = m.regions.length;
      if (nt > 16 || nr > 4096) throw new Error('phantom too large for the GPU kernel');
      const pts = new Float32Array(w * h * 4), si = new Float32Array(w * h * 4);
      for (let i = 0; i < n; i++) { pts[4 * i] = a.kx[i]; pts[4 * i + 1] = a.ky[i]; pts[4 * i + 2] = a.t[i] - m.infos[a.si[i]].tE; pts[4 * i + 3] = a.tau[i]; si[4 * i] = a.si[i]; }
      const reg = new Float32Array(3 * nr * 4);
      m.regions.forEach((r, k) => { reg.set([r.x0, r.y0, r.a, r.b], 12 * k); reg.set([r.c, r.s, r.w, r.type === 'ell' ? 0 : 1], 12 * k + 4); reg.set([m.rOwn[k], m.rPar[k] + 1, 0, 0], 12 * k + 8); });
      const ns = m.infos.length, shot = new Float32Array(nt * ns * 4);
      m.infos.forEach((inf, s) => m.tis.forEach((tn, i) => { const ww = inf.w[tn]; shot[4 * (s * nt + i)] = ww[0]; shot[4 * (s * nt + i) + 1] = ww[1]; }));
      if (ns > G.maxTex) throw new Error('too many shots for the GPU kernel');
      const tP = tex(pts, w, h), tS = tex(si, w, h), tR = tex(reg, 3, nr), tSh = tex(shot, nt, ns);
      const px = render(G.P.evalPoints, w, h, (gl, p) => {
        bindTex(gl, p, 'uPts', tP, 0); bindTex(gl, p, 'uSi', tS, 1); bindTex(gl, p, 'uReg', tR, 2); bindTex(gl, p, 'uShot', tSh, 3);
        gl.uniform1i(U(gl, p, 'uN'), n); gl.uniform1i(U(gl, p, 'uW'), w); gl.uniform1i(U(gl, p, 'uNR'), nr); gl.uniform1i(U(gl, p, 'uNT'), nt);
        gl.uniform1i(U(gl, p, 'uT2on'), m.opt.t2 ? 1 : 0); gl.uniform1i(U(gl, p, 'uFatOn'), m.opt.fatShift ? 1 : 0);
        const t2 = new Float32Array(16); m.T2.forEach((v, i) => t2[i] = v); gl.uniform1fv(U(gl, p, 'uT2'), t2);
        gl.uniform1fv(U(gl, p, 'uFatHz'), new Float32Array(m.fat)); gl.uniform1fv(U(gl, p, 'uFatAmp'), new Float32Array(m.fatAmp));
        gl.uniform1f(U(gl, p, 'uT2P'), m.T2P); gl.uniform1f(U(gl, p, 'uFatT2'), m.FAT_T2);
      });
      for (const t of [tP, tS, tR, tSh]) gl.deleteTexture(t);
      const re = new Float64Array(n), im = new Float64Array(n); for (let i = 0; i < n; i++) { re[i] = px[4 * i]; im[i] = px[4 * i + 1]; }
      return { re, im };
    },
    directSum(a) {
      const n = a.kx.length, [w, h] = layout(n), gl = G.gl, { Nx, Ny } = a;
      const smp = new Float32Array(w * h * 4); for (let q = 0; q < n; q++) { smp[4 * q] = a.kx[q]; smp[4 * q + 1] = a.ky[q]; smp[4 * q + 2] = a.sr[q]; smp[4 * q + 3] = a.si[q]; }
      const tS = tex(smp, w, h), xr = new Float64Array(Nx * Ny), xi = new Float64Array(Nx * Ny), chunk = Math.max(64, Math.floor(4e6 / (Nx * Ny)));
      for (let s0 = 0; s0 < n; s0 += chunk) {
        const px = render(G.P.directSum, Nx, Ny, (gl, p) => { bindTex(gl, p, 'uS', tS, 0); gl.uniform1i(U(gl, p, 'uNx'), Nx); gl.uniform1i(U(gl, p, 'uNy'), Ny); gl.uniform1i(U(gl, p, 'uS0'), s0); gl.uniform1i(U(gl, p, 'uS1'), Math.min(n, s0 + chunk)); gl.uniform1i(U(gl, p, 'uSW'), w); gl.uniform1f(U(gl, p, 'uPx'), a.px); gl.uniform1f(U(gl, p, 'uPy'), a.py); });
        for (let o = 0; o < Nx * Ny; o++) { xr[o] += px[4 * o]; xi[o] += px[4 * o + 1]; }
      }
      gl.deleteTexture(tS); return { xr, xi };
    },
    bubbleDirect(a) {
      const n = a.kx.length, N = a.df.length, [w, h] = layout(n), gl = G.gl, nt = a.TR.length;
      const q = new Float32Array(w * h * 4); for (let i = 0; i < n; i++) { q[4 * i] = a.kx[i]; q[4 * i + 1] = a.ky[i]; q[4 * i + 2] = a.tau[i]; }
      const [nw, nh] = layout(2 * N), nd = new Float32Array(nw * nh * 4);
      for (let k = 0; k < N; k++) { nd.set([a.x0 + a.pi[k] * a.h, a.y0 + a.pj[k] * a.h, a.df[k], a.w[k]], 8 * k); nd[8 * k + 4] = a.ti[k]; }
      const [tw, th] = layout(n * nt), ts = new Float32Array(tw * th * 4);
      for (let i = 0; i < n; i++) for (let t = 0; t < nt; t++) { ts[4 * (i * nt + t)] = a.TR[t][i]; ts[4 * (i * nt + t) + 1] = a.TI[t][i]; }
      const tQ = tex(q, w, h), tN = tex(nd, nw, nh), tT = tex(ts, tw, th), dR = new Float64Array(n), dI = new Float64Array(n), chunk = Math.max(64, Math.floor(2e7 / Math.max(1, n)));
      for (let n0 = 0; n0 < N; n0 += chunk) {
        const px = render(G.P.bubbleDirect, w, h, (gl, p) => { bindTex(gl, p, 'uQ', tQ, 0); bindTex(gl, p, 'uNode', tN, 1); bindTex(gl, p, 'uTS', tT, 2);
          gl.uniform1i(U(gl, p, 'uN'), n); gl.uniform1i(U(gl, p, 'uW'), w); gl.uniform1i(U(gl, p, 'uN0'), n0); gl.uniform1i(U(gl, p, 'uN1'), Math.min(N, n0 + chunk));
          gl.uniform1i(U(gl, p, 'uNW'), nw); gl.uniform1i(U(gl, p, 'uNT'), nt); gl.uniform1i(U(gl, p, 'uTW'), tw); });
        for (let i = 0; i < n; i++) { dR[i] += px[4 * i]; dI[i] += px[4 * i + 1]; }
      }
      for (let i = 0; i < n; i++) { const box = sincPi(a.kx[i] * a.h) * sincPi(a.ky[i] * a.h); dR[i] *= a.area * box; dI[i] *= a.area * box; }
      for (const t of [tQ, tN, tT]) gl.deleteTexture(t);
      return { dR, dI };
    }
  };
  const run = (task, a) => { if (!init()) throw new Error('no GPU'); return tasks[task](a); };
  run.has = task => task in tasks;
  return { available: () => !!init(), run, info: () => (G ? G.renderer : null) };
})();

/* ===== Seqret image simulation =====
   Forward model for every imaging ADC sample j of a chosen image (one slice of one volume):

     s_j = Σ_regions A_r(k_j) e^{-i2π k_j·r_r} [ S_tissue(r)(j) − S_parent(r)(j) ]  +  bubble correction

   A_r: closed-form 2D Fourier transform of an ellipse (Bessel J1) or rectangle (sinc), from the
   analytic phantom. S_tissue(j): complex signal density of a tissue at that sample,

     S = PD·sinα·[ (1−ff)·Mz_w·e^{−t/T2w} + ff·Mz_f·e^{−t/T2f}·Σ_p a_p e^{−i2π f_p τ} ]·e^{−|τ|/T2′}·e^{−b·ADC}

   t = time since the excitation, τ = dephasing time (runs forward, flips sign at each refocusing
   pulse; 0 at a spin echo). Off-resonance (fat peaks, air-bubble field) acts through τ.
   Mz: steady state for the flip angle and the time between excitations of the same slice,
   inversion recovery for inversion pulses, frequency-selective saturation from the saturation
   pulse's small-tip frequency response. b: from the gradient waveform of the shot,
   (2π)² ∫ k(t)ᵀk(t) dt from excitation to the echo. No spin history beyond this.
   The image plane is spanned by the readout direction and the largest k-space spread perpendicular to it
   (never the slab normal of a slab-selective 3D scan); k along the third axis is ignored (the object is a
   thin sheet, one partition for 3D). Units: mm, s, Hz. */

const SIM_GBAR = 42.577478e6;
const FAT6 = { ppm: [-3.80, -3.40, -2.60, -1.94, -0.39, 0.60], amp: [0.087, 0.693, 0.128, 0.004, 0.039, 0.048] };
{ const s = FAT6.amp.reduce((a, b) => a + b, 0); FAT6.amp = FAT6.amp.map(a => a / s); }

// approximate values at 3 T (T1, T2, T2′ in s; ADC in mm²/s; ff = fat fraction)
const TISSUES = {
  air:    { pd: 0,    ff: 0,   T1: 1,    T2: 1,     adc: 0 },
  fat:    { pd: 0.9,  ff: 1,   T1: 0.38, T2: 0.08,  adc: 0.01e-3 },
  wm:     { pd: 0.70, ff: 0,   T1: 0.83, T2: 0.08,  adc: 0.70e-3 },
  gm:     { pd: 0.80, ff: 0,   T1: 1.33, T2: 0.11,  adc: 0.80e-3 },
  csf:    { pd: 1.00, ff: 0,   T1: 4.0,  T2: 2.0,   adc: 3.0e-3 },
  lesion: { pd: 0.85, ff: 0,   T1: 1.6,  T2: 0.20,  adc: 1.4e-3 },
  blood:  { pd: 0.85, ff: 0,   T1: 1.65, T2: 0.15,  adc: 1.6e-3 },
  muscle: { pd: 0.75, ff: 0,   T1: 1.40, T2: 0.05,  adc: 1.5e-3 },
  liver:  { pd: 0.80, ff: 0.1, T1: 0.80, T2: 0.04,  adc: 1.1e-3 },
  kidney: { pd: 0.85, ff: 0,   T1: 1.20, T2: 0.07,  adc: 2.0e-3 },
  fluid:  { pd: 1.00, ff: 0,   T1: 3.0,  T2: 1.0,   adc: 2.5e-3 },
  marrow: { pd: 0.90, ff: 0.6, T1: 0.50, T2: 0.06,  adc: 0.3e-3 }
};
const T2P = 0.067;         // reversible dephasing time constant T2′ (s), all tissues
const FAT_T1 = 0.38, FAT_T2 = 0.08;

function bessj1(x) { // Numerical Recipes rational approximation, |error| < 1e-7
  const ax = Math.abs(x);
  if (ax < 8) {
    const y = x * x;
    const a1 = x * (72362614232.0 + y * (-7895059235.0 + y * (242396853.1 + y * (-2972611.439 + y * (15704.48260 + y * (-30.16036606))))));
    const a2 = 144725228442.0 + y * (2300535178.0 + y * (18583304.74 + y * (99447.43394 + y * (376.9991397 + y))));
    return a1 / a2;
  }
  const z = 8 / ax, y = z * z, xx = ax - 2.356194491;
  const b1 = 1.0 + y * (0.183105e-2 + y * (-0.3516396496e-4 + y * (0.2457520174e-5 + y * (-0.240337019e-6))));
  const b2 = 0.04687499995 + y * (-0.2002690873e-3 + y * (0.8449199096e-5 + y * (-0.88228987e-6 + y * 0.105787412e-6)));
  const r = Math.sqrt(0.636619772 / ax) * (Math.cos(xx) * b1 - z * Math.sin(xx) * b2);
  return x < 0 ? -r : r;
}
function sincPi(x) { if (Math.abs(x) < 1e-12) return 1; const p = Math.PI * x; return Math.sin(p) / p; }

/* ---------- 3D phantoms (mm; x = patient left, y = anterior, z = superior; B0 along z) ----------
   Each region: ellipsoid (centre, semi-axes, Euler angles φ θ ψ in degrees), tissue, parent. */
const SIM_PHANTOMS3D = {
  head: {
    bubble: { c: [-50, 42, 0], r: 7 },
    regions() { // 3D Shepp–Logan geometry (Kak & Slaney), scaled to 110 mm
      const s = 110, E = (x, y, z, a, b, c, phi, th, psi) => ({ c: [x * s, y * s, z * s], ax: [a * s, b * s, c * s], eul: [phi || 0, th || 0, psi || 0] });
      return [
        [E(0, 0, 0, 0.69, 0.92, 0.81), 'fat', -1],
        [E(0, -0.0184, 0, 0.6624, 0.874, 0.78), 'wm', 0],
        [E(0.22, 0, 0, 0.11, 0.31, 0.22, -18, 0, 10), 'csf', 1],
        [E(-0.22, 0, 0, 0.16, 0.41, 0.28, 18, 0, 10), 'csf', 1],
        [E(0, 0.35, -0.15, 0.21, 0.25, 0.41), 'gm', 1],
        [E(0, 0.1, 0.25, 0.046, 0.046, 0.05), 'lesion', 1],
        [E(0, -0.1, 0.25, 0.046, 0.046, 0.05), 'lesion', 1],
        [E(-0.08, -0.605, 0, 0.046, 0.023, 0.05), 'gm', 1],
        [E(0, -0.606, 0, 0.023, 0.023, 0.02), 'gm', 1],
        [E(0.06, -0.605, 0, 0.023, 0.046, 0.02), 'gm', 1],
        [{ c: [0, -90, 0], ax: [4, 4, 60], eul: [0, 0, 0] }, 'blood', 1],
        // nose (anterior, below the centre) and neck (inferior, slightly posterior): shape cues for orientation
        // nose, neck and brainstem overlap the head; where top-level regions overlap, the later one wins
        [{ c: [0, 98, -34], ax: [11, 11, 18], eul: [0, 0, 0] }, 'muscle', -1, 0.05],
        [{ c: [0, -15, -94], ax: [42, 46, 18], eul: [0, 0, 0] }, 'muscle', -1, 0.012], // ends at −112 mm: stays inside a 220 mm FOV
        [{ c: [0, -14, -80], ax: [15, 17, 28], eul: [0, 0, 0] }, 'gm', -1, 0.03]
      ];
    }
  },
  abdomen: {
    bubble: { c: [58, 56, 45], r: 8 },
    regions() {
      const E = (x, y, z, a, b, c, phi) => ({ c: [x, y, z], ax: [a, b, c], eul: [phi || 0, 0, 0] });
      return [
        [E(0, 0, 0, 170, 120, 260), 'fat', -1],
        [E(0, -2, 0, 157, 107, 255), 'muscle', 0],
        [E(-60, 45, 20, 70, 40, 80, 15), 'liver', 1],
        [E(-48, 38, 5, 10, 14, 30, 20), 'fluid', 2],
        [E(58, 48, 40, 34, 24, 50, -10), 'fluid', 1],
        [E(75, -40, -30, 34, 42, 70, -20), 'fat', 1],
        [E(75, -40, -30, 22, 32, 55, -20), 'kidney', 5],
        [E(-75, -40, -40, 34, 42, 70, 20), 'fat', 1],
        [E(-75, -40, -40, 22, 32, 55, 20), 'kidney', 7],
        [E(0, -72, 0, 20, 15, 245), 'marrow', 1],
        [E(0, -96, 0, 8, 6, 245), 'csf', 1],
        [E(-22, -48, 0, 9, 9, 245), 'blood', 1]
      ];
    }
  }
};
function eulerA(eul) { // rotation used for the ellipsoid frames (as in the common phantom3d definition)
  const [f, t, p] = eul.map(d => d * Math.PI / 180), cf = Math.cos(f), sf = Math.sin(f), ct = Math.cos(t), st = Math.sin(t), cp = Math.cos(p), sp = Math.sin(p);
  return [[cp * cf - ct * sf * sp, cp * sf + ct * cf * sp, sp * st], [-sp * cf - ct * sf * cp, -sp * sf + ct * cf * cp, cp * st], [st * sf, -st * cf, ct]];
}
function build3D(key, bubble) {
  const P = SIM_PHANTOMS3D[key];
  const R = P.regions().map(([e, tissue, parent, vis]) => { // vis: optional density in the 3D view
    const A = eulerA(e.eul), Q = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]; // Q = Aᵀ diag(1/a²) A
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) for (let k = 0; k < 3; k++) Q[i][j] += A[k][i] * A[k][j] / (e.ax[k] * e.ax[k]);
    return { c: e.c, Q, tissue, parent, vis };
  });
  return { key, R, bubble: bubble ? P.bubble : null };
}
function inside3(r, p) { const d = [p[0] - r.c[0], p[1] - r.c[1], p[2] - r.c[2]]; let v = 0; for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) v += d[i] * r.Q[i][j] * d[j]; return v <= 1; }
function tissueAt3(P3, p) {
  if (P3.bubble) { const b = P3.bubble, d = Math.hypot(p[0] - b.c[0], p[1] - b.c[1], p[2] - b.c[2]); if (d < b.r) return 'air'; }
  let t = null; for (const r of P3.R) if (inside3(r, p)) t = r.tissue; return t;
}
const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const addS = (a, b, s) => [a[0] + s * b[0], a[1] + s * b[1], a[2] + s * b[2]];
/* ellipse where the plane o + u·e1 + v·e2 cuts the ellipsoid r (null if it misses) */
function sectionEllipse(r, o, e1, e2) {
  const d = [o[0] - r.c[0], o[1] - r.c[1], o[2] - r.c[2]], Qv = v => [0, 1, 2].map(i => r.Q[i][0] * v[0] + r.Q[i][1] * v[1] + r.Q[i][2] * v[2]);
  const Qe1 = Qv(e1), Qe2 = Qv(e2), Qd = Qv(d);
  const p = dot3(e1, Qe1), q = dot3(e1, Qe2), rr = dot3(e2, Qe2), b1 = dot3(e1, Qd), b2 = dot3(e2, Qd), c2 = dot3(d, Qd);
  const det = p * rr - q * q; if (det <= 1e-18) return null;
  const u0 = -(rr * b1 - q * b2) / det, v0 = -(-q * b1 + p * b2) / det;
  const m = 1 - c2 + (b1 * (rr * b1 - q * b2) + b2 * (-q * b1 + p * b2)) / det; if (m <= 0) return null;
  const th = 0.5 * Math.atan2(2 * q, p - rr), c = Math.cos(th), s = Math.sin(th);
  const la = (p * c * c + 2 * q * s * c + rr * s * s) / m, lb = (p * s * s - 2 * q * s * c + rr * c * c) / m;
  return { type: 'ell', x0: u0, y0: v0, a: 1 / Math.sqrt(la), b: 1 / Math.sqrt(lb), th, c, s };
}
/* the 2D phantom seen by one slice: sections at nd depths across the slice (weights 1/nd), plus the
   centre-plane sections for tissue look-ups and the bubble's circle in the plane */
function sectionPhantom(key, bubble, geom) {
  const P3 = build3D(key, bubble), regions = [], nd = geom.nd, probe = [], corr = [];
  const bbox = r => { const hx = Math.hypot(r.a * r.c, r.b * r.s), hy = Math.hypot(r.a * r.s, r.b * r.c); r.bx0 = r.x0 - hx; r.bx1 = r.x0 + hx; r.by0 = r.y0 - hy; r.by1 = r.y0 + hy; };
  for (let j = 0; j < nd; j++) {
    const off = nd > 1 ? ((j + 0.5) / nd - 0.5) * geom.thick : 0, o = addS(geom.o, geom.n, off), base = regions.length, idx = new Map();
    P3.R.forEach((r, i) => {
      const e = sectionEllipse(r, o, geom.e1, geom.e2); if (!e) return;
      const par = r.parent >= 0 && idx.has(r.parent) ? idx.get(r.parent) : -1;
      Object.assign(e, { tissue: r.tissue, parent: par, w: 1 / nd }); bbox(e); idx.set(i, regions.length); regions.push(e);
    });
    if (P3.bubble) { // the air sphere's section, inside whichever region holds its centre
      const b = P3.bubble, dist = dot3([b.c[0] - o[0], b.c[1] - o[1], b.c[2] - o[2]], geom.n);
      if (Math.abs(dist) < b.r) {
        const rr = Math.sqrt(b.r * b.r - dist * dist), rel = [b.c[0] - o[0], b.c[1] - o[1], b.c[2] - o[2]], u = dot3(rel, geom.e1), v = dot3(rel, geom.e2);
        let par = -1; for (let i = base; i < regions.length; i++) if (inside(regions[i], u, v)) par = i;
        const e = { type: 'ell', x0: u, y0: v, a: rr, b: rr, th: 0, c: 1, s: 0, tissue: 'air', parent: par, w: 1 / nd }; bbox(e); regions.push(e);
      }
    }
    if (j === Math.floor(nd / 2)) for (let i = base; i < regions.length; i++) probe.push(regions[i]);
    overlapPatches(regions, base, 1 / nd, geom.hc || 0.5, corr);
  }
  const ph = { key, regions, probe, P3, geom, bubble: null, corr };
  if (P3.bubble) { // circle in the centre plane (radius 0 when the plane misses the sphere)
    const b = P3.bubble, rel = [b.c[0] - geom.o[0], b.c[1] - geom.o[1], b.c[2] - geom.o[2]], dist = dot3(rel, geom.n);
    ph.bubble = { x: dot3(rel, geom.e1), y: dot3(rel, geom.e2), r: Math.sqrt(Math.max(0, b.r * b.r - dist * dist)), r3: b.r, d: dist, c3: b.c };
  }
  return ph;
}
/* Top-level regions may overlap; the later one wins. The additive model counts every containing tree,
   so on a patch lattice (spacing h) over each overlap, the signal of every tree except the last is
   subtracted: patch {x, y, tissue, w}. The tissue of a tree at a point is its deepest region there. */
function overlapPatches(regions, base, w, h, out) {
  const R = regions.slice(base), root = R.map((r, i) => { let k = i; while (R[k].parent >= base) k = R[k].parent - base; return k; });
  const roots = [...new Set(root)]; if (roots.length < 2) return;
  const rb = k => R[k];
  for (let a = 0; a < roots.length; a++) for (let b = a + 1; b < roots.length; b++) {
    const A = rb(roots[a]), B = rb(roots[b]);
    const x0 = Math.max(A.bx0, B.bx0), x1 = Math.min(A.bx1, B.bx1), y0 = Math.max(A.by0, B.by0), y1 = Math.min(A.by1, B.by1);
    if (x0 >= x1 || y0 >= y1) continue;
    let hh = h; while ((x1 - x0) * (y1 - y0) / (hh * hh) > 4e4) hh *= 1.25; // bounded work
    for (let y = y0 + hh / 2; y < y1; y += hh) for (let x = x0 + hh / 2; x < x1; x += hh) {
      if (!inside(A, x, y) || !inside(B, x, y)) continue;
      // trees containing the point; all but the last one are subtracted (each pair is visited once: only the pair's earlier root)
      let last = -1; for (const rt of roots) if (inside(rb(rt), x, y)) last = rt;
      if (roots[a] === last) continue;
      // is roots[a] the earlier member of this point's containing set, counted once? subtract it only for the pair with the last tree
      if (roots[b] !== last) continue;
      let tn = null; for (let i = 0; i < R.length; i++) if (root[i] === roots[a] && inside(R[i], x, y)) tn = R[i].tissue;
      if (tn && tn !== 'air') out.push({ x, y, tissue: tn, w: -w * hh * hh, h: hh });
    }
  }
}
/* symmetric 3×3 eigen-decomposition (Jacobi) */
function eig3(A) {
  const a = A.map(r => r.slice()), V = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  for (let it = 0; it < 50; it++) {
    let p = 0, q = 1; for (const [i, j] of [[0, 1], [0, 2], [1, 2]]) if (Math.abs(a[i][j]) > Math.abs(a[p][q])) { p = i; q = j; }
    if (Math.abs(a[p][q]) < 1e-30) break;
    const th = 0.5 * Math.atan2(2 * a[p][q], a[q][q] - a[p][p]), c = Math.cos(th), s = Math.sin(th);
    for (let k = 0; k < 3; k++) { const x = a[k][p], y = a[k][q]; a[k][p] = c * x - s * y; a[k][q] = s * x + c * y; }
    for (let k = 0; k < 3; k++) { const x = a[p][k], y = a[q][k]; a[p][k] = c * x - s * y; a[q][k] = s * x + c * y; }
    for (let k = 0; k < 3; k++) { const x = V[k][p], y = V[k][q]; V[k][p] = c * x - s * y; V[k][q] = s * x + c * y; }
  }
  return [0, 1, 2].map(i => ({ val: a[i][i], vec: [V[0][i], V[1][i], V[2][i]] })).sort((x, y) => y.val - x.val);
}
// sequence axes → phantom axes, for "which sequence axis is head–foot"
const ORIENT_M = {
  ax: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],   // x → left, y → anterior, z → superior (axial slices)
  cor: [[1, 0, 0], [0, 0, 1], [0, 1, 0]],  // z → anterior (coronal), y → superior
  sag: [[0, 0, 1], [1, 0, 0], [0, 1, 0]]   // z → left (sagittal), x → anterior, y → superior
};
const mulM = (M, v) => [0, 1, 2].map(i => M[i][0] * v[0] + M[i][1] * v[1] + M[i][2] * v[2]);
function rfFWHM(seq, rfId) { // bandwidth (Hz) where the small-tip response falls to half
  const cache = seq.geo.fwhm || (seq.geo.fwhm = []); if (cache[rfId] !== undefined) return cache[rfId];
  let f = 0, step = 25; while (f < 2e5 && rfResponse(seq, rfId, f + step) > 0.5) { f += step; if (f > 20 * step) step *= 2; }
  let lo = f, hi = f + step; for (let i = 0; i < 30; i++) { const m = (lo + hi) / 2; if (rfResponse(seq, rfId, m) > 0.5) lo = m; else hi = m; }
  return (cache[rfId] = 2 * lo);
}
/* RF frequency in Hz including the Pulseq 1.5 ppm part: f = freq + freqPPM·1e-6·γ̄·B0 (the ppm part needs a field
   strength; the file does not store one, so the caller passes it) */
function rfFreqHz(r, B0) { return r ? r.freq + (r.freqPPM || 0) * 1e-6 * SIM_GBAR * (B0 || 0) : 0; }
const FAT_MAIN_PPM = FAT6.ppm[1]; // main methylene peak, relative to water
/* slice excited (or refocused, inverted, saturated) by the RF pulse of block b, in the sequence's physical axes.
   Pulseq convention: a pulse at frequency f with gradient G (Hz/m) selects the plane G·r = f, so the slice lies at
   s0 = f/|G| along n = G/|G|, thickness = FWHM bandwidth/|G|. Uses the gradient at the pulse centre; gDev is the
   largest deviation of the gradient vector from that value while |B1| > 1 % of peak (ramp sampling, VERSE). */
function rfSlice(seq, b, B0) {
  const B = seq.B, r = seq.rf.get(B.rf[b]); if (!r) return null;
  const st = rfSt(seq, B.rf[b]), t0 = seq.blockStart[b], tc = t0 + st.center;
  const gAt = t => [channelValue(seq, 'gx', t), channelValue(seq, 'gy', t), channelValue(seq, 'gz', t)];
  const G = gAt(tc), Gm = Math.hypot(G[0], G[1], G[2]), f = rfFreqHz(r, B0);
  const out = { G, Gm, f, fPPM: f - r.freq, B0, bw: rfFWHM(seq, B.rf[b]), dur: st.dur, flip: st.flip, selective: Gm > 1e3, gDev: 0 };
  const s = rfSamples(seq, r), step = Math.max(1, Math.floor(s.t.length / 256));
  for (let i = 0; i < s.t.length; i += step) {
    if (Math.abs(s.mag[i]) < 0.01 * st.peak) continue;
    const g = gAt(t0 + s.t[i]), d = Math.hypot(g[0] - G[0], g[1] - G[1], g[2] - G[2]); if (d > out.gDev) out.gDev = d;
  }
  if (!out.selective) return out;
  out.n = G.map(x => x / Gm); out.s0 = f / Gm; out.pos = out.n.map(x => x * out.s0); out.thick = out.bw / Gm;
  out.fatShift = -FAT_MAIN_PPM * 1e-6 * SIM_GBAR * (B0 || 0) / Gm; // fat is excited where G·r + Δf_fat = f
  if (r.freqPPM) out.s0Species = r.freq / Gm; // where spins at the pulse's own ppm offset are selected
  return out;
}
/* inversion-recovery cycle for the inversion pulse in block bI: the pulses that act on the slice with excitation
   frequency fE until the next inversion (excitations at fE, refocusing pulses inside their shots), their times from
   the inversion and the inversion period P (null for a single inversion). Cached per inversion and frequency. */
function invCycle(seq, bI, fE, B0) {
  const cache = seq.geo.invc || (seq.geo.invc = new Map()), key = bI + '|' + Math.round(fE);
  let c = cache.get(key); if (c) return c;
  const B = seq.B, bs = seq.blockStart, LIM = 2e5, tOf = b => bs[b] + rfSt(seq, B.rf[b]).center;
  const isInv = b => B.rf[b] && rfSt(seq, B.rf[b]).use === 'i', tI = tOf(bI);
  let bN = -1, bP = -1;
  for (let b = bI + 1, n = 0; b < seq.nb && n < LIM; b++, n++) if (isInv(b)) { bN = b; break; }
  for (let b = bI - 1, n = 0; b >= 0 && n < LIM; b--, n++) if (isInv(b)) { bP = b; break; }
  const P = bN >= 0 ? tOf(bN) - tI : bP >= 0 ? tI - tOf(bP) : null;
  const t = [], fl = []; let inShot = false;
  for (let b = bI + 1, n = 0; b < seq.nb && n < LIM; b++, n++) {
    if (bN >= 0 ? b >= bN : P !== null && bs[b] >= tI + P) break;
    if (!B.rf[b]) continue; const st = rfSt(seq, B.rf[b]);
    if (st.use === 'e') { inShot = Math.abs(rfFreqHz(seq.rf.get(B.rf[b]), B0) - fE) < 1; if (!inShot) continue; }
    else if (st.use !== 'r' || !inShot) continue;
    t.push(tOf(b) - tI); fl.push(st.flip);
  }
  c = { P, t: Float64Array.from(t), fl: Float64Array.from(fl) }; cache.set(key, c); return c;
}
/* slice geometry of a shot, in phantom coordinates (mm) */
function sliceGeometry(seq, inf, e1s, e2s, e3s, k3, orient, fixedAt) {
  const B = seq.B, M = ORIENT_M[orient] || ORIENT_M.ax;
  const G = ['gx', 'gy', 'gz'].map(k => channelValue(seq, k, inf.tE)), Gm = Math.hypot(G[0], G[1], G[2]); // Hz/m at the RF centre
  let mode, nS, s0 = 0, thick, bw = rfFWHM(seq, B.rf[inf.exc]);
  if (Gm > 1e3) { nS = G.map(x => x / Gm); s0 = inf.freq / Gm * 1e3; thick = bw / Gm * 1e3; mode = 'slice'; }
  else { nS = e3s; mode = 'nonselective'; }
  if (k3 > 0) { // 3D encoding along the third axis: one partition at the slab centre
    thick = 1 / (2 * k3); mode = mode === 'slice' ? 'partition (slab-selective)' : 'partition';
  } else if (mode === 'nonselective') { thick = 240; }
  const n = mulM(M, nS), e1 = mulM(M, e1s), e2 = mulM(M, e2s);
  let fixed = false;
  if (fixedAt && mode !== 'nonselective') { s0 = dot3(n, fixedAt); fixed = true; } // one plane for all shots: through the given point
  const o = n.map(x => x * s0);
  const nd = mode === 'slice' ? 5 : mode === 'nonselective' ? 15 : 1;
  return { n, e1, e2, o, s0, thick, nd, mode, bw, G: Gm, M, fixed };
}
/* the slice plane of the image whose reference shot is ref, without simulating it (for showing the planes of other
   selected images in the 3D view): normal and position from the excitation pulse (rfSlice, as sliceGeometry), first
   in-plane axis along the readout (the direction k moves in the shot's first imaging ADC), second = normal × first.
   Phantom coordinates (mm), as sliceGeometry. Null for a non-selective excitation or a shot without readout. */
function imagePlaneQuick(seq, shots, ref, opt) {
  const sh = shots[ref], B = seq.B; if (!sh) return null;
  let exc = -1; for (let b = sh.b0; b <= sh.b1; b++) if (B.rf[b] && rfSt(seq, B.rf[b]).use === 'e') { exc = b; break; }
  if (exc < 0) return null;
  const rs = rfSlice(seq, exc, opt.B0); if (!rs || !rs.selective) return null;
  let j = -1; for (let q = sh.j0; q < sh.j1; q++) if (seq.adcType[q] === 0 || seq.adcType[q] === 2) { j = q; break; }
  if (j < 0) j = sh.j1 > sh.j0 ? sh.j0 : -1; if (j < 0) return null;
  const K = kSamples(seq, j, j + 1); if (K.n < 2) return null;
  const nS = rs.n, dk = [0, 1, 2].map(a => K.k[a][K.n - 1] - K.k[a][0]), dn = dot3(dk, nS);
  let e1s = dk.map((x, a) => x - dn * nS[a]); const L = Math.hypot(...e1s); if (L < 1e-9) return null; e1s = e1s.map(x => x / L);
  const e2s = [nS[1] * e1s[2] - nS[2] * e1s[1], nS[2] * e1s[0] - nS[0] * e1s[2], nS[0] * e1s[1] - nS[1] * e1s[0]];
  const M = ORIENT_M[opt.orient || 'ax'] || ORIENT_M.ax, n = mulM(M, nS), e1 = mulM(M, e1s), e2 = mulM(M, e2s);
  const s0 = opt.slicePos === false ? dot3(n, SIM_PHANTOMS3D[opt.phantom].bubble.c) : rs.s0 * 1e3;
  return { n, e1, e2, o: n.map(x => x * s0), s0, thick: rs.thick * 1e3, nS, e1s, e2s };
}
/* Phase-encoding lines of one image (the shots of vol that excite the slice of ref, as imageSet): every imaging ADC
   is one line at k·e2 (e2: perpendicular to the readout and the slice normal, from imagePlaneQuick). The line spacing
   Δk is 1/FOV along e2 when the definitions give it, otherwise the smallest spacing between the lines found (then an
   acceleration without fully sampled reference lines looks like a full acquisition of a smaller FOV; stated as from='data').
   Lines are numbered k/Δk. Full matrix N: twice the largest |line| reached (the readout matrix when the FOVs are
   equal and it is within the uncertainty that undersampling leaves at the edges). R: the most common gap between
   acquired lines outside the reference block; reference (ACS) lines: the run of neighbouring lines around k = 0 when
   R > 1; partial Fourier: the acquired extent over N, to the nearest 1/8, when one side is cut by more than R lines.
   Null for a non-selective excitation; { cart: false } when k moves across lines during an ADC (radial, spiral). */
function lineStats(seq, shots, vol, ref, opt) {
  const set = imageSet(seq, shots, vol, ref, opt.B0); if (!set) return null;
  const q = imagePlaneQuick(seq, shots, ref, opt); if (!q) return null;
  const pos = [], spread = [], ro = [], EC = set.useType(0) ? adcEchoes(seq, shots) : null, echo = opt.echo | 0; // one echo's image (adcEchoes)
  for (const inf of set.list) { const sh = shots[inf.k];
    for (let j = sh.j0; j < sh.j1; j++) { if (!set.useType(seq.adcType[j]) || (EC && EC[j] >= 0 && EC[j] !== echo)) continue;
      const K = kSamples(seq, j, j + 1); if (K.n < 2) continue; let mn = Infinity, mx = -Infinity, sm = 0, r0 = Infinity, r1 = -Infinity;
      for (let i = 0; i < K.n; i++) { const p = K.k[0][i] * q.e2s[0] + K.k[1][i] * q.e2s[1] + K.k[2][i] * q.e2s[2], r = K.k[0][i] * q.e1s[0] + K.k[1][i] * q.e1s[1] + K.k[2][i] * q.e1s[2];
        if (p < mn) mn = p; if (p > mx) mx = p; sm += p; if (r < r0) r0 = r; if (r > r1) r1 = r; }
      pos.push(sm / K.n); spread.push(mx - mn); ro.push([r1 - r0, K.n]); } }
  if (pos.length < 2) return null;
  const D = Array.isArray(seq.defs.FOV) ? seq.defs.FOV : null;
  const fovAlong = e => { if (!D || D.length < 2) return 0; let f = 0; for (let i = 0; i < 3; i++) { if (Math.abs(e[i]) < 1e-3) continue; const v = +D[i]; if (!(v > 0)) return 0; if (f && Math.abs(v - f) > 1e-6 * f) return 0; f = v; } return f; };
  const fPE = fovAlong(q.e2s), fRO = fovAlong(q.e1s);
  // distinct line positions (1/m), clustered within a small tolerance
  const sorted = Float64Array.from(pos).sort(), ext = sorted[sorted.length - 1] - sorted[0] || 1, tol = 1e-4 * ext + 1e-9;
  const lines = []; for (const p of sorted) if (!lines.length || p - lines[lines.length - 1] > tol) lines.push(p);
  let dk = fPE ? 1 / fPE : 0, from = fPE ? 'fov' : 'data';
  if (!dk) { let g = Infinity; for (let i = 1; i < lines.length; i++) g = Math.min(g, lines[i] - lines[i - 1]); dk = g < Infinity ? g : 0; }
  if (!(dk > 0)) return null;
  if (Math.max(...spread) > 0.25 * dk) return { cart: false, nADC: pos.length };
  const idx = [...new Set(lines.map(p => Math.round(p / dk)))].sort((a, b) => a - b), n = idx.length, lo = idx[0], hi = idx[n - 1];
  // gaps; the reference block: the run of gap-1 neighbours containing (or next to) line 0
  const gaps = []; for (let i = 1; i < n; i++) gaps.push(idx[i] - idx[i - 1]);
  let c = idx.findIndex(v => v >= 0); if (c < 0) c = n - 1; let a = c, b = c; while (a > 0 && idx[a] - idx[a - 1] === 1) a--; while (b < n - 1 && idx[b + 1] - idx[b] === 1) b++;
  const outer = []; for (let i = 1; i < n; i++) if (i <= a || i > b) outer.push(idx[i] - idx[i - 1]);
  const mode = arr => { const m = new Map(); for (const x of arr) m.set(x, (m.get(x) || 0) + 1); let best = 1, bn = 0; for (const [k, v] of m) if (v > bn || (v === bn && k < best)) { best = k; bn = v; } return best; };
  const R = outer.length ? mode(outer) : 1, run = b - a + 1, acs = R > 1 && run > R ? run : 0; // a lone line 0 is no reference block
  // full matrix
  const half = Math.max(-lo, hi + 1); let N = 2 * half;
  // readout matrix: K samples δk apart (δk = extent/(K−1)) give N = K·δk·FOV (oversampling: more, closer samples, same N)
  const roN = ro.map(([e, K]) => K > 1 ? K * e / (K - 1) : 0).sort((x, y) => x - y), nRO = fRO ? Math.round(roN[roN.length >> 1] * fRO) : 0;
  if (nRO && fRO === fPE && nRO >= N && nRO <= N + 2 * (R - 1)) N = nRO;
  const lost = Math.abs(-lo - (hi + 1)), pfFrac = lost > R ? Math.round((hi - lo + 1) / N * 8) / 8 : 1;
  return { cart: true, nLines: n, nADC: pos.length, N, lo, hi, R, acs, pf: pfFrac, pfSide: pfFrac < 1 ? (-lo < hi + 1 ? 'low' : 'high') : '', net: N / n, from, dk };
}
/* anatomical letter of a phantom direction */
function dirLetter(v) { const a = [Math.abs(v[0]), Math.abs(v[1]), Math.abs(v[2])], i = a.indexOf(Math.max(...a)); return [['R', 'L'], ['P', 'A'], ['I', 'S']][i][v[i] > 0 ? 1 : 0]; }
function planeName(n) { const a = n.map(Math.abs), i = a.indexOf(Math.max(...a)); return { name: ['sagittal', 'coronal', 'axial'][i], tilt: Math.acos(Math.min(1, a[i])) * 180 / Math.PI }; }

function inside(s, x, y) {
  const dx = x - s.x0, dy = y - s.y0, u = dx * s.c + dy * s.s, v = -dx * s.s + dy * s.c;
  return s.type === 'ell' ? (u * u) / (s.a * s.a) + (v * v) / (s.b * s.b) <= 1 : Math.abs(u) <= s.a / 2 && Math.abs(v) <= s.b / 2;
}
function tissueAt(ph, x, y) { let t = null; for (const r of (ph.probe || ph.regions)) if (x >= r.bx0 && x <= r.bx1 && y >= r.by0 && y <= r.by1 && inside(r, x, y)) t = r.tissue; return t; }
// field offset (Hz) of the air sphere; B0 through the slice, so θ = 90° in the plane
function bubbleHz(ph, B0, x, y) {
  const b = ph.bubble; if (!b) return 0;
  if (ph.geom) { // point of the centre plane in 3D; Δf = γ̄·B0·Δχ/3·(a/r)³·(3cos²θ − 1), θ against B0 (z)
    const g = ph.geom, p = [g.o[0] + x * g.e1[0] + y * g.e2[0], g.o[1] + x * g.e1[1] + y * g.e2[1], g.o[2] + x * g.e1[2] + y * g.e2[2]];
    const d = [p[0] - b.c3[0], p[1] - b.c3[1], p[2] - b.c3[2]], r2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
    if (r2 < b.r3 * b.r3) return 0;
    const c2 = d[2] * d[2] / r2;
    return SIM_GBAR * B0 * (9.4e-6 / 3) * Math.pow(b.r3 * b.r3 / r2, 1.5) * (3 * c2 - 1);
  }
  const dx = x - b.x, dy = y - b.y, r2 = dx * dx + dy * dy, a2 = b.r * b.r;
  if (r2 < a2) return 0;
  return -SIM_GBAR * B0 * (9.4e-6 / 3) * Math.pow(a2 / r2, 1.5);
}

/* ---------- per-shot timing and contrast ---------- */
function rfResponse(seq, rfId, fOff) { // small-tip |B1 spectrum| at frequency offset fOff (Hz) relative to the pulse, normalised
  const r = seq.rf.get(rfId), s = rfSamples(seq, r);
  let re0 = 0, im0 = 0, re = 0, im = 0;
  for (let i = 0; i < s.t.length; i++) {
    const a = s.mag[i], ph = s.ph[i] - 2 * Math.PI * fOff * s.t[i];
    re0 += a * Math.cos(s.ph[i]); im0 += a * Math.sin(s.ph[i]); re += a * Math.cos(ph); im += a * Math.sin(ph);
  }
  return Math.hypot(re, im) / (Math.hypot(re0, im0) || 1); // independent of the pulse's phase offset
}
/* timing and contrast of one shot: excitation, refocusing times, TR, prep pulses, b-value, echo time */
function shotInfo(seq, shots, k, B0) {
  const sh = shots[k], B = seq.B, bs = seq.blockStart;
  let exc = -1; const refs = [], refFlips = [];
  for (let b = sh.b0; b <= sh.b1; b++) if (B.rf[b]) { const st = rfSt(seq, B.rf[b]); if (st.use === 'e' && exc < 0) exc = b; else if (st.use === 'r' && exc >= 0) { refs.push(bs[b] + st.center); refFlips.push(st.flip); } }
  if (exc < 0) return null;
  const est = rfSt(seq, B.rf[exc]), tE = bs[exc] + est.center, rE = seq.rf.get(B.rf[exc]), fE = rfFreqHz(rE, B0);
  // TR: time to the previous (or next) excitation with the same frequency (= same slice)
  let TR = null;
  const sameSlice = kk => { const s2 = shots[kk]; for (let b = s2.b0; b <= s2.b1; b++) if (B.rf[b] && rfSt(seq, B.rf[b]).use === 'e') { const r2 = seq.rf.get(B.rf[b]); return Math.abs(rfFreqHz(r2, B0) - fE) < 1 ? bs[b] + rfSt(seq, B.rf[b]).center : null; } return null; };
  for (let kk = k - 1; kk >= Math.max(0, k - 400) && TR === null; kk--) { const t = sameSlice(kk); if (t !== null) TR = tE - t; }
  for (let kk = k + 1; kk < Math.min(shots.length, k + 400) && TR === null; kk++) { const t = sameSlice(kk); if (t !== null) TR = t - tE; }
  if (TR === null) TR = 1e9; // single excitation: fully relaxed
  // preparation pulses: most recent inversion and saturation pulses before the excitation (within 10 s)
  let inv = null, sats = [];
  let seenExc = false;
  for (let b = exc - 1; b >= 0 && bs[exc] - bs[b] < 10; b--) {
    if (!B.rf[b]) continue; const st = rfSt(seq, B.rf[b]);
    if (st.use === 'e') seenExc = true;
    if (st.use === 'i') { inv = { t: tE - (bs[b] + st.center), cyc: invCycle(seq, b, fE, B0) }; break; }
    if (st.use === 's' && !seenExc) sats.push({ id: B.rf[b], t: tE - (bs[b] + st.center), flip: st.flip, freq: rfFreqHz(seq.rf.get(B.rf[b]), B0) });
  }
  return { k, exc, tE, flip: est.flip, freq: fE, refs, refFlips, TR, inv, sats, B0 };
}
function Mz(T1, info, fHz) { // longitudinal magnetization before the excitation (M0 = 1)
  // steady state over one TR: tilt by the excitation, flip by each refocusing pulse (its own angle), recover in
  // between; with M = A + B·M0 through the cycle, M0 = A / (1 − B). Without refocusing this is (1−E1)/(1−cosα·E1).
  let A = 0, Bc = Math.cos(info.flip), last = 0; // M right after the excitation = cosα · M0
  const rec = dt => { const e = Math.exp(-Math.max(0, dt) / T1); A = 1 - (1 - A) * e; Bc *= e; };
  (info.refs || []).forEach((r, i) => { rec(r - info.tE - last); last = r - info.tE; const c = Math.cos(info.refFlips ? info.refFlips[i] : Math.PI); A *= c; Bc *= c; });
  rec(info.TR - last);
  let m = Math.abs(1 - Bc) > 1e-12 ? A / (1 - Bc) : 1;
  if (!(info.TR < 1e8)) m = 1; // a single excitation: fully relaxed
  if (info.inv) m = MzInv(T1, info.inv);
  for (const s of info.sats) { // selective saturation from the pulse's frequency response
    const th = s.flip * rfResponse(info.seq, s.id, fHz - s.freq);
    m = 1 - (1 - Math.cos(th) * m) * Math.exp(-s.t / T1);
  }
  return m;
}
/* longitudinal magnetization before an excitation that follows an inversion pulse (ideal inversion, spoiled between
   pulses). Through one inversion cycle M = A + B·M0, with M0 just before the inversion; in the steady state M0 is the
   value at the end of the cycle, M0 = A/(1 − B). For one 90° readout at TI this is 1 − 2e^(−TI/T1) + e^(−P/T1);
   for MPRAGE it includes the saturation by the readout train. A single inversion starts from M0 = 1. */
function MzInv(T1, inv) {
  const c = inv.cyc, TI = inv.t;
  if (!c) return 1 - 2 * Math.exp(-TI / T1);
  let A = 0, Bc = -1, last = 0, Ak = null, Bk = 0;
  const rec = dt => { const e = Math.exp(-Math.max(0, dt) / T1); A = 1 - (1 - A) * e; Bc *= e; };
  for (let i = 0; i < c.t.length; i++) {
    if (Ak === null && c.t[i] >= TI - 1e-9) { rec(TI - last); last = TI; Ak = A; Bk = Bc; if (c.P === null) break; }
    rec(c.t[i] - last); last = c.t[i]; const cs = Math.cos(c.fl[i]); A *= cs; Bc *= cs;
  }
  if (Ak === null) { rec(TI - last); last = TI; Ak = A; Bk = Bc; }
  if (c.P === null) return Ak + Bk; // single inversion from equilibrium
  rec(c.P - last);
  const M0 = Math.abs(1 - Bc) > 1e-12 ? A / (1 - Bc) : 1;
  return Ak + Bk * M0;
}
/* dephasing time τ at absolute time t: forward from the excitation, sign flip at each refocusing */
function tauAt(info, t) {
  let tau = 0, last = info.tE;
  for (const r of info.refs) { if (r > t) break; tau = -(tau + (r - last)); last = r; }
  return tau + (t - last);
}
/* b-value (s/mm²) from excitation to tEcho: the trace of the b-tensor, (2π)² ∫ |k|² dt on the trajectory */
function bValue(seq, info, tEcho) {
  const M = bTensor(seq, info.exc, info.tE, tEcho);
  return (M[0] + M[4] + M[8]) * 1e-6;
}
/* Echoes of a shot (from its first excitation):
   se: spin echoes, where the dephasing time τ returns to zero (τ starts at the excitation's centre and changes sign at
       each refocusing pulse's centre; tauAt): 2·t₁₈₀ − t₉₀ for a Hahn echo, every echo of a CPMG train;
   gf: gradient echoes with k = 0, where the readout component of k crosses zero and the rest of k is zero too
       (within 1e-4 of the largest |k| at the ends of the shot's readouts);
   gl: the other gradient echoes, where the readout component crosses zero away from the centre (other lines);
   kp: |k| there (the part across the readout); jf, jl: the ADC event of each. Only during readouts (ADC events other than noise); along a straight
   readout the component along it is quadratic between gradient vertices, so the crossings are solved exactly; a curved
   readout (spiral) has no readout direction: its gradient echo is where k comes to 0 in the readout's block (at a
   sample, or where a spiral-out's gradient starts or a spiral-in's ends, even outside the sampling), if it does. */
function shotEchoes(seq, shots, k) {
  const cache = seq._ech && seq._ech.shots === shots ? seq._ech.m : (seq._ech = { shots, m: new Map() }).m;
  if (cache.has(k)) return cache.get(k);
  const sh = shots[k], B = seq.B, bs = seq.blockStart, res = { tE: null, se: [], gf: [], gl: [], kp: [], jf: [], jl: [] };
  let exc = -1; const refs = [];
  for (let b = sh.b0; b <= sh.b1; b++) if (B.rf[b]) { const st = rfSt(seq, B.rf[b]); if (st.use === 'e' && exc < 0) exc = b; else if (st.use === 'r' && exc >= 0) refs.push(bs[b] + st.center); }
  if (exc < 0) { cache.set(k, res); return res; }
  const tE = res.tE = bs[exc] + rfSt(seq, B.rf[exc]).center, tEnd = sh.t1;
  // spin echoes: τ just after refocusing pulse i is −(τ before it); the echo follows at r_i + |τ| if that is before the next pulse
  let tau = 0, last = tE;
  for (let i = 0; i < refs.length; i++) {
    tau = -(tau + (refs[i] - last)); last = refs[i];
    const te = last - tau, next = i + 1 < refs.length ? refs[i + 1] : tEnd;
    if (tau < 0 && te <= next + 1e-12) res.se.push(te);
  }
  // gradient echoes along each readout
  const AT = seq.adcType, cand = [], out = [new Float64Array(3), new Float64Array(3), new Float64Array(3)], rel = new Float64Array(3);
  const kAt = (b, r) => { rel[0] = r; kInBlock(seq, b, rel, out, 0, 1); return [out[0][0], out[1][0], out[2][0]]; };
  let kmax = 0;
  for (let j = sh.j0; j < sh.j1; j++) {
    if (AT[j] === 3) continue; // noise
    const b = seq.adcBlocks[j], d = seq.adc.get(B.adc[b]); if (!d || !d.num) continue;
    const a0 = d.delay, a1 = d.delay + d.num * d.dwell; if (bs[b] + a1 <= tE) continue;
    const ka = kAt(b, a0), kb = kAt(b, a1); kmax = Math.max(kmax, Math.hypot(...ka), Math.hypot(...kb));
    // pieces between gradient vertices (and an RF centre) inside the readout
    const br = [a0, a1];
    for (const id of [B.pgx[b], B.pgy[b], B.pgz[b]]) if (id) { const g = geoG(seq, id); for (let q = 0; q < g.n; q++) if (g.t[q] > a0 && g.t[q] < a1) br.push(g.t[q]); }
    if (B.rf[b]) { const st = rfSt(seq, B.rf[b]); if (st.center > a0 && st.center < a1) br.push(st.center); }
    br.sort((x, y) => x - y);
    const D = [kb[0] - ka[0], kb[1] - ka[1], kb[2] - ka[2]], L = Math.hypot(...D);
    // straight? the k path stays within 1 % of the chord's length from the chord
    let straight = L > 0;
    const P = []; // [p, q, k(p'), k(m), k(q')] for each piece
    for (let i = 1; i < br.length; i++) {
      const p = br[i - 1], q = br[i]; if (q - p <= 1e-12) continue;
      const dl = Math.min(1e-9, (q - p) / 4), m = 0.5 * (p + q);
      const kp = kAt(b, p + dl), km = kAt(b, m), kq = kAt(b, q - dl);
      P.push([p + dl, m, q - dl, kp, km, kq]);
      if (straight) for (const v of [kp, km, kq]) {
        const w = [v[0] - ka[0], v[1] - ka[1], v[2] - ka[2]], s = (w[0] * D[0] + w[1] * D[1] + w[2] * D[2]) / L;
        if (Math.hypot(w[0] - s * D[0] / L, w[1] - s * D[1] / L, w[2] - s * D[2] / L) > 0.01 * L) { straight = false; break; }
      }
    }
    if (straight) {
      const u = D.map(x => x / L), f = v => v[0] * u[0] + v[1] * u[1] + v[2] * u[2];
      for (let i = 0; i < P.length; i++) {
        const [x0, x1, x2, k0, k1, k2] = P[i], y0 = f(k0), y1 = f(k1), y2 = f(k2);
        // quadratic through the three points, in s = t − x1
        const h0 = x0 - x1, h2 = x2 - x1, c = y1;
        const A = ((y2 - c) / h2 - (y0 - c) / h0) / (h2 - h0), Bq = (y2 - c) / h2 - A * h2;
        const roots = [];
        if (Math.abs(A) * (h2 - h0) ** 2 < 1e-12 * (Math.abs(Bq) * (h2 - h0) + Math.abs(c) + 1e-30)) { if (Bq !== 0) roots.push(-c / Bq); }
        else { const disc = Bq * Bq - 4 * A * c; if (disc >= 0) { const sq = Math.sqrt(disc), qq = -0.5 * (Bq + Math.sign(Bq || 1) * sq); roots.push(qq / A); if (qq !== 0) roots.push(c / qq); } }
        const lo = br[0] === x0 ? x0 - 1e-9 : x0 - 1e-9, hi = x2 + 1e-9;
        for (const s of roots) {
          const t = x1 + s; if (!(t >= lo && t < hi) || bs[b] + t <= tE) continue;
          const kk = kAt(b, Math.min(Math.max(t, x0), x2));
          cand.push([bs[b] + t, Math.hypot(...kk), 0, j]);
        }
      }
    } else { // curved (or no gradient): where k comes closest to 0 in the readout's block (samples, gradient vertices and
      // the block's ends; a spiral-out reaches k = 0 where its gradient starts, which may be before the first sample)
      const dur = bs[b + 1] - bs[b], tt = [0, dur, a0, a1];
      for (let q = 0; q < d.num; q++) tt.push(d.delay + (q + 0.5) * d.dwell);
      for (const id of [B.pgx[b], B.pgy[b], B.pgz[b]]) if (id) { const g = geoG(seq, id); for (let q = 0; q < g.n; q++) tt.push(Math.min(dur, Math.max(0, g.t[q]))); }
      const rr = Float64Array.from(tt.filter(r => bs[b] + r > tE)).sort(), nq = rr.length, tmp = [new Float64Array(nq), new Float64Array(nq), new Float64Array(nq)];
      kInBlock(seq, b, rr, tmp, 0, nq);
      let best = Infinity, tb = null;
      for (let q = 0; q < nq; q++) { const r = Math.hypot(tmp[0][q], tmp[1][q], tmp[2][q]); kmax = Math.max(kmax, r); if (r < best) { best = r; tb = bs[b] + rr[q]; } }
      if (tb !== null && tb > tE && L > 0) cand.push([tb, best, 'curve', j]);
    }
  }
  const tol = 1e-4 * kmax;
  cand.sort((x, y) => x[0] - y[0]);
  let prev = -Infinity;
  for (const [t, kp, cv, j] of cand) {
    if (t - prev < 1e-9) continue; prev = t; // a root shared by two pieces
    if (kp <= tol) { res.gf.push(t); res.jf.push(j); } else if (!cv) { res.gl.push(t); res.kp.push(kp); res.jl.push(j); }
  }
  cache.set(k, res); return res;
}
/* b-tensor (s/m², physical x, y, z) from the excitation to tEcho: B = (2π)² ∫ k kᵀ dt with k the trajectory of
   kInBlock (reset at the excitation, mirrored at each refocusing pulse), all gradients included. Between gradient
   vertices and RF centres k is quadratic, so k kᵀ is quartic and 3-point Gauss–Legendre on each piece is exact. */
const GL3 = [[-Math.sqrt(0.6), 5 / 9], [0, 8 / 9], [Math.sqrt(0.6), 5 / 9]];
function bTensor(seq, exc, tE, tEcho) {
  const B = seq.B, bs = seq.blockStart, M = new Float64Array(9);
  if (!(tEcho > tE)) return M;
  const b1 = blockAtTime(seq, tEcho), out = [new Float64Array(0), new Float64Array(0), new Float64Array(0)];
  for (let b = exc; b <= b1; b++) {
    const lo = Math.max(bs[b], tE) - bs[b], hi = Math.min(bs[b + 1], tEcho) - bs[b];
    if (!(hi > lo)) continue;
    const br = [lo, hi];
    for (const id of [B.pgx[b], B.pgy[b], B.pgz[b]]) if (id) { const g = geoG(seq, id); for (let j = 0; j < g.n; j++) if (g.t[j] > lo && g.t[j] < hi) br.push(g.t[j]); }
    if (B.rf[b]) { const st = rfSt(seq, B.rf[b]); if ((st.use === 'e' || st.use === 'r') && st.center > lo && st.center < hi) br.push(st.center); }
    br.sort((x, y) => x - y);
    const ab = [];
    for (let i = 1; i < br.length; i++) if (br[i] - br[i - 1] > 1e-12) ab.push(br[i - 1], br[i]);
    const n = 3 * ab.length / 2, rel = new Float64Array(n), w = new Float64Array(n);
    for (let i = 0, q = 0; i < ab.length; i += 2) {
      const m = 0.5 * (ab[i] + ab[i + 1]), h = 0.5 * (ab[i + 1] - ab[i]);
      for (const [x, wt] of GL3) { rel[q] = m + h * x; w[q++] = h * wt; }
    }
    if (out[0].length < n) for (let a = 0; a < 3; a++) out[a] = new Float64Array(n);
    kInBlock(seq, b, rel, out, 0, n);
    for (let q = 0; q < n; q++) {
      const x = out[0][q], y = out[1][q], z = out[2][q], wq = w[q];
      M[0] += wq * x * x; M[1] += wq * x * y; M[2] += wq * x * z; M[4] += wq * y * y; M[5] += wq * y * z; M[8] += wq * z * z;
    }
  }
  const c = 4 * Math.PI * Math.PI;
  M[0] *= c; M[1] *= c; M[2] *= c; M[4] *= c; M[5] *= c; M[8] *= c; M[3] = M[1]; M[6] = M[2]; M[7] = M[5];
  return M;
}
/* echo of a shot for the b-tensor: the readout sample closest to k = 0 in the shot's first echo (adcEchoes: echoes
   that form separate images, so a turbo spin echo train is one echo and its centre is the effective echo time).
   Imaging readouts first; a shot with only reference readouts uses those. Returns null without an excitation. */
function shotBTensor(seq, shots, k) {
  const cache = seq._bt && seq._bt.shots === shots ? seq._bt.m : (seq._bt = { shots, m: new Map() }).m;
  if (cache.has(k)) return cache.get(k);
  const sh = shots[k], B = seq.B, bs = seq.blockStart;
  let exc = -1; for (let b = sh.b0; b <= sh.b1 && exc < 0; b++) if (B.rf[b] && rfSt(seq, B.rf[b]).use === 'e') exc = b;
  let res = null;
  if (exc >= 0) {
    const tE = bs[exc] + rfSt(seq, B.rf[exc]).center, AT = seq.adcType, EC = adcEchoes(seq, shots);
    let js = [], nEcho = 0, kind = 'imaging';
    for (let j = sh.j0; j < sh.j1; j++) if ((AT[j] === 0 || AT[j] === 2) && EC[j] >= 0) js.push(j);
    if (js.length) {
      const e0 = Math.min(...js.map(j => EC[j])); nEcho = new Set(js.map(j => EC[j])).size; js = js.filter(j => EC[j] === e0);
    } else { kind = 'reference'; for (let j = sh.j0; j < sh.j1; j++) if (AT[j] === 1) js.push(j); }
    js = js.filter(j => bs[seq.adcBlocks[j]] + 1e-12 >= bs[exc]);
    let best = Infinity, tEcho = null, kAt = null;
    const tmp = [new Float64Array(0), new Float64Array(0), new Float64Array(0)];
    for (const j of js) {
      const b = seq.adcBlocks[j], d = seq.adc.get(B.adc[b]); if (!d || !d.num) continue;
      const rel = new Float64Array(d.num); for (let q = 0; q < d.num; q++) rel[q] = d.delay + (q + 0.5) * d.dwell;
      if (tmp[0].length < d.num) for (let a = 0; a < 3; a++) tmp[a] = new Float64Array(d.num);
      kInBlock(seq, b, rel, tmp, 0, d.num);
      for (let q = 0; q < d.num; q++) {
        const r = tmp[0][q] ** 2 + tmp[1][q] ** 2 + tmp[2][q] ** 2;
        if (r < best) { best = r; tEcho = bs[b] + rel[q]; kAt = [tmp[0][q], tmp[1][q], tmp[2][q]]; }
      }
    }
    if (tEcho !== null && tEcho > tE) {
      const M = bTensor(seq, exc, tE, tEcho), A = [[M[0], M[1], M[2]], [M[3], M[4], M[5]], [M[6], M[7], M[8]]];
      res = { M, eig: eig3(A).map(e => e.val), b: M[0] + M[4] + M[8], tE, tEcho, kAt, nEcho, kind, exc };
    }
  }
  cache.set(k, res); return res;
}

/* ---------- eddy currents (indicative) ----------
   Residual eddy currents as decaying exponentials driven by the slew of each gradient axis:
     g_eddy(t) = −Σᵢ aᵢ ∫ dG/dt′ e^{−(t−t′)/τᵢ} dt′      (per axis, spatially linear)
   plus a spatially constant (B0) part, taken as the eddy gradients acting over a lever arm d.
   Illustrative presets, not measured values. */
const EDDY = {
  typical: { terms: [[0.001, 1e-3], [0.0005, 50e-3]], d: 2e-3, name: 'typical residual' },
  poor: { terms: [[0.005, 1e-3], [0.0025, 50e-3]], d: 5e-3, name: 'poorly compensated' }
};
/* one gradient channel sampled every dt from t0 (N samples), walking the blocks once */
function sampleChannel(seq, key, t0, dt, N) {
  const out = new Float64Array(N), col = CHANNELS[key].col, bs = seq.blockStart;
  let b = blockAtTime(seq, t0), g = null, j = 1, curB = -1;
  for (let n = 0; n < N; n++) {
    const t = t0 + n * dt;
    while (b < seq.nb - 1 && bs[b + 1] <= t) b++;
    if (b !== curB) { curB = b; const id = seq.B[col][b]; g = id ? geoG(seq, id) : null; j = 1; }
    if (!g) continue;
    const r = t - bs[b]; if (r < g.t[0] || r > g.t[g.n - 1]) continue;
    while (j < g.n - 1 && g.t[j] < r) j++;
    const ta = g.t[j - 1], tb = g.t[j]; out[n] = tb > ta ? g.v[j - 1] + (g.v[j] - g.v[j - 1]) * (r - ta) / (tb - ta) : g.v[j];
  }
  return out;
}
/* eddy history over [t0, t1]: cumulative eddy k-space K[a] (1/m) and B0 phase PH (cycles) */
function eddyTrack(seq, t0, t1, preset) {
  const P = EDDY[preset], tauMax = Math.max(...P.terms.map(x => x[1]));
  const start = Math.max(0, t0 - 5 * tauMax), dt = Math.max(10e-6, (t1 - start) / 3e6), N = Math.ceil((t1 - start) / dt) + 2;
  const K = [0, 1, 2].map(() => new Float64Array(N)), PH = new Float64Array(N);
  ['gx', 'gy', 'gz'].forEach((key, a) => {
    const G = sampleChannel(seq, key, start, dt, N), st = P.terms.map(() => 0), dec = P.terms.map(x => Math.exp(-dt / x[1]));
    let prev = G[0], kk = 0, pp = 0;
    for (let n = 0; n < N; n++) {
      const dG = G[n] - prev; prev = G[n]; let ge = 0;
      for (let i = 0; i < st.length; i++) { st[i] = st[i] * dec[i] + P.terms[i][0] * dG; ge -= st[i]; }
      kk += ge * dt; K[a][n] = kk; pp += ge * P.d * dt; PH[n] += pp; // cumulative eddy k-space and B0 phase (cycles)
    }
  });
  return { start, dt, N, K, PH };
}
function eddyInterp(A, E, t) { const x = (t - E.start) / E.dt, i = Math.max(0, Math.min(E.N - 2, Math.floor(x))), f = Math.min(1, Math.max(0, x - i)); return A[i] + (A[i + 1] - A[i]) * f; }
/* eddy k-space shift (1/m, logical axes) and B0 phase (cycles) at time t of a shot: accumulated from the
   excitation, mirrored at each refocusing pulse like the dephasing time */
function eddyShift(E, inf, t) {
  const Kt = s => [eddyInterp(E.K[0], E, s), eddyInterp(E.K[1], E, s), eddyInterp(E.K[2], E, s), eddyInterp(E.PH, E, s)];
  let acc = [0, 0, 0, 0], last = inf.tE, Kl = Kt(last);
  for (const r of inf.refs) { if (r > t) break; const Kr = Kt(r); acc = acc.map((v, i) => -(v + Kr[i] - Kl[i])); last = r; Kl = Kr; }
  const Kn = Kt(t); return acc.map((v, i) => v + Kn[i] - Kl[i]);
}

/* ---------- choose the samples of one image ---------- */
function imageSet(seq, shots, vol, refShot, B0) {
  // imaging ADCs of the shots in this volume that excite the same slice as refShot
  const iRef = shotInfo(seq, shots, refShot, B0); if (!iRef) return null;
  const list = [];
  for (let k = vol.s0; k <= vol.s1; k++) {
    const inf = k === refShot ? iRef : shotInfo(seq, shots, k, B0);
    if (!inf || Math.abs(inf.freq - iRef.freq) > 1) continue;
    list.push(inf);
  }
  let useType = t => t === 0 || t === 2;
  const any = list.some(inf => { const sh = shots[inf.k]; for (let j = sh.j0; j < sh.j1; j++) if (useType(seq.adcType[j])) return true; return false; });
  if (!any) useType = t => t === 1; // a reference-only volume
  return { list, useType, ref: iRef };
}

/* ---------- the simulation ---------- */
let SIM_TICK = null; // set by runSimulation: async progress/cancel hook
/* Parallel tasks. SIM_POOL(task, args) → Promise(result) is set by the page when background workers are
   available; otherwise (Node tests, no workers) the same task functions run here one after the other. */
let SIM_POOL = null;
/* GPU (set by the page when a hardware WebGL2 device is available): SIM_GPU(task, args) returns the same result
   as SIM_TASKS[task](args); SIM_GPU.has(task) tells which tasks it implements. Any failure falls back to the CPU. */
let SIM_GPU = null, SIM_ENGINE = 'CPU';
async function parMap(task, list, p0, p1) {
  if (SIM_GPU && SIM_GPU.has(task)) {
    try { const out = []; for (let i = 0; i < list.length; i++) { out.push(SIM_GPU(task, list[i])); await tick(p0 + (p1 - p0) * (i + 1) / list.length); } SIM_ENGINE = 'GPU'; return out; }
    catch (e) { if (e && e.message === 'cancelled') throw e; console.warn('GPU simulation failed, continuing on the CPU:', e); SIM_GPU = null; }
  }
  if (!(SIM_POOL && list.length > 1) && SIM_ENGINE !== 'GPU') SIM_ENGINE = 'CPU';
  if (SIM_POOL && list.length > 1 && SIM_ENGINE !== 'GPU') SIM_ENGINE = `CPU, ${SIM_POOL.size} worker${SIM_POOL.size > 1 ? 's' : ''}`;
  if (SIM_POOL && list.length > 1) {
    const out = await Promise.all(list.map(a => SIM_POOL(task, a)));
    await tick(p1); return out;
  }
  const out = []; for (let i = 0; i < list.length; i++) { await tick(p0 + (p1 - p0) * i / list.length); out.push(SIM_TASKS[task](list[i])); } return out;
}
function nChunks(work) { const w = SIM_POOL ? (SIM_POOL.size || 4) : 1; return Math.max(1, Math.min(w * 2, Math.ceil(work / 2e5))); }
/* the parts of the model a worker needs to evaluate the phantom (small, copyable) */
function mlite(M) {
  return { infos: M.infos.map(i => ({ tE: i.tE, w: i.w })), tis: M.tis, T2: M.tis.map(t => TISSUES[t].T2), fatAmp: FAT6.amp, T2P, FAT_T2, fat: M.fat, opt: { t2: M.opt.t2, fatShift: M.opt.fatShift },
    regions: M.ph.regions.map(r => ({ type: r.type, x0: r.x0, y0: r.y0, a: r.a, b: r.b, c: r.c, s: r.s, w: r.w ?? 1 })), rOwn: M.rOwn, rPar: M.rPar };
}
function mliteBuild(m) { return { ...m, ph: { regions: m.regions }, n: 0, TR_: m.tis.map(() => new Float64Array(1)), TI_: m.tis.map(() => new Float64Array(1)) }; }
const SIM_TASKS = {
  // the phantom's signal at points (k, absolute time, dephasing time, shot)
  evalPoints(a) {
    const M = mliteBuild(a.m), n = a.kx.length, re = new Float64Array(n), im = new Float64Array(n);
    for (let i = 0; i < n; i++) { const v = signalAt(M, a.kx[i], a.ky[i], a.t[i], a.tau[i], a.si[i]); re[i] = v[0]; im[i] = v[1]; }
    return { re, im };
  },
  // exact adjoint Fourier sum of a subset of samples onto the Nx×Ny pixel grid
  directSum(a) {
    const { Nx, Ny, px, py } = a, xr = new Float64Array(Nx * Ny), xi = new Float64Array(Nx * Ny);
    for (let q = 0; q < a.kx.length; q++) {
      const sr = a.sr[q], si = a.si[q], ax = 2 * Math.PI * a.kx[q] * px, ay = 2 * Math.PI * a.ky[q] * py, dr = Math.cos(ax), di = Math.sin(ax);
      for (let j = 0; j < Ny; j++) {
        const p0 = ax * (-Nx / 2) + ay * (j - Ny / 2); let cr = Math.cos(p0), ci = Math.sin(p0); const o = j * Nx;
        for (let i = 0; i < Nx; i++) { xr[o + i] += sr * cr - si * ci; xi[o + i] += sr * ci + si * cr; const t = cr * dr - ci * di; ci = cr * di + ci * dr; cr = t; }
      }
    }
    return { xr, xi };
  },
  // the bubble's direct sum for a range of readouts (see bubbleDirectFast)
  bubbleDirect(a) { return bubbleDirectCore(a); },
  // 2D FFT of a map (only the columns listed in cols, when given)
  fft2(a) { if (a.cols) fft2cols(a.re, a.im, a.N, a.cols); else fft2(a.re, a.im, a.N); return { re: a.re, im: a.im }; }
};
async function tick(p) { if (SIM_TICK) await SIM_TICK(p); }
async function simulateImage(seq, shots, vol, refShot, opt) {
  const B0 = opt.B0, fat = FAT6.ppm.map(p => p * 1e-6 * SIM_GBAR * B0);
  const set = imageSet(seq, shots, vol, refShot, B0); if (!set || !set.list.length) return { error: 'No excitation found for this shot.' };
  for (const inf of set.list) inf.seq = seq;
  // gather samples: k (1/mm), t, τ and shot index
  const KX = [], KY = [], T = [], TAU = [], SH = [], DW = [], EVS = [];
  const infos = [];
  // image plane: the principal axes of the acquired k-space samples (handles rotated / oblique scans)
  // first axis: the readout (the direction k moves within one ADC); second: the largest k-space spread
  // perpendicular to it. Axes within ~5° of a gradient axis are snapped onto it.
  // echoes: adcEchoes (core.js) for imaging readouts; for a reference-only image, by revisits within each shot
  const C3 = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]; let rd = null, rdLen = 0;
  const echoOf = new Map(); let nEcho = 1;
  if (set.useType(0)) { const EC = adcEchoes(seq, shots); for (const inf of set.list) { const sh = shots[inf.k]; for (let j = sh.j0; j < sh.j1; j++) if (set.useType(seq.adcType[j]) && EC[j] >= 0) echoOf.set(j, EC[j]); } }
  else for (const inf of set.list) { const sh = shots[inf.k], js = []; for (let j = sh.j0; j < sh.j1; j++) if (set.useType(seq.adcType[j])) js.push(j); revisitEchoes(seq, js, (j, v) => echoOf.set(j, v)); }
  for (const v of echoOf.values()) nEcho = Math.max(nEcho, v + 1);
  for (const inf of set.list) { const sh = shots[inf.k]; for (let j = sh.j0; j < sh.j1; j++) if (set.useType(seq.adcType[j])) {
    const S = kSamples(seq, j, j + 1, Infinity); if (!S.n) continue;
    const dk = [0, 1, 2].map(a => S.k[a][S.n - 1] - S.k[a][0]), L = Math.hypot(...dk); if (L > rdLen) { rdLen = L; rd = dk.map(x => x / L); }
    for (let q = 0; q < S.n; q += 3) for (let a = 0; a < 3; a++) for (let b2 = 0; b2 < 3; b2++) C3[a][b2] += S.k[a][q] * S.k[b2][q];
  } }
  const snap = v => { const a = v.map(Math.abs), i = a.indexOf(Math.max(...a)); if (a[i] > 0.996) { const u = [0, 0, 0]; u[i] = v[i] > 0 ? 1 : -1; return u; } return v; };
  const posDom = v => { const a = v.map(Math.abs), i = a.indexOf(Math.max(...a)); return v[i] < 0 ? v.map(x => -x) : v; };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const nrm = v => { const L = Math.hypot(...v) || 1; return v.map(x => x / L); };
  let r1 = posDom(snap(rd || [1, 0, 0]));
  const P = [0, 1, 2].map(i => [0, 1, 2].map(j => (i === j ? 1 : 0) - r1[i] * r1[j]));
  const Cp = [0, 1, 2].map(i => [0, 1, 2].map(j => { let v = 0; for (let a = 0; a < 3; a++) for (let b2 = 0; b2 < 3; b2++) v += P[i][a] * C3[a][b2] * P[b2][j]; return v; }));
  const EVp = eig3(Cp); let r2;
  if (EVp[1].val > 0.7 * EVp[0].val) { // two similar spreads (3D encoding): take the gradient axis with the larger one
    let best = -1, bv = -1; for (let a = 0; a < 3; a++) { if (Math.abs(r1[a]) > 0.5) continue; if (C3[a][a] > bv * 1.0001) { bv = C3[a][a]; best = a; } }
    r2 = [0, 0, 0]; r2[best] = 1;
  } else r2 = posDom(snap(nrm(EVp[0].vec)));
  { // slab-selective 3D: the second image axis must not be the slab normal (the gradient during the excitation);
    // the partitions along it can have a k-spread as large as the phase encoding's. Then take the direction
    // perpendicular to both the readout and the slab normal.
    const Ge = ['gx', 'gy', 'gz'].map(k => channelValue(seq, k, set.ref.tE)), Gm = Math.hypot(...Ge);
    if (Gm > 1e3) {
      const nS = Ge.map(x => x / Gm), c = cross(nS, r1);
      if (Math.abs(dot3(r2, nS)) > 0.5 && Math.hypot(...c) > 0.5) r2 = posDom(snap(nrm(c)));
    }
  }
  r2 = nrm(addS(r2, r1, -dot3(r2, r1))); // keep exactly perpendicular
  const idx = v => { const a = v.map(Math.abs); return a.indexOf(Math.max(...a)); };
  // computed with the readout as the first image axis (rows along the readout); transposed at the end if the
  // display order (x before y before z) wants the other axis horizontal
  const e1s = r1, e2s = r2, swapDisplay = idx(r1) > idx(r2);
  const e3s = cross(e1s, e2s);
  let k3 = 0; const useEcho = Math.max(0, Math.min(nEcho - 1, opt.echo | 0));
  for (const inf of set.list) {
    const sh = shots[inf.k]; let js = [];
    for (let j = sh.j0; j < sh.j1; j++) if (set.useType(seq.adcType[j])) js.push(j);
    js = js.filter(j => (echoOf.get(j) || 0) === useEcho);
    if (!js.length) continue;
    const si = infos.length; infos.push(inf);
    for (const j of js) {
      EVS.push(KX.length);
      const S = kSamples(seq, j, j + 1, Infinity, true), d = seq.adc.get(seq.B.adc[seq.adcBlocks[j]]);
      for (let q = 0; q < S.n; q++) {
        const kx = S.k[0][q], ky = S.k[1][q], kz = S.k[2][q];
        KX.push((kx * e1s[0] + ky * e1s[1] + kz * e1s[2]) * 1e-3); KY.push((kx * e2s[0] + ky * e2s[1] + kz * e2s[2]) * 1e-3);
        k3 = Math.max(k3, Math.abs(kx * e3s[0] + ky * e3s[1] + kz * e3s[2]) * 1e-3);
        T.push(S.t[q]); SH.push(si); DW.push(d.dwell);
      }
    }
  }
  const n = KX.length; if (!n) return { error: 'No imaging samples in this image.' };
  // third axis encoded (3D)? then one partition; otherwise the slice from the excitation
  let k2max = 0; for (let q = 0; q < n; q++) k2max = Math.max(k2max, Math.abs(KY[q]), Math.abs(KX[q]));
  const geom = sliceGeometry(seq, set.ref, e1s, e2s, e3s, k3 > 0.1 * k2max ? k3 : 0, opt.orient || 'ax', opt.slicePos === false ? SIM_PHANTOMS3D[opt.phantom].bubble.c : null);
  geom.e1s = e1s; geom.e2s = e2s;
  const ph = sectionPhantom(opt.phantom, opt.bubble, geom);
  if (n > 4e6) return { error: `${n.toLocaleString()} samples: too many to simulate here.` };
  // per shot: echo time (sample closest to k = 0), b-value, per-tissue weights
  const tis = [...new Set(ph.regions.map(r => r.tissue))];
  const best = new Float64Array(infos.length).fill(Infinity), tEchoA = infos.map(x => x.tE);
  for (let q = 0; q < n; q++) { const r = KX[q] * KX[q] + KY[q] * KY[q]; if (r < best[SH[q]]) { best[SH[q]] = r; tEchoA[SH[q]] = T[q]; } }
  for (let si = 0; si < infos.length; si++) {
    const inf = infos[si], tEcho = tEchoA[si];
    inf.tEcho = tEcho; inf.TE = tEcho - inf.tE; inf.b = opt.diffusion ? bValue(seq, inf, tEcho) : 0;
    inf.w = {}; // real, time-independent factor per tissue (water, fat)
    for (const tn of tis) {
      const X = TISSUES[tn], sa = Math.sin(inf.flip), D = Math.exp(-inf.b * X.adc);
      inf.w[tn] = [X.pd * (1 - X.ff) * sa * (opt.t1 ? Mz(X.T1, inf, 0) : 1) * D, X.pd * X.ff * sa * (opt.t1 ? Mz(FAT_T1, inf, fat[1]) : 1) * Math.exp(-inf.b * 0.01e-3)];
    }
  }
  for (let q = 0; q < n; q++) TAU.push(tauAt(infos[SH[q]], T[q]));
  EVS.push(n);
  const axn = v => { const a = v.map(Math.abs), i = a.indexOf(Math.max(...a)); return 'xyz'[i]; };
  const M = { ph, infos, KX, KY, T, TAU, SH, DW, EVS, n, fat, opt, tis, set, axes: axn(e1s) + axn(e2s), geom, swapDisplay, nEcho, echo: useEcho };
  if (opt.eddy && EDDY[opt.eddy]) { // actual k = nominal k + eddy shift; B0 eddy as a phase
    let t0 = Infinity, t1 = -Infinity; for (const inf of infos) t0 = Math.min(t0, inf.tE); for (let q = 0; q < n; q++) t1 = Math.max(t1, T[q]);
    const E = eddyTrack(seq, t0, t1, opt.eddy);
    M.DKX = new Float64Array(n); M.DKY = new Float64Array(n); M.PHI = new Float64Array(n);
    for (let q = 0; q < n; q++) {
      const d = eddyShift(E, infos[SH[q]], T[q]);
      M.DKX[q] = (d[0] * e1s[0] + d[1] * e1s[1] + d[2] * e1s[2]) * 1e-3; M.DKY[q] = (d[0] * e2s[0] + d[1] * e2s[1] + d[2] * e2s[2]) * 1e-3; M.PHI[q] = -2 * Math.PI * d[3];
    }
  }
  M.tIdx = new Map(tis.map((t, i) => [t, i]));
  M.TR_ = tis.map(() => new Float64Array(n + 1)); M.TI_ = tis.map(() => new Float64Array(n + 1));
  M.TS = {}; tis.forEach((t, i) => M.TS[t] = [M.TR_[i], M.TI_[i]]);
  M.fillSamples = async () => { for (let q = 0; q < n; q++) { if ((q & 32767) === 0) await tick(0.1 + 0.15 * q / n); fillTissue(M, q, T[q], TAU[q], SH[q]); } }; // only needed off the grid
  // per region: indices of own and parent tissue
  M.rOwn = ph.regions.map(r => M.tIdx.get(r.tissue)); M.rPar = ph.regions.map(r => r.parent >= 0 ? M.tIdx.get(ph.regions[r.parent].tissue) : -1);
  M.corr = opt.noOverlapFix ? [] : (ph.corr || []).filter(p => M.tIdx.has(p.tissue)).map(p => ({ ...p, ti: M.tIdx.get(p.tissue) }));
  return M;
}
/* complex signal density of every tissue for timing (t, τ, shot), written to slot q of M.TR_/M.TI_ */
function fillTissue(M, q, t, tau, si) {
  const inf = M.infos[si], ts = t - inf.tE, e2p = Math.exp(-Math.abs(tau) / T2P), opt = M.opt;
  let fr = 1, fi = 0;
  if (opt.fatShift) { fr = 0; for (let p = 0; p < 6; p++) { const a = -2 * Math.PI * M.fat[p] * tau; fr += FAT6.amp[p] * Math.cos(a); fi += FAT6.amp[p] * Math.sin(a); } }
  const ef = opt.t2 ? Math.exp(-ts / FAT_T2) * e2p : 1;
  for (let i = 0; i < M.tis.length; i++) {
    const tn = M.tis[i], X = TISSUES[tn], w = inf.w[tn];
    const ew = opt.t2 ? Math.exp(-ts / X.T2) * e2p : 1;
    M.TR_[i][q] = w[0] * ew + w[1] * ef * fr; M.TI_[i][q] = w[1] * ef * fi;
  }
}
/* analytic k-space value at (kx, ky) (1/mm); q ≥ 0 uses the stored tissue signals of sample q,
   otherwise they are computed for (t, τ, shot) in the scratch slot n */
function signalAt(M, kx, ky, t, tau, si, q = -1) {
  if (q < 0) { q = M.n; fillTissue(M, q, t, tau, si); }
  const R = M.ph.regions, TR = M.TR_, TI = M.TI_;
  let re = 0, im = 0;
  for (let ri = 0; ri < R.length; ri++) {
    const r = R[ri], o = M.rOwn[ri], pa = M.rPar[ri];
    const rw = r.w ?? 1, wr = rw * (TR[o][q] - (pa >= 0 ? TR[pa][q] : 0)), wi = rw * (TI[o][q] - (pa >= 0 ? TI[pa][q] : 0)); if (wr === 0 && wi === 0) continue;
    const u = kx * r.c + ky * r.s, v = -kx * r.s + ky * r.c;
    let A;
    if (r.type === 'ell') { const kap = Math.hypot(r.a * u, r.b * v); A = kap < 1e-12 ? Math.PI * r.a * r.b : r.a * r.b * bessj1(2 * Math.PI * kap) / kap; }
    else A = r.a * r.b * sincPi(r.a * u) * sincPi(r.b * v);
    const p = -2 * Math.PI * (kx * r.x0 + ky * r.y0), cr = Math.cos(p) * A, ci = Math.sin(p) * A;
    re += wr * cr - wi * ci; im += wr * ci + wi * cr;
  }
  return [re, im];
}
/* air-bubble field: correction on nodes around the sphere, direct sum over the samples */
/* content of a square patch (side h, centre x, y): tissue fractions and mean field offset per tissue.
   Interior patches (all four corners and the centre agree) are taken whole; patches on an edge are
   subsampled 4×4, so tissue boundaries and the sphere's surface are resolved below the patch size. */
const PV_OFF = [-0.375, -0.125, 0.125, 0.375];
function patchContent(ph, B0, x, y, h) {
  const probe = (px, py) => { const bx = px - ph.bubble.x, by = py - ph.bubble.y; if (ph.bubble.r > 0 && bx * bx + by * by < ph.bubble.r * ph.bubble.r) return 'air'; return tissueAt(ph, px, py) || 'air'; };
  const c0 = probe(x, y), hh = h / 2;
  if (probe(x - hh, y - hh) === c0 && probe(x + hh, y - hh) === c0 && probe(x - hh, y + hh) === c0 && probe(x + hh, y + hh) === c0) {
    return c0 === 'air' ? [] : [{ tn: c0, frac: 1, df: bubbleHz(ph, B0, x, y) }];
  }
  const acc = new Map();
  for (const oy of PV_OFF) for (const ox of PV_OFF) {
    const px = x + ox * h, py = y + oy * h, tn = probe(px, py); if (tn === 'air') continue;
    const a = acc.get(tn) || { n: 0, df: 0 }; a.n++; a.df += bubbleHz(ph, B0, px, py); acc.set(tn, a);
  }
  const out = []; for (const [tn, a] of acc) out.push({ tn, frac: a.n / 16, df: a.df / a.n });
  return out;
}
function bubbleTmax(M) { let t = 0; for (const x of M.TAU) t = Math.max(t, Math.abs(x)); return t; }
/* patches on a lattice (spacing h) around the sphere where the field turns the phase by more than thr (rad)
   within the longest dephasing time */
async function bubbleNodes(M, h, thr) {
  const ph = M.ph, b = ph.bubble, fmax = 2 * SIM_GBAR * M.opt.B0 * 9.4e-6 / 3, tmax = bubbleTmax(M), R3 = b.r3 || b.r;
  const rmax = R3 * Math.cbrt(Math.max(1, fmax * 2 * Math.PI * tmax / thr));
  const nodes = [], x0 = b.x - rmax, y0 = b.y - rmax, nb = Math.floor(2 * rmax / h) + 1;
  const B0 = M.opt.B0, lim = thr / (2 * Math.PI * tmax), fmaxHz = 2 * SIM_GBAR * B0 * 9.4e-6 / 3, dz2 = (b.d || 0) * (b.d || 0);
  const dmax = M.opt.bubbleRefine ?? 3, sub = M.opt.bubbleSub ?? 3; // refinement depth, and phase spread (rad) allowed across a patch
  for (let j = 0; j < nb; j++) { if ((j & 7) === 0) await tick(0.6 + 0.05 * j / nb); for (let i = 0; i < nb; i++) {
    const x = x0 + i * h, y = y0 + j * h;
    const dc = bubbleHz(ph, B0, x, y), dx = x - b.x, dy = y - b.y;
    if (Math.abs(dc) <= lim && dx * dx + dy * dy + dz2 > (R3 + h) * (R3 + h)) continue; // clearly far (patches at the surface are kept)
    const emit = (px, py, hh, depth) => {
      const r = Math.sqrt((px - b.x) * (px - b.x) + (py - b.y) * (py - b.y) + dz2), grad = r > R3 ? 3 * Math.abs(bubbleHz(ph, B0, px, py)) / r : 3 * fmaxHz / R3;
      if (depth < dmax && grad * hh * 2 * Math.PI * tmax > sub) { const q = hh / 4; for (const [ox, oy] of [[-q, -q], [q, -q], [-q, q], [q, q]]) emit(px + ox, py + oy, hh / 2, depth + 1); return; }
      for (const c of patchContent(ph, B0, px, py, hh)) {
        if (c.df === 0 || Math.abs(c.df) <= lim) continue;
        nodes.push({ x: px, y: py, i, j, df: c.df, tn: c.tn, ti: M.tIdx.get(c.tn), w: c.frac * (hh * hh) / (h * h) });
      }
    };
    emit(x, y, h, 0);
  } }
  return { nodes, area: h * h, rmax, h, x0, y0, nb, thr, tmax };
}

/* Cartesian: within one k-space row the dephasing time is (close to) linear in kx, τ ≈ c + a·kx.
   A patch at x with field offset Δf then contributes  w·e^{−i2π ky y}·[ e^{−i2πΔf c}·e^{−i2π kx (x + Δf·a)} − e^{−i2π kx x} ],
   i.e. a point shifted by Δf·a with a fixed phase, minus the point where it was. Per row and tissue the patches
   are spread onto a fine periodic 1D grid (4-tap Lagrange, 4× oversampled; the field of view wraps as in a
   real acquisition) and one FFT gives the correction at every kx of the row. The tissue signal (relaxation,
   fat phase, weights) at each grid point multiplies the result. */
function lagrange4(t, o) { o[0] = -t * (t - 1) * (t - 2) / 6; o[1] = (t + 1) * (t - 1) * (t - 2) / 2; o[2] = -(t + 1) * t * (t - 2) / 2; o[3] = (t + 1) * t * (t - 1) / 6; }
const LW = new Float64Array(4);
function deposit1(re, im, Nf, u, vr, vi) {
  let iu = Math.floor(u), t = u - iu;
  if (t < 1e-9) { const k = ((iu % Nf) + Nf) % Nf; re[k] += vr; im[k] += vi; return; }
  if (t > 1 - 1e-9) { const k = (((iu + 1) % Nf) + Nf) % Nf; re[k] += vr; im[k] += vi; return; }
  lagrange4(t, LW);
  for (let a = 0; a < 4; a++) { const k = (((iu - 1 + a) % Nf) + Nf) % Nf; re[k] += LW[a] * vr; im[k] += LW[a] * vi; }
}
async function bubbleRows(M, B, Kr, Ki, W, TT, TU, TS, G, dkx, dky, skipRow) {
  const nodes = B.nodes; if (!nodes.length) return;
  { let left = false; for (let r = 0; r < G && !left; r++) if (!(skipRow && skipRow[r])) for (let i = 0; i < G; i++) if (W[r * G + i] !== 0) { left = true; break; } if (!left) return; }
  const Nf = Math.max(64, 1 << Math.ceil(Math.log2(4 * G))), hx = 1 / (dkx * Nf);
  const nt = M.tis.length, byT = Array.from({ length: nt }, () => []);
  for (const nd of nodes) byT[nd.ti].push(nd);
  // e^{−i2π ky y}·area per node, advanced row by row
  const eyR = new Float64Array(nodes.length), eyI = new Float64Array(nodes.length), stR = new Float64Array(nodes.length), stI = new Float64Array(nodes.length);
  const iy0 = -G / 2;
  nodes.forEach((nd, k) => { nd.k = k; const p = -2 * Math.PI * iy0 * dky * nd.y, s = -2 * Math.PI * dky * nd.y, w = B.area * (nd.w ?? 1); eyR[k] = Math.cos(p) * w; eyI[k] = Math.sin(p) * w; stR[k] = Math.cos(s); stI[k] = Math.sin(s); });
  const br = new Float64Array(Nf), bi = new Float64Array(Nf), pts = [], sR = [], sI = [];
  for (let r = 0; r < G; r++) {
    if ((r & 7) === 0) await tick(0.7 + 0.15 * r / G);
    const iy = r - G / 2, row = r * G;
    // points of this row that hold data, and the linear fit τ ≈ c + a·kx
    pts.length = 0;
    if (!(skipRow && skipRow[r])) for (let i = 0; i < G; i++) if (W[row + i] !== 0) pts.push(i);
    if (pts.length) {
      let s0 = 0, s1 = 0, s2 = 0, sy = 0, sxy = 0;
      for (const i of pts) { const kx = (i - G / 2) * dkx, y = TU[row + i]; s0++; s1 += kx; s2 += kx * kx; sy += y; sxy += kx * y; }
      const den = s0 * s2 - s1 * s1, a = den > 1e-30 ? (s0 * sxy - s1 * sy) / den : 0, c = (sy - a * s1) / s0;
      // tissue signals at the row's points
      for (let ti = 0; ti < nt; ti++) { sR[ti] = new Float64Array(pts.length); sI[ti] = new Float64Array(pts.length); }
      pts.forEach((i, p) => { const o = row + i; fillTissue(M, M.n, TT[o] + M.infos[TS[o]].tE, TU[o], TS[o]); for (let ti = 0; ti < nt; ti++) { sR[ti][p] = M.TR_[ti][M.n]; sI[ti][p] = M.TI_[ti][M.n]; } });
      for (let ti = 0; ti < nt; ti++) {
        const L = byT[ti]; if (!L.length) continue;
        br.fill(0); bi.fill(0);
        for (const nd of L) {
          const k = nd.k, vr = eyR[k], vi = eyI[k], ph = -2 * Math.PI * nd.df * c, cr = Math.cos(ph), ci = Math.sin(ph);
          deposit1(br, bi, Nf, (nd.x + nd.df * a) / hx, vr * cr - vi * ci, vr * ci + vi * cr);
          deposit1(br, bi, Nf, nd.x / hx, -vr, -vi);
        }
        fftPow2(br, bi, false);
        const sy = sincPi(iy * dky * B.h);
        pts.forEach((i, p) => {
          const m = ((i - G / 2) % Nf + Nf) % Nf, box = sy * sincPi((i - G / 2) * dkx * B.h), cr = br[m] * box, ci = bi[m] * box, o = row + i;
          Kr[o] += sR[ti][p] * cr - sI[ti][p] * ci; Ki[o] += sR[ti][p] * ci + sI[ti][p] * cr;
        });
      }
    }
    for (let k = 0; k < nodes.length; k++) { const t = eyR[k] * stR[k] - eyI[k] * stI[k]; eyI[k] = eyR[k] * stI[k] + eyI[k] * stR[k]; eyR[k] = t; }
  }
}
/* Row classes: rows whose timing follows one global linear model τ = c0 + a·kx + b·ky (within `tol` s) are
   handled together. Every patch then becomes a point shifted by Δf·(a, b) with the phase e^{−i2πΔf c0}, so one
   2D deposit (4×4 Lagrange taps on a 4× oversampled periodic grid) and one 2D FFT per tissue give the
   correction for all rows of the class. Typical classes: the two readout polarities of an EPI train, all
   rows of a GRE or TSE, the filled rows of an accelerated scan. Returns the rows it handled. */
function gridTissue(M, W, TT, TU, TS, G) { // signal density of every tissue at every grid point with data
  if (M._gt && M._gt.W === W) return M._gt;
  const nt = M.tis.length, R = Array.from({ length: nt }, () => new Float64Array(G * G)), I = Array.from({ length: nt }, () => new Float64Array(G * G));
  for (let o = 0; o < G * G; o++) { if (W[o] === 0) continue; fillTissue(M, M.n, TT[o] + M.infos[TS[o]].tE, TU[o], TS[o]); for (let t = 0; t < nt; t++) { R[t][o] = M.TR_[t][M.n]; I[t][o] = M.TI_[t][M.n]; } }
  return (M._gt = { W, R, I });
}
async function bubbleClasses(M, B, Kr, Ki, W, TT, TU, TS, G, dkx, dky, tol) {
  const GT = gridTissue(M, W, TT, TU, TS, G);
  const done = new Uint8Array(G); if (!B.nodes.length) return done;
  // per-row linear fit τ ≈ c + a·kx
  const rows = [];
  for (let r = 0; r < G; r++) {
    const row = r * G; let s0 = 0, s1 = 0, s2 = 0, sy = 0, sxy = 0;
    for (let i = 0; i < G; i++) if (W[row + i] !== 0) { const kx = (i - G / 2) * dkx, y = TU[row + i]; s0++; s1 += kx; s2 += kx * kx; sy += y; sxy += kx * y; }
    if (!s0) continue;
    const den = s0 * s2 - s1 * s1, a = den > 1e-30 ? (s0 * sxy - s1 * sy) / den : 0, c = (sy - a * s1) / s0;
    let res = 0; for (let i = 0; i < G; i++) if (W[row + i] !== 0) res = Math.max(res, Math.abs(TU[row + i] - c - a * (i - G / 2) * dkx));
    rows.push({ r, ky: (r - G / 2) * dky, a, c, res });
  }
  // cluster by slope a, then fit c ≈ c0 + b·ky within each cluster
  const kxMax = G / 2 * dkx, classes = [];
  for (const R of rows) { if (R.res > tol) continue; let C = classes.find(C => Math.abs(C.a - R.a) * kxMax <= tol); if (!C) classes.push(C = { a: R.a, rows: [] }); C.rows.push(R); }
  const Nf = Math.max(64, 1 << Math.ceil(Math.log2((M.opt.bubbleClassOS || 2) * G))), hx = 1 / (dkx * Nf), hy = 1 / (dky * Nf);
  const nt = M.tis.length, byT = Array.from({ length: nt }, () => []); for (const nd of B.nodes) byT[nd.ti].push(nd);
  const LX = new Float64Array(4), LY = new Float64Array(4);
  for (const C of classes) {
    if (C.rows.length < 2) continue;
    let s0 = 0, s1 = 0, s2 = 0, sy = 0, sxy = 0;
    for (const R of C.rows) { s0++; s1 += R.ky; s2 += R.ky * R.ky; sy += R.c; sxy += R.ky * R.c; }
    const den = s0 * s2 - s1 * s1, b = den > 1e-30 ? (s0 * sxy - s1 * sy) / den : 0, c0 = (sy - b * s1) / s0;
    const members = C.rows.filter(R => Math.abs(R.c - c0 - b * R.ky) <= tol); if (members.length < 2) continue;
    for (let ti = 0; ti < nt; ti++) {
      const L = byT[ti]; if (!L.length) continue;
      await tick(0.72);
      const re = new Float64Array(Nf * Nf), im = new Float64Array(Nf * Nf);
      const dep = (u, v, vr, vi) => { // 4×4 Lagrange deposit at fine-grid coordinates (u, v), periodic
        let iu = Math.floor(u), tu = u - iu, iv = Math.floor(v), tv = v - iv;
        const eu = tu < 1e-9 || tu > 1 - 1e-9, ev = tv < 1e-9 || tv > 1 - 1e-9;
        if (tu > 1 - 1e-9) iu++; if (tv > 1 - 1e-9) iv++;
        if (!eu) lagrange4(tu, LX); if (!ev) lagrange4(tv, LY);
        for (let q = 0; q < (ev ? 1 : 4); q++) {
          const wy = ev ? 1 : LY[q], row = ((((iv + (ev ? 0 : q - 1)) % Nf) + Nf) % Nf) * Nf;
          for (let p = 0; p < (eu ? 1 : 4); p++) { const w = wy * (eu ? 1 : LX[p]), col = (((iu + (eu ? 0 : p - 1)) % Nf) + Nf) % Nf; re[row + col] += w * vr; im[row + col] += w * vi; }
        }
      };
      for (const nd of L) {
        const w = B.area * (nd.w ?? 1), ph = -2 * Math.PI * nd.df * c0;
        dep((nd.x + nd.df * C.a) / hx, (nd.y + nd.df * b) / hy, w * Math.cos(ph), w * Math.sin(ph));
        dep(nd.x / hx, nd.y / hy, -w, 0);
      }
      fft2cols(re, im, Nf, neededCols(G, Nf));
      for (const R of members) {
        const row = R.r * G, iy = R.r - G / 2, m2 = ((iy % Nf) + Nf) % Nf, sy = sincPi(iy * dky * B.h);
        for (let i = 0; i < G; i++) {
          const o = row + i; if (W[o] === 0) continue;
          const ix = i - G / 2, bin = m2 * Nf + (((ix % Nf) + Nf) % Nf), box = sy * sincPi(ix * dkx * B.h);
          const Sr = GT.R[ti][o], Si = GT.I[ti][o], cr = re[bin] * box, ci = im[bin] * box;
          Kr[o] += Sr * cr - Si * ci; Ki[o] += Sr * ci + Si * cr;
        }
      }
    }
    for (const R of members) done[R.r] = 1;
  }
  return done;
}

/* Non-Cartesian: exact direct sum, with phases advanced by complex multiplication. Within one ADC the
   dephasing time steps by a constant, and the patches sit on a lattice, so e^{−i2πΔf τ} and the separable
   spatial phases e^{−i2π kx x}·e^{−i2π ky y} need only a few trigonometric evaluations per sample. */
/* core of the direct sum over packed arrays: patches (x, y, lattice i, j, Δf, tissue, weight) and a contiguous
   range of samples (k, τ, tissue signals) split into readouts at ev; returns the increments of the samples */
function bubbleDirectCore(a) {
  const N = a.df.length, n = a.kx.length, nb = a.nb, dR = new Float64Array(n), dI = new Float64Array(n);
  const exR = new Float64Array(nb), exI = new Float64Array(nb), eyR = new Float64Array(nb), eyI = new Float64Array(nb);
  const pzR = new Float64Array(N), pzI = new Float64Array(N), dzR = new Float64Array(N), dzI = new Float64Array(N);
  for (let e = 0; e + 1 < a.ev.length; e++) {
    const q0 = a.ev[e], q1 = a.ev[e + 1]; if (q1 <= q0) continue;
    const dtau = q1 - q0 > 1 ? a.tau[q0 + 1] - a.tau[q0] : 0;
    for (let k = 0; k < N; k++) { const ph = -2 * Math.PI * a.df[k] * a.tau[q0], d = -2 * Math.PI * a.df[k] * dtau; pzR[k] = Math.cos(ph); pzI[k] = Math.sin(ph); dzR[k] = Math.cos(d); dzI[k] = Math.sin(d); }
    for (let q = q0; q < q1; q++) {
      if (q > q0 && ((q - q0) & 63) === 0) for (let k = 0; k < N; k++) { const ph = -2 * Math.PI * a.df[k] * a.tau[q]; pzR[k] = Math.cos(ph); pzI[k] = Math.sin(ph); } // re-anchor
      const kx = a.kx[q], ky = a.ky[q];
      let ph = -2 * Math.PI * kx * a.x0, st = -2 * Math.PI * kx * a.h, cr = Math.cos(ph), ci = Math.sin(ph); const sr = Math.cos(st), si = Math.sin(st);
      for (let i = 0; i < nb; i++) { exR[i] = cr; exI[i] = ci; const t = cr * sr - ci * si; ci = cr * si + ci * sr; cr = t; }
      ph = -2 * Math.PI * ky * a.y0; st = -2 * Math.PI * ky * a.h; cr = Math.cos(ph); ci = Math.sin(ph); const sr2 = Math.cos(st), si2 = Math.sin(st);
      for (let j = 0; j < nb; j++) { eyR[j] = cr; eyI[j] = ci; const t = cr * sr2 - ci * si2; ci = cr * si2 + ci * sr2; cr = t; }
      let accR = 0, accI = 0;
      for (let k = 0; k < N; k++) {
        const ti = a.ti[k], wq = a.w[k], TRq = a.TR[ti][q] * wq, TIq = a.TI[ti][q] * wq;
        const er = pzR[k] - 1, ei = pzI[k], xr = TRq * er - TIq * ei, xi = TRq * ei + TIq * er;
        const I = a.pi[k], J = a.pj[k], gr = exR[I] * eyR[J] - exI[I] * eyI[J], gi = exR[I] * eyI[J] + exI[I] * eyR[J];
        accR += xr * gr - xi * gi; accI += xr * gi + xi * gr;
        const t = pzR[k] * dzR[k] - pzI[k] * dzI[k]; pzI[k] = pzR[k] * dzI[k] + pzI[k] * dzR[k]; pzR[k] = t;
      }
      const box = sincPi(kx * a.h) * sincPi(ky * a.h); dR[q] = accR * a.area * box; dI[q] = accI * a.area * box;
    }
  }
  return { dR, dI };
}
/* Non-Cartesian: exact direct sum near the sphere, with phases advanced by complex multiplication (within one
   ADC the dephasing time steps by a constant, and the patches sit on a lattice, so e^{−i2πΔf τ} and the
   separable spatial phases need only a few trigonometric evaluations per sample). Split over the workers by
   readouts. */
async function bubbleDirectFast(M, B, SR, SI) {
  const nodes = B.nodes, N = nodes.length; if (!N) return;
  const df = new Float64Array(N), w = new Float64Array(N), pi = new Int32Array(N), pj = new Int32Array(N), ti = new Int32Array(N);
  nodes.forEach((nd, k) => { df[k] = nd.df; w[k] = nd.w ?? 1; pi[k] = nd.i; pj[k] = nd.j; ti[k] = nd.ti; });
  const ev = M.EVS, parts = nChunks(M.n * N / 50), per = M.n / parts, tasks = [];
  let e0 = 0;
  for (let p = 0; p < parts && e0 + 1 < ev.length; p++) {
    let e1 = e0 + 1; while (e1 + 1 < ev.length && ev[e1] < (p + 1) * per) e1++; if (p === parts - 1) e1 = ev.length - 1;
    const q0 = ev[e0], q1 = ev[e1]; if (q1 <= q0) { e0 = e1; continue; }
    tasks.push({ q0, arg: { df, w, pi, pj, ti, nb: B.nb, x0: B.x0, y0: B.y0, h: B.h, area: B.area,
      kx: Float64Array.from(M.KX.slice(q0, q1)), ky: Float64Array.from(M.KY.slice(q0, q1)), tau: Float64Array.from(M.TAU.slice(q0, q1)),
      ev: Int32Array.from(ev.slice(e0, e1 + 1).map(x => x - q0)), TR: M.TR_.map(A => A.slice(q0, q1)), TI: M.TI_.map(A => A.slice(q0, q1)) } });
    e0 = e1;
  }
  const res = await parMap('bubbleDirect', tasks.map(t => t.arg), 0.65, 0.85);
  res.forEach((r, i) => { const q0 = tasks[i].q0; for (let q = 0; q < r.dR.length; q++) { SR[q0 + q] += r.dR[q]; SI[q0 + q] += r.dI[q]; } });
}

/* Far field (phase below NEAR over the whole readout): e^{−i2πΔfτ} − 1 = Σ_{p≥1} (−i2πτ)^p Δf^p / p!, so each
   tissue's correction is Σ_p (−i2πτ(k))^p/p! · FT[w·Δf^p](k): per order one 2D FFT of a field-weighted tissue map
   on the image lattice (spacing FOV/G, wrapped like the acquisition). With |phase| < 1 rad, 6 terms leave < 0.02 %. */
/* 2D forward FFT that transforms only non-empty rows and then only the columns listed in cols
   (the others are left partially transformed and must not be read) */
function fft2cols(re, im, N, cols) {
  const r = new Float64Array(N), i = new Float64Array(N);
  for (let a = 0; a < N; a++) {
    const o = a * N; let any = false;
    for (let b = 0; b < N; b++) if (re[o + b] !== 0 || im[o + b] !== 0) { any = true; break; }
    if (!any) continue;
    for (let b = 0; b < N; b++) { r[b] = re[o + b]; i[b] = im[o + b]; }
    fftPow2(r, i, false);
    for (let b = 0; b < N; b++) { re[o + b] = r[b]; im[o + b] = i[b]; }
  }
  for (const a of cols) {
    for (let b = 0; b < N; b++) { r[b] = re[b * N + a]; i[b] = im[b * N + a]; }
    fftPow2(r, i, false);
    for (let b = 0; b < N; b++) { re[b * N + a] = r[b]; im[b * N + a] = i[b]; }
  }
}
function neededCols(G, N) { const c = []; for (let ix = -G / 2; ix < G / 2; ix++) c.push(((ix % N) + N) % N); return c; }
function fft2(re, im, N) {
  const r = new Float64Array(N), i = new Float64Array(N);
  for (let pass = 0; pass < 2; pass++) for (let a = 0; a < N; a++) {
    for (let b = 0; b < N; b++) { const o = pass ? b * N + a : a * N + b; r[b] = re[o]; i[b] = im[o]; }
    fftPow2(r, i, false);
    for (let b = 0; b < N; b++) { const o = pass ? b * N + a : a * N + b; re[o] = r[b]; im[o] = i[b]; }
  }
}
async function bubbleFar(M, Kr, Ki, W, TT, TU, TS, G, dkx, dky, NEAR, P) {
  const Gf = G * (M.opt.bubbleFarOS || 2); // map lattice: FOV/Gf (oversampled against the image lattice)
  const ph = M.ph, B0 = M.opt.B0, tmax = bubbleTmax(M), hx = 1 / (dkx * Gf), hy = 1 / (dky * Gf), area = hx * hy, nt = M.tis.length;
  let ext = 0; for (const r of ph.regions) ext = Math.max(ext, Math.abs(r.x0) + Math.max(r.a, r.b), Math.abs(r.y0) + Math.max(r.a, r.b));
  const maps = []; // maps[t][p] (re only; the weights are real)
  const iMax = Math.ceil(ext / hx), jMax = Math.ceil(ext / hy); let count = 0;
  for (let j = -jMax; j <= jMax; j++) {
    if ((j & 15) === 0) await tick(0.85 + 0.05 * (j + jMax) / (2 * jMax));
    const y = j * hy, cj = ((j % Gf) + Gf) % Gf;
    for (let i = -iMax; i <= iMax; i++) {
      const x = i * hx;
      for (const c of patchContent(ph, B0, x, y, Math.min(hx, hy))) {
        const df = c.df; if (df === 0 || Math.abs(df) * 2 * Math.PI * tmax > NEAR) continue;
        const t = M.tIdx.get(c.tn); if (!maps[t]) maps[t] = Array.from({ length: P + 1 }, () => new Float64Array(Gf * Gf));
        const o = cj * Gf + (((i % Gf) + Gf) % Gf); let v = area * c.frac;
        for (let p = 1; p <= P; p++) { v *= df; maps[t][p][o] += v; }
        count++;
      }
    }
  }
  const F = []; // F[t][p] = {re, im}
  const cols = neededCols(G, Gf), jobs = [];
  for (let t = 0; t < nt; t++) if (maps[t]) { F[t] = []; for (let p = 1; p <= P; p++) jobs.push({ t, p, arg: { re: maps[t][p], im: new Float64Array(Gf * Gf), N: Gf, cols } }); }
  const done = await parMap('fft2', jobs.map(j => j.arg), 0.86, 0.92);
  done.forEach((r, i) => { F[jobs[i].t][jobs[i].p] = { re: r.re, im: r.im }; });
  await tick(0.93);
  const fact = [1]; for (let p = 1; p <= P; p++) fact[p] = fact[p - 1] * p;
  const GT = gridTissue(M, W, TT, TU, TS, G);
  for (let o = 0; o < G * G; o++) {
    if (W[o] === 0) continue;
    const ix = (o % G) - G / 2, iy = Math.floor(o / G) - G / 2, bin = (((iy % Gf) + Gf) % Gf) * Gf + (((ix % Gf) + Gf) % Gf);
    // c_p = (−i2πτ)^p / p!
    const z = -2 * Math.PI * TU[o]; let cr = 1, ci = 0; const CR = [], CI = [];
    for (let p = 1; p <= P; p++) { const t2 = -ci * z; ci = cr * z; cr = t2; CR[p] = cr / fact[p]; CI[p] = ci / fact[p]; } // multiply by i·z each step
    let ar = 0, ai = 0; const box = sincPi(ix * dkx * hx) * sincPi(iy * dky * hy);
    for (let t = 0; t < nt; t++) {
      if (!F[t]) continue;
      let sr = 0, si = 0;
      for (let p = 1; p <= P; p++) { const fr = F[t][p].re[bin], fi = F[t][p].im[bin]; sr += CR[p] * fr - CI[p] * fi; si += CR[p] * fi + CI[p] * fr; }
      const Sr = GT.R[t][o], Si = GT.I[t][o];
      ar += Sr * sr - Si * si; ai += Sr * si + Si * sr;
    }
    Kr[o] += ar * box; Ki[o] += ai * box;
  }
  return { count, P };
}

/* overlap corrections (see overlapPatches) */
async function overlapGrid(M, Kr, Ki, W, TT, TU, TS, G, dkx, dky) {
  const P = M.corr; if (!P.length) return;
  const Nf = Math.max(64, 1 << Math.ceil(Math.log2(2 * G))), hx = 1 / (dkx * Nf), hy = 1 / (dky * Nf), nt = M.tis.length;
  const GT = gridTissue(M, W, TT, TU, TS, G), LX = new Float64Array(4), LY = new Float64Array(4), cols = neededCols(G, Nf);
  const byT = Array.from({ length: nt }, () => []); for (const p of P) byT[p.ti].push(p);
  for (let t = 0; t < nt; t++) {
    const L = byT[t]; if (!L.length) continue;
    await tick(0.7);
    const re = new Float64Array(Nf * Nf), im = new Float64Array(Nf * Nf), hbox = L[0].h;
    for (const p of L) { // 4×4 Lagrange deposit on the periodic fine grid
      const u = p.x / hx, v = p.y / hy, iu = Math.floor(u), iv = Math.floor(v); lagrange4(u - iu, LX); lagrange4(v - iv, LY);
      for (let a = 0; a < 4; a++) { const row = ((((iv - 1 + a) % Nf) + Nf) % Nf) * Nf; for (let b = 0; b < 4; b++) re[row + ((((iu - 1 + b) % Nf) + Nf) % Nf)] += LY[a] * LX[b] * p.w; }
    }
    fft2cols(re, im, Nf, cols);
    for (let o = 0; o < G * G; o++) {
      if (W[o] === 0) continue;
      const ix = (o % G) - G / 2, iy = Math.floor(o / G) - G / 2, bin = (((iy % Nf) + Nf) % Nf) * Nf + (((ix % Nf) + Nf) % Nf);
      const box = sincPi(ix * dkx * hbox) * sincPi(iy * dky * hbox), cr = re[bin] * box, ci = im[bin] * box, Sr = GT.R[t][o], Si = GT.I[t][o];
      Kr[o] += Sr * cr - Si * ci; Ki[o] += Sr * ci + Si * cr;
    }
  }
}
/* non-Cartesian: the overlap correction through FFT maps (one per tissue) read at the samples' k by 4×4
   Lagrange interpolation, as for the bubble's far field (a direct sum over patches × samples is far too slow) */
async function overlapSamples(M, SR, SI) {
  const P = M.corr; if (!P.length) return;
  let ext = 0; for (const r of M.ph.regions) ext = Math.max(ext, Math.abs(r.x0) + Math.max(r.a, r.b), Math.abs(r.y0) + Math.max(r.a, r.b));
  let kmax = 0; for (let q = 0; q < M.n; q++) kmax = Math.max(kmax, Math.abs(M.KX[q]), Math.abs(M.KY[q]));
  const L = 4 * ext, hm = Math.max(0.125 / Math.max(kmax, 1e-6), L / 1024), Nf = Math.max(64, 1 << Math.ceil(Math.log2(L / hm))), dk = 1 / (Nf * hm);
  const nt = M.tis.length, maps = [], LX = new Float64Array(4), LY = new Float64Array(4);
  for (const p of P) { // deposit each patch (area weight p.w) on the map lattice
    if (!maps[p.ti]) maps[p.ti] = new Float64Array(Nf * Nf);
    const u = p.x / hm, v = p.y / hm, iu = Math.floor(u), iv = Math.floor(v); lagrange4(u - iu, LX); lagrange4(v - iv, LY);
    for (let a2 = 0; a2 < 4; a2++) { const row = ((((iv - 1 + a2) % Nf) + Nf) % Nf) * Nf; for (let b2 = 0; b2 < 4; b2++) maps[p.ti][row + ((((iu - 1 + b2) % Nf) + Nf) % Nf)] += LY[a2] * LX[b2] * p.w; }
  }
  const jobs = []; for (let t = 0; t < nt; t++) if (maps[t]) jobs.push({ t, arg: { re: maps[t], im: new Float64Array(Nf * Nf), N: Nf } });
  const F = []; (await parMap('fft2', jobs.map(j => j.arg), 0.65, 0.7)).forEach((r, i) => { F[jobs[i].t] = r; });
  const hp = P[0].h;
  for (let q = 0; q < M.n; q++) {
    if ((q & 4095) === 0) await tick(0.7 + 0.02 * q / M.n);
    const u = M.KX[q] / dk, v = M.KY[q] / dk, iu = Math.floor(u), iv = Math.floor(v); lagrange4(u - iu, LX); lagrange4(v - iv, LY);
    const box = sincPi(M.KX[q] * hp) * sincPi(M.KY[q] * hp); let ar = 0, ai = 0;
    for (let t = 0; t < nt; t++) {
      if (!F[t]) continue; let fr = 0, fi = 0;
      for (let a2 = 0; a2 < 4; a2++) { const row = ((((iv - 1 + a2) % Nf) + Nf) % Nf) * Nf; for (let b2 = 0; b2 < 4; b2++) { const w = LY[a2] * LX[b2], o = row + ((((iu - 1 + b2) % Nf) + Nf) % Nf); fr += w * F[t].re[o]; fi += w * F[t].im[o]; } }
      const Sr = M.TR_[t][q], Si = M.TI_[t][q]; ar += Sr * fr - Si * fi; ai += Sr * fi + Si * fr;
    }
    SR[q] += ar * box; SI[q] += ai * box;
  }
}

/* Far field for non-Cartesian samples: the same series as bubbleFar, but each order's map is transformed on a
   grid covering twice the phantom's extent (k spacing half that needed), and read at the samples' k by 4×4
   Lagrange interpolation. */
async function bubbleFarSamples(M, SR, SI, NEAR, P, hNode) {
  const ph = M.ph, B0 = M.opt.B0, tmax = bubbleTmax(M), nt = M.tis.length;
  let ext = 0; for (const r of ph.regions) ext = Math.max(ext, Math.abs(r.x0) + Math.max(r.a, r.b), Math.abs(r.y0) + Math.max(r.a, r.b));
  let kmax = 0; for (let q = 0; q < M.n; q++) kmax = Math.max(kmax, Math.abs(M.KX[q]), Math.abs(M.KY[q]));
  // lattice ¼ pixel (as the near patches) but the map at most 1024² over 3× the phantom's extent
  const L = 3 * ext, h = Math.max(hNode * (M.opt.bubbleFarH || 1), 0.125 / Math.max(kmax, 1e-6), L / 1024), Nf = Math.max(64, 1 << Math.ceil(Math.log2(L / h))), dk = 1 / (Nf * h);
  const maps = []; let count = 0; const iMax = Math.ceil(ext / h);
  for (let j = -iMax; j <= iMax; j++) {
    if ((j & 15) === 0) await tick(0.85 + 0.05 * (j + iMax) / (2 * iMax));
    const y = j * h, cj = ((j % Nf) + Nf) % Nf;
    for (let i = -iMax; i <= iMax; i++) {
      const x = i * h;
      for (const c of patchContent(ph, B0, x, y, h)) {
        const df = c.df; if (df === 0 || Math.abs(df) * 2 * Math.PI * tmax > NEAR) continue;
        const t = M.tIdx.get(c.tn); if (!maps[t]) maps[t] = Array.from({ length: P + 1 }, () => new Float64Array(Nf * Nf));
        const o = cj * Nf + (((i % Nf) + Nf) % Nf); let v = h * h * c.frac;
        for (let p = 1; p <= P; p++) { v *= df; maps[t][p][o] += v; }
        count++;
      }
    }
  }
  const F = [], jobs = [];
  for (let t = 0; t < nt; t++) if (maps[t]) { F[t] = []; for (let p = 1; p <= P; p++) jobs.push({ t, p, arg: { re: maps[t][p], im: new Float64Array(Nf * Nf), N: Nf } }); }
  const done = await parMap('fft2', jobs.map(j => j.arg), 0.9, 0.93);
  done.forEach((r, i) => { F[jobs[i].t][jobs[i].p] = { re: r.re, im: r.im }; });
  const fact = [1]; for (let p = 1; p <= P; p++) fact[p] = fact[p - 1] * p;
  const LX = new Float64Array(4), LY = new Float64Array(4), CR = [], CI = [];
  for (let q = 0; q < M.n; q++) {
    if ((q & 4095) === 0) await tick(0.93 + 0.05 * q / M.n);
    const u = M.KX[q] / dk, v = M.KY[q] / dk, iu = Math.floor(u), iv = Math.floor(v); lagrange4(u - iu, LX); lagrange4(v - iv, LY);
    const z = -2 * Math.PI * M.TAU[q]; let cr = 1, ci = 0;
    for (let p = 1; p <= P; p++) { const t2 = -ci * z; ci = cr * z; cr = t2; CR[p] = cr / fact[p]; CI[p] = ci / fact[p]; }
    const box = sincPi(M.KX[q] * h) * sincPi(M.KY[q] * h); let ar = 0, ai = 0;
    for (let t = 0; t < nt; t++) {
      if (!F[t]) continue; let sr = 0, si = 0;
      for (let p = 1; p <= P; p++) {
        const Fr = F[t][p].re, Fi = F[t][p].im; let fr = 0, fi = 0;
        for (let a = 0; a < 4; a++) { const row = ((((iv - 1 + a) % Nf) + Nf) % Nf) * Nf; for (let b = 0; b < 4; b++) { const w = LY[a] * LX[b], o = row + ((((iu - 1 + b) % Nf) + Nf) % Nf); fr += w * Fr[o]; fi += w * Fi[o]; } }
        sr += CR[p] * fr - CI[p] * fi; si += CR[p] * fi + CI[p] * fr;
      }
      const Sr = M.TR_[t][q], Si = M.TI_[t][q]; ar += Sr * sr - Si * si; ai += Sr * si + Si * sr;
    }
    SR[q] += ar * box; SI[q] += ai * box;
  }
  return { count, P, Nf };
}

/* exact references (slow; used to test the fast methods) */
async function bubbleExactSamples(M, B, SR, SI) {
  let ni = 0;
  for (const nd of B.nodes) {
    if ((ni++ & 15) === 0) await tick(0.65 + 0.2 * ni / B.nodes.length);
    const Tr = M.TR_[nd.ti], Ti = M.TI_[nd.ti], wA0 = B.area * (nd.w ?? 1);
    for (let q = 0; q < M.n; q++) {
      const wA = wA0 * sincPi(M.KX[q] * B.h) * sincPi(M.KY[q] * B.h);
      const p = -2 * Math.PI * (M.KX[q] * nd.x + M.KY[q] * nd.y), a = -2 * Math.PI * nd.df * M.TAU[q];
      const er = Math.cos(a) - 1, ei = Math.sin(a), cr = Math.cos(p) * wA, ci = Math.sin(p) * wA;
      const xr = Tr[q] * er - Ti[q] * ei, xi = Tr[q] * ei + Ti[q] * er;
      SR[q] += xr * cr - xi * ci; SI[q] += xr * ci + xi * cr;
    }
  }
}
async function bubbleExactGrid(M, B, Kr, Ki, W, TT, TU, TS, G, dkx, dky) {
  for (let o = 0; o < G * G; o++) {
    if (W[o] === 0) continue;
    if ((o & 255) === 0) await tick(0.7 + 0.15 * o / (G * G));
    const ix = (o % G) - G / 2, iy = Math.floor(o / G) - G / 2, kx = ix * dkx, ky = iy * dky;
    fillTissue(M, M.n, TT[o] + M.infos[TS[o]].tE, TU[o], TS[o]);
    let ar = 0, ai = 0;
    for (const nd of B.nodes) {
      const wf = nd.w ?? 1, Sr = M.TR_[nd.ti][M.n] * wf, Si = M.TI_[nd.ti][M.n] * wf;
      const p = -2 * Math.PI * (kx * nd.x + ky * nd.y), a = -2 * Math.PI * nd.df * TU[o];
      const er = Math.cos(a) - 1, ei = Math.sin(a), cr = Math.cos(p), ci = Math.sin(p);
      const xr = Sr * er - Si * ei, xi = Sr * ei + Si * er;
      ar += xr * cr - xi * ci; ai += xr * ci + xi * cr;
    }
    const box = sincPi(kx * B.h) * sincPi(ky * B.h);
    Kr[o] += ar * B.area * box; Ki[o] += ai * B.area * box;
  }
}

/* ---------- reconstruction onto a Cartesian grid ---------- */
function fftPow2(re, im, inv) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) { let bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) { let t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (inv ? 2 : -2) * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let j = 0; j < len / 2; j++) {
        const a = i + j, b2 = a + len / 2, tr = re[b2] * cr - im[b2] * ci, ti = re[b2] * ci + im[b2] * cr;
        re[b2] = re[a] - tr; im[b2] = im[a] - ti; re[a] += tr; im[a] += ti;
        const nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
      }
    }
  }
}
function ifft2c(Kr, Ki, N) { // centred 2D inverse FFT of an N×N grid (N power of 2), in place
  const r = new Float64Array(N), i = new Float64Array(N);
  for (let pass = 0; pass < 2; pass++) for (let a = 0; a < N; a++) {
    for (let b = 0; b < N; b++) { const o = pass ? b * N + a : a * N + b, q = (b + N / 2) % N; r[q] = Kr[o]; i[q] = Ki[o]; }
    fftPow2(r, i, true);
    for (let b = 0; b < N; b++) { const o = pass ? b * N + a : a * N + b, q = (b + N / 2) % N; Kr[o] = r[q]; Ki[o] = i[q]; }
  }
}
function median(a) { const b = Float64Array.from(a).sort(); return b.length ? b[b.length >> 1] : 0; }
/* run the whole thing: returns image, sampling mask and a summary */
async function runSimulation(seq, shots, vol, refShot, opt, onTick) {
  SIM_TICK = onTick || null;
  try { const r = await runSimulation_(seq, shots, vol, refShot, opt); return r && !r.error && r.swapDisplay ? transposeResult(r) : r; } finally { SIM_TICK = null; }
}
/* show the other image axis horizontally: transpose image, mask and k-space, and swap the per-axis numbers */
function transposeResult(r) {
  const tr = (A, G) => { const B = new A.constructor(A.length); for (let j = 0; j < G; j++) for (let i = 0; i < G; i++) B[i * G + j] = A[j * G + i]; return B; };
  const I = r.img, G = I.G, Gk = r.kspace.G;
  r.img = { ...I, re: tr(I.re, G), im: tr(I.im, G), fovX: I.fovY, fovY: I.fovX, px: I.py, py: I.px, cropX: I.cropY, cropY: I.cropX };
  r.mask = tr(r.mask, Gk); r.kspace = { re: tr(r.kspace.re, Gk), im: tr(r.kspace.im, Gk), G: Gk, dkx: r.kspace.dky, dky: r.kspace.dkx };
  [r.bwX, r.bwY] = [r.bwY, r.bwX]; [r.fatX, r.fatY] = [r.fatY, r.fatX]; r.roAxis = 1 - r.roAxis; r.axes = r.axes[1] + r.axes[0];
  [r.dispW, r.dispH] = [r.dispH, r.dispW];
  if (r.eddy) r.eddy = { ...r.eddy, echoX: r.eddy.echoY, echoY: r.eddy.echoX, maxX: r.eddy.maxY, maxY: r.eddy.maxX };
  r.geom = { ...r.geom, e1: r.geom.e2, e2: r.geom.e1, e1s: r.geom.e2s, e2s: r.geom.e1s };
  return r;
}
async function runSimulation_(seq, shots, vol, refShot, opt) {
  const t0 = Date.now(); SIM_ENGINE = 'CPU';
  await tick(0);
  const M = await simulateImage(seq, shots, vol, refShot, opt); if (M.error) return M;
  const n = M.n;
  // grid: Δk from the FOV definition when present, else from the sampling. The definition gives the FOV along the
  // sequence's x, y and z. It applies to an image axis only when every sequence axis that image axis has a component
  // along has the same FOV: an axis along x, or any in-plane direction when the FOV is the same in x and y (radial),
  // but not the readout of a stack rotated between x (220 mm) and z (the slab). And only when it agrees with the sampling: along the readout the sample
  // spacing may be finer than 1/FOV (oversampling, up to 8×) but not coarser; across Cartesian lines the line spacing
  // may be coarser (parallel imaging, up to 8×) but not finer. Without these checks a stack rotated so that its readout
  // ran mostly along z took the slab thickness as its FOV (an image of 8 pixels across).
  const est = arr => { const u = [...new Set(Array.from(arr, v => Math.round(v * 1e6)))].sort((a, b) => a - b), d = []; for (let i = 1; i < u.length; i++) d.push((u[i] - u[i - 1]) * 1e-6); return median(d.filter(x => x > 1e-6)); };
  const EVS_ = M.EVS, roY = n > 1 && Math.abs(M.KY[1] - M.KY[0]) > Math.abs(M.KX[1] - M.KX[0]);
  // sample spacing along the readout within ADC events; the flat top sets it (ramp samples lie closer): 90th percentile
  const spRO = (() => { const K = roY ? M.KY : M.KX, d = []; for (let e = 0; e + 1 < EVS_.length && d.length < 20000; e++) for (let q = EVS_[e] + 1; q < EVS_[e + 1]; q++) { const v = Math.abs(K[q] - K[q - 1]); if (v > 1e-9) d.push(v); } return d.length ? Float64Array.from(d).sort()[Math.floor(0.9 * (d.length - 1))] : 0; })();
  // spacing of Cartesian lines across the readout (0 when the lines are not Cartesian, e.g. radial)
  const spLine = (() => {
    const K = roY ? M.KX : M.KY; let mx = 0; for (let q = 0; q < n; q++) mx = Math.max(mx, Math.abs(K[q])); if (!(mx > 0)) return 0;
    const tol = mx * 1e-3, v = []; let bad = 0;
    for (let e = 0; e + 1 < EVS_.length; e++) { const a = EVS_[e], b = EVS_[e + 1]; if (b <= a) continue; let lo = Infinity, hi = -Infinity; for (let q = a; q < b; q++) { if (K[q] < lo) lo = K[q]; if (K[q] > hi) hi = K[q]; } if (hi - lo > tol) bad++; else v.push((lo + hi) / 2); }
    if (bad > 0.1 * (bad + v.length) || v.length < 2) return 0;
    // lines closer than tol are the same line (repeats, other shots); the spacing is the median step between the
    // distinct lines, from their actual positions (rounding them to tol would bias it by up to tol / spacing)
    v.sort((a, b) => a - b); const L = []; let s0 = v[0], sn = 1, last = v[0];
    for (let i = 1; i < v.length; i++) { if (v[i] - last > tol) { L.push(s0 / sn); s0 = 0; sn = 0; } s0 += v[i]; sn++; last = v[i]; }
    L.push(s0 / sn); if (L.length < 2) return 0;
    const d = []; for (let i = 1; i < L.length; i++) d.push(L[i] - L[i - 1]); return median(d);
  })();
  let fovX = null, fovY = null;
  const D = Array.isArray(seq.defs.FOV) ? seq.defs.FOV : null, G_ = M.geom || {};
  const fovAlong = e => { // mm, or 0 when the definition does not give one FOV along e
    if (!e || !D || D.length < 2) return 0; let f = 0;
    for (let i = 0; i < 3; i++) { if (Math.abs(e[i]) < 1e-3) continue; const v = D[i]; if (!(v > 0)) return 0; if (f && Math.abs(v - f) > 1e-6 * f) return 0; f = v; }
    return f * 1e3;
  };
  const fx = fovAlong(G_.e1s), fy = fovAlong(G_.e2s);
  { // each image axis separately: a rotated readout may have no FOV in the definition while the phase encoding has
    const fRO = roY ? fy : fx, fPE = roY ? fx : fy;
    const okRO = fRO > 0 && (!spRO || (fRO * spRO >= 1 / 8 && fRO * spRO <= 1.05)), okPE = fPE > 0 && (!spLine || (fPE * spLine >= 0.95 && fPE * spLine <= 8.05));
    if (okRO) { if (roY) fovY = fy; else fovX = fx; }
    if (okPE) { if (roY) fovX = fx; else fovY = fy; }
  }
  // without a usable definition: the sample spacing along the readout, and the line spacing across it (Cartesian) or
  // the readout spacing again (non-Cartesian: radial, spiral), which is the FOV the sampling itself supports
  const sRO = spRO || est(roY ? M.KY : M.KX), sPE = spLine || sRO || est(roY ? M.KX : M.KY);
  let dky = fovY ? 1 / fovY : (roY ? sRO : sPE) || 1e-3, dkx = fovX ? 1 / fovX : ((roY ? sPE : sRO) || dky);
  // readout oversampling: along the readout (the axis consecutive samples move along), compare the sample spacing
  // within ADC events with the prescribed FOV. If oversampled, reconstruct the full sampled FOV (so that objects
  // outside the prescribed FOV do not fold in); cropping to the prescribed FOV is then a display step (img.cropX/Y).
  let osRO = 1, osAxis = -1;
  if (fovX && fovY && n > 1) {
    const sp = spRO, fovRO = roY ? fovY : fovX; // flat-top sample spacing along the readout (see above)
    if (sp > 0) { const s = Math.round(1 / (fovRO * sp) * 20) / 20; if (s >= 1.1 && s <= 8) { osRO = s; osAxis = roY ? 1 : 0; if (roY) dky = 1 / (s * fovY); else dkx = 1 / (s * fovX); } }
  }
  let maxX = 0, maxY = 0; for (let q = 0; q < n; q++) { maxX = Math.max(maxX, Math.abs(M.KX[q])); maxY = Math.max(maxY, Math.abs(M.KY[q])); }
  let Nx = Math.max(8, 2 * Math.ceil(maxX / dkx - 0.49)), Ny = Math.max(8, 2 * Math.ceil(maxY / dky - 0.49));
  // Cartesian in ky?
  let onGrid = 0; for (let q = 0; q < n; q++) { const v = M.KY[q] / dky; if (Math.abs(v - Math.round(v)) < 0.05) onGrid++; }
  const cart = onGrid > 0.95 * n;
  let bub = null;
  const hNode = Math.min(1 / (2 * maxX || 1), 1 / (2 * maxY || 1)) * (opt.bubbleH || 0.25); // bubble patches: ¼ pixel, refined near the surface
  const NEAR = opt.bubbleNear || 1.0;  // rad: nearer patches exactly, the rest by a power series in the phase
  const G = Math.max(16, 1 << Math.ceil(Math.log2(Math.max(Nx, Ny)))); // (a line beyond ±G/2 would be dropped)
  const Kr = new Float64Array(G * G), Ki = new Float64Array(G * G), W = new Float64Array(G * G), acq = new Uint8Array(G);
  const TT = new Float64Array(G * G), TU = new Float64Array(G * G), TS = new Float64Array(G * G), DWg = new Float64Array(G * G); // timing on the grid
  const EX = M.DKX ? [new Float64Array(G * G), new Float64Array(G * G), new Float64Array(G * G)] : null; // eddy Δkx, Δky, phase on the grid
  const put = (ix, iy, re, im, w, t, tau, si, dw, ex) => {
    if (ix < -G / 2 || ix >= G / 2 || iy < -G / 2 || iy >= G / 2) return;
    const o = (iy + G / 2) * G + (ix + G / 2); Kr[o] += re * w; Ki[o] += im * w; W[o] += w; TT[o] += (t - M.infos[si].tE) * w; /* time since its own excitation */ TU[o] += tau * w; TS[o] += si * w; DWg[o] += dw * w;
    if (EX && ex) { EX[0][o] += ex[0] * w; EX[1][o] += ex[1] * w; EX[2][o] += ex[2] * w; }
  };
  let SR = null, SI = null;
  if (cart) {
    // Each k-space row (one ky line of one ADC event) is evaluated exactly at the grid positions it covers,
    // with the sample timing interpolated along the row: the ideal regridding of the acquired data.
    const EVS = M.EVS; let done = 0;
    for (let e = 0; e + 1 < EVS.length; e++) {
      const q0 = EVS[e], q1 = EVS[e + 1]; if (q1 <= q0) continue;
      const rows = new Map();
      for (let q = q0; q < q1; q++) { const iy = Math.round(M.KY[q] / dky); (rows.get(iy) || rows.set(iy, []).get(iy)).push(q); }
      for (const [iy, qs] of rows) {
        if ((done++ & 63) === 0) await tick(0.25 + 0.4 * q0 / n);
        qs.sort((a2, b2) => M.KX[a2] - M.KX[b2]);
        if (iy >= -G / 2 && iy < G / 2) acq[iy + G / 2] = 1;
        const kmin = M.KX[qs[0]], kmax = M.KX[qs[qs.length - 1]];
        for (let ix = Math.ceil((kmin - 0.5 * dkx) / dkx); ix <= Math.floor((kmax + 0.5 * dkx) / dkx); ix++) {
          const kx = ix * dkx; let lo = 0, hi = qs.length - 1;
          while (hi - lo > 1) { const m = (lo + hi) >> 1; if (M.KX[qs[m]] <= kx) lo = m; else hi = m; }
          const a2 = qs[lo], b2 = qs[hi], d = M.KX[b2] - M.KX[a2], f = d > 1e-12 ? Math.min(1, Math.max(0, (kx - M.KX[a2]) / d)) : 0;
          const t = M.T[a2] + (M.T[b2] - M.T[a2]) * f, tau = M.TAU[a2] + (M.TAU[b2] - M.TAU[a2]) * f, si = M.SH[a2];
          const ex = EX ? [M.DKX[a2] + (M.DKX[b2] - M.DKX[a2]) * f, M.DKY[a2] + (M.DKY[b2] - M.DKY[a2]) * f, M.PHI[a2] + (M.PHI[b2] - M.PHI[a2]) * f] : null;
          put(ix, iy, 0, 0, 1, t, tau, si, M.DW[a2], ex); // timing only; the signal is evaluated once per grid point below
        }
      }
    }
  } else {
    // non-Cartesian: the forward model at the acquired samples, reconstructed by an exact inverse Fourier sum
    SR = new Float64Array(n); SI = new Float64Array(n);
    await M.fillSamples(); // (tissue signals per sample, for the bubble and overlap corrections)
    { const ml = mlite(M), parts = nChunks(n * M.ph.regions.length), per = Math.ceil(n / parts), args = [];
      for (let p = 0; p < parts; p++) { const a = p * per, b = Math.min(n, a + per); if (b <= a) break;
        const kx = new Float64Array(b - a), ky = new Float64Array(b - a), t = new Float64Array(b - a), tau = new Float64Array(b - a), si = new Int32Array(b - a);
        for (let q = a; q < b; q++) { kx[q - a] = M.KX[q] + (M.DKX ? M.DKX[q] : 0); ky[q - a] = M.KY[q] + (M.DKY ? M.DKY[q] : 0); t[q - a] = M.T[q]; tau[q - a] = M.TAU[q]; si[q - a] = M.SH[q]; }
        args.push({ a, arg: { m: ml, kx, ky, t, tau, si } }); }
      const res = await parMap('evalPoints', args.map(x => x.arg), 0.25, 0.65);
      res.forEach((r, i) => { const a = args[i].a; for (let q = 0; q < r.re.length; q++) { let vr = r.re[q], vi = r.im[q];
        if (M.PHI) { const c = Math.cos(M.PHI[a + q]), s2 = Math.sin(M.PHI[a + q]); const t2 = vr * c - vi * s2; vi = vr * s2 + vi * c; vr = t2; }
        SR[a + q] = vr; SI[a + q] = vi; } }); }
    await overlapSamples(M, SR, SI);
    if (M.ph.bubble && opt.bubbleField) {
      if (opt.bubbleExact) { bub = await bubbleNodes(M, hNode, 1e-3); await bubbleExactSamples(M, bub, SR, SI); }
      else { // the direct sum costs patches × samples: keep the near zone small (4 rad) and give the series more terms
        const nearNC = opt.bubbleNearNC || 1, orderNC = opt.bubbleOrderNC || 6; // as for Cartesian scans (most accurate)
        bub = await bubbleNodes(M, hNode, nearNC); await bubbleDirectFast(M, bub, SR, SI); bub.far = await bubbleFarSamples(M, SR, SI, nearNC, orderNC, hNode); }
    }
    if (opt.noise > 0) {
      const dwRef = 10e-6; let pk = 0; for (let q = 0; q < n; q++) pk = Math.max(pk, Math.hypot(SR[q], SI[q]));
      for (let q = 0; q < n; q++) {
        const sg = opt.noise * 0.002 * pk * Math.sqrt(dwRef / M.DW[q]);
        const u1 = hashU(2 * q + 1), u2 = hashU(2 * q + 2), R = Math.sqrt(-2 * Math.log(u1)) * sg;
        SR[q] += R * Math.cos(2 * Math.PI * u2); SI[q] += R * Math.sin(2 * Math.PI * u2);
      }
    }
    for (let q = 0; q < n; q++) put(Math.round(M.KX[q] / dkx), Math.round(M.KY[q] / dky), SR[q], SI[q], 1, M.T[q], M.TAU[q], M.SH[q], M.DW[q]);
  }
  let direct = null;
  if (!cart && n * Nx * Ny <= 2e9) { // exact adjoint Fourier sum on the Nx×Ny pixel grid
    const cnt = new Map(), key = q => Math.round(M.KX[q] / dkx) * 65536 + Math.round(M.KY[q] / dky);
    for (let q = 0; q < n; q++) cnt.set(key(q), (cnt.get(key(q)) || 0) + 1);
    const xr = new Float64Array(Nx * Ny), xi = new Float64Array(Nx * Ny);
    const px = 1 / (Nx * dkx), py = 1 / (Ny * dky), parts = nChunks(n * Nx * Ny / 20), per = Math.ceil(n / parts), args = [];
    for (let p = 0; p < parts; p++) { const a = p * per, b = Math.min(n, a + per); if (b <= a) break;
      const kx = new Float64Array(b - a), ky = new Float64Array(b - a), sr = new Float64Array(b - a), si = new Float64Array(b - a);
      for (let q = a; q < b; q++) { const w = 1 / cnt.get(key(q)); kx[q - a] = M.KX[q]; ky[q - a] = M.KY[q]; sr[q - a] = SR[q] * w; si[q - a] = SI[q] * w; }
      args.push({ Nx, Ny, px, py, kx, ky, sr, si }); }
    for (const r of await parMap('directSum', args, 0.85, 0.95)) for (let o = 0; o < Nx * Ny; o++) { xr[o] += r.xr[o]; xi[o] += r.xi[o]; }
    direct = { xr, xi };
  }
  const WN = Float64Array.from(W); // number of samples averaged per grid point (for noise)
  for (let o = 0; o < G * G; o++) if (W[o] > 0) { Kr[o] /= W[o]; Ki[o] /= W[o]; TT[o] /= W[o]; TU[o] /= W[o]; TS[o] = Math.round(TS[o] / W[o]); DWg[o] /= W[o]; if (EX) { EX[0][o] /= W[o]; EX[1][o] /= W[o]; EX[2][o] /= W[o]; } }
  const withEddy = (o, v) => { if (!EX) return v; const c = Math.cos(EX[2][o]), s2 = Math.sin(EX[2][o]); return [v[0] * c - v[1] * s2, v[0] * s2 + v[1] * c]; };
  if (cart) { // one evaluation per grid point with its (averaged) timing, split over the workers
    const pts = []; for (let o = 0; o < G * G; o++) if (W[o] > 0) pts.push(o);
    const ml = mlite(M), parts = nChunks(pts.length * M.ph.regions.length), per = Math.ceil(pts.length / parts), args = [];
    for (let p = 0; p < parts; p++) { const a = p * per, b = Math.min(pts.length, a + per); if (b <= a) break;
      const kx = new Float64Array(b - a), ky = new Float64Array(b - a), t = new Float64Array(b - a), tau = new Float64Array(b - a), si = new Int32Array(b - a);
      for (let i = a; i < b; i++) { const o = pts[i]; kx[i - a] = ((o % G) - G / 2) * dkx + (EX ? EX[0][o] : 0); ky[i - a] = (Math.floor(o / G) - G / 2) * dky + (EX ? EX[1][o] : 0); t[i - a] = TT[o] + M.infos[TS[o]].tE; tau[i - a] = TU[o]; si[i - a] = TS[o]; }
      args.push({ a, arg: { m: ml, kx, ky, t, tau, si } }); }
    const res = await parMap('evalPoints', args.map(x => x.arg), 0.3, 0.65);
    res.forEach((r, i) => { const a = args[i].a; for (let q = 0; q < r.re.length; q++) { const o = pts[a + q], v = withEddy(o, [r.re[q], r.im[q]]); Kr[o] = v[0]; Ki[o] = v[1]; } });
  }
  // missing ky lines (acceleration, partial Fourier): an ideal reconstruction, i.e. the same
  // model evaluated there with the timing interpolated from the neighbouring acquired lines
  // rows are indexed r = iy + G/2. Target range: the acquired range, made symmetric when one side
  // is clearly shorter (partial Fourier)
  const acqRows = []; for (let r = 0; r < G; r++) if (acq[r]) acqRows.push(r);
  const missing = []; let pf = false;
  if (cart && acqRows.length) {
    let lo = acqRows[0] - G / 2, hi = acqRows[acqRows.length - 1] - G / 2;
    const half = Math.max(-lo, hi); if (Math.abs(-lo - hi) > 2) { pf = true; lo = -half; hi = half; }
    lo = Math.max(lo, -G / 2); hi = Math.min(hi, G / 2 - 1);
    for (let iy = lo; iy <= hi; iy++) if (!acq[iy + G / 2]) missing.push(iy + G / 2);
    Ny = hi - lo + 1;
  }
  const nMissing = missing.length;
  if (cart && opt.fill && nMissing && acqRows.length >= 2) {
    const lo = acqRows[0], hi = acqRows[acqRows.length - 1];
    for (const r of missing) {
      let a = -1, b = -1, f;
      if (r < lo || r > hi) { // outside the acquired range (partial Fourier): timing of the mirrored line
        const m = G - r; let best = acqRows[0]; for (const x of acqRows) if (Math.abs(x - m) < Math.abs(best - m)) best = x;
        a = b = best; f = 0;
      } else { for (const x of acqRows) { if (x < r) a = x; else if (b < 0) b = x; } f = (r - a) / (b - a); }
      const iy = r - G / 2;
      for (let ix = -G / 2; ix < G / 2; ix++) {
        const oa = a * G + ix + G / 2, ob = b * G + ix + G / 2; if (!W[oa] || !W[ob]) continue;
        const t = TT[oa] + (TT[ob] - TT[oa]) * f, tau = TU[oa] + (TU[ob] - TU[oa]) * f, si = f < 0.5 ? TS[oa] : TS[ob];
        // (mirrored rows: kx is mirrored too, so the timing of the conjugate point is used)
        const o = (iy + G / 2) * G + ix + G / 2;
        if (EX) for (let c = 0; c < 3; c++) EX[c][o] = EX[c][oa] + (EX[c][ob] - EX[c][oa]) * f;
        const v = withEddy(o, signalAt(M, ix * dkx + (EX ? EX[0][o] : 0), iy * dky + (EX ? EX[1][o] : 0), t + M.infos[si].tE, tau, si));
        Kr[o] = v[0]; Ki[o] = v[1]; W[o] = -1; TT[o] = t; TU[o] = tau; TS[o] = si; // −1 marks filled
      }
    }
  }
  if (cart) await overlapGrid(M, Kr, Ki, W, TT, TU, TS, G, dkx, dky);
  if (M.ph.bubble && opt.bubbleField && cart) {
    if (opt.bubbleExact) { bub = await bubbleNodes(M, hNode, 1e-3); await bubbleExactGrid(M, bub, Kr, Ki, W, TT, TU, TS, G, dkx, dky); }
    else {
      const T0 = Date.now(); bub = await bubbleNodes(M, hNode, NEAR); const T1 = Date.now();
      const tol = 0.1 / (2 * Math.PI * SIM_GBAR * opt.B0 * 9.4e-6 / 3); // 0.1 rad at the sphere's surface
      const handled = opt.bubbleNoClasses ? new Uint8Array(G) : await bubbleClasses(M, bub, Kr, Ki, W, TT, TU, TS, G, dkx, dky, tol);
      bub.classRows = handled.reduce((a, b) => a + b, 0);
      const T2 = Date.now(); await bubbleRows(M, bub, Kr, Ki, W, TT, TU, TS, G, dkx, dky, handled); const T3 = Date.now();
      bub.far = await bubbleFar(M, Kr, Ki, W, TT, TU, TS, G, dkx, dky, NEAR, opt.bubbleOrder || 6); const T4 = Date.now();
      bub.times = { nodes: T1 - T0, classes: T2 - T1, rows: T3 - T2, far: T4 - T3 };
    }
  }
  if (cart && opt.noise > 0) { // noise per grid point: √(bandwidth of the sample), reduced by averaging
    const dwRef = 10e-6; let pk = 0; for (let o = 0; o < G * G; o++) if (W[o] !== 0) pk = Math.max(pk, Math.hypot(Kr[o], Ki[o]));
    for (let o = 0; o < G * G; o++) {
      if (W[o] === 0) continue;
      const dw = DWg[o] || dwRef, sg = opt.noise * 0.002 * pk * Math.sqrt(dwRef / dw) / Math.sqrt(Math.max(1, WN[o]));
      const u1 = hashU(2 * o + 1), u2 = hashU(2 * o + 2), R = Math.sqrt(-2 * Math.log(u1)) * sg;
      Kr[o] += R * Math.cos(2 * Math.PI * u2); Ki[o] += R * Math.sin(2 * Math.PI * u2);
    }
  }
  const mask = new Int8Array(G * G); for (let o = 0; o < G * G; o++) mask[o] = W[o] > 0 ? 1 : W[o] < 0 ? 2 : 0;
  const kspace = { re: Float64Array.from(Kr), im: Float64Array.from(Ki), G, dkx, dky }; // grid steps (1/mm) along x and y
  // effective bandwidth: fit τ ≈ c0 + ax·kx + ay·ky (least squares over acquired samples)
  const fit = lsq3(M.KX, M.KY, M.TAU);
  const pxX = 1 / (Nx * dkx), pxY = 1 / (Ny * dky); // pixel size (mm)
  const shiftX = Math.abs(fit[1]) / pxX, shiftY = Math.abs(fit[2]) / pxY; // pixels per Hz (the phase −2πfτ ≈ shift f·a)
  // image
  let img;
  if (direct) { // the Nx×Ny direct image, centred on a P×P grid (P: the next power of two)
    const P = 1 << Math.ceil(Math.log2(Math.max(Nx, Ny)));
    const Ar = new Float64Array(P * P), Ai = new Float64Array(P * P);
    for (let j = 0; j < Ny; j++) for (let i = 0; i < Nx; i++) { const o = (j - Ny / 2 + P / 2) * P + (i - Nx / 2 + P / 2); Ar[o] = direct.xr[j * Nx + i]; Ai[o] = direct.xi[j * Nx + i]; }
    img = { G: P, Nx, Ny, re: Ar, im: Ai, scale: 1, fovX: P / (Nx * dkx), fovY: P / (Ny * dky), px: 1 / (Nx * dkx), py: 1 / (Ny * dky), cropX: osAxis === 0 ? 1 / osRO : 1, cropY: osAxis === 1 ? 1 / osRO : 1 };
  } else {
    ifft2c(Kr, Ki, G);
    img = { G, Nx, Ny, re: Kr, im: Ki, scale: G * G / (Nx * Ny), fovX: 1 / dkx, fovY: 1 / dky, px: 1 / (G * dkx), py: 1 / (G * dky), cropX: osAxis === 0 ? 1 / osRO : 1, cropY: osAxis === 1 ? 1 / osRO : 1 };
  }
  const inf = M.set.ref, infos = M.infos;
  return {
    img, osRO, mask, kspace, cart, direct: !!direct, nMissing, swapDisplay: M.swapDisplay, engine: SIM_ENGINE, dispW: Nx, dispH: Ny, nEcho: M.nEcho, echo: M.echo, Ny, nAcqRows: acqRows.length, n, bub, ms: Date.now() - t0,
    TE: median(infos.map(x => x.TE)), TR: inf.TR, flip: inf.flip, b: median(infos.map(x => x.b)), bMax: Math.max(...infos.map(x => x.b)), nShots: infos.length,
    bwX: shiftX > 1e-9 ? 1 / shiftX : Infinity, bwY: shiftY > 1e-9 ? 1 / shiftY : Infinity, pf,
    // readout direction: along which image axis consecutive samples of one ADC move
    ...(() => { const ro = n > 1 && Math.abs(M.KY[1] - M.KY[0]) > Math.abs(M.KX[1] - M.KX[0]) ? 1 : 0; return { roAxis: ro, bwRO: 1 / (median(M.DW) * (ro ? Ny : Nx)) }; })(),
    eddy: M.DKX ? (() => { let ex = 0, ey = 0, mx = 0, my = 0, ph = 0; const best = new Map();
      for (let q = 0; q < n; q++) { const r = M.KX[q] ** 2 + M.KY[q] ** 2, b = best.get(M.SH[q]); if (!b || r < b.r) best.set(M.SH[q], { r, q }); mx = Math.max(mx, Math.abs(M.DKX[q] / dkx)); my = Math.max(my, Math.abs(M.DKY[q] / dky)); ph = Math.max(ph, Math.abs(M.PHI[q])); }
      for (const { q } of best.values()) { ex = Math.max(ex, Math.abs(M.DKX[q] / dkx)); ey = Math.max(ey, Math.abs(M.DKY[q] / dky)); }
      return { name: EDDY[opt.eddy].name, echoX: ex, echoY: ey, maxX: mx, maxY: my, phase: ph }; })() : null,
    fatX: M.fat[1] * shiftX, fatY: M.fat[1] * shiftY, axes: M.axes, geom: M.geom, phantomKey: opt.phantom, bubbleOn: !!opt.bubble,
    sliceOffsets: (() => { // positions (mm) of all slices excited in this volume, along the same normal
      const g = M.geom; if (g.mode !== 'slice' || !(g.G > 0) || g.fixed) return [];
      const fs = new Set();
      for (let k = vol.s0; k <= vol.s1; k++) { const sh = shots[k]; for (let b = sh.b0; b <= sh.b1; b++) if (seq.B.rf[b] && rfSt(seq, seq.B.rf[b]).use === 'e') { fs.add(Math.round(seq.rf.get(seq.B.rf[b]).freq)); break; } }
      return [...fs].map(f => f / g.G * 1e3).sort((a, b) => a - b);
    })(), se: inf.refs.length > 0, inv: inf.inv, sats: inf.sats.length, useRef: M.set.useType(1) && !M.set.useType(0)
  };
}
function lsq3(X, Y, Z) { // fit z ≈ c0 + c1·x + c2·y
  let s = [0, 0, 0, 0, 0, 0, 0, 0, 0], r = [0, 0, 0];
  for (let i = 0; i < X.length; i++) { const v = [1, X[i], Y[i]]; for (let a = 0; a < 3; a++) { r[a] += v[a] * Z[i]; for (let b = 0; b < 3; b++) s[a * 3 + b] += v[a] * v[b]; } }
  const A = [[s[0], s[1], s[2], r[0]], [s[3], s[4], s[5], r[1]], [s[6], s[7], s[8], r[2]]];
  for (let c = 0; c < 3; c++) { let p = c; for (let q = c + 1; q < 3; q++) if (Math.abs(A[q][c]) > Math.abs(A[p][c])) p = q; [A[c], A[p]] = [A[p], A[c]]; if (Math.abs(A[c][c]) < 1e-30) return [0, 0, 0]; for (let q = 0; q < 3; q++) if (q !== c) { const f = A[q][c] / A[c][c]; for (let k = c; k < 4; k++) A[q][k] -= f * A[c][k]; } }
  return [A[0][3] / A[0][0], A[1][3] / A[1][1], A[2][3] / A[2][2]];
}
function hashU(i) { let a = (i * 2654435761 + 0x6D2B79F5) | 0, t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return (((t ^ (t >>> 14)) >>> 0) + 0.5) / 4294967297; }

if (typeof module !== 'undefined' && module.exports) module.exports = { lineStats, imagePlaneQuick, mlite, SIM_TASKS, setSimPool: p => { SIM_POOL = p; }, eddyTrack, eddyShift, sampleChannel, EDDY, sectionPhantom, build3D, tissueAt3, sectionEllipse, eig3, runSimulation, simulateImage, TISSUES, bValue, bTensor, shotBTensor, shotEchoes, shotInfo, tauAt, lsq3, rfSlice, rfFreqHz, invCycle, MzInv, Mz };


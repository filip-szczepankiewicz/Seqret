// Loads the #core sources (core.js + sim.js + stim.js) into one VM context, as a worker sees them, and returns
// the functions the tests use. Each file sets module.exports differently, so the tests read globals instead.
import fs from 'fs'; import vm from 'vm'; import path from 'path'; import { fileURLToPath } from 'url';
const here = path.dirname(fileURLToPath(import.meta.url));
export const SRC = path.join(here, '..', 'src');
export function loadCore(names) {
  const ctx = vm.createContext({ console, TextEncoder, TextDecoder, performance, setTimeout, clearTimeout, Date, Math, queueMicrotask });
  vm.runInContext(['core.js', 'sim.js', 'stim.js'].map(f => fs.readFileSync(path.join(SRC, f), 'utf8')).join(''), ctx);
  return vm.runInContext(`({${names.join(',')}})`, ctx);
}

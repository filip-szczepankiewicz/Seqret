// Unit and regression tests of the core (no browser):   node tests/test_core.mjs
// Timing benchmark on any file:                           node tests/test_core.mjs --bench file.seq [more.seq] [--no-sim] [--no-stim]
// (large files: node --max-old-space-size=8000 ...; the stimulation pass of a 1-hour file takes minutes on one thread)
import fs from 'fs'; import path from 'path'; import { loadCore, SRC } from './load_core.mjs';

const A = loadCore(['loadSeq', 'computeVolumes', 'runSimulation', 'kSamples', 'md5', 'quatToMat',
  'safeExample', 'safeHwCheck', 'stimJobPack', 'stimJobRun', 'GAMMA']);
let fails = 0;
const ok = (cond, msg) => { console.log(`${cond ? 'ok  ' : 'FAIL'} ${msg}`); if (!cond) fails++; };
const near = (a, b, tol) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(b));
const simOpt = { eddy: 'off', slicePos: true, orient: 'ax', phantom: 'head', B0: 3, t1: true, t2: true, fatShift: true,
  diffusion: true, bubble: false, noise: 0, fill: true, crop: true, bubbleField: true };
const firstImagingShot = (seq, vol) => {
  for (let k = vol.s0; k <= vol.s1; k++) { const sh = seq.shots[k]; for (let j = sh.j0; j < sh.j1; j++) if (seq.adcType[j] === 0 || seq.adcType[j] === 2) return k; }
  return vol.s0;
};

async function unitTests() {
  // md5 against RFC 1321 test vectors
  const enc = s => new TextEncoder().encode(s);
  ok(A.md5(enc('')) === 'd41d8cd98f00b204e9800998ecf8427e', 'md5("")');
  ok(A.md5(enc('abc')) === '900150983cd24fb0d6963f7d28e17f72', 'md5("abc")');
  // rotation: identity quaternion
  const I = A.quatToMat([1, 0, 0, 0]); ok(I.every((row, a) => row.every((v, b) => near(v, a === b ? 1 : 0, 1e-12))), 'quatToMat(identity)');
  const Q = A.quatToMat([Math.SQRT1_2, 0, 0, Math.SQRT1_2]); // 90 degrees about z: x -> y
  ok(near(Q[1][0], 1, 1e-12) && near(Q[0][1], -1, 1e-12) && near(Q[2][2], 1, 1e-12), 'quatToMat(90 deg about z)');

  // the built-in demo (diffusion-weighted SE-EPI, Pulseq 1.5.1, 3 slices, 3 volumes)
  let t = performance.now();
  const seq = A.loadSeq(new Uint8Array(fs.readFileSync(path.join(SRC, 'demo.seq'))));
  const tLoad = performance.now() - t;
  ok(seq.sig.status === 'ok', `demo: md5 signature verified (${seq.sig.status})`);
  ok(seq.version.major === 1 && seq.version.minor === 5, 'demo: Pulseq 1.5');
  ok(seq.nb === 744, `demo: 744 blocks (${seq.nb})`);
  ok(near(seq.totalDur, 2.4, 1e-9), `demo: duration 2.4 s (${seq.totalDur})`);
  ok(seq.shots.length === 12, `demo: 12 shots (${seq.shots.length})`);
  const vols = A.computeVolumes(seq, seq.shots, 'auto');
  ok(vols.length === 3, `demo: 3 volumes (${vols.length})`);
  const sh = seq.shots.find(s => s.nADC), k = A.kSamples(seq, sh.j0, sh.j1);
  ok(k.n > 0 && k.k.every(a => a.length === k.n && a.every(Number.isFinite)) && Math.max(...k.k[0].map(Math.abs)) > 0, `demo: k-space [kx, ky, kz] (1/m) of the first shot with a readout is finite (${k.n} samples)`);

  t = performance.now();
  const vol = vols[1], r = await A.runSimulation(seq, seq.shots, vol, firstImagingShot(seq, vol), simOpt);
  const tSim = performance.now() - t;
  ok(!r.error && r.n > 0, `demo: image simulation of volume 2 runs (${r.error || r.n + ' samples'})`);

  // stacks rotated about y (phase encoding) by k·360/11: every image must be 32×32 (the FOV definition gives x, y
  // and the slab along z; applied to a readout running mostly along z it once gave images 4 pixels across)
  const rot = A.loadSeq(new Uint8Array(fs.readFileSync(path.join(SRC, '..', 'tests', 'data', 'rotated_stacks_11x1.seq'))));
  const rv = A.computeVolumes(rot, rot.shots, 'label', 'SET'), dims = [];
  let pxErr = 0;
  for (const v of rv) { const r = await A.runSimulation(rot, rot.shots, v, v.s0, simOpt); dims.push(r.error ? 'error' : `${r.img.Nx}x${r.img.Ny}`);
    if (!r.error) pxErr = Math.max(pxErr, Math.abs(r.img.px - 220 / 32) / (220 / 32), Math.abs(r.img.py - 220 / 32) / (220 / 32)); }
  ok(rv.length === 11 && dims.every(d => d === '32x32'), `rotated stacks: 11 images of 32x32 (${[...new Set(dims)].join(', ')})`);
  ok(pxErr < 1e-4, `rotated stacks: pixel size 220/32 mm on both axes in every stack (largest error ${(pxErr * 100).toFixed(3)} %)`);

  // slab-selective 3D (16×16, 4 partitions of 3 mm), rotated 20° about x: the image plane is readout × phase encoding,
  // perpendicular to the slab normal (before 1.24.3 the partitions' k-spread made it readout × slab normal, 16×4)
  const slab = A.loadSeq(new Uint8Array(fs.readFileSync(path.join(SRC, '..', 'tests', 'data', 'slab3d_16x4_rot20x.seq'))));
  const sv = A.computeVolumes(slab, slab.shots, 'auto'), sr = await A.runSimulation(slab, slab.shots, sv[0], sv[0].s0, simOpt);
  const nSlab = [0, -Math.sin(20 * Math.PI / 180), Math.cos(20 * Math.PI / 180)]; // z rotated 20° about x
  const nDot = sr.error ? 1 : Math.max(...[sr.geom.e1s, sr.geom.e2s].map(e => Math.abs(e[0] * nSlab[0] + e[1] * nSlab[1] + e[2] * nSlab[2])));
  ok(!sr.error && sr.img.Nx === 16 && sr.img.Ny === 16 && nDot < 1e-4 && sr.geom.mode.startsWith('partition') && near(sr.geom.thick, 3, 1e-4),
    `3D slab rotated 20° about x: 16x16 image in the plane perpendicular to the slab, one 3 mm partition (${sr.error || `${sr.img.Nx}x${sr.img.Ny}, |axis·slab normal| ${nDot.toExponential(1)}, ${sr.geom.mode} ${sr.geom.thick.toFixed(2)} mm`})`);

  const hw = A.safeExample();
  ok(A.safeHwCheck(hw).ok, 'SAFE example hardware passes the check');
  t = performance.now();
  const st = A.stimJobRun({ models: [{ hw }], dt: seq.raster.grad || 1e-5, ...A.stimJobPack(seq) });
  const tStim = performance.now() - t;
  ok(st.N > 0 && st.peak.length > 0 && Array.from(st.peak).every(Number.isFinite), 'demo: SAFE stimulation pass gives finite peaks');
  console.log(`\ntimes (Node, one thread): load ${tLoad.toFixed(0)} ms, simulation ${tSim.toFixed(0)} ms, stimulation ${tStim.toFixed(0)} ms`);
}

async function bench(file) {
  const bytes = new Uint8Array(fs.readFileSync(file));
  let t = performance.now(); const seq = A.loadSeq(bytes); const tl = performance.now() - t;
  t = performance.now(); const vols = A.computeVolumes(seq, seq.shots, 'auto'); const tv = performance.now() - t;
  console.log(`${path.basename(file)}: ${(bytes.length / 1e6).toFixed(1)} MB, ${seq.nb.toLocaleString()} blocks, ${seq.shots.length.toLocaleString()} shots, ${vols.length} volumes, ${seq.adcT0.length.toLocaleString()} ADCs, md5 ${seq.sig.status}`);
  console.log(`  parse ${seq.loadTimes.parse} ms, analyze ${seq.loadTimes.analyze} ms (load total ${tl.toFixed(0)} ms incl. md5), volumes ${tv.toFixed(0)} ms`);
  if (vols.length && !process.argv.includes('--no-sim')) {
    const vol = vols[Math.min(1, vols.length - 1)];
    t = performance.now(); const r = await A.runSimulation(seq, seq.shots, vol, firstImagingShot(seq, vol), simOpt);
    console.log(`  image simulation (CPU, one thread): ${(performance.now() - t).toFixed(0)} ms ${r.error ? '(' + r.error + ')' : ''}`);
  }
  if (!process.argv.includes('--no-stim')) { t = performance.now(); A.stimJobRun({ models: [{ hw: A.safeExample() }], dt: seq.raster.grad || 1e-5, ...A.stimJobPack(seq) });
  console.log(`  SAFE stimulation pass: ${(performance.now() - t).toFixed(0)} ms`); }
  const mem = process.memoryUsage(); console.log(`  heap ${(mem.heapUsed / 1e6).toFixed(0)} MB, array buffers ${(mem.arrayBuffers / 1e6).toFixed(0)} MB`);
}

const i = process.argv.indexOf('--bench');
if (i > 0) { for (const f of process.argv.slice(i + 1).filter(a => !a.startsWith('--'))) await bench(f); }
else { await unitTests(); console.log(fails ? `\n${fails} test(s) FAILED` : '\nall tests passed'); process.exit(fails ? 1 : 0); }

// Helper for tests/compare_pypulseq.py: loads a .seq file with Seqret's core and writes, as raw little-endian float64:
//   g.f64    physical gradients gx, gy, gz (Hz/m) at the times in tg.f64 (s)
//   rf.f64   RF real and imaginary parts (Hz) at the times in trf.f64 (s)
//   kadc.f64 ADC sample times, then kx, ky, kz (1/m) at every ADC sample (computeKspace)
// Usage: node tests/pp_dump.mjs file.seq DIR
import fs from 'fs'; import path from 'path'; import { loadCore } from './load_core.mjs';
const A = loadCore(['loadSeq', 'channelValue', 'computeKspace']);
const [file, dir] = process.argv.slice(2);
const seq = A.loadSeq(new Uint8Array(fs.readFileSync(file)));
const rd = f => { const b = fs.readFileSync(path.join(dir, f)); return new Float64Array(b.buffer, b.byteOffset, b.length / 8); };
const wr = (f, arrs) => { const n = arrs.reduce((s, a) => s + a.length, 0), o = new Float64Array(n); let p = 0; for (const a of arrs) { o.set(a, p); p += a.length; } fs.writeFileSync(path.join(dir, f), Buffer.from(o.buffer)); };
const at = (key, T) => { const o = new Float64Array(T.length); for (let i = 0; i < T.length; i++) o[i] = A.channelValue(seq, key, T[i]); return o; };
const tg = rd('tg.f64'), trf = rd('trf.f64');
wr('g.f64', ['gx', 'gy', 'gz'].map(k => at(k, tg)));
wr('rf.f64', [at('rfRe', trf), at('rfIm', trf)]);
const K = A.computeKspace(seq);
wr('kadc.f64', [K.tA, ...K.kA.map(a => Float64Array.from(a))]);
fs.writeFileSync(path.join(dir, 'info.json'), JSON.stringify({ nb: seq.nb, version: seq.version, nADC: K.tA.length }));

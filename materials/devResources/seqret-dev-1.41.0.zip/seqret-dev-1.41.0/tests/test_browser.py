#!/usr/bin/env python3
"""Browser tests of the built page (Playwright, Chromium):

    pip install playwright && python -m playwright install chromium
    python3 tests/test_browser.py [dist/seqret.html] [--seq file.seq ...] [--shots DIR] [--bench]

1. Smoke test: loads the demo (and the given files), visits every tab, zooms and pans the diagram, waits for the
   k-space and the simulated image.
2. Scenarios, each in a fresh browser profile: default and saved settings, migration of old settings, diagram
   quality and peaks, hiding the side panel, stepping through shots, linked tabs, the k-space view of the image tab, dot size, hovering and panning in the k-space tab.
3. With --bench: the frame-rate test (⋯ › Run frame-rate test) runs to the end and reports every case.
Every step fails on any page error or console error. With --shots, screenshots are saved to DIR.

Do NOT use frame times measured here to tune drawing performance: headless Chromium renders in software, which
is slow in different places than a GPU-accelerated browser. Use the frame-time panel (Shift+D) in a normal browser
for that. This test is for correctness only.
"""
import sys, pathlib, json
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
args = sys.argv[1:]
page_file = pathlib.Path(args[0]) if args and not args[0].startswith('--') else ROOT / 'dist' / 'seqret.html'
URL = page_file.resolve().as_uri()
seqs = []
if '--seq' in args:
    i = args.index('--seq') + 1
    while i < len(args) and not args[i].startswith('--'):
        seqs.append(pathlib.Path(args[i]).resolve()); i += 1
shots = pathlib.Path(args[args.index('--shots') + 1]) if '--shots' in args else None
if shots: shots.mkdir(parents=True, exist_ok=True)

errors, results = [], []
IDLE = "() => document.querySelector('#fname').textContent.trim() !== '' && !document.querySelector('#busy').classList.contains('on')"


def ok(cond, msg):
    results.append((bool(cond), msg)); print(f'{"ok  " if cond else "FAIL"} {msg}')


def new_page(ctx, label):
    page = ctx.new_page()
    page.on('pageerror', lambda e: errors.append(f'{label}: page error: {e}'))
    page.on('console', lambda m: errors.append(f'{label}: console {m.type}: {m.text}') if m.type == 'error' else None)
    return page


def open_demo(page, url=URL):
    page.goto(url); page.click('#demoBtn'); page.wait_for_function(IDLE, timeout=180000); page.wait_for_timeout(300)


def plot_pixels(page):
    """the diagram canvas as a list of RGBA bytes (drawn content only; the page background is not in it)"""
    page.wait_for_timeout(250)
    return page.evaluate("() => { const c = document.querySelector('#plot'); return Array.from(c.getContext('2d').getImageData(0, 0, c.width, c.height).data); }")


def differ(a, b):
    n = min(len(a), len(b)) // 4
    return sum(1 for i in range(n) if a[4 * i:4 * i + 4] != b[4 * i:4 * i + 4]) / max(1, n)


def open_display(page):
    if page.locator('#dispPop').is_hidden(): page.click('#dispBtn')


def close_display(page):
    if not page.locator('#dispPop').is_hidden(): page.keyboard.press('Escape')


# ---------------- 1. smoke test ----------------
def smoke(page, label):
    page.wait_for_function(IDLE, timeout=180000)
    page.wait_for_timeout(300)
    box = page.locator('#plot').bounding_box()
    page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
    for _ in range(6): page.mouse.wheel(0, -300); page.wait_for_timeout(50)   # zoom in
    page.mouse.down(button='right'); page.mouse.move(box['x'] + box['width'] / 3, box['y'] + box['height'] / 2); page.mouse.up(button='right')  # pan
    for _ in range(6): page.mouse.wheel(0, 300); page.wait_for_timeout(50)    # zoom out
    if shots: page.screenshot(path=str(shots / f'{label}_diagram.png'))
    for tab in ['seq', 'blk', 'k', 'img', 'defs']:
        page.click(f'.tab[data-tab="{tab}"]')
        if tab == 'k':
            page.wait_for_function("() => document.querySelector('#kInfo').textContent.trim() !== ''", timeout=60000)
        if tab == 'img':
            page.wait_for_function("() => document.querySelector('#imInfo').textContent.trim() !== '' && !document.querySelector('#imBusy').classList.contains('on')", timeout=300000)
            print(f'  image: {page.inner_text("#imInfo")[:160]!r}')
        page.wait_for_timeout(200)
        if shots: page.screenshot(path=str(shots / f'{label}_{tab}.png'))
    print(f'  loaded as: {page.inner_text("#fname")} {page.inner_text("#fmeta")}')


# ---------------- 2. scenarios ----------------
def scenario_settings(browser):
    """defaults without saved settings (1.24.0 fixed 'ultra' shown while 'high' was drawn); a change is saved and
    survives a reload"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'settings')
    open_demo(page)
    ok(page.input_value('#diagRes') == 'high' and page.input_value('#lineMode') == 'exact',
       f'settings: defaults without saved settings are quality high, peaks exact ({page.input_value("#diagRes")}, {page.input_value("#lineMode")})')
    open_display(page); page.select_option('#diagRes', 'standard'); page.select_option('#lineMode', 'columns'); close_display(page)
    page.wait_for_timeout(600)  # saved 250 ms after a change
    saved = page.evaluate("() => JSON.parse(localStorage.getItem('seqret-settings') || '{}')")
    page.reload(); page.wait_for_timeout(500)
    ok(saved.get('diagRes') == 'standard' and page.input_value('#diagRes') == 'standard' and page.input_value('#lineMode') == 'columns',
       f'settings: quality and peaks are saved and restored after a reload ({page.input_value("#diagRes")}, {page.input_value("#lineMode")})')
    ctx.close()


def scenario_migration(browser):
    """settings saved under the earlier name (seqview-*, before 1.12.0) are read when the new ones are absent, and the
    quality 'sharp' of 1.17.0 becomes 'high'"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900})
    ctx.add_init_script("if (!localStorage.getItem('seqret-settings') && !sessionStorage.getItem('seeded')) {"
                        " localStorage.setItem('seqview-settings', JSON.stringify({ v: 1, diagRes: 'sharp', gUnit: 'Hz', kProj: 'xz' }));"
                        " sessionStorage.setItem('seeded', '1'); }")
    page = new_page(ctx, 'migration'); page.goto(URL); page.wait_for_timeout(500)
    ok(page.input_value('#diagRes') == 'high' and page.input_value('#gUnit') == 'Hz'
       and page.get_attribute('#kProj button[data-v="xz"]', 'aria-pressed') == 'true',
       f'settings: old seqview-settings are read, quality sharp becomes high ({page.input_value("#diagRes")}, gradient unit {page.input_value("#gUnit")})')
    ctx.close()


def scenario_quality(browser):
    """every diagram quality and both peak modes draw; exact and per-column peaks differ when zoomed out"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'quality')
    open_demo(page); open_display(page)
    blank = []
    for q in ['ultra', 'high', 'standard', 'fast']:
        page.select_option('#diagRes', q); px = plot_pixels(page)
        if sum(px[3::4]) == 0: blank.append(q)
    ok(not blank, f'diagram: all four qualities draw ({", ".join(blank) + " blank" if blank else "ultra, high, standard, fast"})')
    page.select_option('#diagRes', 'high')
    page.select_option('#lineMode', 'exact'); a = plot_pixels(page)
    page.select_option('#lineMode', 'columns'); b = plot_pixels(page)
    page.select_option('#lineMode', 'exact'); c = plot_pixels(page)
    d_ab, d_ac = differ(a, b), differ(a, c)
    ok(d_ab > 0 and d_ac == 0, f'diagram: peaks per column differs from exact ({100 * d_ab:.2f} % of pixels), and switching back restores it exactly')
    ctx.close()


def scenario_side_panel(browser):
    """the side-panel button and the \\ key hide and show the panel; the diagram gets wider; the choice is remembered"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'side')
    open_demo(page)
    w0 = page.locator('#plot').bounding_box()['width']
    page.click('#sideBtn'); page.wait_for_timeout(400)
    w1 = page.locator('#plot').bounding_box()['width']
    ok(page.get_attribute('#sideBtn', 'aria-pressed') == 'true' and w1 > w0 + 200,
       f'side panel: the button hides it and the diagram widens ({w0:.0f} -> {w1:.0f} px)')
    page.wait_for_timeout(500); page.reload(); page.click('#demoBtn'); page.wait_for_function(IDLE, timeout=180000); page.wait_for_timeout(300)
    w2 = page.locator('#plot').bounding_box()['width']
    ok(page.get_attribute('#sideBtn', 'aria-pressed') == 'true' and abs(w2 - w1) < 2, f'side panel: hidden after a reload ({w2:.0f} px)')
    page.focus('#ovl'); page.keyboard.press('Backslash'); page.wait_for_timeout(400)
    w3 = page.locator('#plot').bounding_box()['width']
    ok(page.get_attribute('#sideBtn', 'aria-pressed') == 'false' and abs(w3 - w0) < 2, f'side panel: the \\ key brings it back ({w3:.0f} px)')
    ctx.close()


def scenario_stepping(browser):
    """the shot stepper moves to the next shot, and the k-space tab follows it"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'stepping')
    open_demo(page); page.click('.tab[data-tab="k"]')
    page.wait_for_function("() => /shot \\d+ of/.test(document.querySelector('#kInfo').textContent)", timeout=60000)
    s0 = int(page.input_value('#nav-shot .num') or 0)
    page.click('#nav-shot .next'); page.wait_for_timeout(400)
    s1 = int(page.input_value('#nav-shot .num') or 0)
    info = page.inner_text('#kInfo')
    ok(s1 == s0 + 1 and f'shot {s1} of 12' in info, f'stepping: next shot {s0} -> {s1}; k-space shows "{info[:60]}"')
    ctx.close()


def scenario_linking(browser):
    """two tabs linked on 'Same shot': stepping in one moves the other to the same shot"""
    ctx = browser.new_context(viewport={'width': 1200, 'height': 800})
    a, b = new_page(ctx, 'link A'), new_page(ctx, 'link B')
    open_demo(a); open_demo(b)
    for p in (a, b):
        if p.locator('#linkSel').is_hidden(): p.click('#moreBtn')
        p.select_option('#linkSel', 'shot')
        if not p.locator('#morePop').is_hidden(): p.keyboard.press('Escape')
    a.wait_for_timeout(500)
    for _ in range(3): a.click('#nav-shot .next'); a.wait_for_timeout(150)
    b.wait_for_timeout(800)
    sa, sb = a.input_value('#nav-shot .num'), b.input_value('#nav-shot .num')
    ok(sa == sb and sa not in ('', '1'), f'linked tabs: the second tab follows the first to the same shot ({sa} and {sb})')
    ctx.close()


def scenario_kspace_image(browser):
    """Image tab, k-space view: the demo's 2× oversampled readout covers the same k range as the phase encoding, so
    the drawn data is about as wide as it is high (before 1.24.4 it was drawn about twice as wide)"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'k image')
    open_demo(page); page.click('.tab[data-tab="img"]')
    page.wait_for_function("() => document.querySelector('#imInfo').textContent.trim() !== '' && !document.querySelector('#imBusy').classList.contains('on')", timeout=300000)
    page.click('#imView button[data-v="k"]'); page.wait_for_timeout(400)
    w, h = page.evaluate("""() => { const c = document.querySelector('#ic'), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data, W = c.width, H = c.height, top = Math.ceil(24 * H / c.clientHeight);
      let x0 = W, x1 = -1, y0 = H, y1 = -1;   // bounding box of the drawn data, below the label row
      for (let y = top; y < H; y++) for (let x = 0; x < W; x++) { const o = (y * W + x) * 4; if (d[o] > 20 || d[o + 1] > 20 || d[o + 2] > 20) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; } }
      return [x1 - x0 + 1, (y1 - y0 + 1) * H / (H - top)]; }""")
    ok(0.9 < w / h < 1.1, f'image tab, k-space: oversampled readout drawn over the same k range as the phase encoding (width/height {w / h:.2f})')
    ctx.close()


def scenario_kspace_hover(browser):
    """k-space tab: zoomed in, the samples are drawn as dots of several pixels (1.24.4 kept 2×2 px); hovering one shows
    what it is and moves the diagram's cursor to its time; moving away hides it"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'k hover')
    open_demo(page); page.click('.tab[data-tab="k"]'); page.wait_for_timeout(400)
    box = page.locator('#kc').bounding_box()
    page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
    for _ in range(12): page.mouse.wheel(0, -250); page.wait_for_timeout(40)
    page.wait_for_timeout(500)
    r = page.evaluate("""() => { const c = document.querySelector('#kc'), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data, W = c.width, H = c.height;
      const seen = new Uint8Array(W * H), sat = p => { const o = 4 * p; return Math.max(d[o], d[o + 1], d[o + 2]) - Math.min(d[o], d[o + 1], d[o + 2]) > 60; }, blobs = [];
      for (let y = 40; y < H - 60; y++) for (let x = 0; x < W; x++) { const p = y * W + x; if (seen[p] || !sat(p)) continue;   // connected dots of colour
        const st = [p]; seen[p] = 1; let n = 0, sx = 0, sy = 0; while (st.length) { const q = st.pop(); n++; sx += q % W; sy += (q / W) | 0;
          for (const nb of [q - 1, q + 1, q - W, q + W]) if (nb >= 0 && nb < W * H && !seen[nb] && sat(nb)) { seen[nb] = 1; st.push(nb); } }
        blobs.push([n, sx / n / devicePixelRatio, sy / n / devicePixelRatio]); }
      blobs.sort((a, b) => a[0] - b[0]); return { n: blobs.length, median: blobs.length ? blobs[blobs.length >> 1][0] / devicePixelRatio ** 2 : 0, pick: blobs[blobs.length >> 1] }; }""")
    ok(r['median'] >= 16, f'k-space: zoomed in, samples are dots of {r["median"]:.0f} px ({r["n"]} in view)')
    t0 = page.inner_text('#readout')
    page.mouse.move(box['x'] + r['pick'][1] + 2, box['y'] + r['pick'][2] + 1); page.wait_for_timeout(300)
    tip = page.evaluate("() => { const t = document.querySelector('.ktip'); return t && !t.hidden ? t.innerText : ''; }")
    ring = page.evaluate("() => !document.querySelector('.kring').hidden")
    t1 = page.inner_text('#readout')
    ok(tip.startswith('Sample ') and ' ms' in tip and 'm⁻¹' in tip and ring and t1 != t0,
       f'k-space: hovering a sample shows it ({tip.splitlines()[0] if tip else "no tooltip"}) and moves the diagram cursor')
    page.mouse.move(box['x'] + 3, box['y'] + box['height'] - 3); page.wait_for_timeout(200)
    ok(page.evaluate("() => document.querySelector('.ktip').hidden && document.querySelector('.kring').hidden"), 'k-space: moving away from the samples hides it')
    ctx.close()


def scenario_kspace_pan(browser):
    """k-space tab: right-drag moves the plot with the mouse (no context menu), keeps the projection; zooming out and
    back in after panning returns the same picture (zoom about the plot centre)"""
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'k pan')
    open_demo(page); page.click('.tab[data-tab="k"]'); page.wait_for_timeout(400)
    page.evaluate("() => { window.__cm = 0; document.addEventListener('contextmenu', e => { if (!e.defaultPrevented) window.__cm++; }); }")
    box = page.locator('#kc').bounding_box(); X, Y = box['x'] + box['width'] / 2, box['y'] + box['height'] / 2
    page.mouse.move(X, Y)
    for _ in range(8): page.mouse.wheel(0, -250); page.wait_for_timeout(40)
    page.wait_for_timeout(400)
    grab = "() => { const c = document.querySelector('#kc'); return Array.from(c.getContext('2d').getImageData(0, 0, c.width, c.height - 60 * devicePixelRatio).data.filter((_, i) => i % 4 === 1)); }"
    size = page.evaluate("() => { const c = document.querySelector('#kc'); return [c.width, c.height - 60 * devicePixelRatio, devicePixelRatio]; }")
    a = page.evaluate(grab)
    page.mouse.down(button='right'); page.mouse.move(X + 20, Y - 12, steps=5); page.mouse.up(button='right'); page.wait_for_timeout(400)
    b = page.evaluate(grab)
    W, H, dpr = size; W, H = int(W), int(H)
    # the shift that best matches the two pictures, searched over ±30 px (device pixels scaled by dpr)
    best, bs = None, None
    for dy in range(-20, 6):
        for dx in range(-6, 31):
            ddx, ddy = int(dx * dpr), int(dy * dpr); err = n = 0
            for y in range(max(0, -ddy) + 5, min(H, H - ddy) - 5, 7):
                for x in range(max(0, -ddx) + 5, min(W, W - ddx) - 5, 7):
                    err += abs(a[y * W + x] - b[(y + ddy) * W + x + ddx]); n += 1
            e = err / max(1, n)
            if bs is None or e < bs: bs, best = e, (dx, dy)
    ok(best == (20, -12) and page.evaluate('window.__cm') == 0 and page.get_attribute('#kProj button[data-v="xy"]', 'aria-pressed') == 'true',
       f'k-space: right-drag by (20, -12) px moves the plot by {best} px, without a context menu, in the same projection')
    ctx.close()


def scenario_bench(browser):
    """the frame-rate test runs through all its cases and restores the view"""
    ctx = browser.new_context(viewport={'width': 1200, 'height': 800}); page = new_page(ctx, 'bench')
    open_demo(page); page.click('#moreBtn'); page.click('#benchBtn')
    page.wait_for_function("() => /Copied to the clipboard|Select this text/.test(document.querySelector('#diag').textContent)", timeout=600000)
    txt = page.inner_text('#diag')
    cases = [l.split('  ')[0] for l in txt.split('\n')[4:] if l.strip() and not l.startswith(('The ', 'Seqret', 'Copied', 'Select', 'In Chrome'))]
    ok('normal, panning' in txt and 'blank diagram' in txt and 'one path' not in txt,
       f'frame-rate test: completes with {len(cases)} cases, without the removed path-rectangle cases')
    ctx.close()


with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900}); page = new_page(ctx, 'smoke')
    page.goto(URL)
    print('demo'); page.click('#demoBtn'); smoke(page, 'demo')
    for f in seqs:
        print(f.name); page.set_input_files('#fileIn', str(f)); smoke(page, f.stem)
    ctx.close()
    for sc in (scenario_settings, scenario_migration, scenario_quality, scenario_side_panel, scenario_stepping, scenario_linking, scenario_kspace_image, scenario_kspace_hover, scenario_kspace_pan):
        sc(browser)
    if '--bench' in args: scenario_bench(browser)
    browser.close()

for e in errors: print('FAIL', e)
failed = errors or not all(r for r, _ in results)
print('browser tests ' + ('FAILED' if failed else 'passed') + f' ({sum(r for r, _ in results)} of {len(results)} checks, {len(errors)} page errors)')
sys.exit(1 if failed else 0)

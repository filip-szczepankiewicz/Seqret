#!/usr/bin/env python3
"""Compare Seqret's core with PyPulseq on the same .seq files (DEVELOPMENT.md section 7).

    pip install pypulseq numpy
    python3 tests/compare_pypulseq.py                   # PyPulseq's own test sequences (cloned into tests/out/pypulseq)
    python3 tests/compare_pypulseq.py a.seq b.seq ...   # any files
    python3 tests/compare_pypulseq.py --pypulseq DIR    # use an existing clone of github.com/imr-framework/pypulseq

The reference is built from PyPulseq's parser, block by block (seq.get_block), not from Seqret:
  gradients  gx, gy, gz at the midpoint of every linear piece of every gradient event (PyPulseq's own
             waveforms_and_times joins the vertices at block edges and so smooths real steps between blocks, of
             the size of the file's 6-digit rounding; per-block events keep them, as Seqret does)
  RF |B1|    and RF re/im: rf.signal (the shape with its own phase, without phase or frequency offset, as Seqret's
             RF lanes) at its sample times; first and last sample evaluated 0.1 ns inside the pulse
  k at ADC   kx, ky, kz at every ADC sample: exact integral of those gradient pieces, reset at excitations and
             mirrored at refocusing pulses at PyPulseq's RF centre times (calculate_kspace), and the ADC times
Errors are the largest difference divided by the largest reference value (RF re/im: by the peak |B1|). The pass
limit is 1e-6. Seqret keeps gradient and k values as float32 (about 6e-8), and k differences grow with the
gradient moment reached before it cancels (large crushers with k near 0): write_epi_se_rs gives 8.5e-7 in kz
relative to max |k|, which is 2e-9 of the 53,000 1/m moment reached on that axis.
Seqret is run through Node (tests/pp_dump.mjs). Exit code 1 if any compared file differs or Seqret fails on it. Files PyPulseq cannot read (e.g. the ROTATIONS
extension in PyPulseq 1.5.0) are listed as not compared.
"""
import argparse, os, subprocess, sys, tempfile, warnings
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LIMIT = 1e-6
PP_URL = 'https://github.com/imr-framework/pypulseq'


def rel(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if a.size == 0 and b.size == 0: return 0.0
    if a.shape != b.shape: return float('inf')
    m = np.max(np.abs(b)) if b.size else 0.0
    return float(np.max(np.abs(a - b)) / m) if m > 0 else float(np.max(np.abs(a - b)))


def block_starts(seq):
    d = seq.block_durations
    keys = sorted(d)
    return keys, np.concatenate([[0.0], np.cumsum([d[k] for k in keys])])


def grad_pieces(seq):
    """Per axis: linear pieces (t0, t1, v0, v1) from PyPulseq's own block events, block by block (no merging across
    block edges: a step between blocks stays a step)."""
    keys, bs = block_starts(seq)
    P = [[], [], []]
    for n, k in enumerate(keys):
        b = seq.get_block(k)
        for a, ch in enumerate(('gx', 'gy', 'gz')):
            g = getattr(b, ch)
            if g is None: continue
            t0 = bs[n] + g.delay
            if g.type == 'trap':
                tt = np.array([0, g.rise_time, g.rise_time + g.flat_time, g.rise_time + g.flat_time + g.fall_time])
                vv = np.array([0, g.amplitude, g.amplitude, 0])
            else:
                tt, vv = np.asarray(g.tt, float), np.asarray(g.waveform, float)
                if tt[0] > 1e-12: tt = np.concatenate([[0.0], tt]); vv = np.concatenate([[g.first], vv])
                if tt[-1] < g.shape_dur - 1e-12: tt = np.concatenate([tt, [g.shape_dur]]); vv = np.concatenate([vv, [g.last]])
            for q in range(len(tt) - 1):
                if tt[q + 1] - tt[q] > 1e-12: P[a].append((t0 + tt[q], t0 + tt[q + 1], vv[q], vv[q + 1]))
    return [np.array(sorted(p)).reshape(-1, 4) for p in P]


def integral(pc, x):
    """exact integral of the linear pieces pc from -inf to the times x"""
    x = np.asarray(x, float)
    if not len(pc): return np.zeros_like(x)
    t0, t1, v0, v1 = pc.T
    cum = np.concatenate([[0.0], np.cumsum(0.5 * (v0 + v1) * (t1 - t0))])
    i = np.searchsorted(t0, x, 'right') - 1
    ic = np.clip(i, 0, len(t0) - 1)
    D = t1[ic] - t0[ic]; d = np.clip(x - t0[ic], 0, D); s = (v1[ic] - v0[ic]) / D
    return np.where(i < 0, 0.0, cum[ic] + v0[ic] * d + 0.5 * s * d * d)


def reference(path):
    import pypulseq as pp
    seq = pp.Sequence()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        seq.read(path, detect_rf_use=True)
        _, _, t_exc, t_ref, t_adc = seq.calculate_kspace()  # RF centre times and ADC sample times
    pcs = grad_pieces(seq)
    # k at the ADC samples: k(t) = F(t) + offset; an excitation at tc sets k(tc) = 0, a refocusing pulse k(tc) -> -k(tc)
    t_adc = np.asarray(t_adc, float)
    ev = sorted([(t, 'e') for t in t_exc] + [(t, 'r') for t in t_ref])
    k = np.zeros((3, t_adc.size))
    for a in range(3):
        Fa = integral(pcs[a], t_adc)
        Fe = integral(pcs[a], [e[0] for e in ev]) if ev else []
        off, j, offs = 0.0, 0, np.zeros(t_adc.size)
        for q, t in enumerate(t_adc):
            while j < len(ev) and ev[j][0] <= t:
                off = -Fe[j] if ev[j][1] == 'e' else -2 * Fe[j] - off; j += 1
            offs[q] = off
        k[a] = Fa + offs
    # RF: rf.signal (shape with its own phase; no phase or frequency offset) at the samples, block by block
    keys, bs = block_starts(seq)
    trf, srf = [], []
    for n, kk in enumerate(keys):
        rf = seq.get_block(kk).rf
        if rf is None: continue
        t = bs[n] + rf.delay + np.asarray(rf.t, float)
        # the first and last sample can sit exactly on the pulse's edge, where Seqret's trace steps to zero:
        # evaluate just inside
        t = t.copy(); t[0] += 1e-10; t[-1] -= 1e-10
        trf.append(t); srf.append(np.asarray(rf.signal))
    trf = np.concatenate(trf) if trf else np.zeros(0)
    srf = np.concatenate(srf) if srf else np.zeros(0, complex)
    return pcs, k, t_adc, trf, srf


def compare(path, tmp):
    pcs, k_ref, t_adc, trf, srf = reference(path)
    tg = [0.5 * (p[:, 0] + p[:, 1]) for p in pcs]           # midpoints of every linear piece, per axis
    gref = [0.5 * (p[:, 2] + p[:, 3]) for p in pcs]
    np.concatenate(tg).astype('<f8').tofile(os.path.join(tmp, 'tg.f64'))
    trf.astype('<f8').tofile(os.path.join(tmp, 'trf.f64'))
    subprocess.run(['node', os.path.join(HERE, 'pp_dump.mjs'), path, tmp], check=True, capture_output=True, text=True)
    g = np.fromfile(os.path.join(tmp, 'g.f64'), '<f8').reshape(3, -1)
    rf = np.fromfile(os.path.join(tmp, 'rf.f64'), '<f8').reshape(2, -1)
    kk = np.fromfile(os.path.join(tmp, 'kadc.f64'), '<f8').reshape(4, -1)
    out, off = {}, 0
    gm = max([np.max(np.abs(x)) for x in gref if x.size] or [0.0])
    err = 0.0
    for a in range(3):
        n = tg[a].size
        if n: err = max(err, float(np.max(np.abs(g[a, off:off + n] - gref[a]))))
        off += n
    out['grad'] = err / gm if gm > 0 else err
    out['rf'] = rel(np.hypot(rf[0], rf[1]), np.abs(srf)) if srf.size else 0.0
    out['rf_complex'] = float(np.max(np.abs(rf[0] + 1j * rf[1] - srf)) / np.max(np.abs(srf))) if srf.size and np.max(np.abs(srf)) > 0 else 0.0
    out['n_adc'] = int(t_adc.size)
    if t_adc.size != kk.shape[1]:
        out['adc_count'] = f'{kk.shape[1]} vs {t_adc.size}'; out['k'] = out['t_adc'] = float('inf')
    else:
        out['t_adc'] = float(np.max(np.abs(kk[0] - t_adc))) if t_adc.size else 0.0  # absolute, s
        out['k'] = rel(kk[1:], k_ref) if t_adc.size else 0.0
    return out


# Differences that are expected: since 1.42.0 Seqret restores the corners of arbitrary gradients on raster edges as
# MATLAB Pulseq does (checked against MATLAB Pulseq 1.5.2: gradients within 2.6e-7 of the peak). PyPulseq does not,
# so the gradients of these files differ by about 2e-2 of the peak between corners; the k-space must still agree.
EXPECTED = {'simple_mprage': ('grad', 'arbitrary-gradient corners as in MATLAB Pulseq (1.42.0)')}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('files', nargs='*')
    ap.add_argument('--pypulseq', help='existing clone of the PyPulseq repository')
    a = ap.parse_args()
    files = a.files
    if not files:
        d = a.pypulseq or os.path.join(HERE, 'out', 'pypulseq')
        if not os.path.isdir(d):
            os.makedirs(os.path.dirname(d), exist_ok=True)
            subprocess.run(['git', 'clone', '-q', '--depth', '1', PP_URL, d], check=True)
        e = os.path.join(d, 'tests', 'expected_output')
        files = sorted(os.path.join(e, f) for f in os.listdir(e) if f.endswith('.seq'))
    fails = skipped = 0
    print(f'{"file":34s} {"ADC samples":>11s} {"gradients":>10s} {"RF |B1|":>10s} {"RF re/im":>10s} {"k at ADC":>10s} {"ADC t (s)":>10s}')
    for f in files:
        name = os.path.basename(f)
        with tempfile.TemporaryDirectory() as tmp:
            try:
                r = compare(f, tmp)
            except subprocess.CalledProcessError as e:
                print(f'{name:34s} Seqret failed: {(e.stderr or "").strip().splitlines()[-1:]}'); fails += 1; continue
            except Exception as e:
                print(f'{name:34s} not compared, PyPulseq cannot read it: {type(e).__name__}: {e}'); skipped += 1; continue
        bad = [k for k in ('grad', 'rf', 'k') if not r[k] <= LIMIT] + (['t_adc'] if not r['t_adc'] <= 1e-9 else [])
        exp = next((v for k, v in EXPECTED.items() if name.startswith(k)), None)
        note = ''
        if exp and exp[0] in bad: bad.remove(exp[0]); note = f'  {exp[0]} differs as expected: {exp[1]}'
        fails += bool(bad)
        extra = (f'  FAIL: {", ".join(bad)}' + (f' (ADC count {r["adc_count"]})' if 'adc_count' in r else '') if bad else '') + note
        print(f'{name:34s} {r["n_adc"]:11d} {r["grad"]:10.1e} {r["rf"]:10.1e} {r["rf_complex"]:10.1e} {r["k"]:10.1e} {r["t_adc"]:10.1e}{extra}')
    n = len(files) - skipped
    print(f'\n{f"all {n} compared files agree" if not fails else f"{fails} of {n} compared file(s) differ"} (limit {LIMIT:g}; ADC times 1 ns)'
          + (f'; {skipped} file(s) not compared' if skipped else ''))
    sys.exit(1 if fails else 0)


if __name__ == '__main__':
    main()

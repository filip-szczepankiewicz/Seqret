# Seqret: development package

Seqret is a Pulseq sequence viewer that runs entirely in the browser as one self-contained HTML file. It reads
Pulseq 1.2 to 1.5 `.seq` files and Pulseq binary `.bin` files locally (nothing is uploaded) and shows the sequence
diagram, shots and volumes, k-space, a simulated image, predicted nerve stimulation, concomitant gradients and the
Maxwell index, the b-tensor per shot, and spin- and gradient-echo markers. Segmented images (several shots per image,
from the SEG label) can be shown with the time between their shots left out (Group segments, experimental).

This package (`seqret-dev-<version>`) holds the sources of that Seqret version (see `version.json`), the build script, tests and tools. It is meant as the starting
point for further development, by a person or together with an LLM coding assistant.

Designed by Filip Szczepankiewicz (Lund University); coded by Claude (Anthropic). MIT License (see LICENSE).
Source repository: https://github.com/filip-szczepankiewicz/Seqret

## Quick start

    python3 build.py                  # src/ + version.json  ->  dist/seqret.html
    node tests/test_core.mjs          # unit and regression tests of the core (Node 18+)
    python3 tests/test_browser.py     # browser smoke test and scenarios (pip install playwright; python -m playwright install chromium)
    python3 tests/compare_pypulseq.py # waveforms, RF and k-space against PyPulseq's test sequences (pip install pypulseq numpy)
    python3 build.py --zip DIR        # build and write DIR/seqret-dev-<version>.zip

Packages are named after the viewer version in `version.json`, so each zip can be traced to the release it holds.

Open `dist/seqret.html` in a browser and press "Load demo", or drop a `.seq` file on the page.
From MATLAB or Octave: `addpath matlab; seqret('scan.seq')` or `seqret(seq)` with an `mr.Sequence` object.

## Contents

| Path | What it is |
|---|---|
| `src/template.html` | page skeleton (header, panels, dialogs) with placeholders filled by the build |
| `src/style.css` | all styles, light and dark theme via CSS variables |
| `src/core.js` | parser and sequence model: typed block table, event geometry, pyramids, shots and volumes, k-space, md5 |
| `src/sim.js` | image simulation: analytic 3D phantoms, per-sample signal model, reconstruction |
| `src/stim.js` | nerve stimulation (SAFE model), hardware files, library of known systems |
| `src/simgl.js` | WebGL2 kernels for the image simulation (GPU path, CPU fallback) |
| `src/ui.js` | everything on the page: diagram drawing, interaction, tabs, loading, settings |
| `src/demo.seq` | built-in demo: diffusion-weighted SE-EPI, 3 slices, 3 volumes (Pulseq 1.5.1; reversed lines marked with REV) |
| `version.json` | name, version, date, credits, licence text and the complete changelog (the source of truth) |
| `CHANGELOG.md` | complete version history, written by the build from `version.json` |
| `build.py` | assembles `dist/seqret.html` (Python standard library only) |
| `dist/seqret.html` | the built viewer |
| `matlab/seqret.m` | opens a file or an `mr.Sequence` in Seqret from MATLAB/Octave |
| `tests/` | Node tests of the core, Playwright tests of the page, comparison with PyPulseq, three small generated test sequences (`tests/data`) |
| `tools/` | generators for stress-test and test sequences |
| `DEVELOPMENT.md` | architecture, design strategy, performance rules, validation, release procedure, open issues |
| `AGENTS.md`, `CLAUDE.md` | short working rules for LLM coding assistants (CLAUDE.md points to AGENTS.md) |

Large test sequences are not included; `DEVELOPMENT.md` (section "Stress tests") explains how to make them.

(function () {
'use strict';
const $ = s => document.querySelector(s);
const S = {
  seq: null, name: '', t0: 0, t1: 1, sel: -1, selItems: [], selAnchor: -1, imgIdx: 0, hoverT: null, hoverGap: null, segOn: false, segFocus: 0, yZoom: {}, autoY: false, pauseHatch: true,
  gUnit: 'mT', rfUnit: 'uT', tab: 'seq', diagRes: 'auto', lineMode: 'exact', sideHidden: false,
  vis: { labels: true, adc: false, rfMag: true, rfPh: false, gx: true, gy: true, gz: true, slew: false, m0: false, gc: false, kc: false, kt: false, mu: false, pns: false, cns: false },
  cc: { r: [0.05, 0.06, 0.07], B0: 3, a: 0.5, f: 0, pos: 'fixed' }, // concomitant gradients: position (m), B0 (T), asymmetry, non-Maxwell term (T/m), position mode ('fixed' r or 'slice' centre of each shot)
  stimNorm: true, combineG: true, rfMode: 'mag', linkMode: 'off',
  echo: { se: true, gf: true, gl: true, zoom: true }, // echo markers (Display › Echoes)
  sim: { eddy: 'off', slicePos: true, show3d: true, orient: 'ax', phantom: 'head', B0: 3, t1: true, t2: true, fatShift: true, diffusion: true, bubble: false, noise: false, fill: true, crop: true, view: 'mag' }, labelsPref: true, volPref: 'auto', shotMode: 'exc', volMode: 'auto', vols: [], selKind: null, hist: [],
  kRange: 'shot', kProj: 'xy', kTraj: true, kActual: false, kR: null, kZoom: 1, kPan: [0, 0], kGroup: 'img'
};
const LANES = [
  { key: 'adc', label: 'ADC', w: 0.42, col: 'adc' },
  { key: 'rfMag', label: 'RF |B1|', w: 1, col: 'rf', kind: 'pos' },
  { key: 'rfPh', label: 'RF phase', w: 0.62, col: 'ph', kind: 'phase' },
  { key: 'gx', label: 'Gx', w: 1, col: 'gx', kind: 'sym' },
  { key: 'gy', label: 'Gy', w: 1, col: 'gy', kind: 'sym' },
  { key: 'gz', label: 'Gz', w: 1, col: 'gz', kind: 'sym' },
  { key: 'slew', label: 'Slew', w: 1, col: 'gx', kind: 'sym' },
  { key: 'm0', label: 'k-vector', w: 1, col: 'gx', kind: 'sym' },
  { key: 'gc', label: 'Gc', w: 1, col: 'gx', kind: 'sym' }, // concomitant gradients at r
  { key: 'kc', label: 'kc', w: 1, col: 'gx', kind: 'sym' }, // their zeroth moment
  { key: 'kt', label: 'k + kc', w: 1, col: 'gx', kind: 'sym' }, // total dephasing vector: k-vector plus kc
  { key: 'mu', label: 'Maxwell μ', w: 1, col: 'ink', kind: 'pos' }, // generalized Maxwell index
  { key: 'pns', label: 'PNS', w: 0.9, col: 'muted', kind: 'pos', stim: 'pns' },
  { key: 'cns', label: 'CNS', w: 0.9, col: 'muted', kind: 'pos', stim: 'cns' },
  { key: 'labels', label: 'Labels', w: 0, col: 'ink', fixed: true }
];
const TYPE_COL = ['adc', 'ref', 'refima', 'noise', 'nav'];
const TYPE_NAME = ['imaging', 'reference', 'reference + imaging', 'noise', 'navigator'];
const TYPE_RANK = [1, 4, 3, 5, 2]; // which type wins a pixel column when zoomed out
const FLAG_COL = { NAV: 'nav', REF: 'ref', NOISE: 'noise', IMA: 'adc' };
function labelRows() {
  const s = S.seq, rows = [];
  if (s.adcBlocks.length) rows.push({ kind: 'type', name: 'ADC type' });
  for (const tr of s.labels) rows.push({ kind: tr.flag ? 'flag' : 'count', name: tr.name, tr });
  if (s.triggers.length) rows.push({ kind: 'trig', name: 'TRIG' }); // trigger events (TRIGGERS extension), drawn like a flag
  return rows;
}
function labelsLaneH(availH) {
  const n = labelRows().length; if (!n) return 0;
  const rh = Math.max(EXP ? 6 : 11, Math.min(18, (availH * 0.42 - 6) / n)); // a figure: within 42 % of the height
  return n * rh + 6;
}
const GLANE = { key: 'g', label: 'Gradients', w: 1.9, col: 'gx', kind: 'sym' };
const USE = { e: 'excitation', r: 'refocusing', i: 'inversion', s: 'saturation', p: 'preparation', o: 'other', u: 'undefined' };
let C = {}; // resolved colors
function readColors() {
  const cs = getComputedStyle(document.documentElement);
  for (const k of ['bg', 'plot', 'ink', 'muted', 'faint', 'line', 'line-soft', 'bad', 'c-rf', 'c-ph', 'c-gx', 'c-gy', 'c-gz', 'c-adc', 'c-ref', 'c-refima', 'c-noise', 'c-nav', 'sel', 'shade', 'warn'])
    C[k.replace('c-', '')] = cs.getPropertyValue('--' + k).trim();
  C.font = cs.getPropertyValue('--font');
}

/* ---------- units ---------- */
const gF = () => S.gUnit === 'mT' ? 1 / (GAMMA * 1e-3) : 1e-3;
const gU = () => S.gUnit === 'mT' ? 'mT/m' : 'kHz/m';
const sF = () => S.gUnit === 'mT' ? 1 / GAMMA : 1e-6;
const sU = () => S.gUnit === 'mT' ? 'T/m/s' : 'kHz/m/ms';
const rF = () => S.rfUnit === 'uT' ? 1e6 / GAMMA : 1;
const rU = () => S.rfUnit === 'uT' ? 'µT' : 'Hz';
function laneFactor(k) { return k === 'rfMag' ? rF() : (k === 'rfPh' || k === 'adc' || k === 'mu') ? 1 : k === 'slew' ? sF() : k === 'm0' || k === 'kc' || k === 'kt' ? mF() : gF(); }
function laneUnit(k) { return k === 'rfMag' ? rU() : k === 'rfPh' ? 'rad' : k === 'mu' ? '1/m²' : k === 'slew' ? sU() : k === 'adc' ? '' : k === 'm0' || k === 'kc' || k === 'kt' ? mU() : gU(); }
/* concomitant gradients for the current parameters (rebuilt by ccState only when they, or the file, change) */
function ccEnsure() { if (S.seq) ccState(S.seq, S.cc); }
/* the generalized Maxwell index for the current B0 (its integrals are made once per file; B0 only scales them) */
function muEnsure() { if (S.seq) mxState(S.seq, S.cc.B0); }
const mF = () => 1; // k-vector: ∫G dt with G in Hz/m, in 1/m whatever the gradient unit
const mU = () => '1/m';

function fmt(v, d = 3) {
  if (v === 0) return '0';
  if (!isFinite(v)) return '–';
  const a = Math.abs(v);
  if (a >= 1e5 || a < 1e-3) return v.toExponential(2);
  const p = Math.max(0, d - 1 - Math.floor(Math.log10(a)));
  return v.toFixed(Math.min(p, 6));
}
function fmtT(s) { // seconds -> auto string
  const a = Math.abs(s);
  if (a >= 1) return fmt(s, 5) + ' s';
  if (a >= 1e-3) return fmt(s * 1e3, 5) + ' ms';
  return fmt(s * 1e6, 4) + ' µs';
}
const us = s => fmt(s * 1e6, 5) + ' µs';

/* ---------- search helpers ---------- */
function lb(a, x, n = a.length) { let lo = 0, hi = n; while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] < x) lo = m + 1; else hi = m; } return lo; }
function ub(a, x, n = a.length) { let lo = 0, hi = n; while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] <= x) lo = m + 1; else hi = m; } return lo; }
function blockAt(t) { const s = S.seq; if (!s) return -1; return blockAtTime(s, t); }

/* ---------- canvas setup ---------- */
const plot = $('#plot'), ovl = $('#ovl'), ov = $('#ov'), kc = $('#kc'), ic = $('#ic'), i3 = $('#i3');
const pctx = plot.getContext('2d'), octx = ovl.getContext('2d'), vctx = ov.getContext('2d'), kctx = kc.getContext('2d'), ictx = ic.getContext('2d'), i3ctx = i3.getContext('2d');
let IW = 0, I3W = 0, I3H = 0;
/* position of a pointer or wheel event over the diagram, from the canvas's rectangle kept between events (1.48.1).
   e.offsetX and e.offsetY make the browser lay the page out again whenever anything in it has changed since the last
   frame, and a frame writes the readout and the navigation fields, so every wheel and move event while panning and
   zooming paid for a layout. The rectangle is read again after a resize or a scroll, when the pointer enters or
   presses, and at the latest after half a second. */
let ovlBox = null, ovlBoxT = 0;
function ovlRect() { const now = performance.now(); if (!ovlBox || now - ovlBoxT > 500) { ovlBox = ovl.getBoundingClientRect(); ovlBoxT = now; } return ovlBox; }
const ovlStale = () => { ovlBox = null; };
const pX = e => e.clientX - ovlRect().left, pY = e => e.clientY - ovlRect().top;
window.addEventListener('scroll', ovlStale, true); window.addEventListener('resize', ovlStale); ovl.addEventListener('pointerenter', ovlStale);
let W = 0, H = 0, OW = 0, OH = 0, KW = 0, dpr = 1;
/* pixel density of the diagram and the overview (pdpr): the screen's (dpr) when sharp; at most 1 when fast (Display ›
   Diagram resolution), which on a high-density screen draws a quarter of the pixels at 2× and lets the browser scale
   them up. For browsers whose drawing is limited by the number of pixels. The cursor overlay, k-space and image stay at
   the screen's density. PNG export always draws at the screen's density (PNG_FULL). */
let pdpr = 1, PNG_FULL = false, odpr = 1; // odpr: the overview's density (the diagram's at rest)
/* Diagram quality 'auto' (1.44.0, the default): 'fast' while the view moves, 'high' when it stands still. The frame-rate
   test showed the browser's drawing of dense stretches at full density as the limit (an 8,806-block file at 2.5×:
   40 fps standard, 117 fps fast, with the same columns and values; only the pixel density differs), whichever way the
   min/max bands were drawn. Moving: two view changes within 150 ms (panning, zooming, scrolling, pinching, the
   overview), not a frame time, so a single jump (zoom to a block) stays sharp; still: 200 ms after the last change.
   Only the diagram's canvas is resized at these two moments; the overview, cursor overlay, k-space and image keep
   theirs. */
let MOVING = false, lastViewT = 0, moveTimer = 0;
function diagQ() { const q = BENCH.quality || S.diagRes; return q === 'auto' ? (MOVING ? 'fast' : 'high') : q; }
function plotDensity() { return PNG_FULL || diagQ() !== 'fast' ? dpr : Math.min(1, dpr); }
function noteViewChange() {
  if ((BENCH.quality || S.diagRes) !== 'auto' || EXP || PNG_FULL) { if (MOVING) { MOVING = false; clearTimeout(moveTimer); } return; }
  const now = performance.now(), cont = now - lastViewT < 150; lastViewT = now;
  if (cont && !MOVING) { MOVING = true; applyDensity(); }
  if (MOVING) { clearTimeout(moveTimer); moveTimer = setTimeout(() => { MOVING = false; applyDensity(); }, 200); }
}
function applyDensity() { const d = plotDensity(); if (d !== pdpr) { pdpr = d; sizeCanvas(plot, pctx, W, H, pdpr); } request(); }
let EXP = null; // while a figure is drawn for Save figure… (figure export, below): its options
let GUT = 84, AXH = 26; const SHOTH = 20; // GUT, AXH: smaller in a figure without lane names or time axis (EXP)
const shotsOn = () => S.seq && S.shotMode !== 'off' && S.seq.shots.length > 0 && (!EXP || EXP.shots);
const volsOn = () => S.seq && S.volMode !== 'off' && S.vols.length > 0 && (!EXP || EXP.vols);
const volY = () => 4, shotY = () => 4 + (volsOn() ? SHOTH + 4 : 0);
const topH = () => (shotsOn() ? shotY() + SHOTH + 8 : volsOn() ? volY() + SHOTH + 8 : 6);
function sizeCanvas(cv, ctx, w, h, d = dpr) { // only touch the canvas when its size really changes (resizing clears it)
  const W2 = Math.round(w * d), H2 = Math.round(h * d);
  if (cv.width !== W2 || cv.height !== H2) { cv.width = W2; cv.height = H2; }
  ctx.setTransform(d, 0, 0, d, 0, 0);
}
function resize() {
  dpr = window.devicePixelRatio || 1;
  pdpr = plotDensity(); { const q = BENCH.quality || S.diagRes; odpr = PNG_FULL || q !== 'fast' ? dpr : Math.min(1, dpr); }
  /* 1.48.1: each canvas is given the size of its own box. Before, it was that of the frame around it, which includes
     the frame's 1 px border on every side, so the canvas held 2 CSS px more each way than it is shown at and the
     browser scaled it down (the diagram by 0.2 %, the overview's 52 rows into 50), which blurred lines drawn on whole
     pixels and put the pointer up to 2 px off at the right and lower edges. */
  ovlBox = null;
  const r = plot.getBoundingClientRect(); W = r.width; H = r.height;
  sizeCanvas(plot, pctx, W, H, pdpr); sizeCanvas(ovl, octx, W, H);
  const o = ov.getBoundingClientRect(); OW = o.width; OH = o.height;
  sizeCanvas(ov, vctx, OW, OH, odpr);
  const kk = kc.getBoundingClientRect(); KW = kk.width;
  if (KW > 0) sizeCanvas(kc, kctx, KW, KW);
  const ii = ic.getBoundingClientRect(); if (ii.width > 0 && Math.abs(ii.width - IW) > 0.5) { IW = ii.width; sizeCanvas(ic, ictx, IW, IW); drawImg(); }
  const j3 = i3.getBoundingClientRect(); if (j3.width > 0 && (Math.abs(j3.width - I3W) > 0.5 || Math.abs(j3.height - I3H) > 0.5)) { I3W = j3.width; I3H = j3.height; sizeCanvas(i3, i3ctx, I3W, I3H); drawSlice3D(); }
  ovCache = null; kInvalidate(); request(); requestK();
}
new ResizeObserver(resize).observe($('#plotwrap'));
new ResizeObserver(resize).observe(kc.parentElement);
new ResizeObserver(resize).observe(ic.parentElement);
new ResizeObserver(resize).observe(i3.parentElement);
new ResizeObserver(resize).observe(ov.parentElement);

/* ---------- lane geometry ---------- */
function lanesGeom() {
  const vis = [];
  for (const l of LANES) {
    const isG = l.key === 'gx' || l.key === 'gy' || l.key === 'gz';
    if (isG && (EXP ? EXP.combineG : S.combineG)) { if (!vis.includes(GLANE) && (S.vis.gx || S.vis.gy || S.vis.gz)) vis.push(GLANE); continue; }
    if (S.vis[l.key]) vis.push(l.key === 'rfMag' && S.rfMode === 'complex' ? { ...l, kind: 'sym', label: 'RF B1' } : l);
  }
  const tot = vis.reduce((s, l) => s + l.w, 0) || 1, TOP = topH();
  const gap = 8, avail0 = H - AXH - TOP - gap * (vis.length - 1);
  const fixedH = l => l.fixed ? labelsLaneH(avail0) : 0;
  const avail = avail0 - vis.reduce((s, l) => s + fixedH(l), 0);
  let y = TOP; const out = [];
  for (const l of vis) { const h = l.fixed ? fixedH(l) : avail * l.w / tot; out.push({ ...l, y, h }); y += h + gap; }
  return out;
}
function laneChannels(l) {
  if (l.key === 'slew') return [['gx', 'sx'], ['gy', 'sy'], ['gz', 'sz']];
  if (l.key === 'm0') return [['gx', 'mx'], ['gy', 'my'], ['gz', 'mz']];
  if (l.key === 'gc') { ccEnsure(); return [['gx', 'cx'], ['gy', 'cy'], ['gz', 'cz']]; }
  if (l.key === 'kc') { ccEnsure(); return [['gx', 'qx'], ['gy', 'qy'], ['gz', 'qz']]; }
  if (l.key === 'kt') { ccEnsure(); return [['gx', 'tx'], ['gy', 'ty'], ['gz', 'tz']]; }
  if (l.key === 'mu') { muEnsure(); return [['ink', 'mu']]; }
  if (l.key === 'rfMag' && S.rfMode === 'complex') return [['ph', 'rfIm'], ['rf', 'rfRe']]; // imaginary first: the real part is drawn on top
  if (l.key === 'g') return ['gx', 'gy', 'gz'].filter(k => S.vis[k]).map(k => [k, k]);
  return [[l.col, l.key]];
}
/* y zoom per lane (Ctrl + wheel over a lane, or a touchpad pinch over its name; double-clicking the lane's name resets it): the lane's scale is divided by the factor, on
   top of the scale the lane would have (fixed, or Fit Y to view), with zero kept where it is. Not for the RF phase, the
   ADC and the labels. Kept per lane key until another file is opened. */
const YZ_MIN = 0.25, YZ_MAX = 1e4;
function yZoomable(key) { return key !== 'rfPh' && key !== 'adc' && key !== 'labels'; }
function yZoomOf(key) { return yZoomable(key) ? (S.yZoom[key] || 1) : 1; }
function laneMax(l) {
  const st = S.seq.stats;
  if (l.key === 'rfMag') return st.maxRF;
  if (l.key === 'rfPh') return Math.PI;
  if (l.key === 'adc') return 1;
  if (l.key === 'slew') return Math.max(...st.maxSlew);
  if (l.key === 'm0') { m0Pyramids(S.seq); return KP_M0.st(S.seq).max; }
  if (l.key === 'gc') { ccEnsure(); return Math.max(...S.seq.cc.max); }
  if (l.key === 'mu') { muEnsure(); kintPyramids(KP_MU, S.seq); return KP_MU.st(S.seq).max; }
  return Math.max(...st.maxG); // shared scale across gradient axes
}

/* ---------- decimating polyline ---------- */
let colMin = new Float64Array(0), colMax, colFirst, colLast, colHas, colBrk;
/* a break inside a column (the k-vector's reset at an excitation): the part before it, emitted before the break */
let preHas = new Uint8Array(0), preMin, preMax, preFirst, preLast, preN, preX, brkPre;
/* times of each column's first, minimum, maximum and last value, and whether they are exact (1.24.0): with them, a
   short feature is drawn through its extremes where they happen (M4, Jugel et al., PVLDB 7(10) 2014), instead of as a
   bar at the column's centre */
let colTf = new Float64Array(0), colTmn, colTmx, colTl, colEx, colRun;
function ensureTimes(n) { if (colTf.length < n) { colTf = new Float64Array(n); colTmn = new Float64Array(n); colTmx = new Float64Array(n); colTl = new Float64Array(n); colEx = new Uint8Array(n); colRun = new Int32Array(n); } }
function ensureCols(n) { if (colMin.length < n) { colMin = new Float64Array(n); colMax = new Float64Array(n); colFirst = new Float64Array(n); colLast = new Float64Array(n); colHas = new Uint8Array(n); colBrk = new Uint8Array(n); } }
function ensurePre(n) { if (preHas.length < n) { preHas = new Uint8Array(n); brkPre = new Uint8Array(n); preMin = new Float64Array(n); preMax = new Float64Array(n); preFirst = new Float64Array(n); preLast = new Float64Array(n); preN = new Float64Array(n); preX = new Float64Array(n); } }
function tracePoints(c, t0, t1, x0, w) {
  // returns flat array [x,y(value),...] with NaN value for pen-up
  const n = c.t.length, pts = []; if (!n) return pts;
  const i0 = Math.max(0, ub(c.t, t0) - 1), i1 = Math.min(n - 1, lb(c.t, t1));
  const sc = w / (t1 - t0);
  const X = t => x0 + (t - t0) * sc;
  if (i1 - i0 < 3 * w) {
    for (let i = i0; i <= i1; i++) pts.push(X(c.t[i]), c.v[i]);
    return pts;
  }
  const nc = Math.ceil(w) + 1; ensureCols(nc); colHas.fill(0, 0, nc); colBrk.fill(0, 0, nc);
  let s = i0, e = i1;
  if (c.t[i0] < t0) { pts.push(X(c.t[i0]), c.v[i0]); s++; }
  const tail = c.t[i1] > t1; if (tail) e--;
  const pyr = c.pyr || (c.pyr = buildPyr(c));
  const col = t => { let k = Math.floor((t - t0) * sc); return k < 0 ? 0 : k >= nc ? nc - 1 : k; };
  /* 1.45.0: per column, its vertex range by binary search, then that range from the largest aligned buckets (sizes
     are powers of two, so the bucket follows from the index's alignment and the vertices left, as in rangeSummary).
     The same result as trying every level at every vertex, with far fewer steps (the labels lane of a 1M-block file
     was over half of a zoomed-out frame). */
  const lv = pyrLevel(pyr), T = c.t, V = c.v, z0 = pyr.length ? pyr[0].size - 1 : -1;
  let i = s;
  while (i <= e) {
    const k = col(T[i]); let j = e;
    if (k < nc - 1) { const tEnd = t0 + (k + 1) / sc; let lo = i, hi = e; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (T[m] < tEnd) lo = m; else hi = m - 1; } j = lo; }
    while (i <= j) {
      if (z0 >= 0 && (i & z0) === 0 && i + z0 <= j) {
        const al = i === 0 ? 32 : 31 - Math.clz32(i & -i), fit = 31 - Math.clz32(j - i + 1), L = lv[al < fit ? al : fit];
        if (L >= 0) {
          const P = pyr[L], sz = P.size, b = i / sz;
          if (P.nan[b]) colBrk[k] = 1;
          if (P.has[b]) {
            if (!colHas[k]) { colHas[k] = 1; colMin[k] = P.mn[b]; colMax[k] = P.mx[b]; colFirst[k] = P.first[b]; }
            else { if (P.mn[b] < colMin[k]) colMin[k] = P.mn[b]; if (P.mx[b] > colMax[k]) colMax[k] = P.mx[b]; }
            colLast[k] = P.last[b];
          }
          i += sz; continue;
        }
      }
      const v = V[i]; i++;
      if (v !== v) { colBrk[k] = 1; continue; }
      if (!colHas[k]) { colHas[k] = 1; colMin[k] = colMax[k] = colFirst[k] = colLast[k] = v; }
      else { if (v < colMin[k]) colMin[k] = v; if (v > colMax[k]) colMax[k] = v; colLast[k] = v; }
    }
  }
  for (let k = 0; k < nc; k++) {
    const x = x0 + k + 0.5;
    if (colHas[k]) { pts.push(x, colFirst[k], x, colMin[k], x, colMax[k], x, colLast[k]); }
    if (colBrk[k]) pts.push(x, NaN);
  }
  if (tail) pts.push(X(c.t[i1]), c.v[i1]);
  return pts;
}
function buildPyr(c) {
  // min/max summaries over fixed-size vertex buckets, for fast zoomed-out drawing
  const out = [], n = c.t.length;
  for (const sz of [32, 128, 512, 2048, 8192, 32768, 131072]) { // 1.45.0: factor 4 (was 32), fewer steps per pixel column
    const nb = Math.floor(n / sz); if (nb < 2) break;
    const P = { size: sz, t0: new Float64Array(nb), t1: new Float64Array(nb), mn: new Float64Array(nb), mx: new Float64Array(nb), first: new Float64Array(nb), last: new Float64Array(nb), has: new Uint8Array(nb), nan: new Uint8Array(nb) };
    for (let b = 0; b < nb; b++) {
      const a = b * sz; let mn = Infinity, mx = -Infinity, f = NaN, l = NaN, nan = 0;
      for (let i = a; i < a + sz; i++) { const v = c.v[i]; if (v !== v) { nan = 1; continue; } if (f !== f) f = v; l = v; if (v < mn) mn = v; if (v > mx) mx = v; }
      P.t0[b] = c.t[a]; P.t1[b] = c.t[a + sz - 1]; P.mn[b] = mn; P.mx[b] = mx; P.first[b] = f; P.last[b] = l; P.has[b] = f === f ? 1 : 0; P.nan[b] = nan;
    }
    out.push(P);
  }
  return out;
}
/* Channel tracing on the block model: pyramid buckets and single blocks that fall inside one pixel
   column are merged from their min/max summaries; wider blocks contribute exact vertices. */
let cN = new Float64Array(0), cX = new Float64Array(0);
/* columns per CSS pixel for traces, decided per frame from the view and the diagram quality (below). In 'standard'
   (1.14.2-1.17.0): one per screen pixel on high-density screens only when zoomed in (fewer visible blocks than half the
   plot width), one per CSS pixel zoomed out, which was cheaper with Chrome's older renderer (measured in a software-
   rendering test browser; 1.18.0 showed it makes dense stretches look blocky). Never chosen from timing: a timing-based
   switch flipped back and forth between frames (a slow frame made it coarse, the fast coarse frame made it fine). */
let traceR = 1;
/* Display › Diagram quality 'high' (1.18.0): one column per screen pixel at every zoom level, so dense stretches keep
   their shape (thin RF pulses, fine readout trains) instead of widening to whole CSS pixels. Costs more rectangles
   and, zoomed out, up to about twice Seqret's time per frame on small files (15-30 % more on large ones). 'standard' is the drawing of 1.14.2-1.17.0, 'fast' is standard at 1× density. */
function chooseTraceR(t0, t1, pw) {
  if (EXP) return Math.min(8, Math.max(1, Math.round(pdpr))); // a figure: one column per output pixel
  const q = diagQ();
  if (q === 'ultra') return Math.min(6, 2 * Math.max(1, pdpr || 1)); // two columns per screen pixel, drawn anti-aliased
  if (q === 'high') return Math.min(3, Math.max(1, pdpr || 1));
  const bs = S.seq.blockStart, nVis = ub(bs, t1) - lb(bs, t0); return nVis <= pw / 2 ? Math.min(2, Math.max(1, pdpr || 1)) : 1;
}
function traceChan(key, t0, t1, x0, w) {
  const s = S.seq, bs = s.blockStart, pts = [];
  // columns per device pixel (up to 2 per CSS px); one per CSS px while frames are slow (very large files)
  const r = traceR, sc = w / (t1 - t0), nc = Math.ceil(w * r) + 1;
  ensureCols(nc); if (cN.length < nc) { cN = new Float64Array(nc); cX = new Float64Array(nc); }
  colHas.fill(0, 0, nc); colBrk.fill(0, 0, nc); ensurePre(nc); preHas.fill(0, 0, nc); brkPre.fill(0, 0, nc);
  const col = t => { const k = Math.floor((t - t0) * sc * r); return k < 0 ? -1 : k >= nc ? nc : k; };
  let pre = null, post = null;
  ensureTimes(nc); const exactMode = !!EXP || (BENCH.lineMode || S.lineMode) === 'exact';
  // tmn, tmx, tf, tl: times of the minimum, maximum, first and last value (undefined: not known, e.g. from a summary)
  const agg = (k, mn, mx, first, last, x, cnt, tmn, tmx, tf, tl) => {
    const ex = tmn !== undefined;
    if (!colHas[k]) { colHas[k] = 1; colMin[k] = mn; colMax[k] = mx; colFirst[k] = first; colLast[k] = last; cN[k] = cnt; cX[k] = x; colEx[k] = ex ? 1 : 0; if (ex) { colTmn[k] = tmn; colTmx[k] = tmx; colTf[k] = tf; colTl[k] = tl; } }
    else {
      if (mn < colMin[k]) { colMin[k] = mn; if (ex) colTmn[k] = tmn; } if (mx > colMax[k]) { colMax[k] = mx; if (ex) colTmx[k] = tmx; }
      colLast[k] = last; cN[k] += cnt; if (ex) colTl[k] = tl; else colEx[k] = 0;
    }
  };
  const add = (t, v) => {
    const k = col(t);
    if (k < 0) { pre = v === v ? [t, v] : null; return; }
    if (k >= nc) { if (!post && v === v) post = [t, v]; return; }
    if (v !== v) { // a break: keep what the column holds so far as its part before the break, and start anew
      if (colHas[k] && !preHas[k]) { preHas[k] = 1; preMin[k] = colMin[k]; preMax[k] = colMax[k]; preFirst[k] = colFirst[k]; preLast[k] = colLast[k]; preN[k] = cN[k]; preX[k] = cX[k]; colHas[k] = 0; }
      else if (!colHas[k]) brkPre[k] = 1; else colBrk[k] = 1;
      return;
    }
    agg(k, v, v, v, v, x0 + (t - t0) * sc, 1, t, t, t, t);
  };
  const o = {}, tmp = {}, nb = s.nb;
  const b0 = blockAtTime(s, t0), b1 = blockAtTime(s, t1);
  for (let b = b0; b <= b1;) {
    const ka = col(bs[b]), kb = col(bs[b + 1]);
    if (ka === kb && ka >= 0 && ka < nc) {
      // all blocks that end inside this column, combined through the pyramid
      const tEnd = t0 + (ka + 1) / (sc * r); let lo = b, hi = Math.min(b1, nb - 1);
      while (lo < hi) { const m = (lo + hi + 1) >> 1; if (bs[m + 1] <= tEnd) lo = m; else hi = m - 1; }
      rangeSummary(s, key, b, lo, o, tmp);
      if (o.has) agg(ka, o.mn, o.mx, o.first, o.last, 0, 2); if (o.brk) colBrk[ka] = 1;
      b = lo + 1; continue;
    }
    if (!exactMode && kb - ka <= 3 && ka >= 0 && kb < nc && !(key in KINT && s.B.rf[b] && rfSt(s, s.B.rf[b]).use === 'e') && blockSummary(s, key, b, o).has && (o.n || 0) > 32) { for (let k = ka; k <= kb; k++) agg(k, o.mn, o.mx, k === ka ? o.first : o.mn, k === kb ? o.last : o.mx, 0, 2); if (o.brk) colBrk[kb] = 1; }
    else if (!manyVerts(b)) blockVertices(s, key, b, add);
    b++;
  }
  /* blocks with many vertices (free waveforms) spanning several columns: the same result as feeding every vertex to
     add(), column by column: the vertex range of each column by binary search, its min/max from 32-vertex chunks */
  function manyVerts(b) {
    const KI = KINT[key], m0a = KI ? KI[1] : -1, ch = CHANNELS[key];
    if (m0a < 0 && (!ch || ch.p)) return false;
    let T, V, n, tb = bs[b];
    if (m0a >= 0) { const m = kintBlock(KI[0], s, b); T = m.t; V = m.v[m0a]; n = T.length; if (n < 64 || m.reset >= 0) return false; aggVerts(T, V, n, tb, m.host || m, 'c' + m0a, m.off[m0a]); return true; } // a reset: vertex by vertex (it breaks the curve)
    const id = s.B[ch.col][b]; if (!id) return false;
    const g = ch.fn(s, id); n = g.n; if (n < 64) return false;
    const dur = bs[b + 1] - tb, first = g.t[0] <= 1e-9 ? g.v[0] : 0, last = Math.abs(g.t[n - 1] - dur) <= 1e-9 ? g.v[n - 1] : 0;
    add(tb, first); if (first === 0 && g.v[0] !== 0) add(tb + g.t[0], 0);            // as blockVertices
    aggVerts(g.t, g.v, n, tb, g, 'c');
    if (last === 0 && g.v[n - 1] !== 0) add(tb + g.t[n - 1], 0); add(bs[b + 1], last);
    return true;
  }
  function aggVerts(T, V, n, tb, host, tag, off = 0) { // values V + off (off: a block's start value, 1.45.0)
    const cc = host._chunks || (host._chunks = {}); let C = cc[tag];
    if (!C) { const m = Math.ceil(n / 32), mn = new Float64Array(m).fill(Infinity), mx = new Float64Array(m).fill(-Infinity), imn = new Int32Array(m), imx = new Int32Array(m); for (let i = 0; i < n; i++) { const q = i >> 5, v = V[i]; if (v < mn[q]) { mn[q] = v; imn[q] = i; } if (v > mx[q]) { mx[q] = v; imx[q] = i; } } C = cc[tag] = { mn, mx, imn, imx }; }
    const colOf = i => col(tb + T[i]);
    let i = 0;
    // vertices left of the view: the last one becomes `pre` (as add() does)
    if (colOf(0) < 0) { let lo = 0, hi = n - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (colOf(m) < 0) lo = m; else hi = m - 1; } const v = V[lo] + off; pre = v === v ? [tb + T[lo], v] : null; i = lo + 1; }
    while (i < n) {
      const k = colOf(i); if (k >= nc) { if (!post && V[i] === V[i]) post = [tb + T[i], V[i] + off]; return; }
      let lo = i, hi = n - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (colOf(m) <= k) lo = m; else hi = m - 1; }
      let mn = Infinity, mx = -Infinity, a = i, jn = i, jx = i; const e = lo;
      while (a <= e && (a & 31)) { const v = V[a]; if (v < mn) { mn = v; jn = a; } if (v > mx) { mx = v; jx = a; } a++; }
      while (a + 31 <= e) { const q = a >> 5; if (C.mn[q] < mn) { mn = C.mn[q]; jn = C.imn[q]; } if (C.mx[q] > mx) { mx = C.mx[q]; jx = C.imx[q]; } a += 32; }
      while (a <= e) { const v = V[a]; if (v < mn) { mn = v; jn = a; } if (v > mx) { mx = v; jx = a; } a++; }
      agg(k, mn + off, mx + off, V[i] + off, V[e] + off, x0 + (tb + T[i] - t0) * sc, e - i + 1, tb + T[jn], tb + T[jx], tb + T[i], tb + T[e]);
      i = e + 1;
    }
  }
  if (pre) pts.push(x0 + (pre[0] - t0) * sc, pre[1]);
  const env = []; let run = null;
  // exact mode: the length of each stretch of dense columns (a column holding several values); short ones are drawn
  // through their extremes at their times, long ones (readout trains, a ZTE view) as before, where it keeps frames cheap
  if (exactMode) for (let k = 0; k < nc;) { if (!(colHas[k] && cN[k] > 1)) { colRun[k++] = 0; continue; } let e = k; while (e < nc && colHas[e] && cN[e] > 1 && !preHas[e] && !brkPre[e]) e++; for (let q = k; q < Math.max(e, k + 1); q++) colRun[q] = Math.max(e, k + 1) - k; k = Math.max(e, k + 1); }
  const tx = t => x0 + (t - t0) * sc, q4 = [];
  for (let k = 0; k < nc; k++) {
    if (preHas[k] || brkPre[k]) { // the part before a break inside this column, then the break
      if (preHas[k]) {
        if (preN[k] === 1) { pts.push(preX[k], preFirst[k]); if (run) { run.x.push(preX[k]); run.mn.push(preFirst[k]); run.mx.push(preFirst[k]); if (run.xt) run.xt.push(0); } }
        else { const x = x0 + (k + 0.5) / r; pts.push(x, preFirst[k], x, preLast[k]); if (!run) { run = { x: [], mn: [], mx: [], xt: [] }; env.push(run); } run.x.push(x); run.mn.push(preMin[k]); run.mx.push(preMax[k]); run.xt.push(0); }
      }
      pts.push(x0 + (k + 0.5) / r, NaN); run = null;
    }
    if (colHas[k]) {
      if (cN[k] === 1) { pts.push(cX[k], colFirst[k]); if (run) { run.x.push(cX[k]); run.mn.push(colFirst[k]); run.mx.push(colFirst[k]); if (run.xt) run.xt.push(0); } } // a single sample continues a band
      else if (exactMode && colEx[k] && EXP) { // first, minimum, maximum and last in time order, where they happen
        q4.length = 0; q4.push(colTf[k], colFirst[k], colTmn[k], colMin[k], colTmx[k], colMax[k], colTl[k], colLast[k]);
        /* the first value first and the last value last, the minimum and maximum between them in time order: vertex
           times are sums (block start + event time) and can be out of order by rounding where a block's last vertex
           meets the next block's first, so sorting all four by time could put the last value before the first (1.33.4
           drew a ramp's slew running on to the next event). A step (two values at one time, e.g. a ramp ending where
           the gradient stops) keeps both ends; only repeats go. */
        const ord = q4[2] <= q4[4] ? [0, 2, 4, 6] : [0, 4, 2, 6]; let lt = NaN, lv = NaN;
        for (const j of ord) { if (q4[j] === lt && q4[j + 1] === lv) continue; pts.push(tx(q4[j]), q4[j + 1]); lt = q4[j]; lv = q4[j + 1]; }
        run = null;
      }
      else if (EXP) { // a figure: the column's values as points of one stroked path (no bands), at the device-pixel column
        const x = x0 + (k + 0.5) / r, up = colFirst[k] <= colLast[k]; pts.push(x, colFirst[k], x, up ? colMin[k] : colMax[k], x, up ? colMax[k] : colMin[k], x, colLast[k]); run = null;
      }
      else {
        const x = x0 + (k + 0.5) / r; pts.push(x, colFirst[k], x, colLast[k]);
        if (!run) { run = { x: [], mn: [], mx: [], xt: [] }; env.push(run); } run.x.push(x); run.mn.push(colMin[k]); run.mx.push(colMax[k]);
        run.xt.push(exactMode && colEx[k] && colRun[k] < SPAN_MIN ? 1 : 0); // peaks exact (1.45.0 on screen): drawn to its extremes
      }
    } else run = null;
    if (colBrk[k]) { pts.push(x0 + (k + 0.5) / r, NaN); run = null; }
  }
  if (post) pts.push(x0 + (post[0] - t0) * sc, post[1]);
  pts.env = env; // min/max band where a column holds many samples
  pts.x0 = x0; pts.r = r; pts.nc = nc; // the column grid (for solidTrace, areaRects)
  return pts;
}
function chanRange(key, t0, t1) { // max |value| in [t0, t1] (edge blocks may overestimate slightly)
  const s = S.seq, o = rangeSummary(s, key, blockAtTime(s, t0), blockAtTime(s, t1), {}, {});
  return o.has ? Math.max(Math.abs(o.mn), Math.abs(o.mx)) : 0;
}
function adcAt(t) { const s = S.seq, j = lb(s.adcT1, t); return j < s.adcT0.length && s.adcT0[j] <= t ? j : -1; }
function trStep(tr) {
  if (tr.step) return tr.step;
  const n = tr.t.length, pt = new Float64Array(2 * n), pv = new Float64Array(2 * n);
  for (let i = 0; i < n; i++) { pt[2 * i] = tr.t[i]; pv[2 * i] = i ? tr.v[i - 1] : tr.v[0]; pt[2 * i + 1] = tr.t[i]; pv[2 * i + 1] = tr.v[i]; }
  return (tr.step = { t: pt, v: pv });
}
/* min/max band of columns holding many samples: filled, with thin upper and lower edges */
/* Dense traces are drawn with fillRect spans instead of long paths. A zoomed-out trace is thousands of vertices that
   double back on themselves; stroking that (round joins, 1-1.35 px, anti-aliased) is among the slowest things a
   canvas does, on the GPU as in software (measured: ~1.8 s per trace in Chromium's GPU pipeline on SwiftShader, 16 ms
   as spans), while what it paints is a vertical span per pixel column. So where columns hold many samples the same
   pixels are painted as rectangles, grouped by style; sparse stretches stay anti-aliased paths. */
const SPAN_MIN = 24; // runs shorter than this stay paths (cheap either way)
/* rectangles of one style, merged when one continues the previous with the same top and height: far fewer canvas
   calls when zoomed out (neighbouring columns often have the same band), the same pixels (columns lie on whole device
   pixels, so no seam changes; same colour and alpha, so the order of overlapping rectangles does not matter) */
/* rectangles of one style, merged along a row where they line up (far fewer calls when zoomed out), each drawn with
   fillRect. From 1.14.2 to 1.16.1 they were collected in one Path2D and filled once, which saves main-thread time but
   is slower on a real graphics card: a path of hundreds of rectangles is rasterised as a general path, fillRect as
   rectangles (frame-rate test on a laptop, whole demo in view: 111 fps as a path, 170 fps as fillRect, same pixels;
   the comparison case was removed from the frame-rate test in 1.24.3). */
/* snapY (1.45.0, the traces' rectangles): top and bottom also on whole device pixels (at least one pixel high), so that
   neighbouring columns whose extremes differ by less than a pixel merge into one rectangle (a flat envelope zoomed out
   is then one rectangle instead of one per column), and every rectangle is drawn without anti-aliasing */
function rectRun(ctx, snapY = false) {
  let x = 0, y = 0, w = 0, h = 0, on = false;
  // left and right edges on whole device pixels, so that neighbouring rectangles meet exactly as in one path; else both
  // cover the shared pixel partly and the colour underneath shows through as a faint seam (at 1.25× or 1.75× pixels)
  // ultra quality: columns narrower than a screen pixel, drawn where they fall (anti-aliased edges smooth the steps);
  // otherwise edges snapped to whole screen pixels
  const d = pdpr || 1, ultra = diagQ() === 'ultra', sn = ultra ? (v => v) : (v => Math.round(v * d) / d);
  const put = () => { const xa = sn(x); let xb = sn(x + w); if (xb <= xa) xb = xa + (ultra ? 1e-3 : 1 / d); ctx.fillRect(xa, y, xb - xa, h); }; // never thinner than one device pixel
  return {
    add(ax, ay, aw, ah) {
      if (snapY && !ultra) { const ya = Math.round(ay * d) / d; let yb = Math.round((ay + ah) * d) / d; if (yb <= ya) yb = ya + 1 / d; ay = ya; ah = yb - ya; }
      if (on && ay === y && ah === h && Math.abs(ax - (x + w)) < 1e-9) { w += aw; return; } if (on) put(); x = ax; y = ay; w = aw; h = ah; on = true; },
    flush() { if (on) put(); on = false; }
  };
}
function colWidth(xs, n) { let w = Infinity; for (let i = 1; i < n; i++) { const d = xs[i] - xs[i - 1]; if (d > 1e-6 && d < w) w = d; } return w === Infinity ? 1 : Math.min(1, w); }
/* vertical limits for rectangles in the lane being drawn (set by laneBody): values far outside the lane's scale (the
   k-vector after the last readout can be orders of magnitude beyond it) otherwise give rectangles millions of pixels
   tall, which the browser draws through a slow general path even though the clip hides almost all of them */
let RY0 = -1e6, RY1 = 1e6;
const cy = y => y < RY0 ? RY0 : y > RY1 ? RY1 : y;
function fillEnvelope(ctx, env, yOf, color) {
  if (!env || !env.length || BENCH.skip.env) return;
  ctx.fillStyle = color; ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.lineJoin = 'round';
  const long = [];
  // short runs: all bands in one fill, all upper edges in one stroke, all lower edges in another (three calls instead
  // of three per run; runs never overlap, and upper and lower edges stay separate strokes, so the pixels are the same)
  const band = new Path2D(), upE = new Path2D(), dnE = new Path2D(); let nShort = 0;
  for (const run of env) {
    const n = run.x.length; if (n < 1) continue;
    if (n >= SPAN_MIN) { long.push(run); continue; }
    band.moveTo(run.x[0], yOf(run.mx[0]));
    for (let i = 1; i < n; i++) band.lineTo(run.x[i], yOf(run.mx[i]));
    for (let i = n - 1; i >= 0; i--) band.lineTo(run.x[i], yOf(run.mn[i]));
    band.closePath();
    upE.moveTo(run.x[0], yOf(run.mx[0])); for (let i = 1; i < n; i++) upE.lineTo(run.x[i], yOf(run.mx[i]));
    dnE.moveTo(run.x[0], yOf(run.mn[0])); for (let i = 1; i < n; i++) dnE.lineTo(run.x[i], yOf(run.mn[i]));
    nShort++;
  }
  if (nShort) { ctx.globalAlpha = 0.45; ctx.fill(band); ctx.globalAlpha = 0.9; ctx.stroke(upE); ctx.stroke(dnE); }
  if (long.length) { // the same band and edges as spans: all bands, then all edges (two style changes)
    ctx.globalAlpha = 0.45;
    const band = rectRun(ctx);
    for (const run of long) { const n = run.x.length, w = colWidth(run.x, n); for (let i = 0; i < n; i++) { const ya = cy(yOf(run.mx[i])), yb = cy(yOf(run.mn[i])); band.add(run.x[i] - w / 2, Math.min(ya, yb), w, Math.abs(yb - ya)); } band.flush(); }
    ctx.globalAlpha = 0.9;
    const up = rectRun(ctx), dn = rectRun(ctx);
    for (const run of long) {
      const n = run.x.length, w = colWidth(run.x, n); let pa = cy(yOf(run.mx[0])), pb = cy(yOf(run.mn[0]));
      for (let i = 0; i < n; i++) { // each edge joins the previous column's edge (the segment a 1 px line would draw)
        const ya = cy(yOf(run.mx[i])), yb = cy(yOf(run.mn[i]));
        up.add(run.x[i] - w / 2, Math.min(pa, ya) - 0.5, w, Math.abs(pa - ya) + 1);
        dn.add(run.x[i] - w / 2, Math.min(pb, yb) - 0.5, w, Math.abs(pb - yb) + 1);
        pa = ya; pb = yb;
      }
      up.flush(); dn.flush();
    }
  }
  ctx.globalAlpha = 1;
}
/* traces on screen (1.45.0): each dense pixel column (several values) is two rectangles, as in 1.44 but without the
   band's edges: the column's min/max band, faint (0.45), from its lowest to its highest value (the exact extremes
   from traceChan), and over it the curve's own span, opaque, from its first to its last value and the previous
   point where the curve comes from the neighbouring column, at least a line wide (in a lane with one trace, and with
   peaks exact where 1.44 drew the curve through the extremes, from its lowest to its highest value). The band is 0.6 opaque (1.44: 0.45, with edges, which made it look stronger). Up to 1.44 the band also had an
   upper and a lower edge, two more rectangles per column; with them a dense column was four rectangles, up to 70,000
   fillRect calls per frame zoomed out on large files, and in the frame-rate test on a laptop the edges alone took the
   frame rate from 61 to 38 fps. The band's rectangles meet without overlapping (top and bottom on whole device pixels,
   so that equal neighbours merge); the spans may overlap, being opaque. Short dense stretches are drawn this way too
   (in peaks exact, 1.44 drew them as a path through each column's four extremes, which on a zoomed-out free-waveform
   file was up to 1.1 million pixels of stroked line per frame); their extremes are in the band. The rest is an anti-aliased line. Tried and dropped:
   one anti-aliased polygon per dense stretch (in a software-drawn test up to ten times as slow to paint); a single
   opaque rectangle per column (hid the axes drawn before it); a single translucent one (pale RF pulses, stripes where
   single-sample columns meet dense ones). Saved figures keep the exact path (strokePtsFig). On a laptop (Chrome,
   2.5× screen) with the 8,806-block file mostly in view, the frame-rate test gave 118 fps against 54 fps with the
   drawing of 1.44 (which was then removed). */
function strokePts(ctx, pts, yOf, color, fillBase, solo = false) { // solo: the lane's only trace (nothing under it to hide)
  if (EXP) return strokePtsFig(ctx, pts, yOf, color, fillBase);
  if (!pts.length) return;
  const LW = 1.35, hw = LW / 2, env = pts.env || [], cw = pts.r ? 1 / pts.r : 1, wd = Math.max(cw, LW), ga = ctx.globalAlpha;
  ctx.fillStyle = color;
  // the bands, first (under the curve)
  if (env.length && !BENCH.skip.env) {
    ctx.globalAlpha = ga * 0.6; const band = rectRun(ctx, true);
    for (const run of env) for (let i = 0; i < run.x.length; i++) { const ya = cy(yOf(run.mx[i])), yb = cy(yOf(run.mn[i])); if (yb !== ya) band.add(run.x[i] - cw / 2, Math.min(ya, yb), cw, Math.abs(yb - ya)); }
    band.flush(); ctx.globalAlpha = ga;
  }
  let qx = NaN, qy = NaN, qDown = false; // the line is clipped to the lane's rows as it is built (as strokePtsFig)
  const M_ = (x, y) => { qx = x; qy = y; qDown = false; };
  const L_ = (x, y) => {
    const ax = qx, ay = qy; qx = x; qy = y;
    if (ay !== ay) { qDown = false; return; }
    if ((ay < RY0 && y < RY0) || (ay > RY1 && y > RY1)) { qDown = false; return; }
    let ta = 0, tb = 1; const dy = y - ay;
    if (dy !== 0) { const t1 = (RY0 - ay) / dy, t2 = (RY1 - ay) / dy; ta = Math.max(0, Math.min(t1, t2)); tb = Math.min(1, Math.max(t1, t2)); if (ta > tb) { qDown = false; return; } }
    const xa = ax + (x - ax) * ta, ya = ay + dy * ta;
    if (!qDown || ta > 0) ctx.moveTo(xa, ya);
    ctx.lineTo(ax + (x - ax) * tb, ay + dy * tb); qDown = tb >= 1;
  };
  /* the span reaches the column's extremes in a lane with one trace (RF, a gradient in its own lane: there is nothing
     under it to hide) and, with peaks exact, where 1.44 drew the curve through them: a column built from vertices (the
     extremes' times known) in a stretch of fewer than SPAN_MIN dense columns (traceChan's xt). Elsewhere the extremes
     are in the band (0.6), so that the axes drawn before stay visible (an opaque span to the extremes of every short
     stretch, tried, hid the x readout of an EPI under its y blips). */
  let ne = 0; for (const run of env) ne += run.x.length;
  const ex = new Float64Array(ne), emn = new Float64Array(ne), emx = new Float64Array(ne), ext = new Uint8Array(ne); { let q = 0; for (const run of env) for (let i = 0; i < run.x.length; i++, q++) { ex[q] = run.x[i]; emn[q] = run.mn[i]; emx[q] = run.mx[i]; ext[q] = run.xt ? run.xt[i] : 0; } }
  let eq = 0;
  ctx.beginPath(); const spans = rectRun(ctx, true);
  let pen = false, px = NaN, py = NaN, fx = null;
  for (let i = 0; i < pts.length;) {
    const x = pts[i], v = pts[i + 1];
    if (v !== v) { pen = false; px = NaN; i += 2; continue; }
    let j = i + 2; while (j < pts.length && pts[j] === x && pts[j + 1] === pts[j + 1]) j += 2;
    if (j - i >= 4) { // a dense column: the curve's span (its points and the join from the previous point)
      let lo = Infinity, hi = -Infinity; for (let q = i; q < j; q += 2) { const y = yOf(pts[q + 1]); if (y < lo) lo = y; if (y > hi) hi = y; }
      while (eq < ne && ex[eq] < x - 1e-9) eq++;
      if (eq < ne && Math.abs(ex[eq] - x) <= 1e-9) { // the lane's only trace, or (peaks exact) a column built from vertices in a short stretch: to its extremes
        if (solo || ext[eq]) { const a = yOf(emx[eq]), b = yOf(emn[eq]); lo = Math.min(lo, a, b); hi = Math.max(hi, a, b); }
        eq++;
      }
      if (pen && px === px) {
        if (x - px > 1.5 * cw) L_(x, yOf(pts[i + 1])); // a longer join stays part of the line
        else { if (py < lo) lo = py; if (py > hi) hi = py; }
      }
      lo = cy(lo); hi = cy(hi); spans.add(x - wd / 2, lo - hw, wd, hi - lo + LW);
      py = yOf(pts[j - 1]); px = x; M_(x, py); pen = true;
      if (fx === null) fx = x; i = j; continue;
    }
    const y = yOf(v);
    if (!pen) { M_(x, y); pen = true; if (fx === null) fx = x; } else L_(x, y);
    px = x; py = y; i += 2;
  }
  ctx.strokeStyle = color; ctx.lineWidth = LW; ctx.lineJoin = 'round'; ctx.stroke();
  spans.flush();
  if (fillBase !== undefined && fx !== null && !BENCH.skip.area) areaRects(ctx, pts, yOf, fillBase, color);
}
/* a saved figure: every point on one anti-aliased path (the same line width everywhere; traceChan gives a figure each
   column's extremes in time order, without bands), with the bands of split columns (fillEnvelope) */
function strokePtsFig(ctx, pts, yOf, color, fillBase) {
  if (!pts.length) return;
  fillEnvelope(ctx, pts.env, yOf, color);
  const LW = EXP.lwCss;
  /* the path is clipped to the lane's rows (RY0..RY1) as it is built: a value far outside the lane's scale (the k-vector
     after the last readout) otherwise gives segments millions of pixels long, which the browser strokes very slowly
     although the clip hides them. Exact inside the lane. */
  let qx = NaN, qy = NaN, qDown = false;
  const M_ = (x, y) => { qx = x; qy = y; qDown = false; };
  const L_ = (x, y) => {
    const ax = qx, ay = qy; qx = x; qy = y;
    if (ay !== ay) { qDown = false; return; }
    if ((ay < RY0 && y < RY0) || (ay > RY1 && y > RY1)) { qDown = false; return; }
    let ta = 0, tb = 1; const dy = y - ay;
    if (dy !== 0) { const t1 = (RY0 - ay) / dy, t2 = (RY1 - ay) / dy; ta = Math.max(0, Math.min(t1, t2)); tb = Math.min(1, Math.max(t1, t2)); if (ta > tb) { qDown = false; return; } }
    const xa = ax + (x - ax) * ta, ya = ay + dy * ta;
    if (!qDown || ta > 0) ctx.moveTo(xa, ya);
    ctx.lineTo(ax + (x - ax) * tb, ay + dy * tb); qDown = tb >= 1;
  };
  ctx.beginPath(); let pen = false, fx = null;
  for (let i = 0; i < pts.length; i += 2) {
    const x = pts[i], v = pts[i + 1];
    if (v !== v) { pen = false; continue; }
    const y = yOf(v);
    if (!pen) { M_(x, y); pen = true; if (fx === null) fx = x; } else L_(x, y);
  }
  ctx.strokeStyle = color; ctx.lineWidth = LW; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke(); ctx.lineCap = 'butt';
  if (fillBase !== undefined && fx !== null && !BENCH.skip.area) areaRects(ctx, pts, yOf, fillBase, color);
}
/* area between a trace and its zero line (RF |B1|; a gradient in its own lane), 1.23.0: one faint rectangle per pixel
   column from the zero line to the highest point the curve reaches in that column, and one to the lowest point below
   it (its points, and where its lines cross the column's edges). Until 1.22.3 it was one filled polygon through every
   point: tens of thousands of vertices for a ZTE sequence with a pulse per spoke, which took a graphics card about
   150 ms per frame to fill (frame-rate test: 6 fps with it, 36 fps without). */
function areaRects(ctx, pts, yOf, base, color) {
  const r = pts.r || 1, x0 = pts.x0 || 0, nc = pts.nc || 1e5, colOf = x => Math.floor((x - x0) * r + 1e-9);
  const top = new Map(), bot = new Map(); // column: highest point above the zero line (smallest y), lowest below it
  const put = (k, y) => { y = cy(y); if (y < base) { const o = top.get(k); if (o === undefined || y < o) top.set(k, y); } else if (y > base) { const o = bot.get(k); if (o === undefined || y > o) bot.set(k, y); } };
  let pk = -1, py = NaN, px = NaN;
  for (let i = 0; i < pts.length; i += 2) {
    const x = pts[i], v = pts[i + 1];
    if (v !== v) { pk = -1; py = NaN; continue; }
    const y = yOf(v), k = colOf(x);
    // where the line from the previous point crosses the column edges, only for the columns on screen: a point far off
    // screen (the last one before the view when zoomed far in) once made this loop run over millions of columns
    if (py === py && k > pk) for (let kb = Math.max(pk + 1, 0), ke = Math.min(k, nc); kb <= ke; kb++) { const xb = x0 + kb / r, yb = py + (y - py) * (xb - px) / (x - px || 1); put(kb - 1, yb); put(kb, yb); }
    if (k >= 0 && k < nc) put(k, y); pk = k; py = y; px = x;
  }
  if (!top.size && !bot.size) return;
  const w = 1 / r; ctx.globalAlpha = 0.13; ctx.fillStyle = color; const rr = rectRun(ctx, !EXP);
  for (const k of [...top.keys()].sort((a, b) => a - b)) { const y = top.get(k); rr.add(x0 + k * w, y, w, base - y); }
  rr.flush();
  for (const k of [...bot.keys()].sort((a, b) => a - b)) { const y = bot.get(k); rr.add(x0 + k * w, base, w, y - base); }
  rr.flush(); ctx.globalAlpha = 1;
}
/* the k-vector lane (1.22.3): the whole trace as one opaque rectangle per pixel column and stretch of the curve, from
   the lowest to the highest point the curve reaches in that column (its samples, the column's min/max summary, and
   where its lines cross the column's edges), at least a line wide. A break (the reset at an excitation) ends a
   stretch, so the curve starts anew without a line. Only rectangles, no strokes: a ZTE sequence has a ramp and a
   reset per spoke, and stroking those as anti-aliased lines was the slow part (tens of thousands of pixels of line
   per frame); rectangles are the cheapest thing a canvas draws. */
function solidTrace(ctx, pts, yOf, color) {
  if (!pts.length) return;
  const r = pts.r || 1, x0 = pts.x0 || 0, nc = pts.nc || 1e5, LW = 1.35, hw = LW / 2, colOf = x => Math.floor((x - x0) * r + 1e-9);
  const envQ = new Map(); // per column centre, the summaries of its dense parts in order (a split column has two)
  for (const run of pts.env || []) for (let i = 0; i < run.x.length; i++) { const k = Math.round(run.x[i] * 64), q = envQ.get(k); if (q) q.push(i, run); else envQ.set(k, [i, run]); }
  const R = []; let ck = -1, lo = 0, hi = 0, on = false;
  const flush = () => { if (on) R.push(ck, lo, hi); on = false; };
  const addY = (k, y) => { y = cy(y); if (!on || k !== ck) { flush(); ck = k; lo = hi = y; on = true; } else { if (y < lo) lo = y; if (y > hi) hi = y; } };
  let pk = -1, py = NaN, px = NaN;
  for (let i = 0; i < pts.length; i += 2) {
    const x = pts[i], v = pts[i + 1];
    if (v !== v) { flush(); pk = -1; py = NaN; continue; }
    const y = yOf(v), k = colOf(x);
    if (py === py && k > pk) { // a line from the previous point: where it crosses each column edge (on screen only, as in areaRects)
      for (let kb = Math.max(pk + 1, 0), ke = Math.min(k, nc); kb <= ke; kb++) { const xb = x0 + kb / r, yb = py + (y - py) * (xb - px) / (x - px || 1); addY(kb - 1, yb); addY(kb, yb); }
    }
    if (i + 2 < pts.length && pts[i + 2] === x && (i === 0 || pts[i - 2] !== x)) { // first point of a dense column: its summary
      const q = envQ.get(Math.round(x * 64)); if (q && q.length) { const j = q.shift(), run = q.shift(); addY(k, yOf(run.mx[j])); addY(k, yOf(run.mn[j])); }
    }
    if (k >= 0 && k < nc) addY(k, y); pk = k; py = y; px = x;
  }
  flush();
  ctx.fillStyle = color; ctx.globalAlpha = 1; const rr = rectRun(ctx, true), w = 1 / r;
  for (let q = 0; q < R.length; q += 3) rr.add(x0 + R[q] * w, R[q + 1] - hw, w, R[q + 2] - R[q + 1] + LW);
  rr.flush();
}

/* width of a text in the diagram's font (600 at 12 px, 400 at 10.5 px), kept per text: used where a lane decides how
   to lay out its margin (1.48.1) */
const TEXT_W = new Map();
function textW(px, txt) {
  const k = px + C.font + txt; let w = TEXT_W.get(k);
  if (w === undefined) { const f = pctx.font; pctx.font = `${px === 12 ? 600 : 400} ${px}px ${C.font}`; w = pctx.measureText(txt).width; pctx.font = f; if (TEXT_W.size > 2000) TEXT_W.clear(); TEXT_W.set(k, w); }
  return w;
}

/* ---------- time axis ticks ---------- */
function niceStep(raw) { const p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p; return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p; }
function timeUnit(span) { return span >= 2 ? [1, 's'] : span >= 2e-3 ? [1e3, 'ms'] : [1e6, 'µs']; }

/* ---------- main render ---------- */
let pending = false, pendingOv = false;
function request() { if (!pending) { pending = true; requestAnimationFrame(() => { pending = false; benchT(render); }); } }
function requestOverlay() { if (!pendingOv) { pendingOv = true; requestAnimationFrame(() => { pendingOv = false; benchT(() => { drawOverlay(); updateReadout(); }); }); } }
/* ---------- Group segments (1.49.0, experimental) ----------
   Segmented imaging: one image read in several shots, each filling part of k-space (segmented EPI, segmented TSE,
   ...). With Group segments on, the diagram shows only the shots of one image, side by side, each from its start to
   the end of its last event; the time between them (other images' shots, and each shot's TR fill) is left out and
   marked by a narrow box saying how much. Which shots belong together is read from the labels only: shots with
   readouts in the same volume and with the same SLC, REP, AVG, SET and PHS at their first readout make one image when
   SEG takes at least two values among them. A file that sets SEG to other values within a shot (some reconstructions
   mark reversed EPI lines that way) is not grouped.
   The view then runs on view time: the shown stretches of the image's shots joined end to end (S.t0, S.t1 and the
   view history are in view time); hovering, clicking, the readout, linking and every list of shots stay in real time.
   tToV, vToT, xToV, xToT and tToX convert. Without Group segments view time is real time. */
const SEG_KEYS = ['SLC', 'REP', 'AVG', 'SET', 'PHS'];
let SEGC = null, VMAP = null, RPANEL = 0; // RPANEL: the panel being drawn (things drawn once are drawn in panel 0)
function segGroups() {
  const s = S.seq; if (!s) return null;
  const shots = s.shots, vols = S.vols;
  if (!SEGC || SEGC.seq !== s || SEGC.shots !== shots || SEGC.vols !== vols) { SEGC = { seq: s, shots, vols, res: computeSegGroups(s, shots, vols) }; VMAP = null; }
  return SEGC.res;
}
function computeSegGroups(s, shots, vols) {
  const R = { groups: [], of: new Int32Array(shots.length).fill(-1), err: '' };
  const lab = n => s.labels.find(x => x.name === n), seg = lab('SEG');
  if (!seg) { R.err = 'This file has no SEG label.'; return R; }
  if (!shots.length) { R.err = 'Shots are hidden (Display › Shots and volumes).'; return R; }
  const idx = (tr, b) => { let lo = 0, hi = tr.b.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (tr.b[m] <= b) lo = m; else hi = m - 1; } return lo; };
  const val = (tr, b) => { if (!tr || !tr.b.length) return 0; const i = idx(tr, b); return tr.b[i] <= b ? tr.v[i] : 0; };
  const keys = SEG_KEYS.map(lab), AB = s.adcBlocks, B = s.B, bs = s.blockStart;
  const trg = new Uint8Array(s.nb); for (const t of s.triggers) trg[t.block] = 1;
  const map = new Map(); let nChange = 0;
  for (let k = 0; k < shots.length; k++) {
    const sh = shots[k]; if (!sh.nADC) continue; // no readout (dummy scans): not part of an image
    const ba = AB[sh.j0], bz = AB[sh.j1 - 1], v = val(seg, ba);
    let i = idx(seg, ba); if (seg.b[i] <= ba) i++;
    for (; i < seg.b.length && seg.b[i] <= bz; i++) if (seg.v[i] !== v) { nChange++; break; }
    const vol = vols.length ? volOfBlock(sh.b0) : -1, key = vol + ':' + keys.map(tr => val(tr, ba)).join(':');
    let g = map.get(key); if (!g) map.set(key, g = { shots: [], segs: new Set(), slc: val(keys[0], ba), vol });
    g.shots.push(k); g.segs.add(v);
  }
  if (nChange) { R.err = `SEG changes within ${nChange.toLocaleString()} shot${nChange > 1 ? 's' : ''}, so it does not number the shots of an image.`; return R; }
  for (const g of map.values()) {
    if (g.segs.size < 2) continue;
    g.iv = []; g.gapShots = []; g.ivShot = []; let prevK = -1;
    for (const k of g.shots) { // from the shot's start to the end of its last event (RF, gradient, ADC or trigger)
      const sh = shots[k]; let b = sh.b1;
      while (b > sh.b0 && !B.rf[b] && !B.pgx[b] && !B.pgy[b] && !B.pgz[b] && !B.adc[b] && !trg[b]) b--;
      const a = sh.t0, e = bs[b + 1], L = g.iv[g.iv.length - 1];
      if (L && a <= L[1] + 1e-12) L[1] = Math.max(L[1], e); // follows straight on: nothing left out
      else { g.iv.push([a, e]); g.ivShot.push(k); if (L) g.gapShots.push(k - prevK - 1); }
      prevK = k;
    }
    R.groups.push(g);
  }
  R.groups.sort((a, b) => a.shots[0] - b.shots[0]);
  R.groups.forEach((g, i) => { for (const k of g.shots) R.of[k] = i; });
  if (!R.groups.length) R.err = 'No image has shots with two or more SEG values.';
  return R;
}
function segView() { // the focused image's stretches, or null without Group segments
  if (!S.segOn || !S.seq) return null;
  const R = segGroups(); if (!R || !R.groups.length) return null;
  const gi = Math.max(0, Math.min(R.groups.length - 1, S.segFocus | 0)), g = R.groups[gi];
  if (!VMAP || VMAP.g !== g) {
    const n = g.iv.length, cum = new Float64Array(n + 1);
    for (let i = 0; i < n; i++) cum[i + 1] = cum[i] + g.iv[i][1] - g.iv[i][0];
    VMAP = { g, gi, iv: g.iv, cum, D: cum[n], n };
  }
  return VMAP;
}
function segGapPx(V, pw) { return V.n < 2 ? 0 : Math.max(10, Math.min(26, Math.floor(0.25 * pw / (V.n - 1)))); }
/* the panels of the view [t0, t1] (view time) over pixels x0 … x0 + pw: real time span and pixels of each; the boxes
   between them. The first and last panels run on past the image's first and last shot into the margins. */
function viewPanels(t0, t1, x0, pw) {
  const V = segView(); if (!V) return { P: [{ t0, t1, x0, pw }], gaps: [], V: null, sc: pw / (t1 - t0) };
  const sc = pw / (t1 - t0), G = segGapPx(V, pw), P = [], gaps = [], xe = x0 + pw, n = V.n, d = pdpr || 1; let ng = 0;
  for (let i = 0; i < n; i++) {
    const ca = i ? V.cum[i] : -Infinity, cb = i < n - 1 ? V.cum[i + 1] : Infinity;
    if (i && ca > t0) ng++;
    if (cb <= t0) continue;
    /* each panel starts and ends on a device pixel, its time moved by under half a pixel to match: the waveforms'
       pixel columns are then aligned as in a normal view (off by a fraction of a pixel, every column was drawn
       anti-aliased, about 5 times the drawing time) */
    const xr = x0 + (Math.max(ca, t0) - t0) * sc + G * ng, xs = Math.round(xr * d) / d;
    if (xs >= xe) break;
    if (i && ca > t0) gaps.push({ j: i, x: xs - G, w: G });
    const ra = V.iv[i][0] + (Math.max(ca, t0) - V.cum[i]) - (xr - xs) / sc;
    let rb = i < n - 1 ? V.iv[i][1] : Infinity, xb = Math.round((xs + (rb - ra) * sc) * d) / d;
    if (xb > xe) xb = xe;
    rb = ra + (xb - xs) / sc;
    if (xb > xs) P.push({ t0: ra, t1: rb, x0: xs, pw: xb - xs, i });
  }
  return { P, gaps, V, sc, G };
}
function vLayout() { return viewPanels(S.t0, S.t1, GUT, W - GUT - 8); }
function xToV(x) { // view time at x (over a box: the place of the left-out time)
  const L = vLayout(); if (!L.V) return S.t0 + (x - GUT) / L.sc;
  let v = S.t0 + (x - GUT) / L.sc;
  for (const g of L.gaps) { if (x >= g.x + g.w) v -= g.w / L.sc; else if (x >= g.x) return L.V.cum[g.j]; }
  return v;
}
function xToT(x) { // real time at x; null over a box of left-out time
  const L = vLayout(); if (!L.V) return S.t0 + (x - GUT) / L.sc;
  for (const p of L.P) if (x >= p.x0 && x <= p.x0 + p.pw) return p.t0 + (x - p.x0) / L.sc;
  return null;
}
function tToX(t) { // x of real time t; null where it is left out
  const L = vLayout(); if (!L.V) return GUT + (t - S.t0) * L.sc;
  for (const p of L.P) if (t >= p.t0 && t <= p.t1) return p.x0 + (t - p.t0) * L.sc;
  return null;
}
function segGapAt(x) { const L = vLayout(); if (!L.V) return null; for (const g of L.gaps) if (x >= g.x && x < g.x + g.w) return g; return null; }
function tToV(t) { // view time of real time t (left-out time: the edge of the next shown stretch)
  const V = segView(); if (!V) return t;
  const iv = V.iv, n = V.n;
  if (t <= iv[0][1]) return t - iv[0][0];
  for (let i = 1; i < n; i++) { if (t < iv[i][0]) return V.cum[i]; if (t <= iv[i][1]) return V.cum[i] + t - iv[i][0]; }
  return V.cum[n - 1] + t - iv[n - 1][0];
}
function vToT(v) { const V = segView(); if (!V) return v; const i = Math.max(0, Math.min(V.n - 1, ub(V.cum, v) - 1)); return V.iv[i][0] + v - V.cum[i]; }
function vcT() { return vToT((S.t0 + S.t1) / 2); } // real time at the view's centre
function viewDur() { const V = segView(); return V ? V.D : S.seq ? S.seq.totalDur : 1; }
/* the boxes of left-out time: a band with dashed edges and the time, written upwards where it fits */
function drawSegGaps(L) {
  const bot = H - AXH, V = L.V, top = 0;
  for (const g of L.gaps) {
    const dt = V.iv[g.j][0] - V.iv[g.j - 1][1];
    pctx.fillStyle = C.ink; pctx.globalAlpha = 0.07; pctx.fillRect(g.x, top, g.w, bot - top); pctx.globalAlpha = 0.45;
    pctx.strokeStyle = C.ink; pctx.lineWidth = 1; pctx.setLineDash([3, 3]); pctx.beginPath();
    for (const x of [Math.round(g.x) + 0.5, Math.round(g.x + g.w) - 0.5]) { pctx.moveTo(x, top); pctx.lineTo(x, bot + 4); }
    pctx.stroke(); pctx.setLineDash([]); pctx.globalAlpha = 1;
    if (g.w >= 12) {
      const txt = '−' + fmtT(dt); pctx.save(); pctx.translate(g.x + g.w / 2, (top + bot) / 2); pctx.rotate(-Math.PI / 2);
      pctx.font = `600 10.5px ${C.font}`; pctx.textAlign = 'center'; pctx.textBaseline = 'middle';
      const tw = pctx.measureText(txt).width; pctx.fillStyle = C.plot; pctx.fillRect(-tw / 2 - 4, -6.5, tw + 8, 13);
      pctx.fillStyle = C.ink; pctx.fillText(txt, 0, 0.5); pctx.restore();
    }
  }
}
function segGapText(g) {
  const V = segView(); if (!V) return '';
  const dt = V.iv[g.j][0] - V.iv[g.j - 1][1], ns = V.g.gapShots[g.j - 1];
  return `${fmtT(dt)} left out: ${ns ? (ns > 1 ? `${ns.toLocaleString()} other shots and ` : '1 other shot and ') : ''}the TR fill after shot ${V.g.ivShot[g.j - 1] + 1}`;
}
/* fit the focused image in the view, with the boxes between its shots */
function segFit() {
  const V = segView(); if (!V) return;
  const pw = W - GUT - 8, gx = segGapPx(V, pw) * (V.n - 1), sc = Math.max(pw * 0.984 - gx, pw * 0.2) / V.D, m = (pw - V.D * sc - gx) / 2;
  setView(-m / sc, (pw - m) / sc);
}
function segToggle(on) {
  if (!S.seq) return;
  if (on) {
    const R = segGroups();
    if (!R.groups.length) { S.segOn = false; segUI(); segMsg(R.err); return; }
    const k = S.sel >= 0 ? shotOfBlock(S.sel) : shotAt(vcT()); // the image of the selected shot or of the one in the middle
    let gi = k >= 0 ? R.of[k] : -1;
    if (gi < 0) { gi = R.groups.findIndex(g => g.shots[g.shots.length - 1] >= k); if (gi < 0) gi = 0; }
    S.segFocus = gi; S.segOn = true; VMAP = null;
  } else {
    const V = segView(); S.segOn = false; VMAP = null;
    if (V) { const a = V.iv[0][0], b = V.iv[V.n - 1][1], d = b - a; setView(a - d * 0.03, b + d * 0.03); } // the image's shots, in real time
  }
  S.hist = []; $('#backBtn').disabled = true; S.hoverT = null; S.hoverGap = null;
  if (S.segOn) segFit();
  segUI(); request(); requestK(); requestImg(); if (!S.segOn) linkSendView();
}
/* focus image gi; the view is kept where the image has as many shown stretches as the one before (zoomed into the
   second segment, the next image opens on its second segment), otherwise the image is fitted */
function segFocusTo(gi, fit) {
  const R = segGroups(); if (!R || !R.groups.length) return;
  gi = Math.max(0, Math.min(R.groups.length - 1, gi)); const V0 = segView();
  S.segFocus = gi; VMAP = null; const V = segView();
  if (fit || !V0 || V0.n !== V.n) segFit(); else setView(S.t0, S.t1);
  request(); requestK(); requestImg();
}
function segMsg(t) { if (t) fnote(`Group segments: ${t}`); }
const SEG_TITLE = 'Experimental: show only the shots that make one segmented image (same slice and other labels, different SEG), side by side, leaving out the time between them. Uses the SLC, SEG, REP, AVG, SET and PHS labels.';
function segUI() {
  const b = $('#segBtn'); if (!b) return;
  const has = !!(S.seq && S.seq.labels.some(x => x.name === 'SEG' && x.max > x.min)); // SEG takes two or more values
  b.hidden = !has; b.setAttribute('aria-pressed', !!S.segOn); if (!has) return;
  const R = segGroups(); b.disabled = !R.groups.length; // e.g. SEG used for reversed EPI lines: the reason in the tooltip
  b.title = R.groups.length ? SEG_TITLE + ` (${R.groups.length.toLocaleString()} image${R.groups.length > 1 ? 's' : ''} found)` : `Group segments: ${R.err}`;
}
/* a lane's pyramids, made when the lane is first shown */
function lanePrep(L) {
  const s = S.seq;
  if (L.key === 'm0') m0Pyramids(s);
  if (L.key === 'gc') { ccEnsure(); for (const k of ['cx', 'cy', 'cz']) if (!s.pyr[k]) s.pyr[k] = buildPyramid(s, k); }
  if (L.key === 'kc') { ccEnsure(); kintPyramids(KP_KC, s); }
  if (L.key === 'kt') { ccEnsure(); kintPyramids(KP_KT, s); }
  if (L.key === 'mu') { muEnsure(); kintPyramids(KP_MU, s); }
  if (L.key === 'rfMag' && S.rfMode === 'complex') for (const k of ['rfRe', 'rfIm']) if (!s.pyr[k]) s.pyr[k] = buildPyramid(s, k);
}
/* a lane's scale (before its y zoom): with Fit Y, the largest value over all panels (Group segments: one scale for
   the shots of the image) */
function laneM(L, P) {
  const chans = laneChannels(L), KPL = { m0: KP_M0, kc: KP_KC, kt: KP_KT, mu: KP_MU }[L.key];
  let m;
  if (KPL) { if (S.autoY) { m = 0; for (const p of P) m = Math.max(m, kViewMax(KPL, p.t0, p.t1)); } else m = kSeqMax(KPL); }
  else m = laneMax(L);
  if (S.autoY && L.key !== 'rfPh' && L.key !== 'adc' && !KPL) { let mv = 0; for (const p of P) for (const [, c] of chans) mv = Math.max(mv, chanRange(c, p.t0, p.t1)); if (mv > 0) m = mv; }
  return m > 0 ? m : 1;
}
/* Group segments: shot and volume steps. Shots step through the images' shots in turn (the shots of the focused image,
   then those of the next image); a shot that is in no image, or a volume without one, turns Group segments off. The
   new shot's start lands where the current one's start was on screen. */
function segOffV(k) { const V = segView(); if (!V) return null; const t = S.seq.shots[k].t0; for (let i = 0; i < V.n; i++) if (t >= V.iv[i][0] - 1e-12 && t <= V.iv[i][1]) return V.cum[i] + t - V.iv[i][0]; return null; }
function segGoto(kind, k) {
  const s = S.seq, R = segGroups(), V = segView();
  if (kind === 'shot') {
    k = Math.max(0, Math.min(s.shots.length - 1, k));
    const gi = R.of[k]; if (gi < 0) { segToggle(false); gotoItem(kind, k); return; }
    const cur = S.sel >= 0 ? shotOfBlock(S.sel) : shotAt(vcT()), o0 = cur >= 0 && R.of[cur] === V.gi ? segOffV(cur) : null;
    if (gi !== V.gi) segFocusTo(gi);
    selectBlock(s.shots[k].b0, { kind: 'shot' });
    const o1 = segOffV(k), sp = S.t1 - S.t0;
    if (o0 != null && o1 != null) setView(S.t0 + o1 - o0, S.t1 + o1 - o0); else if (o1 != null) setView(o1 - sp * 0.1, o1 + sp * 0.9);
    return;
  }
  k = Math.max(0, Math.min(S.vols.length - 1, k)); // a volume: the image in it with the same slice, or its first
  const inV = R.groups.map((g, i) => i).filter(i => R.groups[i].vol === k);
  if (!inV.length) { segToggle(false); gotoItem(kind, k); return; }
  const gi = inV.find(i => R.groups[i].slc === V.g.slc) ?? inV[0];
  segFocusTo(gi); selectBlock(S.vols[k].b0, { kind: 'vol' });
}
function segShotList() { const R = segGroups(); if (!R.list) { R.list = []; for (const g of R.groups) for (const k of g.shots) R.list.push(k); } return R.list; }
function segStepShot(cur, dir) {
  const R = segGroups(), V = segView(), list = segShotList();
  const i = list.indexOf(cur), gs = V.g.shots;
  if (i < 0 || R.of[cur] !== V.gi) { segGoto('shot', dir > 0 ? gs[0] : gs[gs.length - 1]); return; } // from outside the image: its first (last) shot
  const n = list[i + dir]; if (n !== undefined) segGoto('shot', n);
}
function segGapTip(g) {
  const txt = segGapText(g); if (!txt) return;
  octx.font = `600 11px ${C.font}`; octx.textBaseline = 'middle';
  const tw = octx.measureText(txt).width, cx = g.x + g.w / 2, right = cx + 10 + tw < W - 8, tx = right ? cx + 10 : cx - 10 - tw, ty = topH() + 12;
  octx.fillStyle = C.plot; octx.globalAlpha = 0.94; octx.fillRect(tx - 4, ty - 8, tw + 8, 16); octx.globalAlpha = 1;
  octx.fillStyle = C.ink; octx.textAlign = 'left'; octx.fillText(txt, tx, ty);
}
function render() {
  if (!C.ink) readColors();
  pctx.clearRect(0, 0, W, H);
  if (BENCH.skip.draw && S.seq) { if (!BENCH.skip.ov) drawOverview(); drawOverlay(); if (!BENCH.skip.dom) { updateReadout(); updateNav(); updateLegend(); } return; }
  if (!S.seq || W <= 0) { octx.clearRect(0, 0, W, H); vctx.clearRect(0, 0, OW, OH); return; }
  const renderT0 = performance.now();
  const s = S.seq, PW = W - GUT - 8;
  /* Group segments (1.49.0): the view is a row of panels, one per shot of the segmented image in view, each drawn as a
     normal diagram of its own time span (same scale), with a narrow box for the time left out between them. Without
     it, one panel: the view itself. */
  const LAY = viewPanels(S.t0, S.t1, GUT, PW), nP = LAY.P.length;
  const lanes = lanesGeom(); traceR = chooseTraceR(S.t0, S.t1, PW);
  const noSel = EXP && !EXP.sel, dLane = DIAG.on ? {} : null;
  const LM = new Map(); // each lane's scale, shared by the panels
  for (const L of lanes) if (L.key !== 'labels' && !L.stim) { lanePrep(L); LM.set(L.key, laneM(L, LAY.P)); }
  for (let pi = 0; pi < nP; pi++) {
    const p = LAY.P[pi], ca = pi ? p.x0 : 0, cb = pi < nP - 1 ? p.x0 + p.pw : W;
    RPANEL = pi;
    if (nP > 1) { pctx.save(); pctx.beginPath(); pctx.rect(ca, 0, cb - ca, H); pctx.clip(); }
    drawPanel(pi, p.t0, p.t1, p.x0, p.pw);
    if (nP > 1) pctx.restore();
  }
  RPANEL = 0;
  if (LAY.V) drawSegGaps(LAY);
  if (EXP) return; // a figure: nothing else
  { const dt = performance.now() - renderT0; if (!BENCH.run && DIAG.on) diagShow(dt, dLane); }
  if (!BENCH.skip.ov) drawOverview(); drawOverlay(); if (!BENCH.skip.dom) { updateReadout(); updateNav(); updateLegend(); }
  if (S.tab === 'img' && S.sel < 0 && !S.sideHidden) requestImg();
  if (S.tab === 'k' && S.kRange !== 'all' && !S.sideHidden) { if (S.kRange === 'view') requestKLazy(); else requestK(); }
  function drawPanel(pi, t0, t1, x0, pw) {
  const X = t => x0 + (t - t0) / (t1 - t0) * pw;
  const nb = s.nb;
  const b0 = Math.max(0, ub(s.blockStart, t0, nb) - 1), b1 = Math.min(nb - 1, lb(s.blockStart, t1, nb));
  const nVis = b1 - b0 + 1;
  const bot = H - AXH;
  pctx.save();
  pctx.beginPath(); pctx.rect(x0, 0, pw, H); pctx.clip();
  // block shading: decided per block from its own width on screen (not from how many blocks are visible, which
  // changes while panning), fading in between 2 and 6 px, so panning never switches it on and off
  const wOf = b => (s.blockStart[b + 1] - s.blockStart[b]) / (t1 - t0) * pw;
  const dmax = blockDurMax(s), pxPerS = pw / (t1 - t0); // skip groups of 64 blocks too narrow on screen to draw (exact)
  if (nVis < 2e5 && !BENCH.skip.shade && (!EXP || EXP.shade)) {
    pctx.fillStyle = C.shade; pctx.beginPath(); const partial = [];
    for (let b = b0 | 1; b <= b1; b += 2) {
      if ((b & 63) < 2 && dmax[b >> 6] * pxPerS < 2) { b = (((b >> 6) + 1) << 6) - 1; continue; } // next odd block after this group
      const w = wOf(b); if (w < 2) continue;
      const xa = X(s.blockStart[b]); if (w >= 6) pctx.rect(xa, 0, w, bot); else partial.push([xa, w]);
    }
    pctx.fill();
    for (const [xa, w] of partial) { pctx.globalAlpha = (w - 2) / 4; pctx.fillRect(xa, 0, w, bot); }
    pctx.globalAlpha = 1;
  }
  if ((EXP ? EXP.pause : S.pauseHatch) && !BENCH.skip.pause) drawPauses(s, X, t0, t1, x0, pw, lanes); // faint hatch over blocks without events
  for (const sr of EXP && !EXP.sel ? [] : selRanges()) {
    if (sr[1] < t0 || sr[0] > t1) continue;
    const xa = X(sr[0]), xb = X(sr[1]);
    pctx.globalAlpha = S.selKind === 'block' ? 0.18 : 0.1; pctx.fillStyle = C.sel; pctx.fillRect(xa, 0, Math.max(2, xb - xa), bot);
    pctx.globalAlpha = 1; pctx.fillRect(xa, bot - 3, Math.max(2, xb - xa), 3);
  }
  if (nVis < 2e5 && (!EXP || EXP.shade)) { // block boundaries where both neighbouring blocks are at least 7 px wide
    pctx.strokeStyle = C['line-soft']; pctx.lineWidth = 1; pctx.beginPath();
    for (let b = b0; b <= b1 + 1 && b <= nb; b++) {
      if (b < nb && (b & 63) === 0 && dmax[b >> 6] * pxPerS < 7 && b + 64 <= nb) { b += 63; continue; } // every block in the group < 7 px: no boundary inside or at its start
      const wl = b > 0 ? wOf(b - 1) : Infinity, wr = b < nb ? wOf(b) : Infinity; if (Math.min(wl, wr) < 7) continue;
      const x = Math.round(X(s.blockStart[b])) + 0.5; pctx.moveTo(x, 0); pctx.lineTo(x, bot);
    }
    pctx.stroke();
  }
  // shot boundaries
  let si0 = 0, si1 = -1;
  if (shotsOn()) {
    const sh = s.shots; si0 = Math.max(0, ub(S.shotT0, t0) - 1); si1 = Math.min(sh.length - 1, lb(S.shotT0, t1));
    if (si1 - si0 < pw / 4) { // 1.45.0: solid, fainter, as pixel-aligned rectangles (were dashed strokes: on a 100-shot view
      // about 70,000 px of dashed line per frame, then the largest stroke in the diagram)
      const d = pdpr || 1, w = Math.max(1, Math.round(d)) / d, ya = shotY(); pctx.fillStyle = C.ink; pctx.globalAlpha = EXP ? 0.4 : 0.18;
      if (EXP) { pctx.strokeStyle = C.ink; pctx.setLineDash([4, 3]); pctx.lineWidth = 1; pctx.beginPath(); for (let k = si0; k <= si1; k++) { const x = Math.round(X(sh[k].t0)) + 0.5; pctx.moveTo(x, ya); pctx.lineTo(x, bot); } pctx.stroke(); pctx.setLineDash([]); }
      else for (let k = si0; k <= si1; k++) pctx.fillRect(Math.round(X(sh[k].t0) * d) / d, ya, w, bot - ya);
      pctx.globalAlpha = 1;
    }
  }
  let vi0 = 0, vi1 = -1;
  if (volsOn()) {
    const v = S.vols; vi0 = Math.max(0, ub(S.volT0, t0) - 1); vi1 = Math.min(v.length - 1, lb(S.volT0, t1));
    if (vi1 - vi0 < pw / 4) { // 1.45.0: pixel-aligned rectangles (were 1.5 px strokes)
      const d = pdpr || 1, w = Math.max(1, Math.round(1.5 * d)) / d, ya = volY(); pctx.fillStyle = C.ink; pctx.globalAlpha = 0.7;
      for (let k = vi0; k <= vi1; k++) { if (!k) continue; pctx.fillRect(Math.round((X(v[k].t0) - w / 2) * d) / d, ya, w, bot - ya); }
      pctx.globalAlpha = 1;
    }
  }
  pctx.restore();
  if (volsOn()) drawStrip(S.vols, vi0, vi1, volY(), 'Volumes', 'vol', noSel ? new Set() : S.selKind === 'vol' ? selSet() : new Set([volOfBlock(S.sel)]), S.selKind === 'vol', v => !v.nSamples, X, x0, pw);
  if (shotsOn()) drawStrip(s.shots, si0, si1, shotY(), 'Shots', 'shot', noSel || S.selKind === 'vol' ? new Set() : S.selKind === 'shot' ? selSet() : new Set([shotOfBlock(S.sel)]), S.selKind === 'shot', v => !v.nADC, X, x0, pw);

  // lanes
  pctx.font = `500 11.5px ${C.font}`; pctx.textBaseline = 'middle';
  for (const L of lanes) {
    const dT = dLane ? performance.now() : 0;
    try {
    if (L.key === 'labels') { RY0 = -1e6; RY1 = 1e6; if (!BENCH.skip.labels) drawLabelsLane(L, X, t0, t1, x0, pw); continue; }
    if (L.stim) { drawStimLane(L, t0, t1, x0, pw); continue; }
    laneBody(L);
    if (!EXP && L === lanes.find(l => l.key === 'rfMag' || l.key === 'rfPh')) drawEchoMarks(L, X, t0, t1, x0, pw, pi > 0);
    } finally { if (dLane) dLane[L.label] = (pi ? dLane[L.label] : 0) + performance.now() - dT; }
  }
  function laneBody(L) {
    const chans = laneChannels(L), f = laneFactor(L.key);
    let m = LM.get(L.key);
    const yz = yZoomOf(L.key); m /= yz;
    const pad = 4;
    /* a figure: the scale goes up to the next multiple of half a power of ten above the largest value (58.3 mT/m:
       60; 19.3 µT: 20), with ticks dividing it into round steps (1, 2, 2.5 or 5 × 10^n: 60 by 2 → 30, by 3 → 20), as
       many as fit at least 20 px apart */
    let ticks = null;
    if (EXP && L.key !== 'adc') {
      if (L.kind === 'phase') ticks = [[-Math.PI, '−π'], [0, '0'], [Math.PI, 'π']];
      else {
        const sym = L.kind === 'sym', room = (sym ? L.h / 2 : L.h) - 2 * pad, nT = Math.max(1, Math.floor(room / 20)), v = m * f;
        const p = Math.pow(10, Math.floor(Math.log10(v))) / 2, M = Math.ceil(v / p - 1e-9) * p;
        const nice = x => { const q = x / Math.pow(10, Math.floor(Math.log10(x) + 1e-9)); return [1, 2, 2.5, 5, 10].some(c => Math.abs(q - c) < 1e-6); };
        let n = 1; for (let d = Math.min(nT, 10); d >= 1; d--) if (nice(M / d)) { n = d; break; }
        const step = M / n; m = M / f; ticks = [];
        for (let q = sym ? -n : 0; q <= n; q++) ticks.push([q * step / f, (q < 0 ? '−' : '') + String(+Math.abs(q * step).toPrecision(6))]);
      }
    }
    let yOf, base;
    if (L.kind === 'sym' || L.kind === 'phase') { const mid = L.y + L.h / 2, hh = L.h / 2 - pad; yOf = v => mid - v / m * hh; base = mid; }
    else { const b = L.y + L.h - pad, hh = L.h - 2 * pad; yOf = v => b - v / m * hh; base = b; }
    // zero line
    pctx.strokeStyle = C.line; pctx.lineWidth = 1; pctx.setLineDash(!EXP && (L.kind === 'sym' || L.kind === 'phase') ? [3, 3] : []);
    pctx.beginPath(); pctx.moveTo(x0, Math.round(base) + 0.5); pctx.lineTo(x0 + pw, Math.round(base) + 0.5); pctx.stroke(); pctx.setLineDash([]);
    // gutter
    const multi = L.key === 'slew' || L.key === 'g' || L.key === 'm0' || L.key === 'gc' || L.key === 'kc' || L.key === 'kt', color = multi ? C.ink : C[L.col];
    pctx.fillStyle = color; pctx.fillRect(8, L.y + 2, 3, L.h - 4);
    pctx.fillStyle = C.ink; pctx.textAlign = 'left'; pctx.font = `600 12px ${C.font}`;
    const twoLine = L.key !== 'adc' && (L.h > 58 || (EXP && L.h > 30)); // a figure's lanes are lower: the unit still fits below the name
    /* a low lane whose name and scale numbers do not fit side by side (1.48.1; with many lanes on, "k-vector" ran into
       "30844" and "RF phase" into "π"): the name on an upper line and the scale under it as one range (±max, or 0–max,
       with the unit where it fits), or the name alone where the lane is too low for two lines */
    let compact = 0, rangeTxt = '';
    if (!EXP && L.key !== 'adc' && !twoLine && L.h < 38) {
      const top = L.kind === 'phase' ? 'π' : fmt(m * f, 3), room = x0 - 6 - 16;
      if (textW(12, L.label) + 5 + textW(10.5, L.kind === 'pos' ? top : '−' + top) > room) {
        compact = L.h >= 25 ? 1 : 2; rangeTxt = (L.kind === 'pos' ? '0–' : '±') + top;
        const u = L.kind === 'phase' ? '' : ' ' + laneUnit(L.key); if (u.trim() && textW(10.5, rangeTxt + u) <= room) rangeTxt += u;
      }
    }
    pctx.fillText(L.label, 16, L.y + L.h / 2 - (twoLine ? 7 : compact === 1 ? 6.5 : 0));
    pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
    if (L.key !== 'adc') {
      const unit = laneUnit(L.key), top = L.kind === 'phase' ? 'π' : fmt(m * f, 3);
      if (twoLine) pctx.fillText(unit, 16, L.y + L.h / 2 + 8);
      if (L.key === 'rfMag' && S.rfMode === 'complex' && L.h > 80) {
        pctx.font = `600 11px ${C.font}`; pctx.fillStyle = C.rf; pctx.fillText('re', 16, L.y + L.h / 2 + 24); pctx.fillStyle = C.ph; pctx.fillText('im', 34, L.y + L.h / 2 + 24);
        pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
      }
      if (multi && (L.h > 80 || (EXP && twoLine && EXP.names))) { // the x y z legend below the unit, or in a figure's low lane after it
        const inl = !(L.h > 80), ly = L.y + L.h / 2 + (inl ? 8 : 24); let lx = inl ? 16 + pctx.measureText(unit).width + 8 : 16;
        pctx.font = `600 11px ${C.font}`;
        for (const [col] of (L.key === 'g' ? chans : [['gx'], ['gy'], ['gz']])) { pctx.fillStyle = C[col]; const tx = col[1]; pctx.fillText(tx, lx, ly); lx += 12; }
        pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
      }
      pctx.textAlign = 'right';
      if (ticks) { // a figure: an axis line with ticks and their values
        const ya = yOf(ticks[ticks.length - 1][0]), yb = yOf(ticks[0][0]), ax = x0 - 0.5;
        pctx.strokeStyle = C.muted; pctx.lineWidth = Math.max(0.5, EXP.lwCss * 0.6); pctx.beginPath(); pctx.moveTo(ax, ya); pctx.lineTo(ax, yb);
        for (const [v] of ticks) { const y = yOf(v); pctx.moveTo(ax, y); pctx.lineTo(ax - 4, y); }
        pctx.stroke(); pctx.lineWidth = 1; pctx.textBaseline = 'middle';
        for (const [v, t] of ticks) pctx.fillText(t, x0 - 7, yOf(v));
      } else if (compact) { if (compact === 1) { pctx.textAlign = 'left'; pctx.fillText(rangeTxt, 16, L.y + L.h / 2 + 6.5); }
      } else {
      pctx.fillText(top, x0 - 6, L.y + 7);
      if (L.kind !== 'pos') pctx.fillText(L.kind === 'phase' ? '−π' : '−' + fmt(m * f, 3), x0 - 6, L.y + L.h - 7);
      else pctx.fillText('0', x0 - 6, L.y + L.h - 7);
      }
    }
    pctx.save(); pctx.beginPath(); pctx.rect(x0, L.y - 1, pw, L.h + 2); pctx.clip(); RY0 = L.y - 8; RY1 = L.y + L.h + 8;
    if (L.key === 'adc') drawADC(L, X, t0, t1, pw, x0);
    else if (L.key === 'm0' || L.key === 'kc' || L.key === 'kt' || L.key === 'mu') {
      /* 1.44.0: the traces at full strength everywhere, on the same background as every other lane. Up to 1.43 the
         stretches outside the active ones (excitation to last readout) were covered with a pale veil, which hid the
         block shading there and made these lanes lighter than the others; fading the traces instead (tried in 1.44.0)
         cost about a third of the frame time, so those stretches are no longer marked. */
      for (const [col, c] of chans) { const p = traceChan(c, t0, t1, x0, pw); if (EXP) strokePts(pctx, p, yOf, C[col]); else solidTrace(pctx, p, yOf, C[col]); }
    }
    else for (const [col, c] of chans) {
      const pts = traceChan(c, t0, t1, x0, pw);
      strokePts(pctx, pts, yOf, C[col], L.kind === 'phase' || chans.length > 1 || (EXP && !EXP.fill) ? undefined : base, chans.length === 1);
    }
    pctx.restore(); RY0 = -1e6; RY1 = 1e6; // only this lane's rows were limited
    if (yz !== 1 && !EXP) yZoomTag(L, x0);
  }
  // time axis (the unit in the gutter; in a figure with a narrow gutter, after the last tick value)
  if (!EXP || EXP.axis) {
  const span = nP > 1 ? S.t1 - S.t0 : t1 - t0, [uf, un] = timeUnit(span); // Group segments: one unit and step for all panels
  const step = niceStep(span / Math.max(2, (nP > 1 ? PW : pw) / 95)), narrow = GUT < 40;
  pctx.strokeStyle = EXP ? C.muted : C.line; if (EXP) pctx.lineWidth = Math.max(0.5, EXP.lwCss * 0.6); pctx.beginPath(); pctx.moveTo(x0, bot + 0.5); pctx.lineTo(x0 + pw, bot + 0.5); pctx.stroke();
  pctx.fillStyle = C.muted; pctx.textAlign = 'center'; pctx.font = `400 11px ${C.font}`;
  const dec = Math.max(0, -Math.floor(Math.log10(step * uf) + 1e-9));
  for (let t = Math.ceil(t0 / step) * step; t <= t1; t += step) {
    const x = X(t); pctx.beginPath(); pctx.moveTo(x, bot); pctx.lineTo(x, bot + 4); pctx.stroke();
    if (narrow && !EXP && x > x0 + pw - 40) continue;
    if (nP > 1 && (x < x0 + 14 || x > x0 + pw - 14)) continue; // Group segments: not into the boxes between panels
    pctx.fillText((t * uf).toFixed(dec), x, bot + 15);
  }
  if (pi) { /* the unit once, in the gutter (first panel) */ }
  else if (EXP) pctx.fillText(`Time (${un})`, GUT + PW / 2, bot + 31); // a figure: an axis title
  else if (narrow) { pctx.textAlign = 'right'; pctx.fillText(un, x0 + pw, bot + 15); } else { pctx.textAlign = 'left'; pctx.fillText(un, 14, bot + 15); }
  }
  // block numbers
  if (nVis < pw / 34 && (!EXP || EXP.blockNums)) {
    pctx.font = `500 10.5px ${C.font}`; pctx.fillStyle = C.faint; pctx.textAlign = 'center';
    for (let b = b0; b <= b1; b++) {
      const xa = Math.max(x0, X(s.blockStart[b])), xb = Math.min(x0 + pw, X(s.blockStart[b + 1]));
      if (xb - xa > 26) pctx.fillText(s.B.id[b], (xa + xb) / 2, bot - 8);
    }
  }
  } // drawPanel
}
/* scale of the k-vector, kc, k + kc and μ lanes: the largest |value| in the active stretches (moments differ by orders of
   magnitude between imaging, diffusion encoding and spoiling, and what happens after the last readout should not set the
   scale). With Fit Y off, over the whole sequence, so the scale stays put while panning and zooming; with Fit Y on, over
   the stretches in view. The maximum of each whole stretch is kept per provider (kSeqPer); the provider's st object is
   emptied when its values change (new concomitant settings, new B0). */
function kStretchMax(P, s, a, b, o, tmp) {
  let m = 0; for (const k of P.keys) { rangeSummary(s, k, blockAtTime(s, a), blockAtTime(s, b), o, tmp); if (o.has) m = Math.max(m, Math.abs(o.mn), Math.abs(o.mx)); }
  return m;
}
function kSeqPer(P, s) {
  const ST = P.st(s); if (ST.actPer) return ST.actPer;
  const A = m0Active(s), n = A.a.length, per = new Float64Array(n), o = {}, tmp = {}; let all = 0;
  for (let j = 0; j < n; j++) { per[j] = kStretchMax(P, s, A.a[j], A.b[j], o, tmp); if (per[j] > all) all = per[j]; }
  ST.actAll = all; return (ST.actPer = per);
}
function kSeqMax(P) { // whole sequence (Fit Y off)
  const s = S.seq, ST = P.st(s); kSeqPer(P, s);
  const m = ST.actAll > 0 ? ST.actAll : ST.max; // no active stretch (no readout): the largest value anywhere
  return m > 0 ? m * 1.05 : 1;
}
function kViewMax(P, t0, t1) { // P: KP_M0 (k-vector), KP_KC (kc), KP_KT (k + kc) or KP_MU (Maxwell index)
  const s = S.seq, A = m0Active(s), n = A.a.length, per = kSeqPer(P, s), o = {}, tmp = {}; let m = 0;
  for (let j = Math.max(0, ub(A.b, t0) - 1); j < n && A.a[j] < t1; j++) {
    const a = Math.max(t0, A.a[j]), b = Math.min(t1, A.b[j]); if (b <= a) continue;
    if (a === A.a[j] && b === A.b[j]) { if (per[j] > m) m = per[j]; } // whole stretch in view: its kept maximum
    else m = Math.max(m, kStretchMax(P, s, a, b, o, tmp)); // cut by the view's edge
  }
  if (!(m > 0)) for (const k of P.keys) m = Math.max(m, chanRange(k, t0, t1)); // nothing active in view
  return m > 0 ? m * 1.05 : 1;
}
/* longest block per group of 64 (seconds), for skipping narrow stretches in the shading and boundary loops */
/* pauses: runs of consecutive blocks without RF, gradients, ADC or trigger (labels and delays are allowed), found once per
   file; start and end times in two sorted arrays */
function pauseRuns(seq) {
  if (seq._pause) return seq._pause;
  const B = seq.B, nb = seq.nb, bs = seq.blockStart, trg = new Uint8Array(nb), a = [], b = [];
  for (const tr of seq.triggers) trg[tr.block] = 1;
  let open = -1;
  for (let i = 0; i <= nb; i++) {
    const p = i < nb && !B.rf[i] && !B.pgx[i] && !B.pgy[i] && !B.pgz[i] && !B.adc[i] && !trg[i] && bs[i + 1] > bs[i];
    if (p && open < 0) open = i; else if (!p && open >= 0) { a.push(bs[open]); b.push(bs[i]); open = -1; }
  }
  const g = new Float64Array(Math.ceil(a.length / 64)); for (let k = 0; k < a.length; k++) g[k >> 6] = Math.max(g[k >> 6], b[k] - a[k]);
  return (seq._pause = { t0: Float64Array.from(a), t1: Float64Array.from(b), gmax: g }); // gmax: longest run per group of 64
}
/* a faint diagonal hatch (16 CSS px apart), made once per theme; drawn over every lane (Display › View › Mark pauses; up
   to 1.43 the RF and gradient lanes only), one fillRect per lane and visible pause run. Tried in 1.44.0: computing the
   lines and drawing them as one path with one stroke, and copying a pre-drawn hatch image; in a software-drawn test
   each cost the same as this pattern fill (the cost is blending the area), and a pattern fill is the cheapest on a
   graphics card. Measure on a given machine with ⋯ › Run frame-rate test (without pause texture). */
let pauseHatch = null;
const PAUSE_M = new DOMMatrix(); // the pattern's transform, reused (anchored to each pause)
function drawPauses(s, X, t0, t1, x0, pw, lanes) {
  const LS = lanes; if (!LS.length) return;
  const P = pauseRuns(s), n = P.t0.length; if (!n) return;
  if (!pauseHatch || pauseHatch.key !== C.faint + pdpr) {
    const d = Math.max(1, Math.round(pdpr)), q = 16 * d, c = document.createElement('canvas'); c.width = c.height = q;
    const g = c.getContext('2d'); g.strokeStyle = C.faint; g.lineWidth = d; g.globalAlpha = 0.28;
    g.beginPath(); for (const o of [-q, 0, q]) { g.moveTo(o, q); g.lineTo(o + q, 0); } g.stroke();
    pauseHatch = { key: C.faint + pdpr, pat: pctx.createPattern(c, 'repeat'), d };
  }
  const pat = pauseHatch.pat, sc = pw / (t1 - t0), M = PAUSE_M; M.a = M.d = 1 / pauseHatch.d; M.b = M.c = M.f = 0;
  let i = Math.max(0, ub(P.t1, t0) - 1); if (P.t1[i] < t0) i++;
  pctx.fillStyle = pat;
  for (; i < n && P.t0[i] <= t1; i++) {
    if ((i & 63) === 0 && P.gmax[i >> 6] * sc < 4) { i += 63; continue; } // a whole group too narrow on screen
    const w = (P.t1[i] - P.t0[i]) * sc; if (w < 4) continue; // too narrow to read; fades in up to 10 px
    const xa = X(P.t0[i]), xs = Math.max(x0 - 1, xa), xe = Math.min(x0 + pw + 1, xa + w);
    M.e = xa; pat.setTransform(M); // anchored to the pause, so it moves with it
    pctx.globalAlpha = w >= 10 ? 1 : (w - 4) / 6; for (const L of LS) pctx.fillRect(xs, L.y, xe - xs, L.h);
  }
  pctx.globalAlpha = 1;
}
function blockDurMax(seq) {
  if (seq.durMax64) return seq.durMax64;
  const n = Math.ceil(seq.nb / 64), d = new Float64Array(n), bs = seq.blockStart;
  for (let i = 0; i < seq.nb; i++) { const w = bs[i + 1] - bs[i]; if (w > d[i >> 6]) d[i >> 6] = w; }
  return (seq.durMax64 = d);
}
/* frame-time readout (Shift+D, or the ⋯ menu): Seqret's own time per frame and per lane, and the interval between
   drawn frames, which also contains the browser's drawing time on the graphics card. For reporting performance. */
const DIAG = { on: false, times: [], lastT: 0, fr: [], loop: false };
/* frame-rate test (⋯ › Run frame-rate test): switches used only while it runs, to find out on the user's own machine
   which part of a frame costs time. skip: leave out one part of the drawing; quality, lineMode: draw as with that
   setting (the normal view never uses them). */
const BENCH = { run: false, skip: {}, js: [], acc: 0, quality: '', lineMode: '' };
const benchT = (f) => { if (!BENCH.run) return f(); const t = performance.now(); try { return f(); } finally { BENCH.acc += performance.now() - t; } };
/* display frame rate: while the panel is open and the view moves, a requestAnimationFrame loop records the time
   between screen frames (a dropped frame shows as a longer gap); it stops half a second after the last redraw */
function diagFrames() {
  if (DIAG.loop || !DIAG.on) return; DIAG.loop = true; let last = 0;
  const f = t => {
    if (!DIAG.on || performance.now() - DIAG.lastT > 500) { DIAG.loop = false; diagText(); return; }
    if (last) { DIAG.fr.push(t - last); if (DIAG.fr.length > 90) DIAG.fr.shift(); }
    last = t; requestAnimationFrame(f);
  };
  requestAnimationFrame(f);
}
function diagShow(js, lanes) {
  DIAG.js = js; DIAG.lanes = lanes; const now = performance.now(), iv = DIAG.lastT ? now - DIAG.lastT : 0; DIAG.lastT = now;
  if (iv > 0 && iv < 1000) { DIAG.times.push(iv); if (DIAG.times.length > 30) DIAG.times.shift(); }
  diagFrames(); diagText();
}
function diagText() {
  if (BENCH.run || $('#diag').classList.contains('sel')) return;
  const js = DIAG.js || 0, lanes = DIAG.lanes;
  const medOf = a => a.length ? [...a].sort((x, y) => x - y)[a.length >> 1] : 0;
  const worst = DIAG.fr.length ? Math.max(...DIAG.fr) : 0;
  // frames delivered over the time they took (a slow frame counts for its full length, unlike in a median)
  const tot = DIAG.fr.reduce((a, b) => a + b, 0), fps = tot ? `${Math.round(1000 * DIAG.fr.length / tot)} fps (over the last ${DIAG.fr.length} screen frames; slowest ${worst.toFixed(0)} ms)` : '–';
  const med = medOf(DIAG.times);
  const lan = Object.entries(lanes || {}).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v.toFixed(1)}`).join(', ');
  $('#diag').textContent = `Seqret time: ${js.toFixed(1)} ms per frame (${traceR} column${traceR > 1 ? 's' : ''} per pixel)\n` +
    `lanes: ${lan}\nframe rate while moving: ${fps}\nredraws while moving: every ${med ? med.toFixed(0) + ' ms (median; also set by how fast you scroll or drag)' : '–'}\n` +
    `${Math.round(W)}×${Math.round(H)} CSS px, ${pdpr}× pixels${pdpr !== dpr ? ` (screen ${dpr}×, diagram quality ${diagQ()}${MOVING ? ' while moving' : ''})` : ''}, ${S.seq ? S.seq.nb.toLocaleString() + ' blocks' : ''}`;
}
function diagToggle() { $('#diag').classList.remove('sel'); DIAG.on = !DIAG.on; DIAG.times = []; DIAG.fr = []; DIAG.lastT = 0; $('#diag').hidden = !DIAG.on; $('#diagBtn').textContent = DIAG.on ? 'Hide frame times' : 'Show frame times'; request(); }
$('#diagBtn').onclick = diagToggle;
/* the test: from the current view, the view is moved on every screen frame (panning back and forth by 2 % of the span,
   or zooming in and out by 3 % about the centre), so that a frame is drawn on every screen frame, as while scrolling
   fast. It records the time between screen frames (all of the browser's work, including drawing on the graphics card)
   and Seqret's own time per frame, first for the normal drawing, then with each part left out, then with the other
   peak drawing and the other diagram qualities. Takes about half a minute; the view, the selection and the settings are restored. */
async function diagBench() {
  if (!S.seq || BENCH.run) return;
  const btn = $('#benchBtn'), v0 = [S.t0, S.t1], el = $('#diag');
  if (!DIAG.on) diagToggle();
  const CASES = [['normal, panning', 'pan', {}], ['normal, zooming', 'zoom', {}],
    ['without block shading', 'pan', { skip: { shade: 1 } }], ['without min/max bands', 'pan', { skip: { env: 1 } }],
    ['without area under RF', 'pan', { skip: { area: 1 } }], ['without labels lane', 'pan', { skip: { labels: 1 } }], ['without pause texture', 'pan', { skip: { pause: 1 } }],
    ['without overview', 'pan', { skip: { ov: 1 } }], ['without page updates', 'pan', { skip: { dom: 1 } }],
    ['blank diagram', 'pan', { skip: { draw: 1 } }], ['blank diagram, no page updates', 'pan', { skip: { draw: 1, dom: 1, ov: 1 } }],
    [S.lineMode === 'exact' ? 'peaks per column' : 'peaks exact', 'pan', { lineMode: S.lineMode === 'exact' ? 'columns' : 'exact' }],
    ...['auto', 'ultra', 'high', 'standard', 'fast'].filter(q => q !== S.diagRes && (q !== 'fast' || window.devicePixelRatio > 1.01)).map(q => [`diagram quality ${q}`, 'pan', { quality: q }])];
  const frame = () => new Promise(r => requestAnimationFrame(r));
  const q = (a, f) => { const b = [...a].sort((x, y) => x - y); return b.length ? b[Math.min(b.length - 1, Math.floor(f * b.length))] : 0; };
  const rows = []; BENCH.run = true; btn.disabled = true;
  try {
    for (let c = 0; c < CASES.length; c++) {
      const [name, kind, o] = CASES[c];
      BENCH.skip = o.skip || {}; BENCH.lineMode = o.lineMode || ''; ovCache = null; BENCH.js = [];
      if ((o.quality || '') !== BENCH.quality) { BENCH.quality = o.quality || ''; resize(); }
      setView(v0[0], v0[1]); await frame(); await frame();
      const iv = []; let last = 0; const N = 150, WARM = 15;
      for (let i = 0; i < N; i++) {
        const t = await frame(); if (i > WARM && last) { iv.push(t - last); BENCH.js.push(BENCH.acc); } BENCH.acc = 0; last = t;
        const sp = S.t1 - S.t0, d = (i % 60) < 30 ? 1 : -1;
        if (kind === 'pan') setView(S.t0 + d * 0.02 * sp, S.t1 + d * 0.02 * sp); else zoomAt((S.t0 + S.t1) / 2, d > 0 ? 0.97 : 1 / 0.97);
        if (i % 10 === 0) el.textContent = `Frame-rate test: ${name} (${c + 1} of ${CASES.length})…`;
      }
      const tot = iv.reduce((a, b) => a + b, 0), js = BENCH.js;
      rows.push({ name, fps: 1000 * iv.length / tot, med: q(iv, 0.5), p95: q(iv, 0.95), js: q(js, 0.5), jsMax: q(js, 0.95) });
    }
  } finally {
    BENCH.run = false; BENCH.skip = {}; BENCH.lineMode = ''; ovCache = null; BENCH.js = []; btn.disabled = false;
    if (BENCH.quality) { BENCH.quality = ''; resize(); }
    setView(v0[0], v0[1]);
  }
  const pad = (x, n) => String(x).padStart(n), nm = Math.max(...rows.map(r => r.name.length));
  const txt = `Seqret ${APP.version} frame-rate test · ${S.name} · ${S.seq.nb.toLocaleString()} blocks · ${(v0[1] - v0[0] >= S.seq.totalDur * 0.9) ? 'whole file' : 'span ' + fmt((v0[1] - v0[0]) * 1e3, 3) + ' ms'} in view\n` +
    `plot ${Math.round(W)}×${Math.round(H)} CSS px at ${window.devicePixelRatio}× · diagram quality ${S.diagRes}${S.diagRes === 'auto' ? ' (fast while moving, high when still)' : ''}, peaks ${S.lineMode}${S.diagRes !== 'auto' && pdpr !== dpr ? ` (${pdpr}× pixels)` : ''} · ${{ seq: 'Sequence', blk: 'Selection', k: 'k-space', img: 'Image', defs: 'Defs' }[S.tab] || S.tab} tab${S.tab === 'k' ? ` (${S.kRange})` : ''} · ${navigator.userAgent.replace(/^.*?\) /, '').slice(0, 60)}\n` +
    // quantity names on the first header line, their units on the second
    `${'case'.padEnd(nm)}  ${pad('frame rate', 10)}  ${pad('frame time', 16)}  ${pad('Seqret time', 16)}\n` +
    `${''.padEnd(nm)}  ${pad('fps', 10)}  ${pad('ms, median / 95%', 16)}  ${pad('ms, median / 95%', 16)}\n` +
    rows.map(r => `${r.name.padEnd(nm)}  ${pad(r.fps.toFixed(0), 10)}  ${pad(`${pad(r.med.toFixed(1), 6)} / ${pad(r.p95.toFixed(1), 5)}`, 16)}  ${pad(`${pad(r.js.toFixed(1), 6)} / ${pad(r.jsMax.toFixed(1), 5)}`, 16)}`).join('\n');
  // a suggestion when the browser's drawing, not Seqret, limits the frame rate
  const row = n => rows.find(r => r.name === n), nrm = row('normal, panning'), blank = row('blank diagram');
  // who limits the frame rate: the browser's drawing (the frame takes much longer than Seqret's own work) or Seqret
  let tip = '';
  if (nrm && blank && blank.fps > 1.25 * nrm.fps) {
    const QS = ['ultra', 'high', 'standard', 'fast', 'auto'], better = QS.slice(QS.indexOf(S.diagRes) + 1).map(q => row(`diagram quality ${q}`)).filter(r => r && r.fps > 1.2 * nrm.fps);
    const lower = better.map(r => `Display › Diagram quality › ${r.name.split(' ').pop()} gave ${r.fps.toFixed(0)} fps${r.name.endsWith(' auto') ? ' (sharp when still)' : ''}`);
    // the one part of the drawing whose removal helps most, when it is a large share
    const parts = rows.filter(r => r.name.startsWith('without ') && r.name !== 'without page updates').sort((a, b) => b.fps - a.fps);
    const worst = parts.length && parts[0].fps > 1.5 * nrm.fps ? parts[0] : null;
    // Seqret's own work is the limit only when it takes most of what the screen allows per frame (the blank diagram's
    // frame time); before 1.24.2 it was compared with the (slow) frame itself, so 5 ms of Seqret in a 10 ms frame on
    // a 100 Hz screen, where the drawing took the rest, was blamed on Seqret
    // 1.44.0: and only when it is also a large part of the frame itself; 7.8 ms of Seqret in a 33 ms frame at 120 Hz
    // was blamed on Seqret, though the drawing took the other 25 ms
    if (nrm.js > 0.8 * (1000 / blank.fps) && nrm.js > 0.5 * nrm.med) {
      tip = `\n\nSeqret's own work limits the frame rate here: it needs ${nrm.js.toFixed(1)} ms of a ${nrm.med.toFixed(1)} ms frame (a blank diagram runs at ${blank.fps.toFixed(0)} fps). This grows with the number of blocks in view; zooming in makes it faster.`;
      if (lower.length) tip += ` ${lower.join('; ')}.`;
    } else {
      tip = `\n\nThe browser's drawing limits the frame rate here: a blank diagram runs at ${blank.fps.toFixed(0)} fps, the diagram at ${nrm.fps.toFixed(0)} fps, while Seqret needs ${nrm.js.toFixed(1)} ms per frame.`;
      if (worst) tip += ` Most of it is one part: ${worst.name.replace('without ', '')} (${worst.fps.toFixed(0)} fps without it); please report this.`;
      if (lower.length) tip += ` ${lower.join('; ')}.`;
      tip += ' In Chrome or Edge, check chrome://gpu: if Skia Graphite is disabled, enabling it (chrome://flags/#skia-graphite) may give the full frame rate at full sharpness.';
    }
  }
  BENCH.last = txt; console.log(txt + tip);
  el.textContent = txt + tip + '\n\nCopied to the clipboard. Press Shift+D to close.';
  el.classList.add('sel');
  try { await navigator.clipboard.writeText(txt + tip); } catch (_) { el.textContent = txt + tip + '\n\nSelect this text to copy it. Press Shift+D to close.'; }
}
$('#benchBtn').onclick = () => { $('#morePop').hidden = true; $('#moreBtn').setAttribute('aria-expanded', 'false'); diagBench(); };
function shotOfBlock(b) { const sh = S.seq.shots; if (!sh.length || b < 0) return -1; let lo = 0, hi = sh.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (sh[m].b0 <= b) lo = m; else hi = m - 1; } return lo; }
function shotAt(t) { return S.seq.shots.length ? Math.max(0, Math.min(S.seq.shots.length - 1, ub(S.shotT0, t) - 1)) : -1; }
function volOfBlock(b) { const v = S.vols; if (!v.length || b < 0) return -1; let lo = 0, hi = v.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (v[m].b0 <= b) lo = m; else hi = m - 1; } return lo; }
function volAt(t) { return S.vols.length ? Math.max(0, Math.min(S.vols.length - 1, ub(S.volT0, t) - 1)) : -1; }
/* multiple selection of shots or volumes (S.selItems, sorted indices; S.sel is the first block of the focused one).
   Click: one item. Ctrl/Cmd+click: add or remove one. Shift+click: the range from the anchor (the last plain or
   Ctrl click). Ctrl+Shift+click: add that range. As in a file manager. */
function selSet() { return new Set(S.selItems.length ? S.selItems : [S.selKind === 'vol' ? volOfBlock(S.sel) : shotOfBlock(S.sel)]); }
function selRanges() {
  const s = S.seq; if (!s || S.sel < 0) return [];
  if ((S.selKind === 'shot' || S.selKind === 'vol') && S.selItems.length > 1) {
    const L = S.selKind === 'shot' ? s.shots : S.vols, out = [];
    for (const k of S.selItems) { const x = L[k]; if (!x) continue; if (out.length && Math.abs(out[out.length - 1][1] - x.t0) < 1e-12) out[out.length - 1][1] = x.t1; else out.push([x.t0, x.t1]); }
    return out;
  }
  const r = selRange(); return r ? [r] : [];
}
function clickItem(kind, k, e) {
  const L = kind === 'vol' ? S.vols : S.seq.shots; if (!L[k]) return;
  const ctrl = e.ctrlKey || e.metaKey, same = S.selKind === kind && S.sel >= 0;
  const cur = same ? [...selSet()] : [];
  const range = (a, b) => { const r = []; for (let i = Math.min(a, b); i <= Math.max(a, b); i++) r.push(i); return r; };
  let items, focus = k, anchor = S.selAnchor;
  if (e.shiftKey && same && anchor >= 0) items = ctrl ? [...new Set([...cur, ...range(anchor, k)])] : range(anchor, k);
  else if (ctrl && same) { items = cur.includes(k) ? cur.filter(i => i !== k) : cur.concat(k); anchor = k; if (!items.includes(k)) focus = items.length ? items.reduce((a, b) => Math.abs(b - k) < Math.abs(a - k) ? b : a) : -1; }
  else { items = [k]; anchor = k; }
  items.sort((a, b) => a - b);
  if (!items.length) { S.sel = -1; S.selKind = null; S.selItems = []; S.selAnchor = -1; renderBlock(); request(); requestImg(); return; }
  S.selAnchor = anchor;
  selectBlock(L[focus].b0, { tab: true, kind, items });
}
function selRange() {
  const s = S.seq; if (!s || S.sel < 0) return null;
  if (S.selKind === 'shot' && s.shots.length) { const x = s.shots[shotOfBlock(S.sel)]; return [x.t0, x.t1]; }
  if (S.selKind === 'vol' && S.vols.length) { const x = S.vols[volOfBlock(S.sel)]; return [x.t0, x.t1]; }
  return [s.blockStart[S.sel], s.blockStart[S.sel + 1]];
}
function drawStrip(items, i0, i1, y, title, word, selIdx, strong, isEmpty, X, x0, pw) { // selIdx: Set of selected indices
  const h = SHOTH;
  pctx.save(); pctx.beginPath(); pctx.rect(x0, y - 1, pw, h + 2); pctx.clip();
  pctx.font = `500 11px ${C.font}`; pctx.textBaseline = 'middle'; pctx.textAlign = 'center';
  if (i1 - i0 > pw / 3) {
    pctx.fillStyle = C.ink; pctx.globalAlpha = 0.09; pctx.fillRect(x0, y, pw, h); pctx.globalAlpha = 1;
    pctx.fillStyle = C.muted; pctx.fillText(`${(i1 - i0 + 1).toLocaleString()} ${title.toLowerCase()} in view · zoom in to see them`, x0 + pw / 2, y + h / 2 + 0.5);
  } else {
    for (let k = i0; k <= i1; k++) {
      const it = items[k], a = X(it.t0), b = X(it.t1), w = b - a, empty = isEmpty(it), sel = selIdx.has(k);
      pctx.fillStyle = sel ? C.sel : C.ink;
      pctx.globalAlpha = sel ? (strong ? 0.7 : 0.32) : empty ? 0.04 : (k % 2 ? 0.14 : 0.08);
      pctx.fillRect(a + 0.5, y, Math.max(1, w - 1), h); pctx.globalAlpha = 1;
      if (sel && strong) { pctx.strokeStyle = C.ink; pctx.lineWidth = 1.5; pctx.strokeRect(a + 1.25, y + 0.75, Math.max(1, w - 2.5), h - 1.5); pctx.lineWidth = 1; }
      else if (empty && w > 4) { pctx.strokeStyle = C.faint; pctx.setLineDash([2, 2]); pctx.strokeRect(a + 1, y + 0.5, w - 2, h - 1); pctx.setLineDash([]); }
      const vis0 = Math.max(a, x0), vis1 = Math.min(b, x0 + pw), vw = vis1 - vis0;
      const lab = vw > 120 && empty ? `${word} ${k + 1} · no ADC` : vw > 60 ? `${word} ${k + 1}` : vw > 22 ? `${k + 1}` : '';
      if (lab) { pctx.fillStyle = empty ? C.muted : C.ink; pctx.fillText(lab, (vis0 + vis1) / 2, y + h / 2 + 0.5); }
    }
  }
  pctx.restore();
  pctx.fillStyle = C.muted; pctx.textAlign = 'left'; pctx.font = `600 11px ${C.font}`; pctx.textBaseline = 'middle';
  pctx.fillText(title, 16, y + h / 2 + 0.5);
}
/* ADC events as bars coloured by type; one winner per pixel column when zoomed out */
let typeCols = new Int8Array(0);
function drawTypeBar(y, h, X, t0, t1, x0, pw, alpha = 1) {
  const s = S.seq, A0 = s.adcT0, A1 = s.adcT1, AT = s.adcType; if (!A0.length) return;
  const lo = lb(A1, t0), hiI = ub(A0, t1);
  pctx.globalAlpha = alpha;
  const paths = new Map(), pathOf = tp => { let q = paths.get(tp); if (!q) paths.set(tp, q = new Path2D()); return q; }; // one fill per ADC type
  if (hiI - lo <= pw) {
    for (let i = lo; i < hiI; i++) { const xa = X(A0[i]), xb = X(A1[i]); pathOf(AT[i]).rect(xa, y, Math.max(1, xb - xa), h); }
  } else {
    const nc = Math.ceil(pw) + 1; if (typeCols.length < nc) typeCols = new Int8Array(nc); typeCols.fill(-1, 0, nc);
    for (let i = lo; i < hiI;) {
      let ka = Math.floor(X(A0[i]) - x0), kb = Math.floor(X(A1[i]) - x0);
      let tp = AT[i], next = i + 1;
      if (ka === kb && ka >= 0 && ka < nc) { // events ending inside this column, via the ADC pyramid
        const tEnd = t0 + (ka + 1) * (t1 - t0) / pw; let a = i, b = hiI - 1;
        while (a < b) { const m = (a + b + 1) >> 1; if (A1[m] <= tEnd) a = m; else b = m - 1; }
        tp = adcRangeType(s, i, a); next = a + 1;
      }
      if (ka < 0) ka = 0; if (kb >= nc) kb = nc - 1;
      for (let k = ka; k <= kb; k++) if (typeCols[k] < 0 || TYPE_RANK[tp] > TYPE_RANK[typeCols[k]]) typeCols[k] = tp;
      i = next;
    }
    for (let k = 0; k < nc;) { const tp = typeCols[k]; let e = k + 1; while (e < nc && typeCols[e] === tp) e++; if (tp >= 0) pathOf(tp).rect(x0 + k, y, e - k, h); k = e; }
  }
  for (const [tp, q] of paths) { pctx.fillStyle = C[TYPE_COL[tp]]; pctx.fill(q); }
  pctx.globalAlpha = 1;
}
/* Labels lane: ADC type row, then one row per label (flags as bars, counters as numbered steps) */
function drawLabelsLane(L, X, t0, t1, x0, pw) {
  const s = S.seq, rows = labelRows(); if (!rows.length) return;
  const rh = (L.h - 6) / rows.length, T = s.totalDur;
  pctx.fillStyle = C.ink; pctx.fillRect(8, L.y + 2, 3, L.h - 4);
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r], y = L.y + 3 + r * rh;
    pctx.textBaseline = 'middle'; pctx.textAlign = 'left'; pctx.font = `600 10.5px ${C.font}`; pctx.fillStyle = C.ink;
    pctx.fillText(row.name, 16, y + rh / 2);
    if (row.kind === 'count' && rh >= 13) { pctx.textAlign = 'right'; pctx.font = `400 10px ${C.font}`; pctx.fillStyle = C.muted; pctx.fillText(`${row.tr.min}–${row.tr.max}`, x0 - 6, y + rh / 2); }
    if (row.kind === 'trig' && rh >= 13) { // the channels in use, where they fit beside the row name
      const nw = pctx.measureText(row.name).width; pctx.textAlign = 'right'; pctx.font = `400 10px ${C.font}`; pctx.fillStyle = C.muted;
      const tx = trigChannels(); if (pctx.measureText(tx).width < x0 - 6 - (16 + nw + 6)) pctx.fillText(tx, x0 - 6, y + rh / 2); }
    pctx.strokeStyle = C['line-soft']; pctx.lineWidth = 1; pctx.beginPath(); pctx.moveTo(x0, Math.round(y + rh) + 0.5); pctx.lineTo(x0 + pw, Math.round(y + rh) + 0.5); pctx.stroke();
    pctx.save(); pctx.beginPath(); pctx.rect(x0, y, pw, rh); pctx.clip();
    if (row.kind === 'type') drawTypeBar(y + 2, rh - 4, X, t0, t1, x0, pw);
    else if (row.kind === 'trig') drawTrigRow(y, rh, X, t0, t1, x0, pw);
    else {
      const tr = row.tr, n = tr.t.length, i0 = Math.max(0, ub(tr.t, t0) - 1), i1 = Math.min(n, lb(tr.t, t1));
      const end = i => i + 1 < n ? tr.t[i + 1] : T;
      if (row.kind === 'flag') {
        pctx.fillStyle = C[FLAG_COL[tr.name]] || C.muted; pctx.globalAlpha = FLAG_COL[tr.name] ? 0.9 : 0.55;
        const bars = new Path2D(); // one fill per row instead of one per bar (thousands per frame when zoomed out)
        if (i1 - i0 <= 2 * pw) { for (let i = i0; i < i1; i++) if (tr.v[i]) { const xa = X(tr.t[i]), xb = X(end(i)); bars.rect(xa, y + 3, Math.max(1, xb - xa), rh - 6); } }
        else { const pts = tracePoints(trStep(tr), t0, t1, x0, pw); let on = -1; for (let k = 0; k < pts.length; k += 2) { const x = pts[k] | 0; if (pts[k + 1]) { if (on < 0) on = x; } else if (on >= 0) { bars.rect(on, y + 3, Math.max(1, x - on + 1), rh - 6); on = -1; } } if (on >= 0) bars.rect(on, y + 3, x0 + pw - on, rh - 6); }
        pctx.fill(bars); pctx.globalAlpha = 1;
      } else if (i1 - i0 < pw / 9) {
        pctx.font = `500 10px ${C.font}`; pctx.textAlign = 'center';
        for (let i = i0; i < i1; i++) {
          const xa = X(tr.t[i]), xb = X(end(i)), w = xb - xa;
          pctx.fillStyle = C.ink; pctx.globalAlpha = i % 2 ? 0.1 : 0.05; pctx.fillRect(xa + 0.5, y + 2, Math.max(1, w - 1), rh - 4); pctx.globalAlpha = 1;
          const txt = String(tr.v[i]), tw = pctx.measureText(txt).width;
          const va = Math.max(xa, x0), vb = Math.min(xb, x0 + pw);
          if (vb - va > tw + 4) { pctx.fillStyle = C.ink; pctx.fillText(txt, (va + vb) / 2, y + rh / 2 + 0.5); }
        }
      } else {
        const span = (tr.max - tr.min) || 1, yb = y + rh - 3, hh = rh - 6;
        strokePts(pctx, tracePoints(trStep(tr), t0, t1, x0, pw), v => yb - (v - tr.min) / span * hh, C.muted);
      }
    }
    pctx.restore();
  }
}
/* trigger events: a bar from the trigger's start to its end, at least 2 px wide; output pulses in ink, waits for an
   external trigger in the warning colour. Zoomed out, at most one bar per pixel column is drawn (binary search to the
   next column), so the cost does not grow with the number of triggers. */
function trigChannels() {
  const s = S.seq; if (s._trigCh) return s._trigCh;
  const names = new Set(); for (const tr of s.triggers) { names.add(trigName(tr.type, tr.ch)); if (names.size > 3) break; }
  return (s._trigCh = [...names].slice(0, 3).join(', ') + (names.size > 3 ? ', …' : ''));
}
function drawTrigRow(y, rh, X, t0, t1, x0, pw) {
  const TR = S.seq.triggers, n = TR.length, sc = pw / (t1 - t0);
  const first = t => { let a = 0, b = n; while (a < b) { const m = (a + b) >> 1; if (TR[m].t + TR[m].dur < t) a = m + 1; else b = m; } return a; };
  const out = new Path2D(), wait = new Path2D(); let i = first(t0);
  while (i < n && TR[i].t <= t1) {
    const tr = TR[i], xa = X(tr.t), w = Math.max(2, tr.dur * sc);
    (TRIG_TYPES[tr.type] && TRIG_TYPES[tr.type].kind === 'wait' ? wait : out).rect(xa, y + 3, w, rh - 6);
    const nx = Math.floor(xa) + 1; i = Math.max(i + 1, first(t0 + (nx - x0) / sc)); // next pixel column
  }
  pctx.globalAlpha = 0.85; pctx.fillStyle = C.ink; pctx.fill(out); pctx.fillStyle = C.warn; pctx.fill(wait); pctx.globalAlpha = 1;
  // zoomed in: the channel name inside bars wide enough for it
  if (rh >= 12) {
    pctx.font = `500 10px ${C.font}`; pctx.textAlign = 'center'; pctx.textBaseline = 'middle'; pctx.fillStyle = C.plot;
    for (let j = first(t0); j < n && TR[j].t <= t1; j++) {
      const tr = TR[j], xa = Math.max(x0, X(tr.t)), xb = Math.min(x0 + pw, X(tr.t + tr.dur)); if (xb - xa < 30) { if (xb - xa < 1) j = Math.max(j, first(t0 + (Math.floor(X(tr.t)) + 1 - x0) / sc) - 1); continue; }
      const txt = trigName(tr.type, tr.ch); if (pctx.measureText(txt).width + 6 < xb - xa) pctx.fillText(txt, (xa + xb) / 2, y + rh / 2 + 0.5);
    }
  }
}
function trigAt(t) { // the trigger event whose span contains time t, or null
  const TR = S.seq.triggers; let a = 0, b = TR.length; while (a < b) { const m = (a + b) >> 1; if (TR[m].t <= t) a = m + 1; else b = m; }
  for (let i = a - 1; i >= 0 && i >= a - 8; i--) if (t <= TR[i].t + TR[i].dur) return TR[i];
  return null;
}
function drawADC(L, X, t0, t1, pw, x0) {
  const s = S.seq, y1 = L.y + L.h - 5, y0 = L.y + 5, mid = (y0 + y1) / 2;
  drawTypeBar(y0, y1 - y0, X, t0, t1, x0, pw, 0.85);
  // samples when zoomed in
  const sc = pw / (t1 - t0), A0 = s.adcT0, A1 = s.adcT1;
  if (A0.length) {
    const lo = lb(A1, t0), hi = ub(A0, t1);
    if (hi - lo < pw) {
      pctx.fillStyle = C.plot; pctx.globalAlpha = 0.8;
      for (let i = lo; i < hi; i++) {
        const d = s.adc.get(s.B.adc[s.adcBlocks[i]]); if (d.dwell * sc < 4) continue;
        for (let k = 0; k < d.num; k++) { const x = X(A0[i] + (k + 0.5) * d.dwell); if (x < x0 - 3 || x > x0 + pw + 3) continue; pctx.fillRect(x - 1, mid - 3, 2, 6); }
      }
      pctx.globalAlpha = 1;
    }
  }
  // triggers
  pctx.fillStyle = C.ink;
  const TR = s.triggers; let ti = 0; { let a = 0, b = TR.length; while (a < b) { const m = (a + b) >> 1; if (TR[m].t < t0) a = m + 1; else b = m; } ti = a; }
  for (; ti < TR.length && TR[ti].t <= t1; ti++) {
    const tr = TR[ti];
    const x = X(tr.t); pctx.beginPath(); pctx.moveTo(x, y0 - 2); pctx.lineTo(x - 4, y0 - 8 + 12); pctx.lineTo(x + 4, y0 - 8 + 12); pctx.closePath(); pctx.fill();
  }
}

function updateLegend() {
  const el = $('#legend'), s = S.seq;
  const cnt = s ? s.adcTypeCounts : null, show = !!(cnt && cnt.slice(1).some(Boolean) && (S.vis.adc || S.vis.labels));
  if (el.hidden !== !show) el.hidden = !show; if (!show) return;
  if (el._seq === s) return; el._seq = s; // (the counts belong to the file: made once per file, 1.48.1)
  const html = cnt.map((n, i) => n ? `<span class="v"><i style="--c:var(--c-${TYPE_COL[i]})"></i>${TYPE_NAME[i]} <span class="muted">${n.toLocaleString()}</span></span>` : '').join('');
  if (el.dataset.html !== html) { el.innerHTML = '<span class="muted">ADC events:</span>' + html; el.dataset.html = html; }
}
/* ---------- overview ---------- */
let ovCache = null;
function drawOverview() {
  const s = S.seq; if (!s || OW <= 0) return;
  if (!ovCache) {
    ovCache = document.createElement('canvas'); ovCache.width = Math.round(OW * odpr); ovCache.height = Math.round(OH * odpr);
    const c = ovCache.getContext('2d'); c.setTransform(odpr, 0, 0, odpr, 0, 0);
    const T = s.totalDur || 1, mg = Math.max(...s.stats.maxG) || 1, mr = s.stats.maxRF || 1;
    const mid = OH * 0.62, hh = OH * 0.34;
    for (const k of ['gx', 'gy', 'gz']) {
      const pts = traceChan(k, 0, T, 0, OW);
      c.globalAlpha = 0.75; strokePts(c, pts, v => mid - v / mg * hh, C[k]); c.globalAlpha = 1;
    }
    const pr = traceChan('rfMag', 0, T, 0, OW);
    strokePts(c, pr, v => OH * 0.26 - v / mr * OH * 0.22, C.rf, OH * 0.26);
    if (shotsOn() && s.shots.length < OW / 2) {
      c.strokeStyle = C.ink; c.globalAlpha = 0.55; c.beginPath();
      for (const sh of s.shots) { const x = Math.round(sh.t0 / T * OW) + 0.5; c.moveTo(x, 0); c.lineTo(x, 6); }
      c.stroke(); c.globalAlpha = 1;
    }
    if (volsOn() && S.vols.length < OW / 3) {
      c.strokeStyle = C.ink; c.globalAlpha = 0.6; c.lineWidth = 1.5; c.beginPath();
      for (const v of S.vols.slice(1)) { const x = Math.round(v.t0 / T * OW) + 0.5; c.moveTo(x, 0); c.lineTo(x, OH); }
      c.stroke(); c.globalAlpha = 1; c.lineWidth = 1;
    }
  }
  vctx.clearRect(0, 0, OW, OH);
  vctx.drawImage(ovCache, 0, 0, OW, OH);
  const T = s.totalDur || 1;
  const LV = segView() ? vLayout() : null;
  if (LV) { // Group segments: the shown stretches (real time)
    vctx.fillStyle = C.plot; vctx.globalAlpha = 0.62; let x = 0; const R = [];
    for (const p of LV.P) { let a = Math.max(0, p.t0) / T * OW, b = Math.min(T, p.t1) / T * OW; if (b - a < 2) { const m = (a + b) / 2; a = m - 1; b = m + 1; } R.push([a, b]); }
    for (const [a, b] of R) { if (a > x) vctx.fillRect(x, 0, a - x, OH); x = Math.max(x, b); }
    if (x < OW) vctx.fillRect(x, 0, OW - x, OH); vctx.globalAlpha = 1;
    vctx.strokeStyle = C.ink; vctx.lineWidth = 1.5; for (const [a, b] of R) vctx.strokeRect(a + 0.75, 0.75, Math.max(0.5, b - a - 1.5), OH - 1.5);
    if (S.sel >= 0) { vctx.fillStyle = C.sel; const x2 = s.blockStart[S.sel] / T * OW; vctx.fillRect(x2 - 1, 0, 2, OH); }
    return;
  }
  let xa = S.t0 / T * OW, xb = S.t1 / T * OW;
  if (xb - xa < 3) { const m = (xa + xb) / 2; xa = m - 1.5; xb = m + 1.5; }
  vctx.fillStyle = C.plot; vctx.globalAlpha = 0.62;
  vctx.fillRect(0, 0, Math.max(0, xa), OH); vctx.fillRect(xb, 0, OW - xb, OH); vctx.globalAlpha = 1;
  vctx.strokeStyle = C.ink; vctx.lineWidth = 1.5; vctx.strokeRect(xa + 0.75, 0.75, xb - xa - 1.5, OH - 1.5);
  if (S.sel >= 0) { vctx.fillStyle = C.sel; const x = s.blockStart[S.sel] / T * OW; vctx.fillRect(x - 1, 0, 2, OH); }
}

/* ---------- overlay: crosshair + values ---------- */
let boxSel = null;
/* a faint band across the labels-lane row under the mouse, from its name in the gutter to the right edge, so the
   name and the values far to the right are easy to pair (mouse only; not while panning) */
/* ---------- echo markers (shotEchoes in core.js) ----------
   On the RF lane: spin echoes (▼, ink) in a top row; gradient echoes with k = 0 (●) and the other gradient echoes along
   the readouts (○), in the ADC colour, in a row below. Switched under Display › Echoes; by default only while the view
   covers at most ECHO_ZOOM_SHOTS shots. Computed per shot on demand (cached); when many shots come into view at once,
   up to 12 ms of new shots per frame, the rest at the next frames. */
const ECHO_ZOOM_SHOTS = 4;
let echoVis = [], echoPend = false;
function echoShots() { const s = S.seq; return s.shots.length ? s.shots : (s._echShots || (s._echShots = computeShots(s, 'exc'))); }
function echoCached(shots, k) { const c = S.seq._ech; return !!(c && c.shots === shots && c.m.has(k)); }
function shotRange(shots, t0, t1) { // first and last shot overlapping [t0, t1]
  let a = 0, b = shots.length; while (a < b) { const m = (a + b) >> 1; if (shots[m].t1 <= t0) a = m + 1; else b = m; }
  let c = a, d = shots.length; while (c < d) { const m = (c + d) >> 1; if (shots[m].t0 < t1) c = m + 1; else d = m; }
  return [a, c - 1];
}
function echoesOn() { const E = S.echo; return E.se || E.gf || E.gl; }
function drawEchoMarks(L, X, t0, t1, x0, pw, keep) { // keep: a later panel (Group segments) adds to echoVis
  if (!keep) echoVis = [];
  const E = S.echo; if (!echoesOn() || !S.seq) return;
  const shots = echoShots(); if (!shots.length) return;
  const [k0, k1] = shotRange(shots, t0, t1); if (k1 < k0) return;
  if (E.zoom && k1 - k0 + 1 > ECHO_ZOOM_SHOTS) return;
  const T0 = performance.now(), P = { se: new Path2D(), gf: new Path2D(), gl: new Path2D() }, lastX = { se: -1e9, gf: -1e9, gl: -1e9 };
  const ySE = L.y + 7, yGE = L.y + 18; let pending = false;
  for (let k = k0; k <= k1; k++) {
    if (!echoCached(shots, k) && performance.now() - T0 > 12) { pending = true; break; }
    const r = shotEchoes(S.seq, shots, k);
    for (const [kind, arr, y] of [['se', r.se, ySE], ['gf', r.gf, yGE], ['gl', r.gl, yGE]]) {
      if (!E[kind]) continue;
      const p = P[kind];
      for (let i = 0; i < arr.length; i++) {
        const t = arr[i]; if (t < t0 || t > t1) continue;
        const x = X(t); if (Math.abs(x - lastX[kind]) < 1.5) continue; lastX[kind] = x;
        if (kind === 'se') { p.moveTo(x - 4.5, y - 4); p.lineTo(x + 4.5, y - 4); p.lineTo(x, y + 3.5); p.closePath(); }
        else { const rr = kind === 'gf' ? 3.6 : 2.6; p.moveTo(x + rr, y); p.arc(x, y, rr, 0, 2 * Math.PI); }
        echoVis.push({ x, y, kind, t, tE: r.tE, kp: kind === 'gl' ? r.kp[i] : 0, k });
      }
    }
  }
  pctx.save(); pctx.beginPath(); pctx.rect(x0, L.y - 1, pw, L.h + 2); pctx.clip();
  pctx.fillStyle = C.ink; pctx.fill(P.se);
  pctx.fillStyle = C.adc; pctx.fill(P.gf);
  pctx.strokeStyle = C.adc; pctx.lineWidth = 1.3; pctx.stroke(P.gl);
  pctx.restore();
  if (pending && !echoPend) { echoPend = true; setTimeout(() => { echoPend = false; request(); }, 0); }
}
/* the marker under the mouse (within 5 px), for its description in the overlay */
function echoHover(x) {
  if (S.hoverY == null || !echoVis.length) return null;
  let best = null, bd = 5;
  for (const m of echoVis) { const d = Math.abs(m.x - x); if (d <= bd && Math.abs(S.hoverY - m.y) <= 7) { bd = d; best = m; } }
  return best;
}
function echoText(m) {
  const r = shotEchoes(S.seq, echoShots(), m.k), after = `${fmtT(m.t - m.tE)} after the excitation`;
  const rel = (other, word) => { // the nearest echo of the other kind in the same shot
    let n = null; for (const t of other) if (n === null || Math.abs(t - m.t) < Math.abs(n - m.t)) n = t;
    if (n === null) return ''; const d = n - m.t;
    return Math.abs(d) < 1e-7 ? ` · ${word} at the same time` : ` · ${word} ${fmtT(Math.abs(d))} ${d > 0 ? 'later' : 'earlier'}`;
  };
  if (m.kind === 'se') return `Spin echo · ${after}` + rel(r.gf, 'gradient echo (k = 0)');
  if (m.kind === 'gf') return `Gradient echo, k = 0 · ${after}` + rel(r.se, 'spin echo');
  return `Gradient echo along the readout · |k| = ${fmt(m.kp * mF(), 4)} ${mU()} · ${after}`;
}
function drawEchoTip(x) {
  const m = echoHover(x); if (!m) return;
  octx.font = `600 11px ${C.font}`; octx.textBaseline = 'middle';
  const txt = echoText(m), tw = octx.measureText(txt).width, right = m.x + 9 + tw < W - 8, tx = right ? m.x + 9 : m.x - 9 - tw, ty = m.y;
  octx.fillStyle = C.plot; octx.globalAlpha = 0.92; octx.fillRect(tx - 3, ty - 7, tw + 6, 14); octx.globalAlpha = 1;
  octx.fillStyle = C.ink; octx.textAlign = 'left'; octx.fillText(txt, tx, ty);
}
/* k-space: where each echo lies on the trajectory (shots of the shown range; gradient echoes of the shown kind of
   readout), drawn over the samples with an outline in the plot colour */
/* echo markers on screen (1.45.0): each shape (with its halo) drawn once into a small image at the screen's pixel
   ratio, then stamped into the k-space pixel buffer at every echo, blended over it; the echoes' k-vectors are kept
   per range, so turning or zooming the view only projects them again. Before, every redraw computed the k-vector of
   each echo and stroked and filled every marker as a path: on a 30-slice EPI in full view about 25,000 rings, 0.9 s
   per redraw in a test browser. Echoes of one kind at the same device pixel (the slices of an EPI repeat the same k)
   are stamped once. A figure keeps vector markers (drawEchoesK). */
let kEchoStampC = null, kEchoCache = null;
function echoStamp(kind, d, layer) { // layer 'h': the halo (plot colour); 'f': the marker itself
  const key = kind + layer + '|' + d + '|' + C.plot + C.adc + C.ink; kEchoStampC = kEchoStampC || new Map(); let st = kEchoStampC.get(key); if (st) return st;
  const S2 = Math.ceil(18 * d) | 1, h = S2 >> 1, cv = document.createElement('canvas'); cv.width = cv.height = S2;
  const g = cv.getContext('2d'); g.setTransform(d, 0, 0, d, h, h); g.lineJoin = 'round';
  const H = layer === 'h';
  if (kind === 'gl') { g.beginPath(); g.arc(0, 0, 3, 0, 2 * Math.PI); if (H) { g.strokeStyle = C.plot; g.lineWidth = 3.2; } else { g.strokeStyle = C.adc; g.lineWidth = 1.4; } g.stroke(); }
  else { if (kind === 'gf') { g.beginPath(); g.arc(0, 0, 4.2, 0, 2 * Math.PI); } else { g.beginPath(); g.moveTo(-5, -6); g.lineTo(5, -6); g.lineTo(0, 2); g.closePath(); }
    if (H) { g.strokeStyle = C.plot; g.lineWidth = 2.5; g.stroke(); } else { g.fillStyle = kind === 'gf' ? C.adc : C.ink; g.fill(); } }
  const D = g.getImageData(0, 0, S2, S2).data, dx = [], dy = [], cr = [], cg = [], cb = [], ca = [];
  for (let y = 0; y < S2; y++) for (let x = 0; x < S2; x++) { const o = (y * S2 + x) * 4; if (D[o + 3]) { dx.push(x - h); dy.push(y - h); cr.push(D[o]); cg.push(D[o + 1]); cb.push(D[o + 2]); ca.push(D[o + 3] / 255); } }
  st = { n: dx.length, dx: Int16Array.from(dx), dy: Int16Array.from(dy), r: Float32Array.from(cr), g: Float32Array.from(cg), b: Float32Array.from(cb), a: Float32Array.from(ca) };
  kEchoStampC.set(key, st); return st;
}
function stampEchoesK(B, P, pb0, pb1, grp) {
  const E = S.echo; if (!echoesOn() || !S.seq) return '';
  const s = S.seq, bs = s.blockStart, shots = echoShots(); if (!shots.length) return '';
  let [k0, k1] = shotRange(shots, bs[pb0], bs[pb1 + 1]); if (k1 < k0) return '';
  const capped = k1 - k0 + 1 > 400; if (capped) k1 = k0 + 399;
  const act = S.kActual && s.cc, key = [k0, k1, grp ? grp.id : '', E.se, E.gf, E.gl, s.nb, act ? s.cc.key : ''].join(',');
  if (!kEchoCache || kEchoCache.key !== key || kEchoCache.seq !== s) { // the echoes' k-vectors, per kind
    const rel = new Float64Array(1), out = [new Float64Array(1), new Float64Array(1), new Float64Array(1)], L = { se: [], gf: [], gl: [] };
    const kAt = (t, arr) => { const b = blockAtTime(s, t); rel[0] = t - bs[b]; (act ? ktInBlock : kInBlock)(s, b, rel, out, 0, 1); arr.push(out[0][0], out[1][0], out[2][0]); };
    for (let k = k0; k <= k1; k++) {
      const r = shotEchoes(s, shots, k);
      if (E.se) for (const t of r.se) kAt(t, L.se);
      if (E.gf) r.gf.forEach((t, i) => { if (!grp || grp.fj(r.jf[i])) kAt(t, L.gf); });
      if (E.gl) r.gl.forEach((t, i) => { if (!grp || grp.fj(r.jl[i])) kAt(t, L.gl); });
    }
    kEchoCache = { key, seq: s, gl: Float64Array.from(L.gl), gf: Float64Array.from(L.gf), se: Float64Array.from(L.se) };
  }
  const { buf, Wd, Hd, d } = B;
  // one marker per kind and device pixel: echoes repeated at the same k (the slices of an EPI) are stamped once
  const seen = new Uint8Array(Wd * Hd);
  for (const [kind, bit] of [['gl', 1], ['gf', 2], ['se', 4]]) { // the order the paths were drawn in
    const K3 = kEchoCache[kind]; if (!K3.length) continue;
    const XY = []; // the markers' device pixels, once per pixel
    for (let q = 0; q < K3.length; q += 3) {
      const [px, py] = P(K3[q], K3[q + 1], K3[q + 2]), X0 = Math.round(px * d), Y0 = Math.round(py * d);
      if (X0 >= 0 && Y0 >= 0 && X0 < Wd && Y0 < Hd) { const c = Y0 * Wd + X0; if (seen[c] & bit) continue; seen[c] |= bit; }
      XY.push(X0, Y0);
    }
    for (const layer of ['h', 'f']) { const st = echoStamp(kind, d, layer); // all halos, then all markers (as the two paths were)
    for (let m = 0; m < XY.length; m += 2) {
      const X0 = XY[m], Y0 = XY[m + 1];
      for (let u = 0; u < st.n; u++) {
        const x = X0 + st.dx[u], y = Y0 + st.dy[u]; if (x < 0 || y < 0 || x >= Wd || y >= Hd) continue;
        const o = y * Wd + x, a = st.a[u], v = buf[o], ad = (v >>> 24) / 255;
        if (a >= 1 || !ad) { buf[o] = ((Math.round(a * 255) << 24) | (st.b[u] << 16) | (st.g[u] << 8) | st.r[u]) >>> 0; continue; }
        const oa = a + ad * (1 - a), w = ad * (1 - a) / oa, ws = a / oa; // over, straight alpha
        const r = st.r[u] * ws + (v & 255) * w, g = st.g[u] * ws + (v >> 8 & 255) * w, bb = st.b[u] * ws + (v >> 16 & 255) * w;
        buf[o] = ((Math.round(oa * 255) << 24) | (Math.round(bb) << 16) | (Math.round(g) << 8) | Math.round(r)) >>> 0;
      }
    }
    }
  }
  return capped ? 'echo markers for the first 400 shots' : '';
}
function drawEchoesK(ctx, P, pb0, pb1, grp) {
  const E = S.echo; if (!echoesOn() || !S.seq) return '';
  const s = S.seq, bs = s.blockStart, shots = echoShots(); if (!shots.length) return '';
  let [k0, k1] = shotRange(shots, bs[pb0], bs[pb1 + 1]); if (k1 < k0) return '';
  const capped = k1 - k0 + 1 > 400; if (capped) k1 = k0 + 399;
  const rel = new Float64Array(1), out = [new Float64Array(1), new Float64Array(1), new Float64Array(1)];
  const kAt = t => { const b = blockAtTime(s, t); rel[0] = t - bs[b]; kInBlock(s, b, rel, out, 0, 1); return P(out[0][0], out[1][0], out[2][0]); };
  const Pse = new Path2D(), Pgf = new Path2D(), Pgl = new Path2D();
  for (let k = k0; k <= k1; k++) {
    const r = shotEchoes(s, shots, k);
    if (E.se) for (const t of r.se) { const [x, y] = kAt(t); Pse.moveTo(x - 5, y - 6); Pse.lineTo(x + 5, y - 6); Pse.lineTo(x, y + 2); Pse.closePath(); }
    if (E.gf) r.gf.forEach((t, i) => { if (grp && !grp.fj(r.jf[i])) return; const [x, y] = kAt(t); Pgf.moveTo(x + 4.2, y); Pgf.arc(x, y, 4.2, 0, 2 * Math.PI); });
    if (E.gl) r.gl.forEach((t, i) => { if (grp && !grp.fj(r.jl[i])) return; const [x, y] = kAt(t); Pgl.moveTo(x + 3, y); Pgl.arc(x, y, 3, 0, 2 * Math.PI); });
  }
  ctx.save(); ctx.lineJoin = 'round';
  ctx.strokeStyle = C.plot; ctx.lineWidth = 3.2; ctx.stroke(Pgl); ctx.strokeStyle = C.adc; ctx.lineWidth = 1.4; ctx.stroke(Pgl);
  ctx.strokeStyle = C.plot; ctx.lineWidth = 2.5; ctx.stroke(Pgf); ctx.fillStyle = C.adc; ctx.fill(Pgf);
  ctx.strokeStyle = C.plot; ctx.lineWidth = 2.5; ctx.stroke(Pse); ctx.fillStyle = C.ink; ctx.fill(Pse);
  ctx.restore();
  return capped ? 'echo markers for the first 400 shots' : '';
}
function buildEchoChips() {
  const el = $('#echoChips'); if (!el) return; el.innerHTML = '';
  const defs = [['se', 'Spin', 'ink', 'tri', 'Spin echoes (▼): where the dephasing from off-resonance returns to zero — from the excitation, reversed at each refocusing pulse (pulse centres)'],
    ['gf', 'Gradient, k = 0', 'c-adc', 'dot', 'Gradient echoes at k = 0 (●): during a readout, where the whole k-vector is zero (the centre line of an image, a navigator, a spiral\'s start)'],
    ['gl', 'Gradient, lines', 'c-adc', 'ring', 'Other gradient echoes (○): where the k component along a readout crosses zero, on lines away from the centre (k ≠ 0 across the readout)']];
  for (const [key, lab, col, shape, tip] of defs) {
    const b = document.createElement('button'); b.className = 'chip'; b.type = 'button'; b.title = tip;
    b.style.setProperty('--c', `var(--${col})`); b.setAttribute('aria-pressed', S.echo[key]);
    b.innerHTML = `<span class="sw ${shape}"></span>${lab}`;
    b.onclick = () => { S.echo[key] = !S.echo[key]; b.setAttribute('aria-pressed', S.echo[key]); scheduleSave(); request(); requestOverlay(); kKey = null; drawK(); };
    el.appendChild(b);
  }
  $('#echoZoom').checked = S.echo.zoom;
}
function labelRowBand() {
  if (S.hoverY == null || (drag && drag.moved)) return;
  const L = lanesGeom().find(l => l.key === 'labels'); if (!L) return;
  const rows = labelRows(); if (!rows.length) return;
  const rh = (L.h - 6) / rows.length, r = Math.floor((S.hoverY - L.y - 3) / rh);
  if (r < 0 || r >= rows.length) return;
  octx.fillStyle = C.ink; octx.globalAlpha = 0.08; octx.fillRect(12, L.y + 3 + r * rh, W - 8 - 12, rh); octx.globalAlpha = 1;
}
function drawOverlay() {
  octx.clearRect(0, 0, W, H);
  if (!S.seq) return;
  const pw = W - GUT - 8, x0 = GUT;
  if (boxSel) {
    const a = Math.min(boxSel.a, boxSel.b), b = Math.max(boxSel.a, boxSel.b);
    octx.fillStyle = C.gx; octx.globalAlpha = 0.12; octx.fillRect(a, 0, b - a, H - AXH); octx.globalAlpha = 1;
    octx.strokeStyle = C.gx; octx.strokeRect(a + 0.5, 0.5, b - a, H - AXH - 1);
    const lab = fmtT(xToV(b) - xToV(a)); octx.font = `600 11px ${C.font}`;
    const tw = octx.measureText(lab).width, lx = (a + b) / 2;
    octx.fillStyle = C.gx; octx.fillRect(lx - tw / 2 - 5, H - AXH + 3, tw + 10, 17);
    octx.fillStyle = C.plot; octx.textAlign = 'center'; octx.textBaseline = 'middle'; octx.fillText(lab, lx, H - AXH + 12);
    return;
  }
  labelRowBand();
  if (S.hoverGap && S.hoverT == null) { segGapTip(S.hoverGap); return; }
  if (S.hoverT == null) return;
  const t = S.hoverT, x = tToX(t);
  if (x == null || x < x0 || x > x0 + pw) return;
  octx.strokeStyle = C.ink; octx.globalAlpha = 0.55; octx.lineWidth = 1;
  octx.beginPath(); octx.moveTo(Math.round(x) + 0.5, 0); octx.lineTo(Math.round(x) + 0.5, H - AXH); octx.stroke(); octx.globalAlpha = 1;
  octx.font = `600 11px ${C.font}`; octx.textBaseline = 'middle';
  const right = x < x0 + pw - 120;
  for (const L of lanesGeom()) {
    if (L.key === 'adc') { // a trigger marker (triangle at the top of the lane) within 6 px of the cursor, or a trigger spanning it
      const TR = S.seq.triggers; if (!TR.length) continue;
      const sc = pw / (S.t1 - S.t0); let a2 = 0, b2 = TR.length; while (a2 < b2) { const m = (a2 + b2) >> 1; if (TR[m].t < t) a2 = m + 1; else b2 = m; }
      let tg = null, best = 6; for (const i of [a2 - 1, a2]) if (TR[i]) { const d = Math.abs(TR[i].t - t) * sc; if (d <= best) { best = d; tg = TR[i]; } }
      if (!tg) tg = trigAt(t); if (!tg) continue;
      const blk = S.seq.B.id[tg.block], txt = `Trigger: ${trigText(tg.type, tg.ch)} · ${fmtT(tg.dur)} long · ${fmtT(tg.t - S.seq.blockStart[tg.block])} into block ${blk}`;
      const ty = L.y + 10, tw = octx.measureText(txt).width, tx = right ? x + 6 : x - 6 - tw;
      octx.fillStyle = C.plot; octx.globalAlpha = 0.9; octx.fillRect(tx - 3, ty - 7, tw + 6, 14); octx.globalAlpha = 1;
      octx.fillStyle = C.ink; octx.textAlign = 'left'; octx.fillText(txt, tx, ty);
      continue;
    }
    if (L.key === 'labels') {
      const rows = labelRows(), rh = (L.h - 6) / rows.length;
      octx.font = `600 10.5px ${C.font}`;
      rows.forEach((row, r) => {
        let txt = '';
        if (row.kind === 'type') { const j = adcAt(t); if (j >= 0) txt = TYPE_NAME[S.seq.adcType[j]]; }
        else if (row.kind === 'trig') { const tg = trigAt(t); if (tg) txt = `${trigName(tg.type, tg.ch)} ${TRIG_TYPES[tg.type] ? TRIG_TYPES[tg.type].kind : ''}`.trim(); }
        else { const i = ub(row.tr.t, t) - 1; if (i >= 0) txt = row.kind === 'flag' ? (row.tr.v[i] ? 'on' : '') : String(row.tr.v[i]); }
        if (!txt) return;
        const ty = L.y + 3 + r * rh + rh / 2, tw = octx.measureText(txt).width, tx = right ? x + 6 : x - 6 - tw;
        octx.fillStyle = C.plot; octx.globalAlpha = 0.9; octx.fillRect(tx - 3, ty - 6.5, tw + 6, 13); octx.globalAlpha = 1;
        octx.fillStyle = row.kind === 'type' ? C[TYPE_COL[TYPE_NAME.indexOf(txt)]] : C.ink; octx.textAlign = 'left'; octx.fillText(txt, tx, ty);
      });
      octx.font = `600 11px ${C.font}`;
      continue;
    }
    if (L.stim) { // values of the stimulation traces at the cursor
      const m = STIM ? STIM.idx[L.stim] : undefined; if (m === undefined) continue;
      const v = stimAtCached(t); if (!v) continue;
      cursorTags([['gx', 0, 'x'], ['gy', 1, 'y'], ['gz', 2, 'z']].concat(S.stimNorm ? [['muted', 3, '‖·‖']] : []).map(([col, j, lab]) => [`${stimNum(v[m * 4 + j])} % ${lab}`, C[col]]), L, x, right);
      continue;
    }
    const chans = laneChannels(L), f = laneFactor(L.key), tags = [];
    for (const [col, c] of chans) {
      const v = channelValue(S.seq, c, t);
      const txt = v !== v ? '' : (L.kind === 'phase' ? fmt(v, 3) + ' rad' : fmt(v * f, 3) + (chans.length > 1 ? ` ${c === 'rfRe' ? 're' : c === 'rfIm' ? 'im' : col.toUpperCase()[1]}` : ''));
      if (txt) tags.push([txt, C[col]]);
    }
    cursorTags(tags, L, x, right);
  }
  const tl = fmtT(t), tw = octx.measureText(tl).width;
  octx.fillStyle = C.ink; octx.fillRect(x - tw / 2 - 5, H - AXH + 3, tw + 10, 17);
  octx.fillStyle = C.plot; octx.textAlign = 'center'; octx.fillText(tl, x, H - AXH + 12);
  drawEchoTip(x); // last: over the lanes' values at the cursor
}
/* a lane's values at the cursor, [text, colour] each: one under the other where the lane is high enough for them, as
   before; otherwise side by side on one line across the lane's middle (1.48.1: in a low lane the stack ran on into
   the lanes below, over their values) */
function cursorTags(tags, L, x, right) {
  const n = tags.length; if (!n) return;
  octx.textAlign = 'left';
  const box = (tx, ty, tw) => { octx.fillStyle = C.plot; octx.globalAlpha = 0.85; octx.fillRect(tx - 3, ty - 7, tw + 6, 14); octx.globalAlpha = 1; };
  if (n * 14 + 3 <= L.h + 2) {
    for (let i = 0; i < n; i++) { const ty = L.y + 10 + i * 14, tw = octx.measureText(tags[i][0]).width, tx = right ? x + 6 : x - 6 - tw; box(tx, ty, tw); octx.fillStyle = tags[i][1]; octx.fillText(tags[i][0], tx, ty); }
    return;
  }
  const gap = 9, ws = tags.map(g => octx.measureText(g[0]).width), tw = ws.reduce((a, b) => a + b, 0) + gap * (n - 1), ty = L.y + L.h / 2;
  let tx = right ? x + 6 : x - 6 - tw; box(tx, ty, tw);
  for (let i = 0; i < n; i++) { octx.fillStyle = tags[i][1]; octx.fillText(tags[i][0], tx, ty); tx += ws[i] + gap; }
}
const HINT = '<span class="hint">Drag to zoom into a range · right-drag or scroll sideways to pan · scroll to zoom · <kbd>Ctrl</kbd>+scroll or a pinch over a lane’s name zooms it in y · <kbd>Backspace</kbd> goes back · click a block to inspect it · ← → step through the selected block, shot or volume</span>';
let readoutHTML = null; // what the readout holds (1.48.1: written only when it changes; every frame calls this)
function updateReadout() {
  const el = $('#readout');
  if (!S.seq || S.hoverT == null) {
    if (!el.dataset.hint) { el.innerHTML = HINT; el.dataset.hint = '1'; readoutHTML = null; }
    return;
  }
  if (el.dataset.hint) el.dataset.hint = '';
  const s = S.seq, t = S.hoverT, b = blockAt(t);
  const g = k => fmt(channelValue(s, k, t) * gF(), 3);
  const adcOn = adcAt(t) >= 0;
  const sk = shotsOn() ? shotAt(t) : -1;
  const html = `<span>t <b>${fmtT(t)}</b></span><span>block <b>${s.B.id[b]}</b> <span class="muted">${esc(describeBlock(b))}</span> <span class="muted">(${fmtT(t - s.blockStart[b])} in)</span></span>` +
    (volsOn() ? `<span>volume <b>${volAt(t) + 1}</b><span class="muted"> / ${S.vols.length}</span></span>` : '') +
    (sk >= 0 ? `<span>shot <b>${sk + 1}</b><span class="muted"> / ${s.shots.length}</span></span>` : '') + segReadout(sk) +
    (S.rfMode === 'complex' ? `<span class="v"><i style="--c:var(--c-rf)"></i>RF <b>${fmt(channelValue(s, 'rfRe', t) * rF(), 3)}</b> re, <b>${fmt(channelValue(s, 'rfIm', t) * rF(), 3)}</b> im ${rU()}</span>`
      : `<span class="v"><i style="--c:var(--c-rf)"></i>RF <b>${fmt(channelValue(s, 'rfMag', t) * rF(), 3)}</b> ${rU()}</span>`) +
    ['gx', 'gy', 'gz'].map(k => `<span class="v"><i style="--c:var(--c-${k})"></i>${'G' + k[1]} <b>${g(k)}</b></span>`).join('') +
    `<span class="muted">${gU()}</span>` + (adcOn ? `<span class="v"><i style="--c:var(--c-adc)"></i><b>ADC on</b></span>` : '') +
    (S.vis.m0 ? `<span class="v"><i style="--c:var(--ink)"></i>k <b>${['mx', 'my', 'mz'].map(k => fmt(channelValue(s, k, t) * mF(), 3)).join(', ')}</b> <span class="muted">${mU()}</span></span>` : '') +
    (S.vis.gc || S.vis.kc || S.vis.kt ? (ccEnsure(), ccPosReadout(t)) : '') +
    (S.vis.gc ? `<span class="v"><i style="--c:var(--ink)"></i>Gc <b>${['cx', 'cy', 'cz'].map(k => fmt(channelValue(s, k, t) * gF(), 3)).join(', ')}</b> <span class="muted">${gU()}</span></span>` : '') +
    (S.vis.kc ? `<span class="v"><i style="--c:var(--ink)"></i>kc <b>${['qx', 'qy', 'qz'].map(k => fmt(channelValue(s, k, t) * mF(), 3)).join(', ')}</b> <span class="muted">${mU()}</span></span>` : '') +
    (S.vis.kt ? `<span class="v" title="Total dephasing vector: the k-vector plus kc at the same position"><i style="--c:var(--ink)"></i>k + kc <b>${['tx', 'ty', 'tz'].map(k => fmt(channelValue(s, k, t) * mF(), 3)).join(', ')}</b> <span class="muted">${mU()}</span></span>` : '') +
    (S.vis.mu ? (muEnsure(), `<span class="v" title="Generalized Maxwell index (γ/B0)|∫g⊗g h dt|, from the last excitation"><i style="--c:var(--ink)"></i>μ <b>${fmt(channelValue(s, 'mu', t), 3)}</b> <span class="muted">1/m²</span></span>`) : '') + stimReadout(t);
  if (html !== readoutHTML) { el.innerHTML = html; readoutHTML = html; } // (zooming at the cursor and drag-panning keep the time under it)
}

/* ---------- view control ---------- */
function setView(t0, t1) {
  const V = segView(), T = viewDur(); // Group segments: view time (the image's shots joined), plus the boxes between them
  const pw = W - GUT - 8, gx = V && V.n > 1 && pw > 0 ? Math.min(0.8 * pw, segGapPx(V, pw) * (V.n - 1)) : 0;
  // at least 0.1 ms across the plot (1.23.3): finer is below every raster time of interest, and at the former limit
  // of 0.2 µs a few drawing paths had to walk from far off-screen points to the view
  const MIN_SPAN = 1e-4; let span = Math.min(Math.max(t1 - t0, MIN_SPAN), Math.max(T * 1.1 || 1, MIN_SPAN) / (1 - gx / pw || 1));
  let c = (t0 + t1) / 2;
  const Te = T + (gx ? span * gx / pw : 0), lo = -0.05 * Te + span / 2, hi = Te * 1.05 - span / 2;
  if (lo <= hi) c = Math.min(Math.max(c, lo), hi); else c = Te / 2;
  S.t0 = c - span / 2; S.t1 = c + span / 2; noteViewChange(); request();
  if (!linkApplying && !V) linkSendView();
}
function pushHist() { S.hist.push([S.t0, S.t1]); if (S.hist.length > 60) S.hist.shift(); $('#backBtn').disabled = false; }
function back() { const v = S.hist.pop(); if (v) setView(v[0], v[1]); $('#backBtn').disabled = !S.hist.length; }
function zoomToRange(t0, t1, hist = true) { t0 = tToV(t0); t1 = tToV(t1); const d = t1 - t0; if (!(d > 0) && segView()) return; if (hist) pushHist(); setView(t0 - d * 0.03, t1 + d * 0.03); } // real times
function zoomToShot(k, hist = true) { const sh = S.seq.shots[k]; if (sh) zoomToRange(sh.t0, sh.t1, hist); }
function zoomToVol(k, hist = true) { const v = S.vols[k]; if (v) zoomToRange(v.t0, v.t1, hist); }
/* Go to shot/volume k, keeping the zoom (the time span): the start of the new item lands where the start of the
   current one was on screen (left edges stay in place; setView keeps the view inside the sequence, so near the ends
   it can shift). */
function gotoItem(kind, k) {
  if (segView()) { segGoto(kind, k); return; }
  const list = kind === 'shot' ? S.seq.shots : S.vols; if (!list.length) return;
  k = Math.max(0, Math.min(list.length - 1, k));
  const cur = S.sel >= 0 ? (kind === 'shot' ? shotOfBlock(S.sel) : volOfBlock(S.sel)) : (kind === 'shot' ? shotAt : volAt)((S.t0 + S.t1) / 2);
  const span = S.t1 - S.t0, c = list[cur], nx = list[k];
  selectBlock(nx.b0, { kind });
  // the zoom never changes: the view moves by the distance between the starts of the current and the next item (also
  // from a selected block, or from the item at the view centre); double-click a bar to zoom to an item
  if (c) { const d = nx.t0 - c.t0; setView(S.t0 + d, S.t1 + d); }
  else { const m = (nx.t0 + nx.t1) / 2; setView(m - span / 2, m + span / 2); }
}
function stepShot(dir) {
  if (!S.seq.shots.length) return;
  const cur = S.sel >= 0 ? shotOfBlock(S.sel) : shotAt(vcT());
  if (segView()) { segStepShot(cur, dir); return; }
  gotoItem('shot', cur + dir);
}
function stepVol(dir) {
  if (!S.vols.length) return;
  const cur = S.sel >= 0 ? volOfBlock(S.sel) : volAt(vcT()); gotoItem('vol', cur + dir);
}
/* toolbar steppers */
function stepBlock(dir) {
  if (!S.seq) return;
  const cur = S.sel >= 0 ? S.sel : blockAt(vcT());
  let b = cur + dir; const V = segView();
  if (V) { // Group segments: only blocks that are shown
    const shown = b => { const t = S.seq.blockStart[b]; for (const r of V.iv) if (t >= r[0] && t < r[1]) return true; return false; };
    while (b >= 0 && b < S.seq.nb && !shown(b)) b += dir;
    if (b < 0 || b >= S.seq.nb) return;
  }
  selectBlock(b, { ensureVisible: true, kind: 'block' });
}
function navCurrent(kind) {
  const s = S.seq, c = vcT();
  if (kind === 'img') { const V = segView(); return V ? V.gi : -1; }
  if (kind === 'block') return S.sel >= 0 ? S.sel : blockAt(c);
  if (kind === 'shot') return !s.shots.length ? -1 : S.sel >= 0 ? shotOfBlock(S.sel) : shotAt(c);
  return !S.vols.length ? -1 : S.sel >= 0 ? volOfBlock(S.sel) : volAt(c);
}
/* 1.48.1: every frame calls this, so the elements are looked up once and a field is written only when its value
   changes (before: three counts formatted and a dozen fields set per frame, each a reason for the next layout) */
const NAV_EL = {};
function updateNav() {
  const s = S.seq, nav = NAV_EL.nav || (NAV_EL.nav = $('#nav'));
  if (nav.hidden !== !s) nav.hidden = !s;
  if (!s) return;
  const V = segView(), total = { block: s.nb, shot: shotsOn() ? s.shots.length : 0, vol: volsOn() ? S.vols.length : 0, img: V ? segGroups().groups.length : 0 };
  for (const k of ['block', 'shot', 'vol', 'img']) {
    let E = NAV_EL[k]; if (!E) { const g = $('#nav-' + k); E = NAV_EL[k] = { g, inp: g.querySelector('input'), of: g.querySelector('.of'), prev: g.querySelector('.prev'), next: g.querySelector('.next'), nIn: -1, nOf: -1, act: null }; }
    const g = E.g, n = total[k];
    if (g.hidden !== !n) g.hidden = !n; if (!n) continue;
    const i = navCurrent(k), inp = E.inp, act = k === 'img' || (S.sel >= 0 && S.selKind === k);
    if (E.act !== act) { g.classList.toggle('active', act); E.act = act; }
    if (document.activeElement !== inp) {
      const v = String(i + 1); if (inp.value !== v) inp.value = v;
      if (E.nIn !== n) { inp.max = n; inp.style.width = (String(n).length + 2.2) + 'ch'; E.nIn = n; }
    }
    if (E.nOf !== n) { E.of.textContent = '/ ' + n.toLocaleString(); E.nOf = n; }
    let dp = act && i <= 0, dn = act && i >= n - 1;
    if (k === 'shot' && act && V) { const L = segShotList(), q = L.indexOf(i); dp = q <= 0; dn = q < 0 || q >= L.length - 1; } // Group segments: the images' shots in turn
    if (E.prev.disabled !== dp) E.prev.disabled = dp;
    if (E.next.disabled !== dn) E.next.disabled = dn;
  }
}
function navGo(kind, idx) {
  const s = S.seq; if (!s || !(idx >= 0)) return;
  if (kind === 'block') { idx = Math.min(idx, s.nb - 1); selectBlock(idx, { kind: 'block' }); pushHist(); zoomToBlock(idx); }
  else if (kind === 'img') segFocusTo(idx);
  else gotoItem(kind, idx);
}
for (const k of ['block', 'shot', 'vol', 'img']) {
  const g = $('#nav-' + k), step = k === 'block' ? stepBlock : k === 'shot' ? stepShot : k === 'img' ? (d => { const V = segView(); if (V) segFocusTo(V.gi + d); }) : stepVol;
  g.querySelector('.prev').onclick = () => step(-1);
  g.querySelector('.next').onclick = () => step(1);
  const inp = g.querySelector('input');
  inp.onchange = () => navGo(k, parseInt(inp.value, 10) - 1);
  inp.onkeydown = e => { if (e.key === 'Enter') { inp.blur(); } if (e.key === 'Escape') { inp.blur(); updateNav(); } };
}
function fitAll() { if (segView()) { segFit(); return; } const T = S.seq.totalDur; setView(-0.008 * T, T * 1.008); }
function zoomAt(t, f) { setView(t - (t - S.t0) * f, t + (S.t1 - t) * f); }
function zoomToBlock(b) { const s = S.seq, a = tToV(s.blockStart[b]), d = tToV(s.blockStart[b + 1]) - a; if (!(d > 0) && segView()) return; setView(a - d * 0.08, a + d * 1.08); }
function selectBlock(b, opts = {}) {
  if (!S.seq) return;
  b = Math.max(0, Math.min(S.seq.nb - 1, b)); S.sel = b; S.selKind = opts.kind || 'block';
  if (S.selKind === 'shot' || S.selKind === 'vol') { const k = S.selKind === 'vol' ? volOfBlock(b) : shotOfBlock(b); S.selItems = opts.items || [k]; if (!opts.items) S.selAnchor = k; }
  else { S.selItems = []; S.selAnchor = -1; }
  if (opts.ensureVisible) { const s = S.seq, a = tToV(s.blockStart[b]), e = tToV(s.blockStart[b + 1]); if (a < S.t0 || e > S.t1) { const sp = S.t1 - S.t0; if (e - a > sp) zoomToBlock(b); else setView(a - (sp - (e - a)) / 2, a - (sp - (e - a)) / 2 + sp); } }
  renderBlock(); if (opts.tab && S.tab !== 'k' && S.tab !== 'img') setTab('blk'); request(); if (S.kRange === 'shot' || S.kRange === 'vol') requestK(); requestImg();
}

/* ---------- plot interaction ---------- */
const ptrs = new Map(); let drag = null;
ovl.addEventListener('pointerdown', e => {
  if (!S.seq) return; ovlStale();
  if (e.button === 0 && !ptrs.size) { const k = yzCrossAt(pX(e), pY(e)); if (k) { delete S.yZoom[k]; ovl.style.cursor = ''; e.preventDefault(); request(); return; } } // the y-zoom tag's reset cross
  ovl.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: pX(e), y: pY(e) });
  if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; drag = { pinch: true, d0: Math.abs(a.x - b.x) || 1, t0: S.t0, t1: S.t1, cx: xToV((a.x + b.x) / 2) }; return; }
  if (e.button === 1 || e.button === 2) e.preventDefault();
  // mouse: left-drag selects a range to zoom into; right-drag (or Shift/middle-drag) pans. Touch and pen: drag pans.
  const pan = e.pointerType !== 'mouse' || e.shiftKey || e.button === 1 || e.button === 2;
  drag = { x: pX(e), y: pY(e), t0: S.t0, t1: S.t1, moved: false, box: !pan, button: e.button };
});
ovl.addEventListener('pointermove', e => {
  if (!S.seq) return;
  if (ptrs.has(e.pointerId)) ptrs.set(e.pointerId, { x: pX(e), y: pY(e) });
  if (drag && drag.pinch && ptrs.size === 2) {
    const [a, b] = [...ptrs.values()]; const d = Math.abs(a.x - b.x) || 1, f = drag.d0 / d;
    const c = drag.cx; setView(c - (c - drag.t0) * f, c + (drag.t1 - c) * f); return;
  }
  if (drag && !drag.pinch) {
    const dx = pX(e) - drag.x;
    if (Math.abs(dx) > 3 || Math.abs(pY(e) - drag.y) > 3) drag.moved = true;
    if (drag.box) { if (drag.moved) { boxSel = { a: Math.max(GUT, drag.x), b: Math.min(W - 8, Math.max(GUT, pX(e))) }; requestOverlay(); } }
    else if (drag.moved) { ovl.classList.add('grabbing'); const dt = dx / (W - GUT - 8) * (drag.t1 - drag.t0); setView(drag.t0 - dt, drag.t1 - dt); }
  }
  S.hoverY = e.pointerType === 'mouse' ? pY(e) : null;
  if (e.pointerType === 'mouse') { const c = !drag && yzCrossAt(pX(e), pY(e)) ? 'pointer' : ''; if (ovl.style.cursor !== c) ovl.style.cursor = c; }
  if (e.pointerType === 'mouse' || !drag) { hoverAt(pX(e)); requestOverlay(); linkSendHover(); }
});
function endPtr(e) {
  ptrs.delete(e.pointerId); ovl.classList.remove('grabbing');
  if (!drag) return;
  if (drag.pinch) { if (ptrs.size === 0) drag = null; return; }
  if (drag.box && boxSel) {
    const a = Math.min(boxSel.a, boxSel.b), b = Math.max(boxSel.a, boxSel.b); boxSel = null;
    if (b - a > 6) { pushHist(); setView(xToV(a), xToV(b)); } else requestOverlay();
  } else if (!drag.moved && e.type === 'pointerup' && pX(e) > GUT && !drag.button) {
    const t = xToT(pX(e)); hoverAt(pX(e));
    const y = pY(e);
    if (t == null) { boxSel = null; drag = null; return; } // a box of left-out time (Group segments)
    if (volsOn() && y >= volY() - 2 && y < volY() + SHOTH + 2) clickItem('vol', volAt(t), e); // double-click zooms (below)
    else if (shotsOn() && y >= shotY() - 2 && y < shotY() + SHOTH + 2) clickItem('shot', shotAt(t), e);
    else if (y >= topH() - 4) selectBlock(blockAt(t), { tab: true });
  }
  boxSel = null;
  drag = null;
}
ovl.addEventListener('pointerup', endPtr); ovl.addEventListener('pointercancel', endPtr);
ovl.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') { S.hoverY = null; requestOverlay(); } if (e.pointerType === 'mouse' && !drag) { S.hoverT = null; S.hoverGap = null; requestOverlay(); linkSendHover(); } });
ovl.addEventListener('dblclick', e => {
  if (S.seq && pX(e) <= GUT) { // double-click on a lane's name: reset its y zoom
    const L = laneAtY(pY(e)); if (L && S.yZoom[L.key]) { delete S.yZoom[L.key]; request(); } return;
  }
  if (!S.seq || pX(e) <= GUT || e.ctrlKey || e.metaKey || e.shiftKey) return;
  const t = xToT(pX(e)), y = pY(e); if (t == null) return;
  if (volsOn() && y >= volY() - 2 && y < volY() + SHOTH + 2) zoomToVol(volAt(t));
  else if (shotsOn() && y >= shotY() - 2 && y < shotY() + SHOTH + 2) zoomToShot(shotAt(t));
  else if (y >= topH() - 4) { const b = blockAt(t); selectBlock(b); pushHist(); zoomToBlock(b); }
});
ovl.addEventListener('auxclick', e => { if (e.button === 1) e.preventDefault(); });
ovl.addEventListener('contextmenu', e => e.preventDefault()); // right-drag pans the diagram
/* the Ctrl key as actually held: a touchpad pinch also sends wheel events with ctrlKey set, but without a key press, and
   keeps zooming time (faster); Ctrl + wheel with the key held zooms the lane under the mouse in y */
let ctrlHeld = false;
document.addEventListener('keydown', e => { if (e.key === 'Control') ctrlHeld = true; }, true);
document.addEventListener('keyup', e => { if (e.key === 'Control') ctrlHeld = false; }, true);
window.addEventListener('blur', () => { ctrlHeld = false; });
function segReadout(k) { // Group segments: the image and segment of the shot under the cursor
  const V = segView(); if (!V || k < 0) return '';
  const R = segGroups(), gi = R.of[k]; if (gi < 0) return '';
  const tr = S.seq.labels.find(x => x.name === 'SEG'), sh = S.seq.shots[k], b = S.seq.adcBlocks[sh.j0];
  let i = ub(tr.b, b) - 1, seg = i >= 0 ? tr.v[i] : 0;
  return `<span>image <b>${gi + 1}</b><span class="muted"> / ${R.groups.length}</span> · SEG <b>${seg}</b></span>`;
}
function hoverAt(x) { const t = xToT(x); S.hoverT = t; S.hoverGap = t == null ? segGapAt(x) : null; }
function laneAtY(y) { return lanesGeom().find(l => y >= l.y && y < l.y + l.h); }
/* multiply the y zoom of the lane at y by f (false if there is no zoomable lane there) */
function yZoomBy(y, f) {
  const L = laneAtY(y); if (!L || !yZoomable(L.key)) return false;
  let z = Math.min(YZ_MAX, Math.max(YZ_MIN, (S.yZoom[L.key] || 1) * f)); if (Math.abs(Math.log(z)) < 0.03) z = 1; // snaps back to 1 on the way through
  if (z === 1) delete S.yZoom[L.key]; else S.yZoom[L.key] = z;
  request(); return true;
}
ovl.addEventListener('wheel', e => {
  if (!S.seq) return; e.preventDefault();
  const pw = W - GUT - 8;
  const dx = e.deltaMode === 1 ? e.deltaX * 16 : e.deltaX, dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
  // y zoom of the lane under the mouse: Ctrl + wheel with the key held, or a touchpad pinch (wheel with ctrlKey, no key)
  // over the lane's name in the left margin, which zooms faster like a pinch over the plot does in time
  if (e.ctrlKey && (ctrlHeld || pX(e) <= GUT)) { if (dy) yZoomBy(pY(e), Math.exp(-dy * (ctrlHeld ? 0.0022 : 0.012))); return; }
  if (e.shiftKey || Math.abs(dx) > Math.abs(dy)) { const d = (e.shiftKey ? dy || dx : dx) / pw * (S.t1 - S.t0); setView(S.t0 + d, S.t1 + d); }
  else zoomAt(xToV(pX(e)), Math.exp(dy * (e.ctrlKey ? 0.012 : 0.0022)));
  hoverAt(pX(e));
}, { passive: false });

/* Safari (macOS) sends a touchpad pinch as gesture events with a running scale instead of Ctrl + wheel, and otherwise
   zooms the whole page: over the plot it zooms time, over a lane's name y, as the pinch in other browsers */
let gest = null;
ovl.addEventListener('gesturestart', e => { if (!S.seq) return; e.preventDefault(); const r = ovl.getBoundingClientRect(); gest = { x: e.clientX - r.left, y: e.clientY - r.top, s: 1 }; });
ovl.addEventListener('gesturechange', e => {
  if (!S.seq || !gest) return; e.preventDefault();
  const f = e.scale / gest.s; gest.s = e.scale; if (!(f > 0) || f === 1) return;
  if (gest.x <= GUT) yZoomBy(gest.y, f); else zoomAt(xToV(gest.x), 1 / f);
});
ovl.addEventListener('gestureend', e => { e.preventDefault(); gest = null; });

/* overview interaction */
let ovDrag = null;
ov.addEventListener('pointerdown', e => {
  if (!S.seq) return; ov.setPointerCapture(e.pointerId);
  const T = S.seq.totalDur, t = e.offsetX / OW * T;
  if (segView()) { const v = tToV(t), sp = S.t1 - S.t0; setView(v - sp / 2, v + sp / 2); ovDrag = { seg: true }; return; } // Group segments: centre on the shown time nearest t
  if (t < S.t0 || t > S.t1) { const sp = S.t1 - S.t0; setView(t - sp / 2, t + sp / 2); }
  ovDrag = { x: e.clientX, t0: S.t0, t1: S.t1 };
});
ov.addEventListener('pointermove', e => { if (!ovDrag) return; if (ovDrag.seg) { const v = tToV(e.offsetX / OW * S.seq.totalDur), sp = S.t1 - S.t0; setView(v - sp / 2, v + sp / 2); return; } const dt = (e.clientX - ovDrag.x) / OW * S.seq.totalDur; setView(ovDrag.t0 + dt, ovDrag.t1 + dt); });
ov.addEventListener('pointerup', () => ovDrag = null); ov.addEventListener('pointercancel', () => ovDrag = null);
ov.addEventListener('wheel', e => { if (!S.seq) return; e.preventDefault(); zoomAt((S.t0 + S.t1) / 2, Math.exp(e.deltaY * 0.0022)); }, { passive: false });

/* keyboard */
document.addEventListener('keydown', e => {
  if (!S.seq || e.target.closest('input,select,textarea,.popbody') || e.metaKey || e.ctrlKey || e.altKey) return;
  const sp = S.t1 - S.t0, c = (S.t0 + S.t1) / 2; let hit = true;
  switch (e.key) {
    case 'ArrowLeft': case 'ArrowRight': {
      const d = e.key === 'ArrowLeft' ? -1 : 1;
      if (S.sel >= 0 && S.selKind === 'block') stepBlock(d);
      else if (S.sel >= 0 && S.selKind === 'shot') stepShot(d);
      else if (S.sel >= 0 && S.selKind === 'vol') stepVol(d);
      else setView(S.t0 + d * sp * 0.2, S.t1 + d * sp * 0.2);
      break;
    }
    case '+': case '=': case 'ArrowUp': zoomAt(c, 0.7); break;
    case '-': case '_': case 'ArrowDown': zoomAt(c, 1 / 0.7); break;
    case 'f': case '0': case 'Home': fitAll(); break;
    case ']': if (S.sel < 0) selectBlock(blockAt(vToT(S.t0)), { ensureVisible: true }); else stepBlock(1); break;
    case '[': if (S.sel < 0) selectBlock(blockAt(vToT(S.t0)), { ensureVisible: true }); else stepBlock(-1); break;
    case 'Escape': S.sel = -1; S.selKind = null; S.selItems = []; S.selAnchor = -1; renderBlock(); request(); requestImg(); break;
    case ';': stepVol(-1); break;
    case "'": stepVol(1); break;
    case ',': stepShot(-1); break;
    case '.': stepShot(1); break;
    case 'Backspace': case 'b': back(); break;
    case 'r': if (SRC && (SRC.handle || SRC.file)) reloadFile(); else hit = false; break;
    case 'D': diagToggle(); break;
    case '\\': setSide(!S.sideHidden); scheduleSave(); break;
    default: hit = false;
  }
  if (hit) e.preventDefault();
});

/* ---------- toolbar ---------- */
// chips grouped by kind of channel in the Display panel (RF; gradients, then slew and k-vector; concomitant; readout; stimulation), with short labels
const CHIP_GROUP = { rfMag: 'rf', rfPh: 'rf', gx: 'g', gy: 'g', gz: 'g', slew: 'g2', m0: 'g2', gc: 'cc', kc: 'cc', kt: 'cc', mu: 'cc', adc: 'acq', labels: 'acq', pns: 'stim', cns: 'stim' };
const CHIP_LABEL = { rfMag: '|B1|', rfPh: 'Phase', mu: 'μ' };
function buildChips() {
  for (const el of document.querySelectorAll('#dispPop .chips[data-group]')) el.innerHTML = '';
  for (const L of LANES) {
    const el = document.querySelector(`#dispPop .chips[data-group="${CHIP_GROUP[L.key] || 'acq'}"]`);
    const b = document.createElement('button'); b.className = 'chip'; b.type = 'button';
    b.style.setProperty('--c', L.key === 'slew' || L.key === 'labels' || L.key === 'm0' || L.key === 'gc' || L.key === 'kc' || L.key === 'kt' || L.key === 'mu' ? 'var(--ink)' : L.stim ? 'var(--muted)' : `var(--c-${L.col})`);
    if (L.key === 'm0') b.title = 'k-vector (the zeroth gradient moment): reset at each excitation, sign flipped at each refocusing pulse, faded after the last readout';
    if (L.key === 'gc') { b.title = 'Concomitant gradients: the extra gradient seen by spins at the position set under Concomitant › Settings…'; b.setAttribute('aria-label', 'Concomitant gradients'); }
    if (L.key === 'kc') { b.title = 'Zeroth moment of the concomitant gradients (k-space shift at the position set under Concomitant › Settings…): reset at each excitation, sign flipped at each refocusing pulse'; b.setAttribute('aria-label', 'Concomitant k-space shift'); }
    if (L.key === 'kt') { b.title = 'Total dephasing vector k + kc: the k-vector plus the concomitant k-space shift at the position set under Concomitant › Settings…; reset at each excitation, sign flipped at each refocusing pulse'; b.setAttribute('aria-label', 'Total dephasing vector k plus kc'); }
    if (L.key === 'mu') b.title = 'Generalized Maxwell index μ = (γ/B0)|∫g⊗g h dt| (1/m², Frobenius norm, γ = 42.58 MHz/T, B0 from Concomitant › Settings…): reset at each excitation, h flips at each refocusing pulse';
    if (L.stim) b.title = L.stim === 'pns' ? 'Peripheral nerve stimulation (SAFE model)' : 'Cardiac nerve stimulation (SAFE model)';
    b.setAttribute('aria-pressed', S.vis[L.key]); b.innerHTML = `<span class="sw"></span>${CHIP_LABEL[L.key] || L.label}`; if (CHIP_LABEL[L.key]) b.setAttribute('aria-label', L.key === 'mu' ? 'Generalized Maxwell index' : L.label);
    b.onclick = () => {
      S.vis[L.key] = !S.vis[L.key]; if (!LANES.some(l => S.vis[l.key])) S.vis[L.key] = true; if (L.key === 'labels') S.labelsPref = S.vis.labels; b.setAttribute('aria-pressed', S.vis[L.key]);
      if (L.stim && S.vis[L.key] && !stimHasModel(L.stim)) openSafeDialog();
      request();
      if ((L.key === 'gc' || L.key === 'kc' || L.key === 'kt') && S.seq) { renderSeqInfo(); renderBlock(); } // their rows in the side panel
    };
    el.appendChild(b);
  }
  buildEchoChips();
}
buildChips();
$('#echoZoom').onchange = e => { S.echo.zoom = e.target.checked; scheduleSave(); request(); };
$('#gUnit').onchange = e => { S.gUnit = e.target.value; request(); renderSeqInfo(); renderBlock(); };
$('#rfUnit').onchange = e => { S.rfUnit = e.target.value; request(); renderSeqInfo(); renderBlock(); };
$('#rfMode').onchange = e => { S.rfMode = e.target.value; request(); };
$('#autoY').onchange = e => { S.autoY = e.target.checked; request(); };
$('#pauseHatch').onchange = e => { S.pauseHatch = e.target.checked; request(); };
$('#diagRes').onchange = e => { S.diagRes = e.target.value; resize(); };
/* the side panel (tabs) can be hidden for a wider diagram (1.24.1): button in the toolbar, or the \ key; remembered */
function setSide(hidden) {
  S.sideHidden = !!hidden; document.querySelector('.app').classList.toggle('noside', S.sideHidden);
  const b = $('#sideBtn'); b.setAttribute('aria-pressed', S.sideHidden); const t = S.sideHidden ? 'Show the side panel' : 'Hide the side panel, for a wider diagram';
  b.setAttribute('aria-label', t); b.title = t + ' (\\)';
  if (!S.sideHidden) { if (S.tab === 'img') requestImg(); if (S.tab === 'k') requestK(); } // what was skipped while hidden
}
$('#sideBtn').onclick = () => { setSide(!S.sideHidden); scheduleSave(); };
$('#lineMode').onchange = e => { S.lineMode = e.target.value; ovCache = null; request(); };
$('#fitBtn').onclick = () => { if (S.seq) { pushHist(); fitAll(); } };
$('#backBtn').onclick = () => S.seq && back();
$('#combG').onchange = e => { S.combineG = e.target.checked; request(); };
$('#shotSel').onchange = e => { S.shotMode = e.target.value; if (S.seq) { applyShots(); applyVols(); segRegroup(); renderSeqInfo(); renderBlock(); ovCache = null; request(); requestK(); } };
$('#volSel').onchange = e => { S.volMode = S.volPref = e.target.value; if (S.seq) { applyVols(); segRegroup(); renderSeqInfo(); renderBlock(); ovCache = null; request(); requestK(); } };
/* shots or volumes changed: the images are found again; Group segments goes off where none is left */
function segRegroup() { if (!S.segOn) { segUI(); return; } const R = segGroups(); if (!R.groups.length) { S.segOn = false; segUI(); segMsg(R.err); fitAll(); } else { S.segFocus = Math.min(S.segFocus, R.groups.length - 1); VMAP = null; S.hist = []; segFit(); } }
$('#segBtn').onclick = () => segToggle(!S.segOn);
function applyVols() {
  const s = S.seq; S.vols = []; S.volT0 = new Float64Array(0);
  if (S.volMode === 'off') return;
  const shots = s.shots.length ? s.shots : (s.shotsExc || computeShots(s, 'exc'));
  if (!shots.length) return;
  let mode = 'auto', lab = null;
  if (S.volMode.startsWith('label:')) { mode = 'label'; lab = S.volMode.slice(6); }
  S.vols = s.vols0 && mode === 'auto' && S.shotMode === 'exc' ? s.vols0 : computeVolumes(s, shots, mode, lab);
  S.volT0 = Float64Array.from(S.vols.map(x => x.t0));
}
function fillVolMenu() {
  const sel = $('#volSel'), labs = labelNames(S.seq), cur = S.volPref; // a label rule is kept for files that have that label
  sel.innerHTML = '<option value="auto">Auto (repeated k-space)</option>' + labs.map(l => `<option value="label:${esc(l)}">Label ${esc(l)} changes</option>`).join('') + '<option value="off">Hidden</option>';
  S.volMode = [...sel.options].some(o => o.value === cur) ? cur : 'auto'; sel.value = S.volMode;
}
function applyShots() {
  const s = S.seq;
  s.shots = S.shotMode === 'off' ? [] : S.shotMode === 'exc' && s.shotsExc ? s.shotsExc : computeShots(s, S.shotMode);
  S.shotT0 = Float64Array.from(s.shots.map(x => x.t0));
}
$('#zoomIn').onclick = () => S.seq && zoomAt((S.t0 + S.t1) / 2, 0.6);
$('#zoomOut').onclick = () => S.seq && zoomAt((S.t0 + S.t1) / 2, 1 / 0.6);
$('#pngBtn').onclick = () => {
  if (!S.seq) return; const name = `${S.name.replace(/\.(seq|bin)$/i, '')}_diagram.png`;
  if (pdpr === dpr) { savePNG(plot, name); return; }
  PNG_FULL = true; resize(); render(); savePNG(plot, name); PNG_FULL = false; resize(); // always at the screen's density
};
$('#kPng').onclick = () => { if (kData) savePNG(kc, `${S.name.replace(/\.(seq|bin)$/i, '')}_kspace.png`); };
function savePNG(cv, name) {
  const foot = Math.round(18 * dpr), c = document.createElement('canvas'); c.width = cv.width; c.height = cv.height + foot; // footer strip for the stamp
  const x = c.getContext('2d'); x.fillStyle = C.plot; x.fillRect(0, 0, c.width, c.height); x.drawImage(cv, 0, 0);
  const stamp = `${APP.name} ${APP.version} · ${S.name} · ${new Date().toISOString().slice(0, 10)}`;
  x.font = `${Math.round(10 * dpr)}px ${C.font}`; x.textAlign = 'right'; x.textBaseline = 'bottom'; x.fillStyle = C.faint;
  x.fillText(stamp, c.width - 8 * dpr, c.height - 4 * dpr);
  x.fillStyle = C.line; x.fillRect(0, cv.height, c.width, Math.max(1, Math.round(dpr)));
  c.toBlob(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); });
}
/* ---------- Save figure…: a PNG at a chosen physical size, resolution and text size ----------
   The view is drawn again by its own code (render, drawK, drawImg) on its canvas, temporarily resized: text set in
   CSS px at 11 px, so a text size of p pt at d dpi is a pixel ratio r = (p·d/72)/11 output pixels per CSS px, and the
   layout is width/r CSS px wide. Lines, dots and marks scale with the text. EXP holds the options the drawing code
   reads (what to leave out); everything (sizes, theme, canvases) is restored afterwards. The PNG carries its
   resolution (pHYs chunk), so layout programs place it at the chosen size. */
const FIG_DEF = { what: 'diag', preset: '175', w: 175, h: 100, unit: 'mm', dpi: 600, pt: 8, lw: 0.75, font: 'arial', theme: '', bg: 'theme', combineG: true, fill: true,
  vols: true, shots: true, axis: true, names: true, yNums: true, blockNums: false, shade: true, sel: false, pause: false,
  kPath: true, kAxes: true, kRange: true, kLegend: true, kBoxes: true,
  imText: false, imDirs: true, imScout: false, imCrop: true, imSharp: false, stamp: false };
const FIG_FLAGS = ['combineG', 'fill', 'vols', 'shots', 'axis', 'names', 'yNums', 'blockNums', 'shade', 'sel', 'pause', 'kPath', 'kAxes', 'kRange', 'kLegend', 'kBoxes', 'imText', 'imDirs', 'imScout', 'imCrop', 'imSharp', 'stamp'];
const FIG_ID = k => 'fig' + k[0].toUpperCase() + k.slice(1);
let FIG = { ...FIG_DEF }, figLanes = null;
try { const o = JSON.parse(lsGet('fig') || 'null'); if (o && typeof o === 'object') for (const k in FIG_DEF) if (typeof o[k] === typeof FIG_DEF[k]) FIG[k] = o[k]; } catch (_) { }
const figSaveOpts = () => { try { localStorage.setItem('seqret-fig', JSON.stringify(FIG)); } catch (_) { } };
const FIG_MAX_SIDE = 16384, FIG_MAX_PX = 2.4e8; // browser canvas limits (Chromium: 16384 per side by default on some GPUs)
function figImgAspect() { // height / width of the cropped image
  const R = imgRes; if (!R || R.error || S.sim.view === 'k') return 1;
  const I = R.img, ax = I.fovX * imgCrop(I, 'x'), ay = I.fovY * imgCrop(I, 'y'); return ay / ax;
}
function figGeom() {
  const f = FIG.unit === 'in' ? 1 : 1 / 25.4, wIn = FIG.w * f;
  let hIn = FIG.h * f; if (FIG.what === 'k' || (FIG.what === 'img' && !FIG.imCrop)) hIn = wIn; else if (FIG.what === 'img') hIn = wIn * figImgAspect();
  const pxW = Math.round(wIn * FIG.dpi), pxH = Math.round(hIn * FIG.dpi), r = FIG.pt * FIG.dpi / 72 / 11;
  const cssW = pxW / r, cssH = pxH / r;
  let err = '';
  if (!(pxW > 0 && pxH > 0 && r > 0 && FIG.lw > 0)) err = 'Enter a size, resolution, text size and line width.';
  else if (Math.max(pxW, pxH) > FIG_MAX_SIDE || pxW * pxH > FIG_MAX_PX) err = `Too large for the browser (${pxW.toLocaleString()} × ${pxH.toLocaleString()} px; at most ${FIG_MAX_SIDE.toLocaleString()} per side): lower the resolution or the size.`;
  else if (FIG.what === 'diag' && (cssW < 260 || cssH < 120)) err = 'The text is too large for this size: the diagram would have no room. Use smaller text or a larger figure.';
  else if (FIG.what !== 'diag' && cssW < 120) err = 'The text is too large for this size. Use smaller text or a larger figure.';
  else if (FIG.what === 'img' && (!imgRes || imgRes.error)) err = 'No simulated image yet: open the Image tab first.';
  else if (!S.seq) err = 'No sequence loaded.';
  return { pxW, pxH, r, cssW, cssH, err };
}
function figSync() { // dialog from FIG
  segPress('#figWhat', FIG.what);
  $('#figPreset').value = FIG.preset; $('#figW').value = +FIG.w.toFixed(2); $('#figH').value = +FIG.h.toFixed(2); $('#figUnit').value = FIG.unit;
  $('#figDpi').value = FIG.dpi; $('#figPt').value = FIG.pt; $('#figLw').value = FIG.lw; $('#figFont').value = FIG.font; $('#figTheme').value = FIG.theme; $('#figBg').value = FIG.bg;
  for (const k of FIG_FLAGS) $('#' + FIG_ID(k)).checked = FIG[k];
  for (const sec of document.querySelectorAll('#figDlg .fsec')) sec.hidden = sec.dataset.for !== FIG.what;
  $('#figH').disabled = FIG.what !== 'diag';
  const L = $('#figLanes'); L.innerHTML = '';
  for (const l of LANES) {
    if (l.key === 'labels' && !(S.seq && (S.seq.labels.length || S.seq.triggers.length || S.seq.adcBlocks.length))) continue;
    const lab = document.createElement('label'); lab.className = 'chip tg';
    lab.innerHTML = `<input type="checkbox">${esc(CHIP_LABEL[l.key] || l.label)}`; const cb = lab.firstChild; cb.checked = !!figLanes[l.key];
    cb.onchange = () => { figLanes[l.key] = cb.checked; figUpdate(); }; L.append(lab);
  }
  figUpdate();
}
function figUpdate() { // the pixel size and any problem
  const g = figGeom(), note = $('#figNote');
  $('#figPx').textContent = g.pxW > 0 && g.pxH > 0 ? `${g.pxW.toLocaleString()} × ${g.pxH.toLocaleString()} px` : '';
  const anyLane = FIG.what !== 'diag' || LANES.some(l => figLanes[l.key]);
  note.textContent = g.err || (anyLane ? '' : 'Choose at least one lane.');
  $('#figSave').disabled = !!g.err || !anyLane;
  if (FIG.what === 'img' && FIG.imCrop) $('#figH').value = +(FIG.w * figImgAspect()).toFixed(2); else if (FIG.what !== 'diag') $('#figH').value = +FIG.w.toFixed(2);
}
function openFigDialog(what) {
  FIG.what = what || FIG.what; figLanes = { ...S.vis, labels: false }; // the lanes on screen, without the labels lane (it needs the height)
  figSync(); const d = $('#figDlg'); if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else d.setAttribute('open', '');
}
const figClose = () => { const d = $('#figDlg'); if (d.close) d.close(); else d.removeAttribute('open'); };
$('#figClose').onclick = $('#figCancel').onclick = figClose;
$('#figBtn').onclick = () => openFigDialog('diag');
$('#kFig').onclick = () => openFigDialog('k');
$('#imFig').onclick = () => openFigDialog('img');
$('#figWhat').querySelectorAll('button').forEach(b => b.onclick = () => { FIG.what = b.dataset.v; figSync(); });
$('#figPreset').onchange = e => {
  const v = e.target.value; FIG.preset = v; if (!v) return figUpdate();
  const toU = mm => FIG.unit === 'in' ? mm / 25.4 : mm;
  if (v === 'slide') { FIG.w = toU(254); FIG.h = toU(143); } else { const r = FIG.h / FIG.w; FIG.w = toU(+v); FIG.h = FIG.w * (r > 0 ? r : 0.57); }
  figSync();
};
$('#figUnit').onchange = e => { const u = e.target.value; if (u !== FIG.unit) { const f = u === 'in' ? 1 / 25.4 : 25.4; FIG.w *= f; FIG.h *= f; FIG.unit = u; } figSync(); };
for (const [id, k] of [['#figW', 'w'], ['#figH', 'h'], ['#figDpi', 'dpi'], ['#figPt', 'pt'], ['#figLw', 'lw']]) $(id).oninput = e => { FIG[k] = +e.target.value; if (k === 'w' || k === 'h') { FIG.preset = ''; $('#figPreset').value = ''; } figUpdate(); };
$('#figTheme').onchange = e => { FIG.theme = e.target.value; };
$('#figFont').onchange = e => { FIG.font = e.target.value; };
$('#figBg').onchange = e => { FIG.bg = e.target.value; };
for (const k of FIG_FLAGS) $('#' + FIG_ID(k)).onchange = e => { FIG[k] = e.target.checked; figUpdate(); };
$('#figSave').onclick = () => { const g = figGeom(); if (g.err) return; figSaveOpts(); figClose(); setTimeout(() => figExport(g), 30); };
/* draw the figure and save it */
function figExport(g) {
  const root = document.documentElement, theme0 = root.dataset.theme, o = FIG, what = o.what;
  if (o.theme) { root.dataset.theme = o.theme; readColors(); }
  const FONTS = { arial: 'Arial, "Liberation Sans", Helvetica, sans-serif', helvetica: 'Helvetica, Arial, "Liberation Sans", sans-serif', times: '"Times New Roman", Times, "Liberation Serif", serif' };
  if (FONTS[o.font]) C.font = FONTS[o.font];
  EXP = { ...o, lwCss: o.lw * 11 / o.pt }; let src = null, rect = null; // line width in pt → CSS px of the layout
  const sv = { W, H, pdpr, dpr, GUT, AXH, vis: S.vis, KW, IW, kTraj: S.kTraj, kFast, kBusy: kData_busy, tab: S.tab };
  try {
    if (what === 'diag') {
      S.vis = { ...figLanes }; AXH = o.axis ? 40 : 6; W = g.cssW; H = g.cssH; // (lane heights for the gutter)
      { // the gutter: the widest lane name or unit, then the tick values
        pctx.font = `600 12px ${C.font}`; let nw = 0; for (const L of lanesGeom()) nw = Math.max(nw, pctx.measureText(L.label).width);
        const MULTI = new Set(['slew', 'g', 'm0', 'gc', 'kc', 'kt']); // lanes with an x y z legend, which may follow the unit
        pctx.font = `400 10.5px ${C.font}`; for (const L of lanesGeom()) nw = Math.max(nw, pctx.measureText(laneUnit(L.key)).width + (MULTI.has(L.key) && o.names && L.h > 30 && L.h <= 80 ? 8 + 36 : 0));
        const tw = pctx.measureText('−000.0').width;
        GUT = Math.ceil(o.names ? 16 + nw + 10 + (o.yNums ? tw + 8 : 0) : o.yNums ? tw + 12 : 6);
      }
      pdpr = g.r; sizeCanvas(plot, pctx, W, H, g.r);
      /* lane names and value ranges are left out by what they are: names, units, legends and strip titles are
         left-aligned text starting within the screen's gutter (x < 84, also where the figure's gutter is narrower),
         with the colour bars at x = 8; ranges are right-aligned text ending at the plot (x < GUT); the time axis
         below is neither */
      const ft = pctx.fillText, fr = pctx.fillRect, bot = H - AXH;
      pctx.fillText = function (t, x, y, mw) {
        if (y < bot && (this.textAlign === 'right' ? x < GUT && !o.yNums : this.textAlign === 'left' && x < Math.max(84, GUT) && !o.names)) return;
        return mw === undefined ? ft.call(this, t, x, y) : ft.call(this, t, x, y, mw);
      };
      pctx.fillRect = function (x, y, w, h) { if (x === 8 && w === 3) return; return fr.call(this, x, y, w, h); }; // no colour bars in a figure
      try { render(); } finally { delete pctx.fillText; delete pctx.fillRect; }
      src = plot;
    } else if (what === 'k') {
      S.kTraj = o.kPath; kFast = false; kData_busy = true; S.tab = 'k'; // computed here and now, whatever the tab
      KW = g.cssW; dpr = g.r; sizeCanvas(kc, kctx, KW, KW, g.r); kKey = null; drawK(); src = kc;
    } else {
      IW = g.cssW; sizeCanvas(ic, ictx, IW, IW, g.r); drawImg(); src = ic;
      if (o.imCrop && EXP.imRect) { const [x, y, w, h] = EXP.imRect.map(v => v * g.r); rect = [Math.round(x), Math.round(y), Math.round(w), Math.round(h)]; }
    }
    if (!rect) rect = [0, 0, src.width, src.height];
    const ptPx = o.pt * o.dpi / 72, foot = o.stamp ? Math.round(ptPx * 1.6) : 0, c = document.createElement('canvas');
    c.width = rect[2]; c.height = rect[3] + foot; const x = c.getContext('2d');
    if (o.bg !== 'none') { x.fillStyle = o.bg === 'white' ? '#FFFFFF' : C.plot; x.fillRect(0, 0, c.width, c.height); }
    x.drawImage(src, rect[0], rect[1], rect[2], rect[3], 0, 0, rect[2], rect[3]);
    if (o.stamp) {
      x.font = `${Math.round(ptPx * 0.8)}px ${C.font}`; x.textAlign = 'right'; x.textBaseline = 'middle'; x.fillStyle = C.faint;
      x.fillText(`${APP.name} ${APP.version} · ${S.name} · ${new Date().toISOString().slice(0, 10)}`, c.width - ptPx * 0.5, rect[3] + foot / 2);
    }
    const unit = o.unit === 'in' ? 'in' : 'mm', name = `${S.name.replace(/\.(seq|bin)$/i, '')}_${{ diag: 'diagram', k: 'kspace', img: 'image' }[what]}_${+o.w.toFixed(1)}${unit}_${o.dpi}dpi.png`;
    c.toBlob(b => b && pngWithDpi(b, o.dpi).then(b2 => { const a = document.createElement('a'); a.href = URL.createObjectURL(b2); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); }));
  } catch (e) { console.error(e); setTimeout(() => { openFigDialog(what); $('#figNote').textContent = `Could not make the figure: ${e.message}`; }, 50); }
  finally {
    EXP = null; Object.assign(S, { vis: sv.vis, kTraj: sv.kTraj, tab: sv.tab }); GUT = sv.GUT; AXH = sv.AXH; KW = sv.KW; IW = sv.IW; dpr = sv.dpr; kFast = sv.kFast; kData_busy = sv.kBusy;
    if (o.theme) { if (theme0) root.dataset.theme = theme0; else delete root.dataset.theme; }
    if (IW > 0) sizeCanvas(ic, ictx, IW, IW);
    themeChanged(); resize(); // back to the screen: sizes, colours, every view drawn again
  }
}
/* the PNG with its resolution: a pHYs chunk (pixels per metre) after IHDR */
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(u8) { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC_T[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
async function pngWithDpi(blob, dpi) {
  const u = new Uint8Array(await blob.arrayBuffer()), ppm = Math.round(dpi / 0.0254);
  const ch = new Uint8Array(21), dv = new DataView(ch.buffer);
  dv.setUint32(0, 9); ch.set([112, 72, 89, 115], 4); dv.setUint32(8, ppm); dv.setUint32(12, ppm); ch[16] = 1; dv.setUint32(17, crc32(ch.subarray(4, 17)));
  const at = 8 + 25; // signature, then IHDR (4 length + 4 type + 13 data + 4 CRC)
  const out = new Uint8Array(u.length + 21); out.set(u.subarray(0, at)); out.set(ch, at); out.set(u.subarray(at), at + 21);
  return new Blob([out], { type: 'image/png' });
}
// themes: light, dark, redz ('graphite' in 1.34.1), paper, universal, forest (style.css); without a choice, light or dark as the system is set
$('#themeSeg').querySelectorAll('button').forEach(b => b.onclick = () => {
  document.documentElement.dataset.theme = b.dataset.v;
  try { localStorage.setItem('seqret-theme', b.dataset.v); } catch (_) { }
  themeChanged(); themeLabel();
});
/* storage keys were 'seqview-*' before the rename to Seqret (1.12.0): read the old key when the new one is absent */
function lsGet(k) { try { const v = localStorage.getItem('seqret-' + k); return v !== null ? v : localStorage.getItem('seqview-' + k); } catch (_) { return null; } }
try { const t = lsGet('theme'); if (['light', 'dark', 'redz', 'graphite', 'paper', 'universal', 'forest'].includes(t)) document.documentElement.dataset.theme = t === 'graphite' ? 'redz' : t; } catch (_) { }
function themeLabel() { const t = document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); segPress('#themeSeg', t); }
themeLabel(); matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeLabel);
function themeChanged() { readColors(); ovCache = null; kInvalidate(); request(); drawK(); drawImg(); }
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeChanged);

/* tabs */
function setTab(t) {
  S.tab = t;
  document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === t));
  for (const p of ['seq', 'blk', 'k', 'img', 'defs']) $('#p-' + p).hidden = p !== t;
  if (t === 'k') { resize(); requestK(); }
  if (t === 'img') { resize(); requestImg(); }
}
document.querySelectorAll('.tab').forEach(b => b.onclick = () => setTab(b.dataset.tab));

/* ---------- side panels ---------- */
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const kv = rows => `<dl class="kv">${rows.filter(Boolean).map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>`;
/* b-tensor of a shot (shotBTensor in core.js): excitation to the echo, all gradients, scanner x, y, z, in ms/µm² */
/* peak gradient amplitude and slew per physical axis over blocks b0..b1, each a link to the first block that reaches it */
function peakRows(b0, b1, what) {
  const s = S.seq, B = s.B, G = [B.pgx, B.pgy, B.pgz], key = b0 + '-' + b1;
  const memo = s.peakMemo || (s.peakMemo = new Map());
  let P = memo.get(key);
  if (!P) {
    P = { g: [0, 0, 0], s: [0, 0, 0], gb: [-1, -1, -1], sb: [-1, -1, -1] };
    for (let i = b0; i <= b1; i++) for (let a = 0; a < 3; a++) {
      const id = G[a][i]; if (!id) continue;
      const g = geoG(s, id), ss = slewSum(s, id), pg = Math.max(Math.abs(g.min), Math.abs(g.max)), ps = Math.max(Math.abs(ss.min), Math.abs(ss.max));
      if (pg > P.g[a]) { P.g[a] = pg; P.gb[a] = i; } if (ps > P.s[a]) { P.s[a] = ps; P.sb[a] = i; }
    }
    if (memo.size > 64) memo.clear(); memo.set(key, P);
  }
  const lnk = (txt, b, a, q) => b >= 0 ? `<button class="btn link" data-peak-b="${b}" title="Go to block ${B.id[b]}, the first in this ${what} with the peak G${a} ${q}">${txt}</button>` : txt;
  return ['x', 'y', 'z'].map((a, i) => [`G${a} amplitude / slew`, `${lnk(fmt(P.g[i] * gF(), 4), P.gb[i], a, 'amplitude')} / ${lnk(fmt(P.s[i] * sF(), 4), P.sb[i], a, 'slew')}`]);
}
const peakHTML = (b0, b1, what) => `<div class="kvsub muted" style="margin-top:6px">Gradient peaks (${gU()}, ${sU()})</div>` + kv(peakRows(b0, b1, what));
function bTensorRows(sk) {
  const s = S.seq; let r = null;
  try { r = shotBTensor(s, s.shots, sk); } catch (e) { console.warn('b-tensor', e); }
  const tip = 'B = (2π)² ∫ k kᵀ dt from the excitation to the echo (the readout sample nearest k = 0 in the first echo), with k mirrored at each refocusing pulse. All gradients count (diffusion, imaging, crushers). Scanner axes x, y, z.';
  const lab = t => `<span title="${esc(tip)}">${t}</span>`;
  if (!r) return [[lab('b-tensor'), '<span class="muted">no excitation or no readout after it</span>']];
  const f = v => { const x = v * 1e-9; return (Math.abs(x) < 5e-5 ? 0 : x).toFixed(4); }, U = '<span class="muted">ms/µm²</span>', M = r.M;
  const mat = `<table class="btm"><thead><tr><th>ms/µm²</th><th>x</th><th>y</th><th>z</th></tr></thead><tbody>` +
    ['x', 'y', 'z'].map((a, i) => `<tr><th>${a}</th>${[0, 1, 2].map(j => `<td>${f(M[3 * i + j])}</td>`).join('')}</tr>`).join('') + `</tbody></table>`;
  const echo = `${fmtT(r.tEcho - r.tE)} after the excitation${r.nEcho > 1 ? ` <span class="muted">(first of ${r.nEcho} echoes)</span>` : ''}${r.kind === 'reference' ? ' <span class="muted">(reference readout)</span>' : ''}`;
  return [[lab('b-value'), `${f(r.b)} ${U}`], [lab('b-tensor'), mat], [lab('Eigenvalues'), `${r.eig.map(f).join(', ')} ${U}`], [lab('Echo'), echo]];
}
function renderSeqInfo() {
  const s = S.seq, el = $('#p-seq');
  if (!s) { el.innerHTML = '<p class="note">No sequence loaded.</p>'; return; }
  const st = s.stats, v = s.version, d = s.defs;
  const [sigCls, sigTxt] = s.sig.status === 'ok' ? ['ok', 'md5 verified'] : s.sig.status === 'mismatch' ? ['bad', 'md5 mismatch'] : s.sig.status === 'unsupported' ? ['mut', `${esc(s.sig.type)} not checked`] : ['mut', 'not signed'];
  const sigHash = s.signature && s.signature.hash ? String(s.signature.hash).toLowerCase() : null; // clicking the badge shows the full hash and copies it (1.47.0)
  const sig = sigHash ? `<button class="badge ${sigCls}" id="sigBtn" title="Show the full ${esc(s.signature.type || 'signature')} hash and copy it">${sigTxt}</button><div class="sighash" id="sigHash" hidden>${esc(sigHash)}${s.sig.status === 'mismatch' && s.sig.hash ? `<br><span class="muted">computed:</span> ${esc(s.sig.hash)}` : ''} <span class="muted" id="sigMsg"></span></div>` : `<span class="badge ${sigCls}">${sigTxt}</span>`;
  const fdate = SRC && SRC.mod ? new Date(SRC.mod) : null;
  const uses = s.stats.uses;
  const guessed = s.verNum < 1005000;
  const fov = Array.isArray(d.FOV) ? d.FOV.map(x => fmt(x * 1e3, 4)).join(' × ') + ' mm' : null;
  el.innerHTML =
    `<h3>${esc(d.Name || S.name)}</h3>` +
    kv([['Pulseq format', `${v.major}.${v.minor}.${v.revision} <a href="${PULSEQ_WEB}" target="_blank" rel="noopener" title="Pulseq website">ⓘ</a>`], fdate ? ['Written', `<span title="When the file was written: its modification time on disk. Pulseq files store no creation date, and browsers do not report a file's creation time.">${fmtDate(fdate)}</span>`] : null, ['Signature', sig], ['Duration', fmtT(s.totalDur)],
      d.TotalDuration != null && Math.abs(d.TotalDuration - s.totalDur) > 1e-6 ? ['Declared duration', `<span style="color:var(--warn)">${fmtT(d.TotalDuration)}</span>`] : null,
      ['Blocks', s.nb.toLocaleString()], fov ? ['FOV', fov] : null,
      s.rot && s.rot.blocks ? ['Rotations', `${s.rot.blocks.toLocaleString()} blocks rotated (${s.rot.distinct} distinct, up to ${fmt(s.rot.maxAngle * 180 / Math.PI, 3)}°); gradients and k-space are shown rotated`] : null]) +
    `<h3>Events</h3>` +
    kv([['RF pulses', st.nRF.toLocaleString()], ...Object.entries(uses).map(([u, n]) => [`&nbsp;&nbsp;${USE[u] || u}${guessed && (u === 'e' || u === 'r') ? '*' : ''}`, n.toLocaleString()]),
      ['ADC events', st.nADC.toLocaleString()],
      ...(s.adcTypeCounts.slice(1).some(Boolean) ? s.adcTypeCounts.map((n, i) => n ? [`&nbsp;&nbsp;<span style="color:var(--c-${TYPE_COL[i]})">■</span> ${TYPE_NAME[i]}`, n.toLocaleString()] : null) : []),
      ['ADC samples', st.nSamples.toLocaleString()],
      ['Unique RF / grad / ADC', `${s.rf.size} / ${s.grad.size} / ${s.adc.size}`], ['Shapes', s.shapes.size]]) +
    (guessed && st.nRF ? '<p class="note">* Format before 1.5 does not store the pulse purpose. It is inferred from the flip angle (≤ 90° excitation, otherwise refocusing), as Pulseq does, and then corrected by context: a pulse followed by no readout before the next excitation is a preparation pulse (inversion near 180°, otherwise saturation; an off-resonant pulse without a gradient is a saturation pulse).</p>' : '') +
    volsHTML() + shotsHTML() +
    `<h3>Gradient peaks <span class="tag">${gU()}, ${sU()}</span></h3>` +
    kv(['x', 'y', 'z'].map((a, i) => { // each value jumps to the first block that reaches it
      const lnk = (txt, b, what) => b >= 0 && st.maxGBlock ? `<button class="btn link" data-peak-b="${b}" title="Go to block ${s.B.id[b]}, the first with the peak G${a} ${what}">${txt}</button>` : txt;
      return [`G${a} amplitude / slew`, `${lnk(fmt(st.maxG[i] * gF(), 4), st.maxGBlock ? st.maxGBlock[i] : -1, 'amplitude')} / ${lnk(fmt(st.maxSlew[i] * sF(), 4), st.maxSlewBlock ? st.maxSlewBlock[i] : -1, 'slew')}`]; })) +
    ccSummaryHTML() + stimSummaryHTML() +
    `<h3>Rasters</h3>` +
    kv([['Gradient', us(s.raster.grad)], ['RF', us(s.raster.rf)], ['ADC', fmt(s.raster.adc * 1e9, 4) + ' ns'], ['Block', us(s.raster.block)]]) +
    `<h3>Settings</h3><p class="note">Lanes, units, shot and volume rules and k-space options are remembered in this browser.</p><button class="btn" id="resetSettings">Restore default settings</button>` +
    `<p class="note" style="margin-top:14px">${esc(APP.name)} ${esc(APP.version)} · <a href="#" id="aboutLink">About, version history and how to cite</a></p>` +
    (s.warnings.length ? `<h3>Warnings <span class="tag">${s.warnings.length}</span></h3><ul class="warnlist">${s.warnings.slice(0, 50).map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : '');
}
function minMax(a) { let mn = Infinity, mx = -Infinity; for (const x of a) { if (x < mn) mn = x; if (x > mx) mx = x; } return [mn, mx]; } // no spread: arrays can hold ~1M values
function volsHTML() {
  if (S.volMode === 'off') return '';
  const v = S.vols, how = S.volMode === 'auto' ? 'k-space sampling repeats' : `label ${esc(S.volMode.slice(6))} changes`;
  if (!v.length) return `<h3>Volumes</h3><p class="note">No shots were found, so no volumes are marked.</p>`;
  const med = a => { const b = [...a].sort((x, y) => x - y); return b[b.length >> 1]; };
  const range = (a, f) => { const [mn, mx] = minMax(a); return Math.abs(mx - mn) <= 1e-9 * Math.max(1, Math.abs(mx)) ? f(mn) : `${f(med(a))} <span class="muted">(${f(mn)} – ${f(mx)})</span>`; };
  return `<h3>Volumes <span class="tag">new one when ${how}</span></h3>` +
    kv([['Volumes', v.length.toLocaleString()], ['Duration, median', range(v.map(x => x.t1 - x.t0), fmtT)],
      ['Shots / volume', range(v.map(x => x.nShots), n => n.toLocaleString())], ['ADC samples / volume', range(v.map(x => x.nSamples), n => n.toLocaleString())]]) +
    (S.volMode === 'auto' && v.length === 1 ? '<p class="note">No shot repeats its k-space sampling, so the whole sequence counts as one volume.</p>' : '');
}
function shotsHTML() {
  const s = S.seq;
  if (S.shotMode === 'off') return '';
  const sh = s.shots;
  if (!sh.length) return `<h3>Shots</h3><p class="note">No excitation pulses found, so no shots are marked.</p>`;
  const med = a => { const b = [...a].sort((x, y) => x - y); return b[b.length >> 1]; };
  const range = (a, f) => { const [mn, mx] = minMax(a), m = med(a); return Math.abs(mx - mn) <= 1e-9 * Math.max(1, Math.abs(mx)) ? f(m) : `${f(m)} <span class="muted">(${f(mn)} – ${f(mx)})</span>`; };
  const acq = sh.filter(x => x.nADC);
  const fell = S.shotMode === 'prep' && s.shotMode === 'exc';
  const dur = sh.map(x => x.t1 - x.t0);
  return `<h3>Shots <span class="tag">${s.shotMode === 'prep' ? 'split at preparation pulses' : 'one per excitation'}</span></h3>` +
    (fell ? '<p class="note">No inversion, saturation or preparation pulses found, so shots are split at excitations instead.</p>' : '') +
    kv([['Shots', sh.length.toLocaleString()], ['With ADC', acq.length.toLocaleString()],
      sh.length - acq.length ? ['Without ADC', (sh.length - acq.length).toLocaleString()] : null,
      ['Duration, median', sh.length > 1 ? range(dur, fmtT) : fmtT(dur[0])],
      acq.length ? ['ADC samples / shot', range(acq.map(x => x.nSamples), v => v.toLocaleString())] : null]);
}
function fmtDate(d) { const p = v => String(v).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; }
async function copyText(t) { // the clipboard, with the old copy command where the Clipboard API is refused
  try { await navigator.clipboard.writeText(t); return true; } catch (_) { }
  try { const a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;opacity:0;left:0;top:0'; document.body.appendChild(a); a.select(); const ok = document.execCommand('copy'); a.remove(); return ok; } catch (_) { return false; }
}
document.addEventListener('click', e => {
  if (e.target.id === 'sigBtn') {
    const h = $('#sigHash'); h.hidden = false;
    copyText(S.seq.signature.hash.toLowerCase()).then(ok => { const m = $('#sigMsg'); if (m) m.textContent = ok ? '(copied)' : '(select it and press Ctrl/Cmd+C)'; });
  }
  if (e.target.id === 'resetSettings') resetSettings();
  if (e.target.id === 'aboutLink') { e.preventDefault(); openAbout(); }
});
/* ---------- about, version history, attribution ---------- */
const PULSEQ_DOI = 'https://doi.org/10.1002/mrm.26235', PULSEQ_WEB = 'https://pulseq.github.io';
const PULSEQ_LINKS = `<a href="${PULSEQ_DOI}" target="_blank" rel="noopener">doi:10.1002/mrm.26235</a> · <a href="${PULSEQ_WEB}" target="_blank" rel="noopener">pulseq.github.io</a>`;
function openAbout() {
  const A = APP, d = $('#about');
  $('#aboutTitle').textContent = `${A.name} ${A.version}`;
  $('#aboutSub').textContent = `${A.tagline} · released ${A.date}`;
  const cite = `${A.author}. ${A.name}: a ${A.tagline}, version ${A.version} (${A.date.slice(0, 4)}). ${A.affiliation}.${A.url ? ' ' + A.url : ''}`;
  $('#aboutBody').innerHTML =
    `<div class="credits">${(A.credits || []).map(c => `<div>${esc(c)}</div>`).join('')}</div>` +
    kv([['Version', `${esc(A.version)} (${esc(A.date)})`], A.license ? ['License', `${esc(A.license)} · ${esc(A.copyright || '')}`] : null, A.url ? ['Source code', `<a href="${esc(A.url)}" target="_blank" rel="noopener">${esc(A.url.replace(/^https?:\/\//, ''))}</a>`] : null]) +
    (A.licenseText ? `<details class="lic"><summary>Show the licence text</summary><pre>${esc(A.licenseText)}</pre></details>` : '') +
    `<h3>How to cite</h3><div class="cite" id="citeText">${esc(cite)}</div><div class="cite-row"><button class="btn" id="copyCite">Copy citation</button><span class="muted" id="copyMsg"></span></div>` +
    `<h3>Acknowledgements</h3><ul>
      <li>The Pulseq file format and its conventions (event definitions, labels, k-space calculation): Layton KJ, et al. Pulseq: a rapid and hardware-independent pulse sequence prototyping framework. <i>Magn Reson Med</i> 2017;77(4):1544–1552. ${PULSEQ_LINKS}</li>
      <li>PyPulseq was used to validate the viewer: reference files of the suite verify reading files, gradient waveforms and k-space trajectory. Ravi KS, et al. PyPulseq: a Python package for MRI pulse sequence design. <i>J Open Source Softw</i> 2019;4(42):1725. <a href="https://doi.org/10.21105/joss.01725" target="_blank" rel="noopener">doi:10.21105/joss.01725</a> · <a href="https://github.com/imr-framework/pypulseq" target="_blank" rel="noopener">github.com/imr-framework/pypulseq</a></li>
      <li>Concomitant gradients (lanes Gc, kc and k + kc) and the generalized Maxwell index μ are computed as in Olsson V, et al. Concomitant gradient effects across field strengths and gradient amplitudes: improved estimation of errors and correction of concomitant dephasing and diffusion weighting. <i>Magn Reson Med</i> 2026;96(3):1178–1191. <a href="https://doi.org/10.1002/mrm.70422" target="_blank" rel="noopener">doi:10.1002/mrm.70422</a></li>
      <li>Nerve stimulation (PNS, CNS) follows the SAFE model as implemented in safe_pns_prediction by F. Szczepankiewicz and T. Witzel (<a href="https://github.com/filip-szczepankiewicz/safe_pns_prediction" target="_blank" rel="noopener">github.com/filip-szczepankiewicz/safe_pns_prediction</a>), against which it was checked. Model: Hebrank FX, Gebhardt M. SAFE-Model: a new method for predicting peripheral nerve stimulations in MRI. <i>Proc Intl Soc Mag Reson Med</i> 2000;8:2007.</li>
    </ul>` +
    `<h3>Recent changes</h3>` + A.changelog.slice(0, 5).map(c => `<p style="margin:8px 0 2px"><b>${esc(c.version)}</b> <span class="muted">${esc(c.date)}</span></p><ul>${c.notes.map(n => `<li>${esc(n)}</li>`).join('')}</ul>`).join('') +
    `<p class="muted" style="margin-top:10px">The complete version history is in CHANGELOG.md${A.url ? ` in the <a href="${esc(A.url)}" target="_blank" rel="noopener">source code repository</a>` : ''}.</p>`;
  $('#copyCite').onclick = async () => { try { await navigator.clipboard.writeText(cite); $('#copyMsg').textContent = 'Copied'; } catch (_) { const r = document.createRange(); r.selectNodeContents($('#citeText')); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(r); $('#copyMsg').textContent = 'Selected, press Ctrl/Cmd+C'; } };
  if (typeof d.showModal === 'function') d.showModal(); else d.setAttribute('open', '');
}
$('#aboutBtn').onclick = openAbout;
$('#aboutClose').onclick = () => $('#about').close ? $('#about').close() : $('#about').removeAttribute('open');
$('#about').addEventListener('click', e => { if (e.target.id === 'about') $('#about').close(); });
console.info(`${APP.name} ${APP.version} (${APP.date})`);
function renderDefs() {
  const s = S.seq, el = $('#p-defs');
  if (!s) { el.innerHTML = '<p class="note">No sequence loaded.</p>'; return; }
  const keys = [...new Set(s.defOrder)];
  el.innerHTML = keys.length ? `<table class="defs">${keys.map(k => { const v = s.defs[k]; return `<tr><td>${esc(k)}</td><td>${esc(Array.isArray(v) ? v.join('  ') : v)}</td></tr>`; }).join('')}</table>` : '<p class="note">This file has no [DEFINITIONS] section.</p>';
}
function labelState(upTo) { // label values in effect after block upTo
  const st = {};
  for (const tr of S.seq.labels) { const r = ub(tr.b, upTo) - 1; if (r >= 0) st[tr.name] = tr.v[r]; }
  return st;
}
function gradRows(g) {
  const f = gF();
  if (g.type === 'trap') {
    const area = g.amp * (g.rise / 2 + g.flat + g.fall / 2);
    return kv([['Amplitude', `${fmt(g.amp * f, 4)} ${gU()}`], ['Rise / flat / fall', `${fmt(g.rise * 1e6, 5)} / ${fmt(g.flat * 1e6, 5)} / ${fmt(g.fall * 1e6, 5)} µs`],
      ['Delay', us(g.delay)], ['Area', `${fmt(area, 5)} m⁻¹`], ['Slew (ramp up)', g.rise > 0 ? `${fmt(g.amp / g.rise * sF(), 4)} ${sU()}` : '–']]);
  }
  const gt = gradTimes(S.seq, g); let area = 0;
  for (let i = 1; i < gt.t.length; i++) area += 0.5 * (gt.v[i] + gt.v[i - 1]) * (gt.t[i] - gt.t[i - 1]);
  const sh = S.seq.shapes.get(g.shapeId);
  return kv([['Amplitude', `${fmt(g.amp * f, 4)} ${gU()}`], ['Shape', `#${g.shapeId}, ${sh ? sh.length : '?'} samples`],
    ['Timing', g.timeId > 0 ? `time shape #${g.timeId}` : g.timeId === -1 ? 'oversampled (½ raster)' : 'regular raster'],
    ['Delay', us(g.delay)], ['Duration', us(gt.t[gt.t.length - 1] - g.delay)], ['Area', `${fmt(area, 5)} m⁻¹`],
    g.first !== undefined ? ['First / last', `${fmt(g.first * f, 4)} / ${fmt(g.last * f, 4)} ${gU()}`] : null]);
}
/* rotation extension, as text: angle about an axis, plus the quaternion */
function rotText(q) {
  const n = Math.hypot(...q) || 1, w = q[0] / n, ang = 2 * Math.acos(Math.min(1, Math.abs(w))) * 180 / Math.PI;
  if (ang < 1e-6) return 'none (identity)';
  const s = Math.sqrt(Math.max(1e-30, 1 - w * w)), ax = [q[1], q[2], q[3]].map(v => (w < 0 ? -1 : 1) * v / n / s);
  return `${fmt(ang, 4)}° about (${ax.map(v => fmt(v, 3)).join(', ')}) · quaternion ${q.map(v => fmt(v, 4)).join(' ')} · gradients shown rotated (physical)`;
}
/* ---------- short description of a block (rule-based) ---------- */
const USE_WORD = { e: 'excitation', r: 'refocusing', i: 'inversion', s: 'saturation', p: 'preparation' };
let gMaxAll = 0;
function describeBlock(i) {
  const s = S.seq, B = s.B, G = ['gx', 'gy', 'gz'].filter(k => B['p' + k][i]); // physical axes (after any rotation)
  const dur = s.blockStart[i + 1] - s.blockStart[i];
  const j = lb(s.adcBlocks, i), hasAdc = B.adc[i] && j < s.adcBlocks.length && s.adcBlocks[j] === i;
  const adcWord = () => ['Readout', 'Reference readout', 'Reference + imaging readout', 'Noise scan', 'Navigator'][s.adcType[j]];
  if (B.rf[i]) {
    const st = rfSt(s, B.rf[i]), r = s.rf.get(B.rf[i]), flip = Math.round(st.flip * 180 / Math.PI);
    let d = `RF${flip} ${USE_WORD[st.use] || 'pulse'}`;
    if (st.use === 's' && r && (Math.abs(r.freq) > 50 || Math.abs(r.freqPPM || 0) > 0.5)) d += ' (off-resonance)';
    else if (G.length) d += ', slice-selective';
    if (hasAdc) d += ' + ' + adcWord().toLowerCase();
    return d;
  }
  if (hasAdc) return G.length || s.adcType[j] === 3 ? adcWord() : adcWord() + ' (no gradient)';
  if (!G.length) {
    if (B.ext[i]) { const ex = extChain(s, B.ext[i]); return ex.some(x => /TRIGGER/i.test(x.name)) ? 'Trigger' : dur > 1e-9 ? 'Pause (labels)' : 'Labels'; }
    return 'Pause';
  }
  // gradients only: name them from where they sit in the shot
  if (!gMaxAll) gMaxAll = Math.max(...s.stats.maxG) || 1;
  const geos = G.map(k => geoG(s, B['p' + k][i])), arb = ['gx', 'gy', 'gz'].some(k => B[k][i] && (s.grad.get(B[k][i]) || {}).type === 'arb');
  const gmax = Math.max(...geos.map(g => Math.max(Math.abs(g.min), Math.abs(g.max))));
  const glen = Math.max(...geos.map(g => g.t[g.n - 1] - g.t[0]));
  const axes = G.map(k => k[1]).join('');
  const useOf = b => b >= 0 && b < s.nb && B.rf[b] ? rfSt(s, B.rf[b]).use : null;
  const hasEv = b => B.rf[b] || B.gx[b] || B.gy[b] || B.gz[b] || B.adc[b];
  const nextEv = (b, d) => { for (let q = b + d, n = 0; q >= 0 && q < s.nb && n < 8; q += d, n++) if (hasEv(q)) return q; return -1; };
  const pv = nextEv(i, -1), nx = nextEv(i, 1);
  const k = s.shots.length ? shotOfBlock(i) : -1, sh = k >= 0 ? s.shots[k] : null;
  let excB = -1; if (sh) for (let q = Math.min(sh.b1, i); q >= sh.b0; q--) if (useOf(q) === 'e') { excB = q; break; }
  // first main readout (imaging or reference, not noise or navigator) after the excitation, and the last one in the shot
  let firstImg = -1, lastImg = -1;
  if (sh) for (let q = sh.j0; q < sh.j1; q++) { const bb = s.adcBlocks[q], t = s.adcType[q]; if (t > 2) continue; if (firstImg < 0 && bb > excB) firstImg = bb; lastImg = bb; }
  let ctx;
  if (pv >= 0 && nx >= 0 && B.adc[pv] && B.adc[nx] && dur < 1e-3) ctx = 'Phase blip';
  else if (excB >= 0 && (firstImg < 0 || i < firstImg) && glen >= 3e-3 && gmax >= 0.3 * gMaxAll) ctx = arb ? 'Diffusion encoding, arbitrary waveform' : 'Diffusion encoding';
  else if (useOf(pv) === 'r' || useOf(nx) === 'r') ctx = 'Crusher';
  else if (['s', 'i', 'p'].includes(useOf(pv))) ctx = 'Spoiler';
  else if (excB >= 0 && firstImg > i) ctx = 'Prephaser';
  else if (lastImg >= 0 && i > lastImg) ctx = 'Spoiler';
  else ctx = arb ? 'Arbitrary gradient waveform' : 'Gradients';
  return `${ctx} (${axes})`;
}
/* slice selected by the RF pulse of block i (rows for the RF card) */
const mmS = v => { const x = v * 1e3; return Math.abs(x) < 0.005 ? '0.00' : (x > 0 ? '+' : '−') + Math.abs(x).toFixed(2); }; // m → signed mm
function simB0(s) { const d = s.defs.B0; return typeof d === 'number' && d > 0 ? { B0: d, src: 'from the file' } : { B0: S.sim.B0, src: 'Image tab setting' }; }
function sliceRows(i) {
  const s = S.seq, { B0, src } = simB0(s), q = rfSlice(s, i, B0); if (!q) return '';
  const r = s.rf.get(s.B.rf[i]), rows = [], tip = (v, t) => `<span title="${esc(t)}">${v}</span>`, pct = x => `${(100 * x).toFixed(x < 0.1 ? 1 : 0)} %`;
  const neg = x => String(x).replace('-', '−');
  if (r.freqPPM) rows.push(['Total frequency', tip(`${neg(fmt(q.f, 5))} Hz`, `${fmt(r.freq, 5)} Hz ${r.freqPPM < 0 ? '−' : '+'} ${fmt(Math.abs(r.freqPPM), 4)} ppm at ${B0} T (${src}). The ppm part needs a field strength, which the file does not store.`)]);
  const varies = q.gDev > 0.01 * Math.max(q.Gm, 1e3);
  if (!q.selective) {
    rows.push(['Slice selection', 'none (non-selective)']);
    if (varies) rows.push(['Gradient during pulse', tip(`up to ${fmt(q.gDev / GAMMA * 1e3, 3)} mT/m`, 'There is no gradient at the pulse centre, but a gradient is on during part of the pulse.')]);
    return '<h5 class="subh">Slice</h5>' + kv(rows);
  }
  const pn = planeName(q.n), qr = rotationOfBlock(s, i);
  const rotd = qr && 2 * Math.acos(Math.min(1, Math.abs(qr[0]) / (Math.hypot(...qr) || 1))) > 1e-9;
  rows.push(['Slice gradient', tip(`${fmt(q.Gm / GAMMA * 1e3, 4)} mT/m`, 'Gradient amplitude at the pulse centre' + (rotd ? ', after the block\'s rotation (physical axes)' : ''))]);
  if (varies) rows.push(['Gradient during pulse', tip(`varies ${pct(q.gDev / q.Gm)}`, 'Largest deviation of the gradient vector from its value at the pulse centre while |B1| > 1 % of peak (ramp sampling or VERSE). The slice values below use the centre value and are approximate.')]);
  rows.push(['Normal', tip(`(${q.n.map(v => neg(fmt(v, 3))).join(', ')})`, 'Direction of the slice gradient (x, y, z) in the sequence\'s physical axes' + (rotd ? ', after rotation' : ''))]);
  rows.push(['Orientation', tip(pn.tilt > 0.05 ? `${pn.name}, ${fmt(pn.tilt, 3)}° tilt` : pn.name, 'Assumes the scanner axes of a head-first supine patient (x left–right, y anterior–posterior, z head–foot).')]);
  rows.push(['Position', tip(`${mmS(q.s0)} mm`, 'Distance of the slice centre from the isocentre along the normal: frequency offset / gradient (Pulseq convention). The scanner may add its own offset and rotation from the protocol.')]);
  rows.push(['Centre (x, y, z)', `(${q.pos.map(mmS).join(', ')}) mm`]);
  rows.push(['Thickness', tip(`${fmt(q.thick * 1e3, 4)} mm`, `FWHM bandwidth / gradient, from the pulse's small-tip frequency response` + (q.flip > 100 * Math.PI / 180 ? '. A large-angle pulse (refocusing, inversion) has a somewhat different profile.' : '.'))]);
  rows.push(['Bandwidth', tip(`${fmt(q.bw / 1e3, 4)} kHz · TBW ${fmt(q.bw * q.dur, 3)}`, 'FWHM of the small-tip frequency response, and its product with the pulse duration (time–bandwidth product)')]);
  if (q.s0Species !== undefined) rows.push([`Position at ${neg(fmt(r.freqPPM, 4))} ppm`, tip(`${mmS(q.s0Species)} mm`, 'Where spins at the pulse\'s own chemical-shift offset are selected, along the normal')]);
  rows.push(['Fat shift', tip(`${mmS(q.fatShift)} mm (${pct(Math.abs(q.fatShift) / q.thick)})`, `Displacement of the fat slice (main peak, ${neg(fmt(FAT_MAIN_PPM, 3))} ppm) along the normal at ${B0} T (${src}), and as a fraction of the thickness`)]);
  // a pulse after the excitation in the same shot: does it act on the excited slice?
  const k = s.shots.length ? shotOfBlock(i) : -1;
  if (k >= 0) {
    let e = -1; for (let b = s.shots[k].b0; b <= s.shots[k].b1; b++) if (s.B.rf[b] && rfSt(s, s.B.rf[b]).use === 'e') { e = b; break; }
    if (e >= 0 && e !== i) {
      const qe = rfSlice(s, e, B0);
      if (!qe || !qe.selective) rows.push(['vs excitation', 'excitation is non-selective']);
      else {
        const d = Math.hypot(q.pos[0] - qe.pos[0], q.pos[1] - qe.pos[1], q.pos[2] - qe.pos[2]);
        const ang = Math.acos(Math.min(1, Math.abs(q.n[0] * qe.n[0] + q.n[1] * qe.n[1] + q.n[2] * qe.n[2]))) * 180 / Math.PI;
        const same = d < 0.01 * Math.min(q.thick, qe.thick) && ang < 0.1, ratio = `${fmt(q.thick / qe.thick, 3)}× thickness`;
        rows.push(['vs excitation', tip(same ? `same slice, ${ratio}` : `${(d * 1e3).toFixed(2)} mm apart${ang >= 0.1 ? `, ${fmt(ang, 3)}°` : ''}, ${ratio}`,
          'Compared with the excitation of this shot: distance between the slice centres, angle between the planes, and thickness relative to the excitation')]);
        // fat is displaced along each pulse's own gradient: opposite gradients separate the fat slices (gradient reversal)
        if (ang < 0.1) {
          const fp = q.pos.map((v, a) => v + q.n[a] * q.fatShift), fe = qe.pos.map((v, a) => v + qe.n[a] * qe.fatShift);
          const dF = Math.hypot(fp[0] - fe[0], fp[1] - fe[1], fp[2] - fe[2]), opp = q.n[0] * qe.n[0] + q.n[1] * qe.n[1] + q.n[2] * qe.n[2] < 0;
          rows.push(['Fat vs excitation', tip(`${(dF * 1e3).toFixed(2)} mm apart (${pct(dF / Math.min(q.thick, qe.thick))})`,
            'Distance between the fat slices of this pulse and of the excitation, and as a fraction of the thinner slice' + (opp ? '. The slice gradients have opposite signs, so the fat slices move apart (slice-select gradient reversal).' : '.'))]);
        }
      }
    }
  }
  return '<h5 class="subh">Slice</h5>' + kv(rows);
}
function renderBlock() {
  const s = S.seq, el = $('#p-blk');
  if (!s) { el.innerHTML = '<p class="note">No sequence loaded.</p>'; return; }
  if (S.sel < 0) { el.innerHTML = '<p class="note">Click a block in the diagram to inspect it, or click a shot or volume in the strips above the diagram. Step through them with the Block, Shot and Volume controls above the diagram or with <kbd>←</kbd> <kbd>→</kbd>.</p>'; return; }
  const b = blockObj(s, S.sel), t0 = s.blockStart[S.sel];
  const skH = s.shots.length && shotsOn() ? shotOfBlock(S.sel) : -1, vkH = volsOn() ? volOfBlock(S.sel) : -1;
  const where = [skH >= 0 ? `shot ${skH + 1} of ${s.shots.length.toLocaleString()}` : '', vkH >= 0 ? `volume ${vkH + 1} of ${S.vols.length.toLocaleString()}` : ''].filter(Boolean);
  let head;
  const nSel = S.selItems.length > 1 ? ` <span class="muted">· ${S.selItems.length} selected (Ctrl+click to add or remove, Shift+click for a range)</span>` : '';
  if (S.selKind === 'vol' && vkH >= 0) head = `<div class="selmain"><b>Volume ${vkH + 1}</b> <span class="muted">of ${S.vols.length.toLocaleString()}</span>${nSel}</div><div class="selsub">${S.vols[vkH].nShots} shots · starts with block ${b.id}: ${esc(describeBlock(S.sel))}</div>`;
  else if (S.selKind === 'shot' && skH >= 0) head = `<div class="selmain"><b>Shot ${skH + 1}</b> <span class="muted">of ${s.shots.length.toLocaleString()}</span>${nSel}</div><div class="selsub">${vkH >= 0 ? `volume ${vkH + 1} · ` : ''}starts with block ${b.id}: ${esc(describeBlock(S.sel))}</div>`;
  else head = `<div class="selmain"><b>Block ${b.id}</b> <span class="desc">${esc(describeBlock(S.sel))}</span></div><div class="selsub">${where.length ? 'in ' + where.join(' · ') : `of ${s.nb.toLocaleString()} blocks`}</div>`;
  let h = '';
  const firstOf = S.selKind === 'shot' ? ' (first block of the shot)' : S.selKind === 'vol' ? ' (first block of the volume)' : '';
  h += `<h3>Block ${b.id}${firstOf} <span class="tag">${esc(describeBlock(S.sel))}</span></h3>` + kv([['Start', fmtT(t0)], ['Duration', fmtT(b.dur)], ['k at the end', `${[0, 1, 2].map(a => fmt(s.kStart[a][S.sel + 1] * mF(), 4)).join(', ')} <span class="muted">${mU()}</span>`], ...ccRows(S.sel), ...stimRows(t0, t0 + b.dur)]) +
    `<div class="blknav" style="margin-top:8px"><button class="btn" id="bZoom">Zoom to block</button></div>`;
  let shotCard = '', volCard = '';
  const vk = volsOn() ? volOfBlock(S.sel) : -1;
  if (vk >= 0) {
    const v = S.vols[vk];
    volCard = `<div class="evt" style="--c:var(--ink)"><h4>Volume ${vk + 1} <span>of ${S.vols.length.toLocaleString()}</span></h4>` + kv([
      ['Blocks', `${s.B.id[v.b0]} – ${s.B.id[v.b1]}`], ['Starts at', fmtT(v.t0)], ['Duration', fmtT(v.t1 - v.t0)],
      ['Shots', `${v.nShots.toLocaleString()}${v.nAcqShots !== v.nShots ? ` (${v.nAcqShots} with ADC)` : ''}`], ['ADC samples', v.nSamples.toLocaleString()], ...stimRows(v.t0, v.t1)]) + peakHTML(v.b0, v.b1, 'volume') +
      `<div class="blknav" style="margin-top:8px"><button class="btn" id="vZoom">Zoom to volume</button></div></div>`;
  }
  const sk = shotsOn() ? shotOfBlock(S.sel) : -1;
  if (sk >= 0) {
    const sh = s.shots[sk];
    shotCard = `<div class="evt" style="--c:var(--sel)"><h4>Shot ${sk + 1} <span>of ${s.shots.length.toLocaleString()}</span></h4>` + kv([
      ['Blocks', `${s.B.id[sh.b0]} – ${s.B.id[sh.b1]}`], ['Starts at', fmtT(sh.t0)], ['Duration', fmtT(sh.t1 - sh.t0)],
      ['ADC', sh.nADC ? `${sh.nADC} events, ${sh.nSamples.toLocaleString()} samples` : 'none (dummy or preparation)'], ...bTensorRows(sk), ...stimRows(sh.t0, sh.t1)]) + peakHTML(sh.b0, sh.b1, 'shot') +
      `<div class="blknav" style="margin-top:8px"><button class="btn" id="sZoom">Zoom to shot</button></div></div>`;
  }
  if (S.selKind === 'vol') h = volCard + shotCard + h; else if (S.selKind === 'shot') h = shotCard + volCard + h; else h += shotCard + volCard;
  h = `<div class="selhead">${head}</div>` + h;
  let any = false;
  if (b.rf) {
    const r = s.rf.get(b.rf); any = true;
    if (r) {
      const st = rfStats(s, r);
      h += `<div class="evt" style="--c:var(--c-rf)"><h4>RF <span>#${b.rf}</span></h4>` + kv([
        ['Purpose', (USE[st.use] || st.use) + (st.useGuessed ? ' <span class="muted">(inferred)</span>' : '')],
        ['Flip angle', `${fmt(st.flip * 180 / Math.PI, 4)}°`], ['Peak B1', `${fmt(r.amp * rF(), 4)} ${rU()}`],
        ['Duration', us(st.dur)], ['Delay', us(r.delay)], ['Centre', us(st.center - r.delay) + ' after start'],
        ['Frequency offset', `${fmt(r.freq, 5)} Hz`], ['Phase offset', `${fmt(r.phase, 4)} rad (${fmt(r.phase * 180 / Math.PI, 4)}°)`],
        r.freqPPM || r.phasePPM ? ['PPM offsets', `${fmt(r.freqPPM, 4)} ppm, ${fmt(r.phasePPM, 4)} rad/MHz`] : null,
        ['Shapes (mag/phase/time)', `#${r.magId} / #${r.phaseId} / ${r.timeId > 0 ? '#' + r.timeId : 'raster'}`], ['Samples', st.n]]) +
        sliceRows(S.sel) + '</div>';
    }
  }
  for (const a of ['x', 'y', 'z']) {
    const id = b['g' + a]; if (!id) continue; any = true;
    const g = s.grad.get(id);
    h += `<div class="evt" style="--c:var(--c-g${a})"><h4>G${a} <span>#${id} · ${g ? (g.type === 'trap' ? 'trapezoid' : 'arbitrary') : 'missing'}</span></h4>${g ? gradRows(g) : ''}</div>`;
  }
  if (b.adc) {
    const a = s.adc.get(b.adc); any = true;
    if (a) h += `<div class="evt" style="--c:var(--c-adc)"><h4>ADC <span>#${b.adc}</span></h4>` + kv([
      ['Type', (() => { const j = lb(s.adcBlocks, S.sel); const tp = j < s.adcBlocks.length && s.adcBlocks[j] === S.sel ? s.adcType[j] : 0; return `<span style="color:var(--c-${TYPE_COL[tp]});font-weight:600">${TYPE_NAME[tp]}</span>`; })()],
      ['Samples', a.num], ['Dwell', fmt(a.dwell * 1e6, 5) + ' µs'], ['Duration', us(a.num * a.dwell)], ['Delay', us(a.delay)],
      ['Bandwidth / pixel', `${fmt(1 / (a.num * a.dwell), 5)} Hz`], ['Frequency offset', `${fmt(a.freq, 5)} Hz`], ['Phase offset', `${fmt(a.phase, 4)} rad`],
      a.phaseId ? ['Phase shape', '#' + a.phaseId] : null]) + '</div>';
  }
  if (b.ext) {
    const ex = extChain(s, b.ext); any = true;
    h += `<div class="evt" style="--c:var(--ink)"><h4>Extensions <span>list #${b.ext}</span></h4>` + kv(ex.map(x => {
      const d = x.data || [];
      if (/LABELSET/i.test(x.name)) return ['Set label', `${esc(d[1])} = ${esc(d[0])}`];
      if (/LABELINC/i.test(x.name)) return ['Increment label', `${esc(d[1])} += ${esc(d[0])}`];
      if (/TRIGGER/i.test(x.name)) return ['Trigger', `${esc(trigText(+d[0], +d[1]))}, delay ${esc(d[2])} µs, ${esc(d[3])} µs long <span class="muted">(type ${esc(d[0])}, channel ${esc(d[1])})</span>`];
      if (/^ROTATIONS?$/i.test(x.name)) return ['Rotation', rotText(d.slice(0, 4).map(Number))];
      return [esc(x.name), esc(d.join(' '))];
    })) + '</div>';
  }
  if (!any) h += '<p class="note">Pure delay block, no events.</p>';
  if ([...s.extTypes.values()].some(n => /LABEL/i.test(n))) {
    const st = labelState(S.sel), keys = Object.keys(st).sort();
    if (keys.length) h += `<h3>Label counters after this block</h3>` + kv(keys.map(k => [esc(k), st[k]]));
  }
  el.innerHTML = h;
  if ($('#vZoom')) { $('#vZoom').onclick = () => { selectBlock(S.vols[volOfBlock(S.sel)].b0, { kind: 'vol' }); zoomToVol(volOfBlock(S.sel)); }; }
  $('#bZoom').onclick = () => { pushHist(); zoomToBlock(S.sel); };
  if ($('#sZoom')) { $('#sZoom').onclick = () => { selectBlock(s.shots[shotOfBlock(S.sel)].b0, { kind: 'shot' }); zoomToShot(shotOfBlock(S.sel)); }; }
}

/* ---------- k-space ---------- */
const PROJ = { xy: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], xz: [[1, 0, 0], [0, 0, 1], [0, -1, 0]], yz: [[0, 1, 0], [0, 0, 1], [1, 0, 0]] };
function rot3d() { const a = -0.55, b = -1.05; const R = [[Math.cos(a), -Math.sin(a), 0], [Math.sin(a), Math.cos(a), 0], [0, 0, 1]]; return mul(rx(b), R); }
function rx(a) { return [[1, 0, 0], [0, Math.cos(a), -Math.sin(a)], [0, Math.sin(a), Math.cos(a)]]; }
function ry(a) { return [[Math.cos(a), 0, Math.sin(a)], [0, 1, 0], [-Math.sin(a), 0, Math.cos(a)]]; }
function mul(A, B) { return A.map(r => [0, 1, 2].map(j => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j])); }
S.kR = PROJ.xy;
function segSet(id, key, cb) {
  const el = $(id); el.querySelectorAll('button').forEach(b => b.onclick = () => { el.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', x === b)); cb(b.dataset.v); });
}
segSet('#kRange', 'kRange', v => { S.kRange = v; requestK(); });
segSet('#kAct', 'kActual', v => { S.kActual = v === 'act'; kInvalidate(); requestK(); kActNote(); scheduleSave(); });
/* nominal or actual k-space (1.47.0). Actual: the k-vector plus kc, the concomitant k-space shift at the position of
   Concomitant gradients › Position (the slice centre of each shot, or the fixed r), as lane k + kc. A sequence whose
   gradients were pre-corrected for concomitant fields plays a distorted nominal trajectory whose actual one is close to
   the one intended. MxwlCorrParams in [DEFINITIONS] ("B0=0.01 T, a=0.5, f=0 T/m, ...") names the field the
   correction was made for; its values can be taken over (with the slice centres, where such corrections apply). */
function mxwlCorrParams(seq) {
  const v = seq && seq.defs && seq.defs.MxwlCorrParams; if (v == null) return null;
  const t = Array.isArray(v) ? v.join(' ') : String(v), num = re => { const m = t.match(re); return m ? Number(m[1]) : NaN; };
  const P = { B0: num(/B0\s*=\s*([-+0-9.eE]+)/), a: num(/(?:^|[\s,])a\s*=\s*([-+0-9.eE]+)/), f: num(/(?:^|[\s,])f\s*=\s*([-+0-9.eE]+)/), text: t };
  return isFinite(P.B0) && P.B0 > 0 ? P : null;
}
function kActNote() {
  const el = $('#kActNote'), c = S.cc, P = mxwlCorrParams(S.seq);
  const g = v => +(+v).toPrecision(4), cur = `B0 ${g(c.B0)} T, a ${g(c.a)}, f ${g(c.f)} T/m, ${c.pos === 'slice' ? 'slice centre of each shot' : `r = (${c.r.map(v => g(v * 100)).join(', ')}) cm`}`;
  const same = P && Math.abs(P.B0 - c.B0) <= 1e-9 * P.B0 && (!isFinite(P.a) || Math.abs(P.a - c.a) < 1e-9) && (!isFinite(P.f) || Math.abs(P.f - c.f) < 1e-12) && c.pos === 'slice';
  el.innerHTML = (S.kActual ? `Actual: k + kc with ${esc(cur)} (<a href="#" id="kCcLink">change</a>).` : 'Nominal: the k-vector of the gradients in the file.') +
    (P ? ` This file was corrected for concomitant fields (${esc(P.text)}).${same ? '' : ` <button class="btn link" id="kUseCorr">Use these values with the slice centres</button>`}` : '');
}
document.addEventListener('click', e => {
  if (e.target.id === 'kCcLink') { e.preventDefault(); openCcDialog(); }
  if (e.target.id === 'kUseCorr') {
    const P = mxwlCorrParams(S.seq); if (!P) return;
    S.cc = { r: S.cc.r.slice(), B0: P.B0, a: isFinite(P.a) ? P.a : S.cc.a, f: isFinite(P.f) ? P.f : S.cc.f, pos: 'slice' };
    S.kActual = true; segPress('#kAct', 'act'); ccSync(); ccApply();
  }
});
segSet('#kProj', 'kProj', v => { S.kProj = v; S.kR = v === '3d' ? rot3d() : PROJ[v]; S.kZoom = 1; S.kPan = [0, 0]; requestK(); });
$('#kTraj').onchange = e => { S.kTraj = e.target.checked; requestK(); };
let kPending = false;
function requestK() { if (!kPending) { kPending = true; requestAnimationFrame(() => { kPending = false; benchT(drawK); }); } }
const VIR = [[68, 1, 84], [59, 82, 139], [33, 145, 140], [94, 201, 98], [253, 231, 37]];
/* k-space drawing: skipped when nothing changed; ADC points written straight into a pixel
   buffer; the path is simplified in screen space; view-driven redraws are throttled. */
let kFast = false, kFastTimer = null, kKey = null, kOff = null, kImg = null, kLut = null, kLast = 0, kTimer = null;
let kData = null, kData_busy = false, kHit = null, kTip = null, kRing = null, kHoverI = -1; // kHit: drawn samples, for hovering
const K_MAX_PTS = 5e5, K_MAX_PATH = 2e5; // display caps for large ranges (more is not visible at this plot size)
function kInvalidate() { kKey = null; kData = null; kGroupCache = null; kHit = null; kHoverHide(); }
function requestKLazy() {
  if (S.tab !== 'k') return;
  const wait = 120 - (performance.now() - kLast);
  if (wait <= 0) requestK();
  else if (!kTimer) kTimer = setTimeout(() => { kTimer = null; requestK(); }, wait);
}
function hexU32(h) {
  h = (h || '#888').trim(); if (h[0] === '#' && h.length === 4) h = '#' + h[1] + h[1] + h[2] + h[2] + h[3] + h[3];
  const r = parseInt(h.slice(1, 3), 16) || 0, g = parseInt(h.slice(3, 5), 16) || 0, b = parseInt(h.slice(5, 7), 16) || 0;
  return (255 << 24 | b << 16 | g << 8 | r) >>> 0;
}
function buildLut() {
  kLut = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    const x = i / 255 * 4, j = Math.min(3, Math.floor(x)), f = x - j, a = VIR[j], b = VIR[j + 1];
    const r = a[0] + (b[0] - a[0]) * f | 0, g = a[1] + (b[1] - a[1]) * f | 0, bl = a[2] + (b[2] - a[2]) * f | 0;
    kLut[i] = (255 << 24 | bl << 16 | g << 8 | r) >>> 0;
  }
}
/* readouts by kind, each shown on its own in the k-space tab (arrows): imaging (including reference + imaging),
   reference, navigator, noise. For the shown kind: its ADC events in the range, and the trajectory from just after
   the last ADC of another kind before its first one (so a navigator's path does not cross the imaging k-space) to
   its last ADC. Cached per range. */
const KGROUPS = [['img', 'Imaging readouts', t => t === 0 || t === 2], ['ref', 'Reference readouts', t => t === 1], ['nav', 'Navigator readouts', t => t === 4], ['noise', 'Noise readouts', t => t === 3]];
let kGroupCache = null;
/* Imaging readouts of several echoes per excitation (multi-echo spin or gradient echo; adcEchoes) are one group per
   echo. Each group keeps its runs of blocks for the trajectory: from just after an ADC of another group to its own
   last ADC of that run, so echoes acquired in turn each show their own path. */
function kGroupInfo(j0, j1, pb0, pb1) {
  const s = S.seq, key = [j0, j1, pb0, pb1].join(','); if (kGroupCache && kGroupCache.key === key) return kGroupCache;
  const AT = s.adcType, EC = adcEchoes(s, s.shots), G = [];
  let nE = 0; for (let j = j0; j < j1; j++) if (EC[j] + 1 > nE) nE = EC[j] + 1;
  for (const g of KGROUPS) {
    if (g[0] === 'img' && nE > 1) for (let e = 0; e < nE; e++) G.push({ id: 'img' + (e + 1), label: `Imaging readouts, echo ${e + 1}`, fj: j => g[2](AT[j]) && EC[j] === e });
    else G.push({ id: g[0], label: g[1], fj: j => g[2](AT[j]) });
  }
  for (const g of G) { g.jf = -1; g.jl = -1; g.n = 0; g.runs = []; }
  let prev = null, prevB = -1;
  for (let j = j0; j < j1; j++) {
    const g = G.find(x => x.fj(j)); if (!g) continue;
    const b = s.adcBlocks[j];
    if (g.jf < 0) g.jf = j; g.jl = j; g.n += s.adcOff[j + 1] - s.adcOff[j];
    if (g !== prev || !g.runs.length) g.runs.push([prevB >= 0 ? Math.max(pb0, prevB + 1) : pb0, b]); else g.runs[g.runs.length - 1][1] = b;
    prev = g; prevB = b;
  }
  for (const g of G) for (const r of g.runs) r[1] = Math.min(pb1, r[1]);
  return (kGroupCache = { key, groups: G.filter(g => g.jf >= 0) });
}
/* "all readouts" view: a group per sample: reference, navigator, noise (their ADC-type colours), and imaging split by
   image (the excitation frequency of the shot = the slice, as imageSet groups shots, and the echo of a multi-echo
   sequence, adcEchoes), numbered in order of appearance */
// pastel colours, far apart in hue; the other kinds have hues no image uses (navigator rose, reference teal, its
// near-complement, so the two stand apart where they overlap; noise grey)
const K_IMG_COLS = ['#6FA8F0', '#F2A065', '#8CCB6A', '#E3BE4F', '#A58BEB', '#C79C74', '#9DB4D6', '#D9A0D8'];
const K_KIND_COLS = { 1: '#2FB8B0', 2: '#6FA8F0', 3: '#AAB1BB', 4: '#F0738F' }; // reference, (reference + imaging: as imaging), noise, navigator
function kSubgroups(smp) {
  const s = S.seq, B = s.B, AT = s.adcType, sub = new Uint8Array(smp.n), list = [], byKey = new Map();
  const shotFreq = new Map(), freqOf = j => { const k = shotOfBlock(s.adcBlocks[j]); if (shotFreq.has(k)) return shotFreq.get(k); const f = sliceKey(s, s.shots, k, S.sim.B0); shotFreq.set(k, f); return f; };
  let nImg = 0; const EC = adcEchoes(s, s.shots); let nE = 0; for (const j of smp.ej) if (EC[j] + 1 > nE) nE = EC[j] + 1;
  for (let e = 0; e < smp.ej.length; e++) {
    const j = smp.ej[e], t = AT[j]; let key, label, col;
    if (t === 0 || t === 2) { key = 'img|' + freqOf(j) + '|' + EC[j]; } // an image per slice (excitation frequency and orientation) and echo
    else { key = 't' + t; label = TYPE_NAME[t]; col = K_KIND_COLS[t]; }
    let g = byKey.get(key);
    if (g === undefined) {
      if (key.startsWith('img')) { label = `image ${++nImg}${nE > 1 ? ` (echo ${EC[j] + 1})` : ''}`; const c = K_IMG_COLS[(nImg - 1) % K_IMG_COLS.length]; col = c; }
      g = list.length; list.push({ label, col, n: 0, img: key.startsWith('img'), layer: key.startsWith('img') ? 0 : t === 1 ? 1 : t === 3 ? 2 : 3 }); byKey.set(key, g);
    }
    list[g].n += smp.eo[e + 1] - smp.eo[e]; sub.fill(Math.min(g, 255), smp.eo[e], smp.eo[e + 1]);
    const bb = list[g].bb || (list[g].bb = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity]); // k-space bounds of the group
    for (let i = smp.eo[e]; i < smp.eo[e + 1]; i++) for (let a = 0; a < 3; a++) { const v = smp.k[a][i]; if (v < bb[a]) bb[a] = v; if (v > bb[a + 3]) bb[a + 3] = v; }
  }
  return { sub, list };
}
/* the trajectory of a group's runs of blocks (kGroupInfo), one piece per run: starts = index of each piece's first point */
function kPathRuns(s, runs, act = false) {
  if (runs.length === 1) { const p = kPath(s, runs[0][0], runs[0][1], K_MAX_PATH, act); p.starts = [0]; return p; }
  let nbT = 0; for (const r of runs) nbT += r[1] - r[0] + 1;
  const parts = runs.map(r => kPath(s, r[0], r[1], Math.max(64, K_MAX_PATH * (r[1] - r[0] + 1) / nbT), act));
  let n = 0; const starts = []; for (const p of parts) { starts.push(n); n += p.n; }
  const k = [0, 1, 2].map(a => { const o = new Float64Array(n); parts.forEach((p, q) => o.set(p.k[a].subarray(0, p.n), starts[q])); return o; });
  return { n, k, starts, coarse: parts.some(p => p.coarse) };
}
function kStepGroup(d) { const L = kGroupCache && kGroupCache.list; if (!L || L.length < 2) return; const i = L.findIndex(g => g.id === S.kGroup), k = Math.max(0, Math.min(L.length - 1, i + d)); if (k !== i) { S.kGroup = L[k].id; kKey = null; requestK(); } }
$('#kNavPrev').onclick = () => kStepGroup(-1); $('#kNavNext').onclick = () => kStepGroup(1);
/* the trajectory into the k-space pixel buffer (1.45.0, on screen; a figure keeps vector lines). Before, it was one
   anti-aliased, half-transparent path of up to K_MAX_PATH vertices: zoomed out on a large file every readout line
   crosses the plot, tens of millions of pixels of stroke, and the browser took from 1 s (a 30-slice EPI) to 19 s
   (a million-block file) per redraw in a test browser. Here each segment is stepped pixel by pixel (DDA, about a line
   0.8 CSS px wide: round(0.8 × pixel ratio) pixels across) into a mask, and every covered pixel is shaded as the
   half-transparent path was (one stroke paints the area it covers once, at 0.45, however often it passes), and the
   samples are written over it. Points less than 0.6 px from the last drawn one are skipped, as before. The work is
   the length drawn: while the view is turned, zoomed or moved (kFast) at most about one canvas area of path
   (K_PATH_AREA_FAST) is drawn, otherwise up to K_PATH_AREA canvas areas; beyond that only every n-th segment is drawn
   (returned; said under the plot when the view is at rest). */
const K_PATH_AREA = 30, K_PATH_AREA_FAST = 1;
let kCnt = null;
function kPathRaster(buf, Wd, Hd, KT, p0, p1, PS, M, d, color) {
  const [cx, cy, r00, r01, r02, r10, r11, r12] = M, X = KT[0], Y = KT[1], Z = KT[2], tol = 0.6 * d;
  if (!kCnt || kCnt.length !== Wd * Hd) kCnt = new Uint8Array(Wd * Hd); // the mask (all zero between uses: the rows drawn are cleared after)
  // the kept vertices in device pixels (NaN x: a new piece starts)
  const n = p1 - p0, vx = new Float32Array(n), vy = new Float32Array(n); let m = 0, len = 0, lx = 0, ly = 0, ns = 1;
  for (let i = p0; i < p1; i++) {
    const x = (cx + r00 * X[i] + r01 * Y[i] + r02 * Z[i]) * d, y = (cy - (r10 * X[i] + r11 * Y[i] + r12 * Z[i])) * d;
    const brk = i === p0 || (ns < PS.length && i >= PS[ns]); if (brk && i > p0) while (ns < PS.length && i >= PS[ns]) ns++;
    if (brk) { vx[m] = NaN; vy[m] = 0; m++; vx[m] = x; vy[m] = y; m++; lx = x; ly = y; continue; }
    const dx = x > lx ? x - lx : lx - x, dy = y > ly ? y - ly : ly - y;
    if (dx + dy > tol || i === p1 - 1) { len += dx > dy ? dx : dy; vx[m] = x; vy[m] = y; m++; lx = x; ly = y; }
  }
  const th = Math.max(1, Math.round(0.8 * d)), h0 = th >> 1, stride = Math.max(1, Math.ceil(len * th / ((kFast ? K_PATH_AREA_FAST : K_PATH_AREA) * Wd * Hd)));
  const C8 = kCnt; let yMin = Hd, yMax = -1, seg = 0;
  for (let q = 1; q < m; q++) {
    if (vx[q] !== vx[q] || vx[q - 1] !== vx[q - 1]) continue;
    if (stride > 1 && (seg++ % stride)) continue;
    let x0 = vx[q - 1], y0 = vy[q - 1], x1 = vx[q], y1 = vy[q];
    // clip to the canvas (Liang-Barsky)
    let t0 = 0, t1 = 1; const ddx = x1 - x0, ddy = y1 - y0, P4 = [-ddx, ddx, -ddy, ddy], Q4 = [x0, Wd - 1 - x0, y0, Hd - 1 - y0]; let out = false;
    for (let k = 0; k < 4; k++) { const pk = P4[k], qk = Q4[k]; if (pk === 0) { if (qk < 0) { out = true; break; } } else { const r = qk / pk; if (pk < 0) { if (r > t1) { out = true; break; } if (r > t0) t0 = r; } else { if (r < t0) { out = true; break; } if (r < t1) t1 = r; } } }
    if (out) continue;
    const ax = x0 + ddx * t0, ay = y0 + ddy * t0, bx = x0 + ddx * t1, by = y0 + ddy * t1;
    const steps = Math.max(Math.abs(bx - ax), Math.abs(by - ay)) | 0, sx = steps ? (bx - ax) / steps : 0, sy = steps ? (by - ay) / steps : 0, horiz = Math.abs(bx - ax) >= Math.abs(by - ay);
    let x = ax + 0.5, y = ay + 0.5;
    for (let k = 0; k <= steps; k++, x += sx, y += sy) {
      const xi = x | 0, yi = y | 0;
      if (horiz) { for (let t = 0; t < th; t++) { const yy = yi - h0 + t; if (yy >= 0 && yy < Hd) C8[yy * Wd + xi] = 1; } if (yi - h0 < yMin) yMin = Math.max(0, yi - h0); if (yi - h0 + th - 1 > yMax) yMax = Math.min(Hd - 1, yi - h0 + th - 1); }
      else { const o = yi * Wd; for (let t = 0; t < th; t++) { const xx = xi - h0 + t; if (xx >= 0 && xx < Wd) C8[o + xx] = 1; } if (yi < yMin) yMin = yi; if (yi > yMax) yMax = yi; }
    }
  }
  // shade the covered pixels: the colour at 0.45
  const px = ((Math.round(0.45 * 255) << 24) | (hexU32(color) & 0xFFFFFF)) >>> 0;
  const oA = Math.max(0, yMin) * Wd, oB = (Math.min(Hd - 1, yMax) + 1) * Wd;
  for (let o = oA; o < oB; o++) if (C8[o]) buf[o] = px;
  if (oB > oA) C8.fill(0, oA, oB);
  return stride;
}
function drawK() {
  if (S.tab !== 'k' || KW <= 0 || !S.seq) return;
  const s = S.seq, R = S.kR;
  let j0 = 0, j1 = s.adcBlocks.length, pb0 = 0, pb1 = s.nb - 1, what = '';
  if (S.kRange !== 'view' && S.kRange !== 'vol') S.kRange = 'shot';
  if (S.kRange === 'view') { const va = vToT(S.t0), vb = vToT(S.t1); j0 = lb(s.adcT1, va); j1 = ub(s.adcT0, vb); pb0 = blockAt(va); pb1 = blockAt(vb); what = ' in the visible window'; }
  else if (S.kRange === 'vol' || S.kRange === 'shot') {
    const isV = S.kRange === 'vol', list = isV ? S.vols : s.shots;
    if (!list.length) { kctx.clearRect(0, 0, KW, KW); kKey = null; $('#kInfo').textContent = isV ? 'No volumes are marked. Choose a volume rule under Display, above the diagram.' : 'No shots: the sequence has no excitation pulses, or shot marking is off.'; return; }
    const k = S.sel >= 0 ? (isV ? volOfBlock(S.sel) : shotOfBlock(S.sel)) : (isV ? volAt : shotAt)(vcT()), it = list[k];
    pb0 = it.b0; pb1 = it.b1; j0 = lb(s.adcBlocks, pb0); j1 = lb(s.adcBlocks, pb1 + 1);
    what = ` in ${isV ? 'volume' : 'shot'} ${k + 1} of ${list.length}`;
  }
  if (j1 < j0) j1 = j0;
  const gi = kGroupInfo(j0, j1, pb0, pb1), gs0 = gi.groups;
  // each kind of readout in acquisition-order colours, then a last view of all readouts together, coloured by group
  // (kind, and image for imaging); also with one kind, where it tells the images apart
  const gs = gs0.length ? gs0.concat([{ id: 'all', label: 'All readouts, by type', all: true, n: s.adcOff[j1] - s.adcOff[j0] }]) : gs0;
  if (gs.length && !gs.some(g => g.id === S.kGroup)) S.kGroup = gs[0].id;
  kGroupCache.list = gs;
  const grp0 = gs.find(g => g.id === S.kGroup) || null, gIdx = grp0 ? gs.indexOf(grp0) : -1, allMode = !!(grp0 && grp0.all), grp = allMode ? null : grp0;
  { const nav = $('#kNav'); nav.hidden = !gs.length;
    if (!nav.hidden) { $('#kNavTxt').textContent = `${grp0.label} · ${gIdx + 1} / ${gs.length}`; $('#kNavPrev').disabled = gIdx <= 0; $('#kNavNext').disabled = gIdx >= gs.length - 1; } }
  const act = S.kActual; if (act) ccEnsure();
  const dk = j0 + ',' + j1 + ',' + pb0 + ',' + pb1 + ',' + (grp0 ? grp0.id : '') + (act ? '|act|' + s.cc.key : '');
  if (!kData || kData.key !== dk) {
    const total = grp0 ? grp0.n : s.adcOff[j1] - s.adcOff[j0];
    if (total > 2e5 && !kData_busy) { // let the page paint a message before a large computation
      kData_busy = true; $('#kInfo').textContent = `Computing k-space for ${total.toLocaleString()} ADC samples…`;
      setTimeout(() => { kKey = null; drawK(); kData_busy = false; }, 30); return;
    }
    let smp = kSamples(s, grp ? grp.jf : j0, grp ? grp.jl + 1 : j1, K_MAX_PTS, false, act ? ktInBlock : kInBlock);
    if (grp && gs0.length > 1) { // keep the shown kind only (with its ADC-event map, for hovering)
      let n2 = 0; const keep = []; for (let e = 0; e < smp.ej.length; e++) if (grp.fj(smp.ej[e])) { keep.push(e); n2 += smp.eo[e + 1] - smp.eo[e]; }
      const k2 = [new Float32Array(n2), new Float32Array(n2), new Float32Array(n2)], t2 = new Uint8Array(n2), ej = new Int32Array(keep.length), eo = new Int32Array(keep.length + 1); let o = 0;
      keep.forEach((e, q) => { const a = smp.eo[e], b = smp.eo[e + 1]; for (let c = 0; c < 3; c++) k2[c].set(smp.k[c].subarray(a, b), o); t2.set(smp.type.subarray(a, b), o); ej[q] = smp.ej[e]; eo[q] = o; o += b - a; });
      eo[keep.length] = o; smp = { n: n2, k: k2, type: t2, t: null, thinned: smp.thinned, ej, eo };
    }
    const path = grp ? kPathRuns(s, grp.runs, act) : kPath(s, pb0, pb1, K_MAX_PATH, act);
    let mm = 0; const arr = smp.n ? smp.k : path.k, nn = smp.n || path.n;
    for (let a = 0; a < 3; a++) { const c = arr[a]; for (let i = 0; i < nn; i++) { const v = c[i] < 0 ? -c[i] : c[i]; if (v > mm) mm = v; } }
    kData = { key: dk, smp, path, m: mm > 0 ? mm : 1, total };
    if (allMode) kData.sub = kSubgroups(smp);
  }
  const K = { kA: kData.smp.k, kT: kData.path.k, type: kData.smp.type }, a0 = 0, a1 = kData.smp.n, p0 = 0, p1 = kData.path.n;
  const key = [kFast, dk, R.map(r => r.join(',')).join(';'), S.kZoom, S.kPan.join(','), S.kTraj, KW, dpr, C.plot, C.muted, S.echo.se, S.echo.gf, S.echo.gl].join('|');
  if (key === kKey) return;
  kKey = key; kHoverHide(); // the samples move: the hovered one is found again at the next pointer move
  const ctx = kctx; ctx.clearRect(0, 0, KW, KW);
  const n = a1 - a0, m = kData.m;
  const cx = KW / 2 + S.kPan[0], cy = KW / 2 + S.kPan[1], sc = (KW / 2 - 26) / m * S.kZoom; // k = 0 at (cx, cy): moved by panning
  const r00 = R[0][0] * sc, r01 = R[0][1] * sc, r02 = R[0][2] * sc, r10 = R[1][0] * sc, r11 = R[1][1] * sc, r12 = R[1][2] * sc;
  const P = (x, y, z) => [cx + r00 * x + r01 * y + r02 * z, cy - (r10 * x + r11 * y + r12 * z)];
  // axes
  ctx.strokeStyle = C.line; ctx.lineWidth = 1;
  const axes = [['kx', 'gx', [1, 0, 0]], ['ky', 'gy', [0, 1, 0]], ['kz', 'gz', [0, 0, 1]]];
  ctx.setLineDash([3, 4]);
  if (!EXP || EXP.kAxes) for (const [, , d] of axes) { const [xa, ya] = P(-d[0] * m, -d[1] * m, -d[2] * m), [xb, yb] = P(d[0] * m, d[1] * m, d[2] * m); if (Math.hypot(xb - xa, yb - ya) < 4) continue; ctx.beginPath(); ctx.moveTo(xa, ya); ctx.lineTo(xb, yb); ctx.stroke(); }
  ctx.setLineDash([]);
  // the canvas-sized pixel buffer for the samples and (on screen) the trajectory
  const Wd = kc.width, Hd = kc.height;
  const needBuf = n > 0 || (!EXP && S.kTraj && p1 > p0);
  let buf = null, bufPut = false, echoNote = '', echoDone = false;
  // on screen the echo markers go into the buffer too, over the samples, just before it is copied onto the canvas
  const putBuf = () => { if (buf && !bufPut) { if (!EXP) { echoNote = stampEchoesK({ buf, Wd, Hd, d: dpr }, P, pb0, pb1, grp); echoDone = true; } kOff.getContext('2d').putImageData(kImg, 0, 0); ctx.drawImage(kOff, 0, 0, KW, KW); bufPut = true; } };
  if (needBuf) {
    if (!kOff || kOff.width !== Wd || kOff.height !== Hd) { kOff = document.createElement('canvas'); kOff.width = Wd; kOff.height = Hd; kImg = kOff.getContext('2d').createImageData(Wd, Hd); }
    buf = new Uint32Array(kImg.data.buffer); buf.fill(0);
  }
  let trajThin = 1;
  if (!EXP && S.kTraj && p1 > p0) trajThin = kPathRaster(buf, Wd, Hd, K.kT, p0, p1, kData.path.starts || [0], [cx, cy, r00, r01, r02, r10, r11, r12], dpr, C.muted);
  // a figure: the path as vector lines, simplified in screen space (points closer than ~0.6 px to the last drawn one are skipped)
  else if (S.kTraj && p1 > p0) {
    const X = K.kT[0], Y = K.kT[1], Z = K.kT[2], tol = kFast ? 2 : 0.6;
    ctx.beginPath();
    let lx = cx + r00 * X[p0] + r01 * Y[p0] + r02 * Z[p0], ly = cy - (r10 * X[p0] + r11 * Y[p0] + r12 * Z[p0]);
    ctx.moveTo(lx, ly);
    const ps = kFast ? Math.max(1, Math.ceil((p1 - p0) / 2e5)) : 1, PS = kData.path.starts || [0]; let ns = 1; // pieces: a move to each start
    for (let i = p0 + 1; i < p1; i += ps) {
      const x = cx + r00 * X[i] + r01 * Y[i] + r02 * Z[i], y = cy - (r10 * X[i] + r11 * Y[i] + r12 * Z[i]);
      if (ns < PS.length && i >= PS[ns]) { while (ns < PS.length && i >= PS[ns]) ns++; ctx.moveTo(x, y); lx = x; ly = y; continue; }
      if ((x > lx ? x - lx : lx - x) + (y > ly ? y - ly : ly - y) > tol || i === p1 - 1 || (ns < PS.length && i + ps >= PS[ns])) { ctx.lineTo(x, y); lx = x; ly = y; }
    }
    ctx.strokeStyle = C.muted; ctx.globalAlpha = 0.45; ctx.lineWidth = EXP ? EXP.lwCss * 0.6 : 0.8; ctx.stroke(); ctx.globalAlpha = 1;
  }
  // ADC points into a device-pixel buffer
  let thinned = kData.smp.thinned;
  if (kHit) kHit.n = 0;
  if (n > 0) {
    if (!kLut) buildLut();
    const step = Math.max(1, Math.ceil(n / (kFast ? 2e5 : K_MAX_PTS))); if (step > 1 && !kFast) thinned = true;
    const cnt = n / step, d = dpr, X = K.kA[0], Y = K.kA[1], Z = K.kA[2], inv = 255 / Math.max(1, n - 1);
    // project once: device coordinates of the samples inside the canvas (kept for finding the hovered sample)
    if (!kHit || kHit.x.length < cnt + 1) kHit = { x: new Float32Array(cnt + 1), y: new Float32Array(cnt + 1), i: new Int32Array(cnt + 1), n: 0, r: 1 };
    const HX = kHit.x, HY = kHit.y, HI = kHit.i; let nv = 0;
    for (let i = a0; i < a1; i += step) {
      const fx = (cx + r00 * X[i] + r01 * Y[i] + r02 * Z[i]) * d, fy = (cy - (r10 * X[i] + r11 * Y[i] + r12 * Z[i])) * d;
      if (fx < 0 || fy < 0 || fx >= Wd || fy >= Hd) continue;
      HX[nv] = fx; HY[nv] = fy; HI[nv] = i; nv++;
    }
    kHit.n = nv;
    // dot size: at least as before (from the number of samples), and larger when few samples are in view (zoomed in):
    // 0.3 × the side of the canvas area per visible sample, at most 6 px. Large dots are round.
    const base = Math.max(1, Math.round((cnt > 40000 ? 1 : cnt > 4000 ? 1.6 : 2.4) * d));
    // (all-readouts view: per sample of the largest group, as groups such as the echoes of one line lie on each other)
    const nvG = allMode && kData.sub ? nv * Math.max(...kData.sub.list.map(g => g.n)) / Math.max(1, n) : nv;
    const rs = Math.max(base, Math.min(Math.round(6 * d), Math.round(0.3 * Math.sqrt(Wd * Hd / Math.max(1, nvG)))));
    kHit.r = rs / d;
    const stamp = r2 => { const o = []; const c = (r2 - 1) / 2, rr = r2 * r2 / 4 + 0.25; for (let yy = 0; yy < r2; yy++) for (let xx = 0; xx < r2; xx++) if (r2 < 4 || (xx - c) ** 2 + (yy - c) ** 2 <= rr) o.push(yy * Wd + xx); return Int32Array.from(o); };
    const SG = allMode && kData.sub ? kData.sub : null, SUB = SG ? SG.sub : null;
    const SC = SG ? SG.list.map(g => hexU32(g.col[0] === '#' ? g.col : C[g.col])) : null, LAY = SG ? SG.list.map(g => g.layer) : null;
    // by group (all-readouts view): in layers, images, reference, noise, then navigators last and larger (non-imaging
    // samples a bit larger), so a navigator line stays visible on reference lines
    // images (layer 0) are drawn as if translucent: where a sample lands on one of another image (echoes or slices
    // covering the same k-space) the two colours mix half and half, so both show; on empty canvas or its own colour a
    // sample is opaque, so a lone image keeps its full colour
    const nPass = SG ? 4 : 1, over = (d, c) => {
      if (!(d >>> 24) || d === c) return c;
      return (255 << 24 | ((d >> 16 & 255) + (c >> 16 & 255) + 1) >> 1 << 16 | ((d >> 8 & 255) + (c >> 8 & 255) + 1) >> 1 << 8 | ((d & 255) + (c & 255) + 1) >> 1) >>> 0;
    };
    for (let pass = 0; pass < nPass; pass++) {
      const blend = !!SG && pass === 0;
      const r2 = rs + (pass === 3 ? 2 * Math.ceil(d) : pass ? Math.ceil(d) : 0), hh = r2 >> 1, st = stamp(r2), ns = st.length;
      for (let v = 0; v < nv; v++) {
        const i = HI[v]; if (SG && LAY[SUB[i]] !== pass) continue;
        const px = (HX[v] | 0) - hh, py = (HY[v] | 0) - hh;
        if (px < 0 || py < 0 || px + r2 > Wd || py + r2 > Hd) continue;
        const col = SG ? SC[SUB[i]] : kLut[(i - a0) * inv | 0], o = py * Wd + px;
        if (blend) for (let q = 0; q < ns; q++) buf[o + st[q]] = over(buf[o + st[q]], col);
        else for (let q = 0; q < ns; q++) buf[o + st[q]] = col;
      }
    }
    putBuf();
    if (SG) {
      const colOf = g => g.col[0] === '#' ? g.col : C[g.col];
      ctx.save(); ctx.setLineDash([5, 4]); ctx.lineWidth = 1.2;
      // the box of each group in k-space (its range of kx, ky, kz), projected as the samples are, so it turns with the view
      const pad = 0.03 * m; // a little outside the samples (3 % of the plot's k range), so the box does not hide under them
      if (!EXP || EXP.kBoxes) SG.list.forEach(g => { const b0 = g.bb; if (!b0 || !(b0[3] >= b0[0])) return; const b = [b0[0] - pad, b0[1] - pad, b0[2] - pad, b0[3] + pad, b0[4] + pad, b0[5] + pad]; ctx.strokeStyle = colOf(g); ctx.globalAlpha = 0.7; ctx.beginPath();
        const c = q => P(q & 1 ? b[3] : b[0], q & 2 ? b[4] : b[1], q & 4 ? b[5] : b[2]);
        for (const [u, w] of [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]]) { const A = c(u), Bq = c(w); ctx.moveTo(A[0], A[1]); ctx.lineTo(Bq[0], Bq[1]); }
        ctx.stroke(); });
      ctx.restore();
      ctx.font = `500 11px ${C.font}`; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      if (!EXP || EXP.kLegend) SG.list.slice(0, 12).forEach((g, k) => { const y = 14 + k * 15; ctx.globalAlpha = 0.85; ctx.fillStyle = C.plot; const t = `${g.label} · ${g.n.toLocaleString()}`, w = ctx.measureText(t).width; ctx.fillRect(6, y - 7, w + 22, 14);
        ctx.globalAlpha = 1; ctx.fillStyle = colOf(g); ctx.fillRect(9, y - 4, 9, 9); ctx.fillStyle = C.ink; ctx.fillText(t, 23, y); });
      if (SG.list.length > 12 && (!EXP || EXP.kLegend)) { ctx.fillStyle = C.muted; ctx.fillText(`… ${SG.list.length - 12} more groups`, 9, 14 + 12 * 15); }
    }
  }
  putBuf(); // the trajectory alone (no samples in range)
  if (!EXP && !echoDone) echoNote = drawEchoesK(ctx, P, pb0, pb1, grp); // no buffer (nothing else drawn): as paths
  // gizmo
  const gx0 = 34, gy0 = KW - 34; ctx.font = `600 11px ${C.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  if (!EXP || EXP.kAxes) for (const [lab, col, d] of axes) {
    const vx = R[0][0] * d[0] + R[0][1] * d[1] + R[0][2] * d[2], vy = R[1][0] * d[0] + R[1][1] * d[1] + R[1][2] * d[2];
    if (Math.hypot(vx, vy) < 0.08) continue;
    ctx.strokeStyle = C[col]; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(gx0, gy0); ctx.lineTo(gx0 + vx * 20, gy0 - vy * 20); ctx.stroke();
    ctx.fillStyle = C[col]; ctx.fillText(lab, gx0 + vx * 29, gy0 - vy * 29);
  }
  ctx.fillStyle = C.muted; ctx.textAlign = 'right'; ctx.font = `400 11px ${C.font}`;
  if (!EXP || EXP.kRange) ctx.fillText(`|k| ≤ ${fmt(m / S.kZoom, 4)} m⁻¹`, KW - 10, KW - 12);
  if (EXP) return; // a figure: not the page's texts
  const kTxt = n ? `${kData.total.toLocaleString()} ${grp && gs0.length > 1 ? grp.label.split(' ')[0].toLowerCase() + ' ' : ''}ADC samples${what}${allMode ? ', all kinds, coloured by group (not by time)' : ''}${thinned ? ` (${Math.min(n, kFast ? 2e5 : K_MAX_PTS).toLocaleString()} shown)` : ''}${trajThin > 1 && !kFast ? `; trajectory: every ${trajThin === 2 ? 'second' : trajThin + 'th'} segment drawn` : ''}. Max |k| component ${fmt(m, 4)} m⁻¹ (≈ ${fmt(1e3 / (2 * m), 3)} mm resolution).` : 'No ADC samples in range.';
  // phase-encoding lines of the image of the selected shot (or the shot at the view centre)
  let kLines = ''; if (n && s.shots.length) { const k = S.sel >= 0 ? shotOfBlock(S.sel) : shotAt(vcT()), im = k >= 0 ? shotImage(k) : null;
    const ec = grp && /^img\d+$/.test(grp.id) ? +grp.id.slice(3) - 1 : 0; // an echo's group: that echo's image
    if (im) { const l = imageLines(im.vol, im.ref, ec); if (l) kLines = `Image of shot ${im.ref + 1}${S.vols.length ? ` (volume ${volOfBlock(s.shots[im.ref].b0) + 1})` : ''}${gs0.some(g => g.id === 'img2') ? `, echo ${ec + 1}` : ''}: ${linesText(l).replace(/^Phase encoding: /, '')}`; } }
  $('#kInfo').innerHTML = (act ? '<b>Actual (k + kc)</b> · ' : '') + esc(kTxt) + (kLines ? '<br>' + esc(kLines) : '') + (echoNote ? '<br>' + esc(echoNote) : '');
  kLast = performance.now();
}
/* hovered sample: the nearest drawn sample within 8 px (or the dot radius) of the pointer gets a ring and a short
   description; the diagram's cursor moves to its time */
kTip = document.createElement('div'); kRing = document.createElement('div');
kTip.className = 'ktip num'; kRing.className = 'kring'; kTip.hidden = kRing.hidden = true;
kc.parentElement.append(kRing, kTip);
function kHoverHide() { if (!kTip || (kHoverI < 0 && kTip.hidden)) return; kHoverI = -1; kTip.hidden = kRing.hidden = true; if (S.tab === 'k' && S.seq) { S.hoverT = null; requestOverlay(); } }
function kHover(ex, ey) {
  if (!kHit || !kHit.n || !kData || !S.seq) { kHoverHide(); return; }
  const d = dpr, x = ex * d, y = ey * d, R = Math.max(8, kHit.r / 2 + 3) * d; let best = -1, bd = R * R;
  for (let v = 0; v < kHit.n; v++) { const dx = kHit.x[v] - x, dy = kHit.y[v] - y, q = dx * dx + dy * dy; if (q < bd) { bd = q; best = v; } }
  if (best < 0) { kHoverHide(); return; }
  const i = kHit.i[best], smp = kData.smp, s = S.seq, B = s.B;
  let lo = 0, hi = smp.ej.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (smp.eo[m] <= i) lo = m; else hi = m - 1; }
  const j = smp.ej[lo], q = i - smp.eo[lo], b = s.adcBlocks[j], ad = s.adc.get(B.adc[b]), t = s.blockStart[b] + ad.delay + (q + 0.5) * ad.dwell;
  const k = shotOfBlock(b), sh = k >= 0 ? s.shots[k] : null;
  let tE = null; if (sh) for (let c = b; c >= sh.b0; c--) if (B.rf[c]) { const st = rfSt(s, B.rf[c]); if (st.use === 'e') { tE = s.blockStart[c] + st.center; break; } }
  const lab = labelState(b), labs = s.labels.filter(L => !L.flag || lab[L.name]).map(L => `${L.name} ${lab[L.name] ?? 0}`).join(' · ');
  kTip.innerHTML = `<b>Sample ${q + 1}</b> / ${ad.num} · ADC ${sh ? `${j - sh.j0 + 1} / ${sh.nADC} · shot ${k + 1}` : ''} · block ${B.id[b]}<br>` +
    `t ${fmt(t * 1e3, 6)} ms${tE !== null ? ` (${fmt((t - tE) * 1e3, 4)} ms after excitation)` : ''}<br>` +
    `k ${[0, 1, 2].map(a => fmt(smp.k[a][i], 4)).join(', ')} m⁻¹ · ${TYPE_NAME[s.adcType[j]]}` + (labs ? `<br>${esc(labs)}` : '');
  const px = kHit.x[best] / d, py = kHit.y[best] / d, rr = Math.max(5, kHit.r / 2 + 3);
  kRing.style.cssText = `left:${px - rr}px;top:${py - rr}px;width:${2 * rr}px;height:${2 * rr}px`;
  kTip.hidden = kRing.hidden = false;
  const tw = kTip.offsetWidth, th = kTip.offsetHeight; // beside the sample, flipped to stay inside the plot
  kTip.style.left = `${px + 12 + tw > KW ? Math.max(2, px - 12 - tw) : px + 12}px`; kTip.style.top = `${py + 12 + th > KW ? Math.max(2, py - 12 - th) : py + 12}px`;
  kHoverI = i; S.hoverT = t; requestOverlay();
}
let kDrag = null, kHoverPos = null;
kc.addEventListener('pointerdown', e => { kc.setPointerCapture(e.pointerId); kDrag = { x: e.offsetX, y: e.offsetY, pan: e.button === 2 }; kc.style.cursor = kDrag.pan ? 'move' : 'grabbing'; kHoverHide(); });
kc.addEventListener('contextmenu', e => e.preventDefault()); // right-drag pans
kc.addEventListener('pointerleave', () => { kHoverPos = null; if (!kDrag) kHoverHide(); });
kc.addEventListener('pointermove', e => {
  if (!kDrag) { // one search per frame (it runs over all drawn samples, up to K_MAX_PTS)
    if (e.pointerType !== 'mouse') return;
    const first = !kHoverPos; kHoverPos = [e.offsetX, e.offsetY];
    if (first) requestAnimationFrame(() => { const p = kHoverPos; kHoverPos = null; if (p && !kDrag) kHover(p[0], p[1]); });
    return;
  }
  const dx = e.offsetX - kDrag.x, dy = e.offsetY - kDrag.y; kDrag.x = e.offsetX; kDrag.y = e.offsetY;
  if (kDrag.pan) { kPanBy(dx, dy); kFast = true; requestK(); return; } // right-drag: move the view, keep the projection
  S.kR = mul(rx(dy * 0.01), mul(ry(dx * 0.01), S.kR)); kFast = true;
  if (S.kProj !== '3d') { S.kProj = '3d'; $('#kProj').querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', b.dataset.v === '3d')); }
  requestK();
});
/* pan (CSS px, offset of k = 0 from the canvas centre), kept within the data's extent on screen so it cannot be lost */
function kPanBy(dx, dy) { const L = Math.max(0, (KW / 2 - 26) * S.kZoom); S.kPan = [Math.max(-L, Math.min(L, S.kPan[0] + dx)), Math.max(-L, Math.min(L, S.kPan[1] + dy))]; }
function kSettle() { if (kFast) { kFast = false; requestK(); } }
const kUp = () => { kDrag = null; kc.style.cursor = ''; kSettle(); };
kc.addEventListener('pointerup', kUp); kc.addEventListener('pointercancel', kUp);
kc.addEventListener('wheel', e => { e.preventDefault(); kHoverHide(); const z0 = S.kZoom; S.kZoom = Math.min(50, Math.max(0.2, S.kZoom * Math.exp(-e.deltaY * 0.002)));
  S.kPan = [S.kPan[0] * S.kZoom / z0, S.kPan[1] * S.kZoom / z0]; kPanBy(0, 0); /* zoom about the canvas centre: the k there stays */ kFast = true; clearTimeout(kFastTimer); kFastTimer = setTimeout(kSettle, 160); requestK(); }, { passive: false });

/* ---------- simulated image ---------- */
let imgRes = null, imgKey = null, imgRun = 0, imgTimer = null, imgLoadId = 0;
/* recent images: stepping back to a volume or echo just seen is instant (up to 12 images, ~300 MB) */
const imgCache = new Map();
function resBytes(r) { let n = 0; const add = a => { if (a && a.byteLength) n += a.byteLength; }; if (r.img) { add(r.img.re); add(r.img.im); } if (r.kspace) { add(r.kspace.re); add(r.kspace.im); } add(r.mask); return n; }
function cachePut(key, r) {
  if (r.error) return; imgCache.set(key, r);
  let total = 0; for (const v of imgCache.values()) total += resBytes(v);
  while (imgCache.size > 12 || (total > 3e8 && imgCache.size > 1)) { const k = imgCache.keys().next().value; total -= resBytes(imgCache.get(k)); imgCache.delete(k); }
}
function imgReset() { imgRes = null; imgKey = null; imgRun++; imgLoadId++; imgCache.clear(); drawImg(); }
function syncSimControls() {
  const d = S.sim;
  segPress('#simPhantom', d.phantom); segPress('#simFill', d.fill ? 'fill' : 'zero'); segPress('#simCrop', d.crop === false ? 'all' : 'crop'); segPress('#imView', d.view);
  $('#simB0').value = String(d.B0); $('#simOrient').value = d.orient; $('#simEddy').value = d.eddy;
  for (const [id, k] of [['simT1', 't1'], ['simT2', 't2'], ['simFat', 'fatShift'], ['simDiff', 'diffusion'], ['simBubble', 'bubble'], ['simNoise', 'noise'], ['simSlicePos', 'slicePos'], ['sim3d', 'show3d']]) $('#' + id).checked = d[k];
  $('.v3wrap').style.display = d.show3d ? '' : 'none';
  imSummary();
}
/* one-line summary of the simulation options, shown while they are folded away */
function imSummary() {
  const d = S.sim, el = $('#imSum'); if (!el) return;
  const c = [d.t1 && 'T1', d.t2 && 'T2', d.fatShift && 'fat', d.diffusion && 'diffusion'].filter(Boolean);
  const a = [d.bubble && 'air bubble', d.noise && 'noise', d.eddy !== 'off' && `${d.eddy === 'poor' ? 'poor' : 'typical'} eddy currents`].filter(Boolean);
  el.textContent = [`${d.phantom === 'head' ? 'Head' : 'Abdomen'} at ${d.B0} T`, ({ ax: 'axial', cor: 'coronal', sag: 'sagittal' }[d.orient] || d.orient) + (d.slicePos ? '' : ' through the bubble'),
    c.length ? c.join(', ') : 'no contrast effects', ...(a.length ? [a.join(', ')] : []), d.fill ? 'ideal recon' : 'zero-filled recon', ...(d.crop === false ? ['oversampled FOV shown'] : [])].join('; ');
  el.hidden = !$('#imOpts').hidden;
}
syncSimControls();
segSet('#simPhantom', 'x', v => { S.sim.phantom = v; requestImg(true); });
segSet('#simFill', 'x', v => { S.sim.fill = v === 'fill'; requestImg(true); });
segSet('#simCrop', 'x', v => { S.sim.crop = v === 'crop'; drawImg(); drawSlice3D(); imSummary(); }); // display only: no new simulation
segSet('#imView', 'x', v => { S.sim.view = v; drawImg(); });
$('#simB0').onchange = e => { S.sim.B0 = +e.target.value; requestImg(true); };
$('#simOrient').onchange = e => { S.sim.orient = e.target.value; requestImg(true); };
$('#simEddy').onchange = e => { S.sim.eddy = e.target.value; requestImg(true); };
for (const [id, k] of [['simT1', 't1'], ['simT2', 't2'], ['simFat', 'fatShift'], ['simDiff', 'diffusion'], ['simBubble', 'bubble'], ['simNoise', 'noise'], ['simSlicePos', 'slicePos']])
  $('#' + id).onchange = e => { S.sim[k] = e.target.checked; requestImg(true); };
$('#sim3d').onchange = e => { S.sim.show3d = e.target.checked; $('.v3wrap').style.display = S.sim.show3d ? '' : 'none'; I3W = I3H = 0; resize(); if (S.sim.show3d) drawSlice3D(); };
const echoStep = d => { if (!imgRes || !imgRes.nEcho) return; const e = Math.max(0, Math.min(imgRes.nEcho - 1, (imgRes.echo || 0) + d)); if (e !== imgRes.echo) { S.sim.echo = e; requestImg(true); } };
$('#imEchoPrev').onclick = () => echoStep(-1); $('#imEchoNext').onclick = () => echoStep(1);
const imStep = d => { const L = imgList(); if (!L || L.length < 2) return; const i = Math.max(0, Math.min(L.length - 1, S.imgIdx + d)); if (i !== S.imgIdx) { S.imgIdx = i; updateImNav(); requestImg(true); } };
$('#imNavPrev').onclick = () => imStep(-1); $('#imNavNext').onclick = () => imStep(1);
function updateImNav() { // arrows between the images of a selection of several shots or volumes
  const L = S.tab === 'img' ? imgList() : null, nav = $('#imNav'); nav.hidden = !L || L.length < 2; if (nav.hidden) return;
  const i = Math.max(0, Math.min(L.length - 1, S.imgIdx)), it = L[i];
  $('#imNavTxt').textContent = `Image ${i + 1} / ${L.length}${L.length >= IMG_LIST_MAX ? '+' : ''} · ${it.vi >= 0 ? `volume ${it.vi + 1} · ` : ''}shot ${it.ref + 1}`;
  $('#imNavPrev').disabled = i <= 0; $('#imNavNext').disabled = i >= L.length - 1;
}
$('#imPng').onclick = () => { if (imgRes && !imgRes.error) savePNG(ic, `${S.name.replace(/\.(seq|bin)$/i, '')}_image.png`); };
/* which image: the selected volume (or the one at the view centre), slice of the selected shot */
/* the images in a selection of several shots or volumes, in time order: one per volume and excited slice (the
   shots of a volume whose excitation has the same frequency and orientation, as imageSet groups them), with its first shot with
   an imaging readout as reference. Several selected shots of the same image count once. Cached per selection. */
let imgListCache = null;
const IMG_LIST_MAX = 2000;
function imgList() {
  const s = S.seq; if (!s || S.sel < 0 || (S.selKind !== 'vol' && S.selKind !== 'shot') || !s.shots.length) return null;
  const items = [...selSet()]; if (S.selKind === 'shot' && items.length < 2) return null;
  const key = [S.selKind, items.join(','), S.vols.length, S.sim.B0].join('|');
  if (imgListCache && imgListCache.key === key) return imgListCache.list;
  const shots = s.shots, B = s.B, out = [], seen = new Set();
  const freqOf = k => sliceKey(s, shots, k, S.sim.B0); // the slice: frequency and orientation, as imageSet
  const imaging = k => { const sh = shots[k]; for (let j = sh.j0; j < sh.j1; j++) if (s.adcType[j] === 0 || s.adcType[j] === 2) return true; return false; };
  const volOf = k => S.vols.length ? volOfBlock(shots[k].b0) : -1;
  const add = (k, vi) => { const f = freqOf(k); if (f === null) return; const id = vi + '|' + f; if (seen.has(id)) return; seen.add(id); out.push({ ref: k, vi }); };
  if (S.selKind === 'vol') for (const vi of items) {
    const v = S.vols[vi]; if (!v) continue; let any = false;
    for (let k = v.s0; k <= v.s1 && out.length < IMG_LIST_MAX; k++) if (shots[k].nADC && imaging(k)) { add(k, vi); any = true; }
    if (!any) for (let k = v.s0; k <= v.s1 && out.length < IMG_LIST_MAX; k++) if (shots[k].nADC) add(k, vi);
  } else for (const k of items) if (shots[k] && shots[k].nADC && out.length < IMG_LIST_MAX) add(k, volOf(k));
  imgListCache = { key, list: out }; S.imgIdx = 0;
  return out;
}
function imgTarget() {
  const s = S.seq; if (!s) return null;
  const shots = s.shots.length ? s.shots : (s.shotsExc || []); if (!shots.length) return null;
  const L = imgList();
  if (L && L.length) { // an image of a multiple selection
    const it = L[Math.max(0, Math.min(L.length - 1, S.imgIdx))];
    const vol = it.vi >= 0 ? S.vols[it.vi] : { s0: it.ref, s1: it.ref };
    return { shots, vol, vi: it.vi, ref: it.ref, list: L };
  }
  const c = vcT(), blk = S.sel >= 0 ? S.sel : blockAt(c);
  const shotIdx = b => { let lo = 0, hi = shots.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (shots[m].b0 <= b) lo = m; else hi = m - 1; } return lo; };
  let vol, vi = -1;
  if (S.vols.length) { vi = S.sel >= 0 ? volOfBlock(S.sel) : volAt(c); vol = S.vols[vi]; }
  else { const k = shotIdx(blk); vol = { s0: k, s1: k }; }
  let ref = shotIdx(blk);
  // a specific shot (selected, or at the view centre) without a readout, e.g. a dummy scan: nothing to reconstruct
  if (S.selKind !== 'vol' && ref >= vol.s0 && ref <= vol.s1 && !shots[ref].nADC) return { dummy: ref };
  if (ref < vol.s0 || ref > vol.s1 || !shots[ref].nADC) { ref = -1; for (let k = vol.s0; k <= vol.s1; k++) if (shots[k].nADC) { const sh = shots[k]; for (let j = sh.j0; j < sh.j1; j++) if (s.adcType[j] === 0 || s.adcType[j] === 2) { ref = k; break; } if (ref >= 0) break; } }
  if (ref < 0) for (let k = vol.s0; k <= vol.s1; k++) if (shots[k].nADC) { ref = k; break; }
  if (ref < 0) return { none: true };
  return { shots, vol, vi, ref };
}
function requestImg(now) {
  if (S.tab !== 'img' || !S.seq) return;
  updateImNav();
  clearTimeout(imgTimer); imgTimer = setTimeout(computeImg, now ? 0 : 200);
}
async function computeImg() {
  const T = imgTarget();
  if (!T) { if (S.seq && !imgRes) { imgRes = { error: 'No image: the sequence has no excitation pulses, so there are no shots to simulate.' }; imgKey = null; drawImg(); } return; }
  if (T.none) { imgRes = { error: 'This volume has no readout (no ADC events): there is no data to reconstruct.' }; imgKey = null; drawImg(); return; }
  if (T.dummy !== undefined) { imgRes = { error: `Shot ${T.dummy + 1} has no readout (no ADC events), e.g. a dummy scan: there is no data to reconstruct. Select a shot with a readout, or the whole volume.` }; imgKey = null; drawImg(); return; }
  const opt = { ...S.sim, bubbleField: true, noise: S.sim.noise ? 1 : 0 }; delete opt.view; delete opt.show3d;
  const key = [imgLoadId, T.vol.s0, T.vol.s1, T.ref, JSON.stringify(opt)].join('|');
  if (key === imgKey) { v3Request(); return; } // same image; the selection may have changed (outlines in the 3D view)
  if (imgCache.has(key)) { const r = imgCache.get(key); imgCache.delete(key); imgCache.set(key, r); imgRun++; poolCancel(); imgRes = r; imgKey = key; $('#imBusy').classList.remove('on'); drawImg(); return; }
  if (!SIM_POOL && poolInit()) SIM_POOL = poolRun;
  if (!SIM_GPU && S.sim.gpu !== false && SIMGL.available()) SIM_GPU = SIMGL.run; // the graphics card, when there is a real one
  poolCancel();
  imgKey = key; const run = ++imgRun, start = performance.now(); let lastYield = start;
  $('#imBusy').classList.add('on'); $('#imBusyTxt').textContent = 'Simulating…';
  try {
    const res = await runSimulation(S.seq, T.shots, T.vol, T.ref, opt, async p => {
      if (run !== imgRun) throw new Error('cancelled');
      const now = performance.now();
      if (now - lastYield > 40) { $('#imBusyTxt').textContent = `Simulating… ${Math.round(p * 100)}%`; await new Promise(r => setTimeout(r, 0)); lastYield = performance.now(); if (run !== imgRun) throw new Error('cancelled'); }
    });
    if (run !== imgRun) return;
    res.target = T; imgRes = res; cachePut(key, res);
  } catch (e) {
    if (e.message === 'cancelled') return;
    console.error(e); imgRes = { error: 'Simulation failed: ' + e.message };
  } finally { if (run === imgRun) $('#imBusy').classList.remove('on'); }
  drawImg();
}
/* scout: the phantom in the plane spanned by the slice normal (horizontal) and the image's vertical axis,
   with the slice drawn as a band at its position and thickness */
const SCOUT_GRAY = { fat: 0.95, wm: 0.62, gm: 0.45, csf: 0.22, lesion: 0.8, blood: 0.7, muscle: 0.4, liver: 0.5, kidney: 0.58, fluid: 0.28, marrow: 0.75, air: 0 };
function drawScout(ctx, R, x, y, size) {
  const g = R.geom, N = 80, span = 240;
  if (!R.scout) {
    const P3 = build3D(R.phantomKey, R.bubbleOn), c = document.createElement('canvas'); c.width = c.height = N;
    const cc = c.getContext('2d'), id = cc.createImageData(N, N), off = dot3(g.o, g.e1);
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const a = (i + 0.5) / N * span - span / 2, b = span / 2 - (j + 0.5) / N * span;
      const p = [0, 1, 2].map(k => a * g.n[k] + b * g.e2[k] + off * g.e1[k]), t = tissueAt3(P3, p), v = t ? 255 * (SCOUT_GRAY[t] ?? 0.5) : 0, o = (j * N + i) * 4;
      id.data[o] = id.data[o + 1] = id.data[o + 2] = v; id.data[o + 3] = 255;
    }
    cc.putImageData(id, 0, 0); R.scout = c;
  }
  ctx.save();
  ctx.fillStyle = '#000'; ctx.fillRect(x - 1, y - 1, size + 2, size + 2);
  ctx.imageSmoothingEnabled = true; ctx.drawImage(R.scout, x, y, size, size);
  const mm = size / span, pos = dot3(g.o, g.n), bx = x + size / 2 + pos * mm, bw = Math.max(1.5, Math.min(g.thick, span) * mm);
  ctx.fillStyle = 'rgba(245,197,24,.45)'; ctx.fillRect(bx - bw / 2, y, bw, size);
  ctx.strokeStyle = 'rgba(245,197,24,.95)'; ctx.lineWidth = 1; ctx.strokeRect(bx - bw / 2, y + 0.5, bw, size - 1);
  ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.strokeRect(x - 0.5, y - 0.5, size + 1, size + 1);
  ctx.font = `600 10px ${C.font}`; ctx.fillStyle = 'rgba(255,214,120,.95)'; ctx.textBaseline = 'middle';
  ctx.textAlign = 'right'; ctx.fillText(dirLetter(g.n), x + size - 3, y + size / 2);
  ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText(dirLetter(g.e2), x + size / 2, y + 2);
  ctx.restore();
}
/* ---------- 3D view: translucent phantom and the slice plane ---------- */
const V3_COL = { fat: [240, 200, 90], wm: [225, 225, 225], gm: [160, 160, 170], csf: [90, 150, 255], lesion: [255, 90, 90], blood: [200, 40, 60], muscle: [190, 120, 100], liver: [170, 90, 70], kidney: [190, 110, 200], fluid: [90, 160, 255], marrow: [255, 170, 80] };
const V3_DEFAULT = { yaw: -0.65, pitch: 0.38, zoom: 1 };
let v3 = { ...V3_DEFAULT }, v3drag = null;
function inv3(A) {
  const [a, b, c] = A[0], [d, e, f] = A[1], [g, h, i] = A[2], D = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);
  return [[(e * i - f * h) / D, (c * h - b * i) / D, (b * f - c * e) / D], [(f * g - d * i) / D, (a * i - c * g) / D, (c * d - a * f) / D], [(d * h - e * g) / D, (b * g - a * h) / D, (a * e - b * d) / D]];
}
/* ---------- 3D view on the graphics card (WebGL2): the same ray casting as below, per fragment ---------- */
const GL3_MAXO = 20, GL3_MAXP = 48;
const GL3_FS = `#version 300 es
precision highp float; precision highp int;
#define MAXO ${GL3_MAXO}
#define MAXP ${GL3_MAXP}
#define MAXE ${2 * GL3_MAXO + GL3_MAXP}
uniform int uNO, uNP; uniform vec3 uC[MAXO]; uniform mat3 uQ[MAXO]; uniform float uSig[MAXO]; uniform vec3 uCol[MAXO]; uniform float uRim[MAXO];
uniform vec3 uPO[MAXP]; uniform int uPK[MAXP];
uniform vec3 uR, uU, uF, uN, uE1, uE2; uniform vec2 uRes; uniform float uPxmm, uFx, uFy, uEdge, uAxw;
out vec4 outColor;
void main() {
  float aa = (gl_FragCoord.x - uRes.x * 0.5) * uPxmm, bb = (gl_FragCoord.y - uRes.y * 0.5) * uPxmm;
  vec3 base = aa * uR + bb * uU;
  float zs[MAXE]; int kd[MAXE]; float eu[MAXE]; float ev[MAXE]; int ord[MAXE]; bool act[MAXO]; int ne = 0;
  for (int k = 0; k < MAXO; k++) { act[k] = false; if (k >= uNO) continue;
    vec3 w = base - uC[k], Qf = uQ[k] * uF; float A = dot(uF, Qf), B = dot(Qf, w), Cc = dot(w, uQ[k] * w) - 1.0, disc = B * B - A * Cc;
    if (disc <= 0.0) continue; float sq = sqrt(disc);
    zs[ne] = (-B + sq) / A; kd[ne] = 2 * k; ne++; zs[ne] = (-B - sq) / A; kd[ne] = 2 * k + 1; ne++; }
  float fn = dot(uF, uN);
  if (abs(fn) > 1e-6) for (int p = 0; p < MAXP; p++) { if (p >= uNP) break;
    float z = (dot(uPO[p], uN) - dot(base, uN)) / fn; vec3 pt = base + z * uF - uPO[p]; float u = dot(pt, uE1), v = dot(pt, uE2);
    if (abs(u) > uFx || abs(v) > uFy) continue; zs[ne] = z; kd[ne] = 1000 + p; eu[ne] = u; ev[ne] = v; ne++; }
  for (int e = 0; e < MAXE; e++) { if (e >= ne) break; int k = e; while (k > 0 && zs[ord[k - 1]] < zs[e]) { ord[k] = ord[k - 1]; k--; } ord[k] = e; }
  float T = 1.0, zPrev = 0.0; vec3 col = vec3(0.0);
  for (int m = 0; m < MAXE; m++) { if (m >= ne) break; int e = ord[m]; float z = zs[e];
    if (m > 0) { float sig = 0.0; vec3 c = vec3(0.0);
      for (int k = 0; k < MAXO; k++) { if (k >= uNO) break; if (act[k]) { sig += uSig[k]; c += uSig[k] * uCol[k]; } }
      if (sig > 0.0) { float al = 1.0 - exp(-sig * (zPrev - z)); col += T * al / sig * c; T *= 1.0 - al; } }
    zPrev = z; int kk = kd[e];
    if (kk >= 1000) { int p = kk - 1000; float u = eu[e], v = ev[e]; bool nearEdge = uFx - abs(u) < uEdge || uFy - abs(v) < uEdge;
      float al = 0.0; vec3 pc = vec3(245.0, 197.0, 24.0);
      if (uPK[p] == 0) { al = nearEdge ? 0.95 : 0.42; if ((abs(u) < uAxw && v > 0.0 && v < 0.9 * uFy) || (abs(v) < uAxw && u > 0.0 && u < 0.9 * uFx)) { al = 0.95; pc = vec3(255.0, 230.0, 160.0); } }
      else if (nearEdge) al = uPK[p] == 1 ? 0.55 : 0.4;
      if (al > 0.0) { col += T * al * pc; T *= 1.0 - al; } }
    else { int k = kk / 2;
      if (kk - 2 * k == 0) { act[k] = true; vec3 w = base + z * uF - uC[k], n = uQ[k] * w; float gz = 1.0 - abs(dot(n, uF)) / max(length(n), 1e-12), al = uRim[k] * gz * gz * gz;
        col += T * al * uCol[k]; T *= 1.0 - al; }
      else act[k] = false; }
    if (T < 0.01) break; }
  col += T * vec3(13.0, 16.0, 20.0);
  outColor = vec4(min(col, vec3(255.0)) / 255.0, 1.0);
}`;
let GL3 = null;
function gl3Init() {
  if (GL3 !== null) return GL3;
  try {
    const cv = $('#i3gl'), gl = cv.getContext('webgl2', { antialias: false, preserveDrawingBuffer: true }); if (!gl) return (GL3 = false);
    // WebGL emulated in software (no GPU, some virtual machines and remote desktops) is slower than the CPU renderer
    const dbg = gl.getExtension('WEBGL_debug_renderer_info'), renderer = String(dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
    if (/swiftshader|llvmpipe|softpipe|software|basic render/i.test(renderer) && !window.__v3gl) { console.info('3D view: software WebGL (' + renderer + '), using the CPU renderer'); return (GL3 = false); }
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, '#version 300 es\nin vec2 p; void main() { gl_Position = vec4(p, 0.0, 1.0); }'));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, GL3_FS)); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const U = {}; for (const n of ['uNO', 'uNP', 'uC', 'uQ', 'uSig', 'uCol', 'uRim', 'uPO', 'uPK', 'uR', 'uU', 'uF', 'uN', 'uE1', 'uE2', 'uRes', 'uPxmm', 'uFx', 'uFy', 'uEdge', 'uAxw']) U[n] = gl.getUniformLocation(prog, n) || gl.getUniformLocation(prog, n + '[0]');
    cv.addEventListener('webglcontextlost', e => { e.preventDefault(); GL3 = false; });
    return (GL3 = { gl, cv, prog, U });
  } catch (e) { console.warn('3D view: WebGL2 unavailable, using the CPU renderer', e); return (GL3 = false); }
}
function gl3Draw(s) {
  const G = gl3Init(); if (!G || s.objs.length > GL3_MAXO || s.planes.length > GL3_MAXP) return false;
  const { gl, cv, U } = G, W = Math.max(1, Math.round(s.W3 * dpr)), H = Math.max(1, Math.round(s.H3 * dpr));
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
  gl.viewport(0, 0, W, H); gl.useProgram(G.prog);
  const f3 = a => new Float32Array(a.flat());
  gl.uniform1i(U.uNO, s.objs.length); gl.uniform1i(U.uNP, s.planes.length);
  if (s.objs.length) {
    gl.uniform3fv(U.uC, f3(s.objs.map(o => o.c))); gl.uniformMatrix3fv(U.uQ, false, f3(s.objs.map(o => o.Q.flat())));
    gl.uniform1fv(U.uSig, new Float32Array(s.objs.map(o => o.sig))); gl.uniform3fv(U.uCol, f3(s.objs.map(o => o.col))); gl.uniform1fv(U.uRim, new Float32Array(s.objs.map(o => o.rim * 0.35)));
  }
  if (s.planes.length) { gl.uniform3fv(U.uPO, f3(s.planes.map(p => p.o))); gl.uniform1iv(U.uPK, new Int32Array(s.planes.map(p => p.kind === 'cur' ? 0 : p.kind === 'face' ? 1 : 2))); }
  for (const [n, v] of [['uR', s.right], ['uU', s.up], ['uF', s.fwd], ['uN', s.g.n], ['uE1', s.g.e1], ['uE2', s.g.e2]]) gl.uniform3fv(U[n], new Float32Array(v));
  const tiltF = 1 / Math.max(0.3, Math.abs(s.fn)), mmPerCss = 1 / s.sc;
  gl.uniform2f(U.uRes, W, H); gl.uniform1f(U.uPxmm, mmPerCss / dpr); gl.uniform1f(U.uFx, s.fx); gl.uniform1f(U.uFy, s.fy);
  gl.uniform1f(U.uEdge, 1.6 * mmPerCss * tiltF); gl.uniform1f(U.uAxw, 1.0 * mmPerCss * tiltF);
  gl.drawArrays(gl.TRIANGLES, 0, 3); cv.style.visibility = 'visible';
  return true;
}
/* Per-pixel ray casting (orthographic). Along each ray the analytic ellipsoids give exact entry/exit
   depths; the ray is split at every boundary and integrated front to back with an emission–absorption
   model (each tissue absorbs and glows in proportion to the path length inside it). Slice planes sit at
   their true depths, so tissue in front of a plane hides part of it and the plane hides what lies behind. */
const V3_SIG = { fat: 0.0028, wm: 0.0022, gm: 0.012, csf: 0.02, lesion: 0.05, blood: 0.05, muscle: 0.0075, liver: 0.008, kidney: 0.012, fluid: 0.012, marrow: 0.012, air: 0.03 };
let v3Off = null;
/* planes of the other images in the current multiple selection (imagePlaneQuick), except the slices of the shown
   image's own volume, which are drawn already (sliceOffsets); at most 400, cached per selection and view settings */
let otherPlanesCache = null;
function otherPlanes(R) {
  const T = R.target, L = T ? imgList() : null; if (!L || L.length < 2) return []; // the current selection (a cached image may be from an earlier one)
  const opt = { B0: S.sim.B0, orient: S.sim.orient, slicePos: S.sim.slicePos, phantom: R.phantomKey };
  const key = [imgListCache && imgListCache.key, T.ref, T.vi, JSON.stringify(opt)].join('|');
  if (otherPlanesCache && otherPlanesCache.key === key) return otherPlanesCache.out;
  const out = [];
  for (let i = 0; i < L.length && out.length < 400; i++) {
    const it = L[i]; if (it.ref === T.ref || (it.vi >= 0 && it.vi === T.vi)) continue;
    const q = imagePlaneQuick(S.seq, S.seq.shots, it.ref, opt); if (q) out.push({ q, i });
  }
  otherPlanesCache = { key, out }; return out;
}
/* phase-encoding lines of an image (lineStats, sim.js), as one line of text; cached per image */
const lineCache = new Map();
function imageLines(vol, ref, echo = 0) {
  const s = S.seq, key = [imgLoadId, vol.s0, vol.s1, ref, S.sim.B0, echo].join('|');
  if (!lineCache.has(key)) { if (lineCache.size > 50) lineCache.clear(); lineCache.set(key, lineStats(s, s.shots, vol, ref, { B0: S.sim.B0, orient: S.sim.orient, slicePos: S.sim.slicePos, phantom: S.sim.phantom, echo })); }
  return lineCache.get(key);
}
function linesText(r) {
  if (!r) return '';
  if (!r.cart) return `Non-Cartesian: no phase-encoding lines (${r.nADC.toLocaleString()} readouts)`;
  let t = `Phase encoding: ${r.nLines} of ${r.N} lines (${fmt(100 * r.nLines / r.N, 3)} %)`;
  const parts = [];
  if (r.R > 1) parts.push(`acceleration R = ${r.R}${r.acs ? `, fully sampled centre of ${r.acs} lines` : ', no fully sampled centre'}`);
  if (r.pf < 1) parts.push(`partial Fourier ${Math.round(r.pf * 8)}/8 (${r.pfSide === 'low' ? 'negative' : 'positive'} k side cut)`);
  if (parts.length) t += `: ${parts.join('; ')}`;
  else if (r.nLines === r.N) t += ', fully sampled';
  if (r.from === 'data') t += '. Line spacing from the samples (no FOV in the definitions): an acceleration without a fully sampled centre looks like a smaller FOV';
  return t;
}
function shotImage(k) { // the image (volume and reference shot) a shot belongs to
  const s = S.seq, sh = s.shots; if (!sh[k]) return null;
  const vol = S.vols.length ? S.vols[volOfBlock(sh[k].b0)] : { s0: k, s1: k }; let ref = k;
  if (!sh[ref].nADC) { ref = -1; for (let q = vol.s0; q <= vol.s1; q++) if (sh[q].nADC) { ref = q; break; } }
  return ref >= 0 ? { vol, ref } : null;
}
function drawSlice3D() {
  const ctx = i3ctx, W3 = I3W, H3 = I3H; if (W3 <= 0 || !S.sim.show3d) return;
  const R = imgRes;
  if (!R || R.error || !R.geom) { ctx.clearRect(0, 0, W3, H3); ctx.fillStyle = '#0d1014'; ctx.fillRect(0, 0, W3, H3); return; }
  if (!R.p3) { const P3 = build3D(R.phantomKey, R.bubbleOn); P3.R.forEach(r => r.S = inv3(r.Q)); R.p3 = P3; }
  const P3 = R.p3, g = R.geom;
  const cy = Math.cos(v3.yaw), sy = Math.sin(v3.yaw), cp = Math.cos(v3.pitch), sp = Math.sin(v3.pitch);
  const right = [cy, sy, 0], up = [-sy * sp, cy * sp, cp], fwd = [sy * cp, -cy * cp, sp]; // fwd points towards the viewer
  const ext = R.phantomKey === 'abdomen' ? 190 : 130, sc = Math.min(W3, H3) * 0.45 / ext * v3.zoom;
  const VC = R.phantomKey === 'abdomen' ? [0, 0, 0] : [0, 8, -22]; // view centre (mm)
  // scene: ellipsoids (+ the bubble as a sphere) with per-view quadratic coefficients in the pixel coordinates (a, b) in mm
  const objs = [];
  const addQ = (Q, c, tissue, sig, col, rim) => {
    const Qv = v => [0, 1, 2].map(i => Q[i][0] * v[0] + Q[i][1] * v[1] + Q[i][2] * v[2]);
    const Qf = Qv(fwd), Qr = Qv(right), Qu = Qv(up), Qc = Qv(c);
    objs.push({ A: dot3(fwd, Qf), Ba: dot3(Qf, right), Bb: dot3(Qf, up), B0: -dot3(Qf, c),
      Caa: dot3(right, Qr), Cab: 2 * dot3(right, Qu), Cbb: dot3(up, Qu), Ca: -2 * dot3(right, Qc), Cb: -2 * dot3(up, Qc), C0: dot3(c, Qc) - 1,
      Q, c, sig, col, rim });
  };
  const V3_TONE = { fat: [205, 208, 215], wm: [175, 180, 190], muscle: [225, 170, 145] }; // neutral body, so the amber slice stands out
  const rel = c => [c[0] - VC[0], c[1] - VC[1], c[2] - VC[2]];
  for (const r of P3.R) addQ(r.Q, rel(r.c), r.tissue, r.vis ?? V3_SIG[r.tissue] ?? 0.006, V3_TONE[r.tissue] || V3_COL[r.tissue] || [200, 200, 200], r.parent < 0 ? 0.55 : 0.8);
  if (P3.bubble) { const b = P3.bubble, q = 1 / (b.r * b.r); addQ([[q, 0, 0], [0, q, 0], [0, 0, q]], rel(b.c), 'air', 0.03, [235, 240, 255], 1); }
  // planes: the current slice (filled), its slab faces and the other slices (outlines only)
  const fx = (R.img.fovX || 220) * imgCrop(R.img, 'x') / 2, fy = (R.img.fovY || 220) * imgCrop(R.img, 'y') / 2, planes = [];
  const fn = dot3(fwd, g.n);
  const addP = (o, kind) => { o = rel(o); planes.push({ o, kind, on: dot3(o, g.n) }); };
  addP(g.o, 'cur');
  if (g.thick > 1.5 && g.thick < 200) { addP(addS(g.o, g.n, -g.thick / 2), 'face'); addP(addS(g.o, g.n, g.thick / 2), 'face'); }
  const base = addS(g.o, g.n, -g.s0);
  for (const s0 of (R.sliceOffsets || [])) if (Math.abs(s0 - g.s0) > 0.01) addP(addS(base, g.n, s0), 'other');
  const overlays = () => {
    // an edge-on slice is a line: outline it so it does not vanish
    if (Math.abs(fn) < 0.12) {
      const cs = [[-fx, -fy], [fx, -fy], [fx, fy], [-fx, fy]].map(([uu, vv]) => { const p = addS(addS(rel(g.o), g.e1, uu), g.e2, vv); return [W3 / 2 + sc * dot3(p, right), H3 / 2 - sc * dot3(p, up)]; });
      ctx.beginPath(); cs.forEach((c, k) => k ? ctx.lineTo(c[0], c[1]) : ctx.moveTo(c[0], c[1])); ctx.closePath(); ctx.strokeStyle = 'rgba(245,197,24,.9)'; ctx.lineWidth = 1.5; ctx.stroke();
    }
    // orientation triad
    const tx = 34, ty = H3 - 34, L = 22; ctx.font = `600 11px ${C.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (const [v, lab, col] of [[[1, 0, 0], 'L', '#ff7a7a'], [[0, 1, 0], 'A', '#7ddc7d'], [[0, 0, 1], 'S', '#7fb0ff']]) {
      const px = dot3(v, right), py = dot3(v, up); ctx.strokeStyle = col; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(tx + px * L, ty - py * L); ctx.stroke(); ctx.fillStyle = col; ctx.fillText(lab, tx + px * (L + 9), ty - py * (L + 9));
    }
    // the slices of the other images of a multiple selection (other volumes or fields of view): outlines of their
    // fields of view, numbered as in the image arrows; drawn on top, so tissue in front does not hide them
    const others = otherPlanes(R);
    if (others.length) {
      const hRO = R.roAxis === 1 ? fy : fx, hPE = R.roAxis === 1 ? fx : fy;
      ctx.setLineDash([4, 3]); ctx.lineWidth = 1.2; ctx.font = `600 10px ${C.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (const { q, i } of others) {
        const cs = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, b]) => { const p = addS(addS(rel(q.o), q.e1, a * hRO), q.e2, b * hPE); return [W3 / 2 + sc * dot3(p, right), H3 / 2 - sc * dot3(p, up)]; });
        ctx.beginPath(); cs.forEach((c, k) => k ? ctx.lineTo(c[0], c[1]) : ctx.moveTo(c[0], c[1])); ctx.closePath();
        ctx.strokeStyle = 'rgba(245,197,24,.7)'; ctx.stroke();
        if (others.length <= 40) { ctx.fillStyle = 'rgba(245,197,24,.95)'; ctx.fillText(String(i + 1), cs[2][0], cs[2][1]); }
      }
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.textAlign = 'left'; ctx.textBaseline = 'top'; ctx.font = `11px ${C.font}`;
      ctx.fillText(`${others.length} other selected image${others.length > 1 ? 's' : ''}: dashed outlines (drawn on top)`, 8, 8);
    }
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic'; ctx.font = `11px ${C.font}`;
    ctx.fillText('drag to rotate · scroll to zoom · double-click to reset', W3 - 8, H3 - 8);
  };
  // on the graphics card when possible (WebGL2); the same algorithm on the CPU otherwise
  if (!window.__v3cpu && gl3Draw({ objs, planes, right, up, fwd, sc, W3, H3, fx, fy, g, fn })) { ctx.clearRect(0, 0, W3, H3); overlays(); return; }
  $('#i3gl').style.visibility = 'hidden';
  const q = 1, RW = Math.max(40, Math.round(W3 * q)), RH = Math.max(30, Math.round(H3 * q)), pxmm = 1 / (sc * q);
  if (!v3Off || v3Off.width !== RW || v3Off.height !== RH) { v3Off = document.createElement('canvas'); v3Off.width = RW; v3Off.height = RH; }
  const oc = v3Off.getContext('2d'), id = oc.createImageData(RW, RH), D = id.data;
  const NO = objs.length, NP = planes.length, MAXE = 2 * NO + NP + 2;
  const zs = new Float64Array(MAXE), kinds = new Int32Array(MAXE), eu = new Float64Array(MAXE), ev = new Float64Array(MAXE), ord = new Int32Array(MAXE), act = new Uint8Array(NO);
  const tiltF = 1 / Math.max(0.3, Math.abs(dot3(fwd, g.n))), edge = 1.6 * pxmm * tiltF, axw = 1.0 * pxmm * tiltF; // bands stay visible when the plane is seen obliquely
  // flat per-object data for the inner loop
  const oSig = new Float64Array(NO), oR = new Float64Array(NO), oG = new Float64Array(NO), oB = new Float64Array(NO), oRim = new Float64Array(NO);
  objs.forEach((o, k) => { oSig[k] = o.sig; oR[k] = o.col[0]; oG[k] = o.col[1]; oB[k] = o.col[2]; oRim[k] = o.rim * 0.35; });
  // plane geometry in pixel coordinates: z(a, b) = za0 + za·a + zb·b and in-plane (u, v) linear in (a, b)
  const rn = dot3(right, g.n), un = dot3(up, g.n);
  const PL = planes.map(P => {
    const z0 = P.on / fn, za = -rn / fn, zb = -un / fn;
    // point = a·right + b·up + z·fwd − o, projected on e1 / e2
    const lin = e => ({ c: -dot3(P.o, e) + z0 * dot3(fwd, e), a: dot3(right, e) + za * dot3(fwd, e), b: dot3(up, e) + zb * dot3(fwd, e) });
    return { z0, za, zb, U: lin(g.e1), V: lin(g.e2), kind: P.kind === 'cur' ? 0 : P.kind === 'face' ? 1 : 2 };
  });
  const planesOn = Math.abs(fn) > 1e-6;
  for (let j = 0; j < RH; j++) {
    const bb = (RH / 2 - (j + 0.5)) * pxmm;
    for (let i = 0; i < RW; i++) {
      const aa = ((i + 0.5) - RW / 2) * pxmm;
      let ne = 0;
      for (let k = 0; k < NO; k++) {
        const o = objs[k], B = aa * o.Ba + bb * o.Bb + o.B0, Cc = aa * aa * o.Caa + aa * bb * o.Cab + bb * bb * o.Cbb + aa * o.Ca + bb * o.Cb + o.C0;
        const disc = B * B - o.A * Cc; if (disc <= 0) continue;
        const sq = Math.sqrt(disc); zs[ne] = (-B + sq) / o.A; kinds[ne++] = 2 * k; zs[ne] = (-B - sq) / o.A; kinds[ne++] = 2 * k + 1; // near, far
      }
      if (planesOn) for (let p = 0; p < NP; p++) {
        const P = PL[p], uu = P.U.c + P.U.a * aa + P.U.b * bb, vv = P.V.c + P.V.a * aa + P.V.b * bb;
        if (uu > fx || uu < -fx || vv > fy || vv < -fy) continue;
        zs[ne] = P.z0 + P.za * aa + P.zb * bb; kinds[ne] = 1000 + p; eu[ne] = uu; ev[ne] = vv; ne++;
      }
      for (let e = 0; e < ne; e++) { let k = e; while (k > 0 && zs[ord[k - 1]] < zs[e]) { ord[k] = ord[k - 1]; k--; } ord[k] = e; } // near → far
      let T = 1, r = 0, gg = 0, bl = 0, zPrev = 0;
      for (let k = 0; k < NO; k++) act[k] = 0;
      for (let m = 0; m < ne; m++) {
        const e = ord[m], z = zs[e];
        if (m > 0) { // medium between the previous event and this one
          let sig = 0, cr = 0, cg = 0, cb = 0;
          for (let k = 0; k < NO; k++) if (act[k]) { const s = oSig[k]; sig += s; cr += s * oR[k]; cg += s * oG[k]; cb += s * oB[k]; }
          if (sig > 0) { const al = 1 - Math.exp(-sig * (zPrev - z)), w = T * al / sig; r += w * cr; gg += w * cg; bl += w * cb; T *= 1 - al; }
        }
        zPrev = z;
        const kd = kinds[e];
        if (kd >= 1000) { // a plane
          const P = PL[kd - 1000], uu = eu[e], vv = ev[e], nearEdge = fx - Math.abs(uu) < edge || fy - Math.abs(vv) < edge;
          let al = 0, cr = 245, cg = 197, cb = 24;
          if (P.kind === 0) {
            al = nearEdge ? 0.95 : 0.42;
            if ((Math.abs(uu) < axw && vv > 0 && vv < 0.9 * fy) || (Math.abs(vv) < axw && uu > 0 && uu < 0.9 * fx)) { al = 0.95; cr = 255; cg = 230; cb = 160; }
          } else if (nearEdge) al = P.kind === 1 ? 0.55 : 0.4;
          if (al > 0) { r += T * al * cr; gg += T * al * cg; bl += T * al * cb; T *= 1 - al; }
        } else {
          const k = kd >> 1;
          if ((kd & 1) === 0) { // entering: a soft rim where the ray grazes the surface
            act[k] = 1;
            const o = objs[k], wx = aa * right[0] + bb * up[0] + z * fwd[0] - o.c[0], wy = aa * right[1] + bb * up[1] + z * fwd[1] - o.c[1], wz = aa * right[2] + bb * up[2] + z * fwd[2] - o.c[2], Q = o.Q;
            const nx = Q[0][0] * wx + Q[0][1] * wy + Q[0][2] * wz, ny = Q[1][0] * wx + Q[1][1] * wy + Q[1][2] * wz, nz = Q[2][0] * wx + Q[2][1] * wy + Q[2][2] * wz;
            const nl = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1, gz = 1 - Math.abs(nx * fwd[0] + ny * fwd[1] + nz * fwd[2]) / nl, al = oRim[k] * gz * gz * gz;
            r += T * al * oR[k]; gg += T * al * oG[k]; bl += T * al * oB[k]; T *= 1 - al;
          } else act[k] = 0;
        }
        if (T < 0.01) break;
      }
      const p = (j * RW + i) * 4;
      D[p] = r + T * 13; D[p + 1] = gg + T * 16; D[p + 2] = bl + T * 20; D[p + 3] = 255; // Uint8ClampedArray clamps
    }
  }
  oc.putImageData(id, 0, 0);
  ctx.imageSmoothingEnabled = true; ctx.drawImage(v3Off, 0, 0, W3, H3);
  overlays();
}
i3.addEventListener('pointerdown', e => { i3.setPointerCapture(e.pointerId); v3drag = { x: e.clientX, y: e.clientY, yaw: v3.yaw, pitch: v3.pitch }; });
let v3Pending = false;
const v3Request = () => { if (!v3Pending) { v3Pending = true; requestAnimationFrame(() => { v3Pending = false; drawSlice3D(); }); } };
i3.addEventListener('pointermove', e => { if (!v3drag) return; v3.yaw = v3drag.yaw - (e.clientX - v3drag.x) * 0.01; v3.pitch = Math.max(-1.5, Math.min(1.5, v3drag.pitch + (e.clientY - v3drag.y) * 0.01)); v3Request(); });
i3.addEventListener('pointerup', () => { v3drag = null; drawSlice3D(); }); i3.addEventListener('pointercancel', () => { v3drag = null; drawSlice3D(); });
i3.addEventListener('dblclick', () => { v3 = { ...V3_DEFAULT }; drawSlice3D(); });
i3.addEventListener('wheel', e => { e.preventDefault(); v3.zoom = Math.max(0.4, Math.min(4, v3.zoom * Math.exp(-e.deltaY * 0.0015))); v3Request(); }, { passive: false });
let imgOff = null;
/* fraction of the image shown along x or y: < 1 when the readout is oversampled and cropping is on */
function imgCrop(I, a) { return S.sim.crop === false ? 1 : (a === 'x' ? I.cropX : I.cropY) || 1; }
function drawImg() {
  if (IW <= 0) return;
  const ctx = ictx; ctx.clearRect(0, 0, IW, IW);
  const info = $('#imInfo');
  if (!S.seq) { info.textContent = 'No sequence loaded.'; return; }
  if (!imgRes) { info.textContent = ''; return; }
  if (imgRes.error) { info.textContent = imgRes.error; $('#imEcho').hidden = true; return; }
  const R = imgRes, I = R.img, view = S.sim.view;
  { const nav = $('#imEcho'), n = R.nEcho || 1; nav.hidden = n < 2;
    if (n > 1) { $('#imEchoTxt').textContent = `Echo ${R.echo + 1} / ${n} · TE ${fmt(R.TE * 1e3, 3)} ms`; $('#imEchoPrev').disabled = R.echo <= 0; $('#imEchoNext').disabled = R.echo >= n - 1; } }
  let G, getV, lo, hi;
  if (view === 'k') {
    G = R.kspace.G; const Kr = R.kspace.re, Ki = R.kspace.im, L = new Float64Array(G * G); let mx = 0;
    for (let o = 0; o < G * G; o++) { L[o] = Math.log10(1e-12 + Math.hypot(Kr[o], Ki[o])); if (R.mask[o]) mx = Math.max(mx, L[o]); }
    lo = mx - 4; hi = mx; getV = o => L[o];
  } else {
    G = I.G; const M = new Float64Array(G * G);
    for (let o = 0; o < G * G; o++) M[o] = view === 'phase' ? Math.atan2(I.im[o], I.re[o]) : Math.hypot(I.re[o], I.im[o]);
    if (view === 'phase') { lo = -Math.PI; hi = Math.PI; }
    else { const srt = Float64Array.from(M).sort(); lo = 0; hi = srt[Math.floor(0.995 * (srt.length - 1))] * 1.05 || 1; }
    getV = o => M[o];
  }
  if (!imgOff || imgOff.width !== G) { imgOff = document.createElement('canvas'); imgOff.width = imgOff.height = G; }
  const oc = imgOff.getContext('2d'), id = oc.createImageData(G, G), d = id.data;
  const amber = [224, 150, 20];
  for (let y = 0; y < G; y++) for (let x = 0; x < G; x++) {
    const o = y * G + x, p = ((G - 1 - y) * G + x) * 4; // y up
    let v = Math.max(0, Math.min(1, (getV(o) - lo) / (hi - lo))), r, g, b;
    if (view === 'k') {
      const m = R.mask[o];
      if (m === 2) { r = amber[0] * (0.25 + 0.75 * v); g = amber[1] * (0.25 + 0.75 * v); b = amber[2] * (0.25 + 0.75 * v); }
      else if (m === 1) r = g = b = 255 * v; else r = g = b = 0;
    } else r = g = b = 255 * v;
    d[p] = r; d[p + 1] = g; d[p + 2] = b; d[p + 3] = 255;
  }
  oc.putImageData(id, 0, 0);
  // keep the physical aspect ratio (FOV) of the image
  // readout oversampling: the image covers the whole sampled FOV; cropping draws only its central part (display only)
  const cx = view === 'k' ? 1 : imgCrop(I, 'x'), cy = view === 'k' ? 1 : imgCrop(I, 'y');
  ctx.imageSmoothingEnabled = view !== 'k' && !(EXP && EXP.imSharp);
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, IW, IW);
  let w, h, kE = 0;
  if (view === 'k') {
    // k-space in physical units, the same scale on both axes: a grid cell is Δkx wide and Δky high, so readout
    // oversampling (smaller Δk along the readout) shows as denser samples over the same k range, not as a wider
    // range. Shown: a square of ±kE, the largest |k| acquired or filled along either axis.
    const dx = R.kspace.dkx || 1, dy = R.kspace.dky || 1; let mxc = 0, myc = 0;
    for (let y = 0; y < G; y++) for (let x = 0; x < G; x++) if (R.mask[y * G + x]) { mxc = Math.max(mxc, Math.abs(x - G / 2) + 0.5); myc = Math.max(myc, Math.abs(y - G / 2) + 0.5); }
    kE = Math.max(mxc * dx, myc * dy) || G / 2 * Math.max(dx, dy);
    w = h = IW; const px = IW / (2 * kE); // screen pixels per 1/mm
    // source rectangle in grid cells (centre at G/2), clipped to the grid; the destination follows the clipping
    const hx = Math.min(G / 2, kE / dx), hy = Math.min(G / 2, kE / dy), dw = 2 * hx * dx * px, dh = 2 * hy * dy * px;
    ctx.drawImage(imgOff, G / 2 - hx, G / 2 - hy, 2 * hx, 2 * hy, (IW - dw) / 2, (IW - dh) / 2, dw, dh);
  } else {
    const ax = I.fovX * cx, ay = I.fovY * cy, sc = Math.min(IW / ax, IW / ay); w = ax * sc; h = ay * sc;
    const sw = G * cx, sh = G * cy; // source rectangle: centred (the image rows are stored with y up, the crop is symmetric)
    ctx.drawImage(imgOff, (G - sw) / 2, (G - sh) / 2, sw, sh, (IW - w) / 2, (IW - h) / 2, w, h);
  }
  if (EXP) EXP.imRect = [(IW - w) / 2, (IW - h) / 2, w, h]; // the image's area (a figure can be cropped to it)
  ctx.fillStyle = 'rgba(255,255,255,.75)'; ctx.font = `11px ${C.font}`; ctx.textAlign = 'left';
  const T = R.target, ann = !EXP || EXP.imText;
  if (ann) ctx.fillText(view === 'k' ? 'k-space: grey acquired, amber filled' : `${S.vols.length ? `volume ${T.vi + 1} · ` : ''}shot ${T.ref + 1}`, 8, 16);
  if (view !== 'k') {
    ctx.textAlign = 'right'; if (ann) ctx.fillText(`FOV ${fmt(I.fovX * cx, 3)} × ${fmt(I.fovY * cy, 3)} mm${R.osRO > 1 ? ` · ${fmt(R.osRO, 3)}× readout oversampling${cx < 1 || cy < 1 ? ', cropped' : ''}` : ''}`, IW - 8, IW - 8);
    const g = R.geom;
    if (g && (!EXP || EXP.imDirs)) { // anatomical directions at the edges of the image
      const x0i = (IW - w) / 2, y0i = (IW - h) / 2, neg = v => v.map(x => -x);
      ctx.font = `600 12px ${C.font}`; ctx.fillStyle = 'rgba(255,214,120,.95)'; ctx.textBaseline = 'middle';
      ctx.textAlign = 'right'; ctx.fillText(dirLetter(g.e1), x0i + w - 5, y0i + h / 2);
      ctx.textAlign = 'left'; ctx.fillText(dirLetter(neg(g.e1)), x0i + 5, y0i + h / 2);
      ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText(dirLetter(g.e2), x0i + w / 2, y0i + 5);
      ctx.textBaseline = 'bottom'; ctx.fillText(dirLetter(neg(g.e2)), x0i + w / 2, y0i + h - 5);
      ctx.textBaseline = 'alphabetic';
    }
    if (g && (!EXP || EXP.imScout)) drawScout(ctx, R, 8, IW - 8 - Math.round(IW * 0.3), Math.round(IW * 0.3));
  }
  if (EXP) return; // a figure: not the page's texts
  // info
  const f = x => isFinite(x) ? fmt(x, 3) : '∞';
  const parts = [
    `${R.nEcho > 1 ? `Echo ${R.echo + 1} of ${R.nEcho} · ` : ''}${Math.round(R.dispW * imgCrop(R.img, 'x'))}×${Math.round(R.dispH * imgCrop(R.img, 'y'))} · ${R.n.toLocaleString()} samples from ${R.nShots} shot${R.nShots > 1 ? 's' : ''}${R.axes !== 'xy' ? ` · image plane k${R.axes[0]}–k${R.axes[1]}` : ''}${R.useRef ? ' · reference scan' : ''}`,
    (() => { const g = R.geom; if (!g) return '';
      const pn = planeName(g.n), tilt = pn.tilt > 1 ? `, tilted ${fmt(pn.tilt, 2)}°` : '';
      if (g.mode === 'slice' && g.fixed) return `Slice: ${pn.name}${tilt}, ${fmt(g.thick, 2)} mm thick, fixed at the air bubble's plane (${g.s0 >= 0 ? '+' : ''}${fmt(g.s0, 3)} mm); the sequence's position is ignored`;
      if (g.mode === 'slice') return `Slice: ${pn.name}${tilt}, ${fmt(g.thick, 2)} mm thick at ${g.s0 >= 0 ? '+' : ''}${fmt(g.s0, 3)} mm (RF bandwidth ${fmt(g.bw / 1000, 2)} kHz, slice gradient ${fmt(g.G / GAMMA * 1e3, 3)} mT/m)`;
      if (g.mode === 'nonselective') return `No slice selection: projection through the phantom (${pn.name} direction)`;
      return `3D encoding: ${pn.name} partition of ${fmt(g.thick, 2)} mm at ${g.mode.includes('slab') ? `the slab centre (${g.s0 >= 0 ? '+' : ''}${fmt(g.s0, 3)} mm)` : 'the centre'}`; })(),
    `TE ${fmt(R.TE * 1e3, 3)} ms · TR ${R.TR > 1e8 ? 'single shot' : fmt(R.TR * 1e3, 3) + ' ms'} · flip ${fmt(R.flip * 180 / Math.PI, 3)}° · ${R.se ? 'spin echo' : 'gradient echo'}${R.inv ? ` · TI ${fmt(R.inv.t * 1e3, 3)} ms` : ''}${R.sats ? ' · saturation pulse' : ''}${S.sim.diffusion ? ` · b = ${Math.round(R.b)} s/mm²` : ''}`,
    (() => { const ax = R.axes, big = Math.abs(R.fatY) >= Math.abs(R.fatX) ? 1 : 0, fs = Math.abs(big ? R.fatY : R.fatX);
      return `Bandwidth per pixel: readout (k${ax[R.roAxis]}) ${f(R.bwRO)} Hz · effective along k${ax[0]} ${f(R.bwX)} Hz, along k${ax[1]} ${f(R.bwY)} Hz → fat shift ${fmt(fs, 2)} px along k${ax[big]} (${S.sim.B0} T)`; })(),
    R.eddy ? `Eddy currents (${R.eddy.name}, illustrative): k-space off by up to ${fmt(R.eddy.echoX, 2)} px along k${R.axes[0]} and ${fmt(R.eddy.echoY, 2)} px along k${R.axes[1]} at the echo (${fmt(R.eddy.maxX, 2)} / ${fmt(R.eddy.maxY, 2)} px over the readout); B0 eddy phase up to ${fmt(R.eddy.phase, 2)} rad` : '',
    (() => { const T = R.target, l = T ? imageLines(T.vol, T.ref, R.echo || 0) : null; return l ? linesText(l) : ''; })(),
    R.cart ? (R.nMissing ? `Lines not acquired: ${S.sim.fill ? 'filled as by an ideal reconstruction' : 'zero-filled'}` : 'Fully sampled Cartesian k-space') : 'Non-Cartesian: exact inverse Fourier sum with density compensation',
    `Computed in ${fmt(R.ms / 1000, 2)} s (${R.engine || 'CPU'})`
  ];
  info.innerHTML = parts.filter(Boolean).map(esc).join('<br>');
  drawSlice3D();
}

/* ---------- linking tabs ---------- */
const TAB_ID = Math.random().toString(36).slice(2);
let linkApplying = false, linkCh = null, linkViewPending = false, linkHoverPending = false;
const linkPeers = new Map();
function linkPost(m) { m.from = TAB_ID; try { linkCh && linkCh.postMessage(m); } catch (_) { } }
function linkInit() {
  try { linkCh = new BroadcastChannel('seqret-link'); linkCh.onmessage = e => onLink(e.data); }
  catch (_) { // fallback: storage events
    linkCh = { postMessage: m => { try { localStorage.setItem('seqret-link', JSON.stringify(m)); localStorage.removeItem('seqret-link'); } catch (_) { } } };
    window.addEventListener('storage', e => { if (e.key === 'seqret-link' && e.newValue) try { onLink(JSON.parse(e.newValue)); } catch (_) { } });
  }
  setInterval(() => { if (S.linkMode !== 'off') linkPost({ type: 'here' }); pruneLinkPeers(); }, 2500);
  window.addEventListener('pagehide', () => linkPost({ type: 'bye' }));
}
function pruneLinkPeers() { const now = Date.now(); for (const [k, t] of linkPeers) if (now - t > 7000) linkPeers.delete(k); updateLinkInfo(); }
function updateLinkInfo() {
  const el = $('#linkInfo'); if (!el) return;
  $('#moreBtn').classList.toggle('linked', S.linkMode !== 'off');
  if (S.linkMode === 'off') { el.textContent = ''; return; }
  const n = linkPeers.size;
  el.innerHTML = n ? `<span class="dot on"></span>${n} other tab${n > 1 ? 's' : ''}` : `<span class="dot"></span>waiting for another linked tab`;
}
/* express the view (or a time) relative to the shot/volume it falls in, for the other tab to map back */
function linkRef(t) {
  const m = S.linkMode, s = S.seq;
  const list = m === 'shot' ? s.shots : m === 'vol' ? S.vols : null;
  if (!list || !list.length) return { k: -1, base: 0 };
  const k = m === 'shot' ? shotAt(t) : volAt(t); return { k, base: list[k].t0 };
}
function linkBase(mode, k) {
  const s = S.seq, list = mode === 'shot' ? s.shots : mode === 'vol' ? S.vols : null;
  if (!list || !list.length || k < 0) return 0;
  return list[Math.min(k, list.length - 1)].t0;
}
function linkSendView() {
  if (S.linkMode === 'off' || !S.seq || linkViewPending || segView()) return; // Group segments: the view is not real time
  linkViewPending = true;
  requestAnimationFrame(() => {
    linkViewPending = false; if (!S.seq) return;
    const r = linkRef((S.t0 + S.t1) / 2);
    linkPost({ type: 'view', mode: S.linkMode, k: r.k, r0: S.t0 - r.base, r1: S.t1 - r.base });
  });
}
function linkSendHover() {
  if (S.linkMode === 'off' || !S.seq || linkHoverPending) return;
  linkHoverPending = true;
  requestAnimationFrame(() => {
    linkHoverPending = false; if (!S.seq) return;
    if (S.hoverT == null) { linkPost({ type: 'hover', h: null }); return; }
    const r = linkRef(S.hoverT); linkPost({ type: 'hover', mode: S.linkMode, k: r.k, rh: S.hoverT - r.base });
  });
}
function onLink(d) {
  if (!d || d.from === TAB_ID || S.linkMode === 'off') return;
  linkPeers.set(d.from, Date.now());
  if (d.type === 'bye') { linkPeers.delete(d.from); updateLinkInfo(); return; }
  if (d.type === 'hello') { linkPost({ type: 'here' }); if (d.want) { S.linkMode !== 'off' && S.seq && (linkViewPending = false, linkSendView()); } }
  if (d.type === 'mode' && d.mode !== S.linkMode && d.mode !== 'off') { S.linkMode = d.mode; $('#linkSel').value = d.mode; }
  if (!S.seq) { updateLinkInfo(); return; }
  if (d.type === 'view') {
    if (segView()) { updateLinkInfo(); return; }
    const b = d.k >= 0 ? linkBase(d.mode, d.k) : 0;
    linkApplying = true; setView(b + d.r0, b + d.r1); linkApplying = false;
  } else if (d.type === 'hover') {
    S.hoverT = d.h === null ? null : (d.k >= 0 ? linkBase(d.mode, d.k) : 0) + d.rh; requestOverlay();
  }
  updateLinkInfo();
}
$('#linkSel').onchange = e => {
  S.linkMode = e.target.value; linkPeers.clear();
  if (S.linkMode !== 'off') { linkPost({ type: 'mode', mode: S.linkMode }); linkPost({ type: 'hello' }); linkSendView(); }
  updateLinkInfo();
};
$('#newTabBtn').onclick = () => {
  const url = location.href.split('#')[0] + (S.linkMode !== 'off' ? '#link=' + S.linkMode : '');
  window.open(url, '_blank');
};
{ const m = /link=(time|shot|vol)/.exec(location.hash); if (m) { S.linkMode = m[1]; $('#linkSel').value = m[1]; } }
linkInit(); updateLinkInfo();
if (S.linkMode !== 'off') linkPost({ type: 'hello' });

/* ---------- loading ---------- */
function showError(msg) { $('#empty').style.display = ''; $('#err').textContent = msg; }
/* workers for the image simulation: they run SIM_TASKS (see sim.js) on the data they are sent */
const POOL_GLUE = `
const __load = onmessage;
onmessage = e => { const d = e.data;
  if (d && d.stim) { // nerve stimulation pass (stim.js): progress messages, then the result with its buffers transferred
    try { const r = stimJobRun(d, p => postMessage({ stimP: p })), tr = [r.mn.buffer, r.mx.buffer, r.ck.buffer, r.peak.buffer, r.peakK.buffer];
      for (const L of r.pyr) if (L.size > 1) tr.push(L.mn.buffer, L.mx.buffer); postMessage({ stimR: r }, tr); }
    catch (err) { postMessage({ stimErr: String(err && err.message || err) }); }
    return; }
  if (!d || !d.task) return __load(e);
  try { const r = SIM_TASKS[d.task](d.args), tr = []; for (const k in r) if (ArrayBuffer.isView(r[k])) tr.push(r[k].buffer); postMessage({ id: d.id, result: r }, tr); }
  catch (err) { postMessage({ id: d.id, err: String(err && err.message || err) }); } };`;
const WORKER_GLUE = `
onmessage = e => {
  try {
    if (e.data && e.data.sigOnly) { postMessage({ hash: signatureHash(e.data.bytes) }); return; } // the parallel md5 worker
    const t0 = Date.now(), s = loadSeq(e.data.bytes, p => postMessage({ p: p * 0.9 }), true), t1 = Date.now();
    s.vols0 = computeVolumes(s, s.shots, 'auto', null, p => postMessage({ p: 0.9 + 0.1 * p }));
    s.loadTimes.volumes = Date.now() - t1; s.loadTimes.posted = Date.now();
    s.shotsPacked = packShots(s.shots); s.shots = null;
    postMessage({ seq: s }, transferList(s));
  } catch (err) { postMessage({ err: String(err && err.message || err) }); }
};`;
function loadMain(bytes, onP) { // fallback without a worker
  return new Promise((res, rej) => setTimeout(() => {
    try { const s = loadSeq(bytes, onP); s.vols0 = computeVolumes(s, s.shots, 'auto'); res(s); } catch (e) { rej(e); }
  }, 30));
}
let workerURL = null;
const POOL = { workers: [], queue: [], busy: new Map(), size: 0, id: 0 };
function poolInit() {
  if (POOL.size) return true;
  const n = Math.max(1, Math.min(8, (navigator.hardwareConcurrency || 4) - 1));
  try {
    for (let i = 0; i < n; i++) {
      const w = coreWorker();
      w.onmessage = ev => { const job = POOL.busy.get(w); POOL.busy.delete(w); if (job) { if (ev.data.err) poolLocal(job); else job.res(ev.data.result); } poolPump(); };
      w.onerror = ev => { ev.preventDefault(); const job = POOL.busy.get(w); POOL.busy.delete(w); if (job) poolLocal(job); poolPump(); };
      POOL.workers.push(w);
    }
  } catch (e) { POOL.workers.forEach(w => w.terminate()); POOL.workers = []; return false; }
  POOL.size = n; poolRun.size = n; return true;
}
function poolLocal(job) { try { job.res(SIM_TASKS[job.task](job.args)); } catch (e) { job.rej(e); } } // a failed worker: run it here
function poolPump() {
  for (const w of POOL.workers) {
    if (!POOL.queue.length) return; if (POOL.busy.has(w)) continue;
    const job = POOL.queue.shift(); POOL.busy.set(w, job); w.postMessage({ task: job.task, args: job.args, id: ++POOL.id });
  }
}
function poolRun(task, args) { return new Promise((res, rej) => { POOL.queue.push({ task, args, res, rej }); poolPump(); }); }
function poolCancel() { const q = POOL.queue; POOL.queue = []; for (const j of q) j.rej(new Error('cancelled')); }
function coreWorker() { // a worker running the core (and simulation) code
  if (!workerURL) workerURL = URL.createObjectURL(new Blob([document.getElementById('core').textContent + WORKER_GLUE + POOL_GLUE], { type: 'text/javascript' }));
  return new Worker(workerURL);
}
function loadWorker(bytes, onP) {
  return new Promise((res, rej) => {
    let w, ws = null, seq = null, hash, gotHash = false;
    try { w = coreWorker(); } catch (e) { loadMain(bytes, onP).then(res, rej); return; }
    // the md5 signature check runs in a second worker, in parallel with parsing
    try { ws = coreWorker(); ws.onmessage = ev => { hash = ev.data.hash; gotHash = true; ws.terminate(); finish(); }; ws.onerror = ev => { ev.preventDefault(); ws.terminate(); ws = null; gotHash = true; hash = undefined; finish(); }; ws.postMessage({ sigOnly: true, bytes }); }
    catch (e) { ws = null; gotHash = true; }
    const t0 = performance.now();
    const finish = () => {
      if (!seq || !gotHash) return;
      seq.sig = hash === undefined ? verifySignature(bytes, seq) : signatureStatus(seq, hash);
      seq.loadTimes.total = performance.now() - t0; res(seq);
    };
    w.onmessage = ev => {
      const d = ev.data;
      if (d.p !== undefined) onP(d.p);
      else if (d.seq) { d.seq.loadTimes.transfer = Date.now() - d.seq.loadTimes.posted; w.terminate(); seq = d.seq; const tu = Date.now(); seq.shots = unpackShots(seq.shotsPacked); delete seq.shotsPacked; seq.loadTimes.unpack = Date.now() - tu; finish(); }
      else if (d.err) { w.terminate(); if (ws) ws.terminate(); rej(new Error(d.err)); }
    };
    w.onerror = ev => { ev.preventDefault(); w.terminate(); if (ws) ws.terminate(); loadMain(bytes, onP).then(res, rej); };
    w.postMessage({ bytes }); // copied, so the fallbacks still have the data
  });
}
function setBusy(on, p) {
  $('#busy').classList.toggle('on', on);
  if (on) { $('#busyTxt').textContent = p == null ? 'Reading sequence…' : `Reading sequence… ${Math.round(p * 100)}%`; $('#busyBar').style.width = ((p || 0) * 100) + '%'; }
}
async function load(bytes, name, opts = {}) {
  if (bytes.length > 2.5e8) { showError(`${name} is ${(bytes.length / 1e6).toFixed(0)} MB. Files over 250 MB are not supported in the browser.`); return false; }
  setBusy(true, 0);
  const prev = opts.keep && S.seq ? { t0: S.t0, t1: S.t1, sel: S.sel, selKind: S.selKind, hist: S.hist.slice() } : null;
  try {
    const tL = performance.now(), seq = await loadWorker(bytes, p => setBusy(true, p)); bytes = null;
    window.__loadTimes = seq.loadTimes; seq.loadTimes.worker = performance.now() - tL;
    seq.shotsExc = seq.shots;
    linkApplying = true;
    Object.assign(S, { seq, name, sel: -1, selKind: null, selItems: [], selAnchor: -1, imgIdx: 0, hoverT: null, hist: [] }); kInvalidate(); gMaxAll = 0; imgReset();
    S.vis.labels = (seq.labels.length > 0 || seq.triggers.length > 0) && S.labelsPref; buildChips();
    applyShots(); fillVolMenu(); applyVols(); $('#backBtn').disabled = true;
    SEGC = null; VMAP = null; if (!prev) S.segOn = false; segUI();
    $('#fname').textContent = name;
    $('#fmeta').textContent = `v${seq.version.major}.${seq.version.minor}.${seq.version.revision}${seq.binary ? ' binary' : ''} · ${seq.nb.toLocaleString()} blocks · ${fmtT(seq.totalDur)}`;
    document.title = `${name} · Seqret`;
    $('#empty').style.display = 'none'; $('#err').textContent = '';
    ovCache = null; readColors();
    if (prev) { // reload: same view, selection and history where they still exist in the new file
      setView(prev.t0, prev.t1); S.hist = prev.hist; $('#backBtn').disabled = !S.hist.length;
      if (prev.sel >= 0 && prev.sel < seq.nb) { S.sel = prev.sel; S.selKind = prev.selKind; S.selItems = []; S.selAnchor = -1; }
    } else { S.yZoom = {}; fitAll(); if (seq.shots.length) zoomToShot(0); }
    SRC = opts.src || null; setReloadBtn(); setFnameTitle(); if (!prev) { fnote(''); addRecent(name, SRC); }
    renderSeqInfo(); renderDefs(); renderBlock(); kActNote(); requestK(); if (prev) requestImg();
    stimStart(true);
    if (!prev) ovl.focus({ preventScroll: true });
    linkApplying = false; if (S.linkMode !== 'off') linkPost({ type: 'hello', want: true });
    return true;
  } catch (err) {
    linkApplying = false;
    console.error(err);
    showError(`Could not open ${name}: ${err.message}`);
    return false;
  } finally { setBusy(false); }
}
/* ---------- reloading the current file ----------
   A page cannot re-read a file by its path. Where the browser offers the File System Access API (Chrome, Edge),
   files opened with Open or dropped on the page are kept as a handle, and getFile() returns what is on disk now.
   Otherwise the File object is kept; browsers let it be read again only while the file is unchanged (Chrome
   refuses after a change), so reloading then asks to open the file again. The demo and files embedded by
   seqret.m have no file to re-read. */
let SRC = null, reloading = false;
const canPick = typeof window.showOpenFilePicker === 'function';
function fnote(t, warn) { const el = $('#fnote'); el.textContent = t; el.classList.toggle('warn', !!warn); }
async function reloadFile() {
  if (!S.seq || !SRC || reloading || !(SRC.handle || SRC.file)) return;
  reloading = true; $('#reloadBtn').classList.add('spin');
  try {
    let f;
    if (SRC.handle) {
      if (SRC.handle.queryPermission && (await SRC.handle.queryPermission({ mode: 'read' })) !== 'granted' &&
          (await SRC.handle.requestPermission({ mode: 'read' })) !== 'granted') { fnote('Reading the file was not allowed', true); return; }
      f = await SRC.handle.getFile();
    } else f = SRC.file;
    let bytes;
    try { bytes = new Uint8Array(await f.arrayBuffer()); }
    catch (e) {
      fnote(SRC.handle ? `Could not read the file: ${e.message}` : 'The file changed on disk and this browser only reads the version it was given: open it again' + (canPick ? '' : ' (Chrome and Edge can reload changed files)'), true);
      return;
    }
    const changed = SRC.handle ? (f.lastModified !== SRC.mod || f.size !== SRC.size) : null;
    const src = { ...SRC, mod: f.lastModified, size: f.size };
    if (await load(bytes, f.name || S.name, { src, keep: true })) {
      const t = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      fnote(changed === false ? `Reloaded ${t}, no change on disk` : `Reloaded ${t}`);
    }
  } catch (e) { fnote(`Could not reload: ${e.message}`, true); }
  finally { reloading = false; $('#reloadBtn').classList.remove('spin'); }
}
$('#reloadBtn').onclick = reloadFile;
function setReloadBtn() {
  const b = $('#reloadBtn'), ok = !!(SRC && (SRC.handle || SRC.file));
  b.disabled = !ok;
  b.title = ok ? 'Reload the file from disk (R). Keeps zoom, selection and settings.' : S.seq ? (SRC && SRC.embedded ? 'A file opened from MATLAB (seqret.m) is part of the page and cannot be re-read: run seqret again, or open the file with Open .seq' : 'This file cannot be re-read from disk') : 'Reload the file from disk (R), once a file is open';
}
/* the file name in the header: hovering shows the full path where it is known, clicking copies it (1.47.0). A
   page is never told the folder of a file it opens (Open, drop, recent files); seqret.m passes the path along
   with an embedded file (data-path). */
function setFnameTitle() {
  const el = $('#fname'), path = SRC && SRC.path;
  el.title = path ? `${path}\nClick to copy the path` : `${S.name}\nClick to copy the name (the browser does not give pages the folder of a file)`;
}
$('#fname').addEventListener('click', () => {
  if (!S.seq) return; const t = (SRC && SRC.path) || S.name;
  copyText(t).then(ok => { const msg = ok ? `Copied ${SRC && SRC.path ? 'path' : 'name'}` : 'Could not copy'; fnote(msg); setTimeout(() => { if ($('#fnote').textContent === msg) fnote(''); }, 2500); });
});
/* the folder of the last opened file (1.20.0): its handle is kept in the browser's IndexedDB, and the next Open .seq
   starts there (startIn). Only where the File System Access API exists (Chrome, Edge); other browsers' own file
   dialogs remember the folder, or not, by themselves. The handle gives no access to the file by itself. */
let lastHandle = null;
const kvDB = (() => { let p = null; return () => p || (p = new Promise((res, rej) => { const r = indexedDB.open('seqret', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); })); })();
async function kvGet(k) { const db = await kvDB(); return new Promise((res, rej) => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); }
async function kvSet(k, v) { const db = await kvDB(); return new Promise((res, rej) => { const tx = db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); }); }
function rememberHandle(h) { if (!h || h.kind !== 'file') return; lastHandle = h; kvSet('lastSeqHandle', h).catch(() => { }); }
if (typeof window.showOpenFilePicker === 'function' && window.indexedDB) kvGet('lastSeqHandle').then(h => { if (h && !lastHandle) lastHandle = h; }, () => { });
async function openFile(f, src) {
  if (!f) return;
  if (src && src.handle) rememberHandle(src.handle);
  let buf; try { buf = new Uint8Array(await f.arrayBuffer()); } catch (e) { showError(`Could not read ${f.name}: ${e.message}`); return; }
  load(buf, f.name, { src: { ...(src || { file: f }), mod: f.lastModified, size: f.size } });
}
async function pickFile() { // File System Access picker where available (reloadable from disk), otherwise the file input
  if (!canPick) { $('#fileIn').click(); return; }
  let h;
  const types = [{ description: 'Pulseq sequence (.seq, or binary .bin)', accept: { 'text/plain': ['.seq'], 'application/octet-stream': ['.bin'] } }];
  // start in the folder of the last opened file; without one (or if the browser rejects it), in the folder the
  // browser remembers for this picker
  try { h = await window.showOpenFilePicker(lastHandle ? { startIn: lastHandle, types, multiple: true } : { id: 'seqret', types, multiple: true }); }
  catch (e) {
    if (e.name === 'AbortError') return;
    if (lastHandle) { try { h = await window.showOpenFilePicker({ id: 'seqret', types, multiple: true }); } catch (e2) { if (e2.name !== 'AbortError') $('#fileIn').click(); return; } }
    else { $('#fileIn').click(); return; }
  }
  try { openMany(await Promise.all(h.map(async x => ({ file: await x.getFile(), handle: x })))); } catch (e) { showError(`Could not read the file: ${e.message}`); }
}
$('#openBtn').onclick = $('#openBtn2').onclick = pickFile;
/* ---------- recent files (1.47.0) ----------
   The last 8 files opened in this browser, kept in IndexedDB with their File System Access handles where the
   browser has them (Chrome, Edge): those reopen from disk (the browser may ask once to allow reading). Files
   opened without a handle (other browsers, files from MATLAB) are listed by name; choosing one opens the file
   dialog. The demo is not listed. */
const RECENT_N = 8; let RECENT = [];
async function addRecent(name, src) {
  if (!src || src.demo || !window.indexedDB) return;
  const e = { name, path: src.path || null, mod: src.mod || null, t: Date.now(), handle: src.handle || null };
  const same = async r => {
    if (r.name !== e.name) return false;
    if (r.handle && e.handle) { try { return await r.handle.isSameEntry(e.handle); } catch (_) { return false; } }
    if (r.path || e.path) return r.path === e.path;
    return !r.handle && !e.handle;
  };
  const keep = []; for (const r of RECENT) if (!(await same(r))) keep.push(r);
  RECENT = [e, ...keep].slice(0, RECENT_N); renderRecent();
  try { await kvSet('recentSeq', RECENT); } catch (_) { try { await kvSet('recentSeq', RECENT.map(r => ({ ...r, handle: null }))); } catch (_) { } }
}
function renderRecent() {
  const html = RECENT.map((r, i) => {
    // the date first and the folder without the file's name (1.48.3): a long path no longer hides the date
    const dir = r.path && r.path.endsWith(r.name) ? r.path.slice(0, -r.name.length).replace(/[\\/]$/, '') : r.path;
    const seg = dir ? dir.split(/[\\/]/).filter(Boolean) : [], sep = dir && dir.includes('\\') ? '\\' : '/'; // the last two folders (the full path is in the tooltip)
    const sub = [r.mod ? fmtDate(new Date(r.mod)) : null, seg.length > 2 ? '…' + sep + seg.slice(-2).join(sep) : dir].filter(Boolean).join(' · ');
    const tip = r.handle ? `Open ${r.name} again${r.path ? ` (${r.path})` : ''}` : `${r.path || r.name}: this browser cannot reopen it by itself, choose it in the file dialog`;
    return `<button class="ritem${r.handle ? '' : ' noreopen'}" data-recent="${i}" title="${esc(tip)}"><b>${esc(r.name)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</button>`;
  }).join('');
  const clear = RECENT.length ? '<button class="btn link rclear" data-recent-clear="1">Clear list</button>' : '';
  $('#recentList').innerHTML = html + clear; $('#recentEmpty').innerHTML = html;
  $('#recentWrap').hidden = !RECENT.length; $('#openGrp').classList.toggle('hasrecent', RECENT.length > 0); $('#recentEmptyBox').hidden = !RECENT.length; $('#recentEmptyBox').closest('.box').classList.toggle('wide', RECENT.length > 0);
}
function closeRecentPop() { $('#recentPop').hidden = true; $('#recentBtn').setAttribute('aria-expanded', 'false'); }
async function openRecent(i) {
  const r = RECENT[i]; closeRecentPop(); if (!r) return;
  if (!r.handle) { pickFile(); return; }
  const fail = m => { if (S.seq) fnote(m, true); else showError(m); };
  try {
    if (r.handle.queryPermission && (await r.handle.queryPermission({ mode: 'read' })) !== 'granted' &&
        (await r.handle.requestPermission({ mode: 'read' })) !== 'granted') { fail(`Reading ${r.name} was not allowed`); return; }
    const f = await r.handle.getFile(); rememberHandle(r.handle); openFile(f, { handle: r.handle });
  } catch (e) { fail(`Could not open ${r.name} (moved or deleted?): ${e.message}`); }
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-recent]'); if (b) { openRecent(+b.dataset.recent); return; }
  if (e.target.closest('[data-recent-clear]')) { RECENT = []; renderRecent(); closeRecentPop(); kvSet('recentSeq', []).catch(() => { }); }
});
if (window.indexedDB) kvGet('recentSeq').then(v => { if (Array.isArray(v)) { RECENT = v.filter(r => r && typeof r.name === 'string').slice(0, RECENT_N); renderRecent(); } }, () => { });
$('#fileIn').onchange = e => { openMany([...e.target.files].map(f => ({ file: f }))); e.target.value = ''; };
$('#demoBtn').onclick = () => load(new TextEncoder().encode($('#demoSeq').textContent), 'seqret_default.seq', { src: { demo: true } });
let dragDepth = 0;
window.addEventListener('dragenter', e => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { dragDepth++; $('#drop').classList.add('on'); e.preventDefault(); } });
window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('#drop').classList.remove('on'); });
window.addEventListener('dragover', e => e.preventDefault());
window.addEventListener('drop', e => {
  e.preventDefault(); dragDepth = 0; $('#drop').classList.remove('on');
  const files = [...(e.dataTransfer?.files || [])]; if (!files.length) return;
  // the handles must be requested during the event; file items come in the same order as the files
  const items = [...(e.dataTransfer.items || [])].filter(it => it.kind === 'file');
  const hps = files.map((f, i) => { const it = items.length === files.length ? items[i] : null;
    return it && typeof it.getAsFileSystemHandle === 'function' ? it.getAsFileSystemHandle().catch(() => null) : null; });
  Promise.all(hps).then(hs => openMany(files.map((f, i) => ({ file: f, handle: hs[i] && hs[i].kind === 'file' ? hs[i] : null }))));
});

/* ---------- several files at once (1.48.0) ----------
   Two or more files (dropped, or chosen with Open) ask whether to open each in its own Seqret tab, linked by
   time, shot or volume, or only the first. This tab opens the first; each other file gets a new tab (#recv=token)
   that asks its opener for the file by postMessage once it has started; the File, and its File System Access
   handle where the browser can pass it on, are sent back. postMessage, not the BroadcastChannel, so it also
   works for pages opened from disk (file://). Browsers allow about one new tab per click: the tabs that could not
   be opened stay in the dialog, which then opens one per click. */
const HANDOFF = new Map(); let MULTI = null;
const isSeqName = n => /\.(seq|bin)$/i.test(n);
function openMany(list) {
  list = (list || []).filter(x => x && x.file); if (!list.length) return;
  const seqs = list.filter(x => isSeqName(x.file.name)); if (seqs.length) list = seqs;
  if (list.length === 1) { const x = list[0]; openFile(x.file, x.handle ? { handle: x.handle } : { file: x.file }); return; }
  MULTI = { list, opened: list.map(() => false), started: false };
  $('#multiLink').value = S.linkMode !== 'off' ? S.linkMode : 'time';
  $('#multiTitle').textContent = `Open ${list.length} files`;
  $('#multiLink').disabled = false; $('#multiFirst').hidden = false; $('#multiGo').disabled = false;
  $('#multiGo').textContent = `Open in ${list.length} tabs`; $('#multiNote').textContent = '';
  renderMulti();
  const d = $('#multiDlg'); if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else d.setAttribute('open', '');
}
function renderMulti() {
  if (!MULTI) return;
  $('#multiList').innerHTML = MULTI.list.map((x, i) => `<li class="${MULTI.opened[i] ? 'done' : ''}"><b title="${esc(x.file.name)}">${esc(x.file.name)}</b><span>${i === 0 ? 'this tab' : MULTI.opened[i] ? 'opened' : 'new tab'}</span></li>`).join('');
}
function closeMulti() { const d = $('#multiDlg'); if (d.open) d.close(); else d.removeAttribute('open'); MULTI = null; }
function openMultiTab(i, mode) {
  const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
  const url = location.href.split('#')[0] + '#' + (mode !== 'off' ? 'link=' + mode + '&' : '') + 'recv=' + token;
  const w = window.open(url, '_blank'); if (!w) return false;
  HANDOFF.set(token, { win: w, file: MULTI.list[i].file, handle: MULTI.list[i].handle || null, t: Date.now() });
  return true;
}
function multiStep() { // opens the tabs not opened yet, as many as the browser allows for this click
  if (!MULTI) return;
  const mode = $('#multiLink').value;
  if (!MULTI.started) {
    MULTI.started = true; MULTI.mode = mode;
    if (mode !== S.linkMode) { $('#linkSel').value = mode; $('#linkSel').onchange({ target: $('#linkSel') }); }
  }
  for (let i = 1; i < MULTI.list.length; i++) {
    if (MULTI.opened[i]) continue;
    if (!openMultiTab(i, MULTI.mode)) break;
    MULTI.opened[i] = true;
  }
  if (!MULTI.opened[0]) { MULTI.opened[0] = true; const x = MULTI.list[0]; openFile(x.file, x.handle ? { handle: x.handle } : { file: x.file }); }
  const left = MULTI.opened.filter(o => !o).length;
  if (!left) { closeMulti(); return; }
  renderMulti();
  const next = MULTI.list[MULTI.opened.indexOf(false)].file.name;
  $('#multiLink').disabled = true; $('#multiFirst').hidden = true;
  $('#multiGo').textContent = left > 1 ? `Open next tab (${left} left)` : 'Open the last tab';
  $('#multiNote').textContent = `The browser blocked ${left === 1 ? 'a new tab' : left + ' new tabs'}: click to open ${next}${left > 1 ? ' and continue' : ''}, or allow pop-ups for this page and click once more to open all.`;
}
$('#multiGo').onclick = multiStep;
$('#multiFirst').onclick = () => { const x = MULTI && MULTI.list[0]; closeMulti(); if (x) openFile(x.file, x.handle ? { handle: x.handle } : { file: x.file }); };
$('#multiClose').onclick = closeMulti;
$('#multiDlg').addEventListener('cancel', () => { MULTI = null; });
window.addEventListener('message', e => {
  const d = e.data; if (!d || typeof d !== 'object' || d.seqret !== 'handoff') return;
  if (d.type === 'ready') { // a tab opened here asks for its file
    const h = HANDOFF.get(d.token); if (!h || h.win !== e.source) return;
    // a repeated request means the last message did not arrive (a handle the other page could not take): no handle
    const m = { seqret: 'handoff', type: 'file', token: d.token, file: h.file, handle: h.sent ? null : h.handle }; h.sent = true;
    try { e.source.postMessage(m, '*'); } catch (_) { try { e.source.postMessage({ ...m, handle: null }, '*'); } catch (_) { } }
  } else if (d.type === 'got') { const h = HANDOFF.get(d.token); if (h && h.win === e.source) HANDOFF.delete(d.token);
  } else if (d.type === 'file' && RECV && d.token === RECV.token && e.source === window.opener) { // this tab's file
    const t = RECV; RECV = null; clearInterval(t.timer);
    try { window.opener.postMessage({ seqret: 'handoff', type: 'got', token: t.token }, '*'); } catch (_) { }
    if (d.file) openFile(d.file, d.handle && d.handle.kind === 'file' ? { handle: d.handle } : { file: d.file });
  }
});
let RECV = null;
{ const m = /recv=([a-z0-9]+)/.exec(location.hash);
  if (m) {
    try { history.replaceState(null, '', location.href.replace(/[&#]?recv=[a-z0-9]+/, '')); } catch (_) { }
    if (window.opener) {
      RECV = { token: m[1], n: 0 };
      const ask = () => { if (!RECV) return; if (++RECV.n > 40) { clearInterval(RECV.timer); RECV = null; showError('The file was not received from the tab that opened this one (closed or reloaded?). Open it here instead.'); return; }
        try { window.opener.postMessage({ seqret: 'handoff', type: 'ready', token: RECV.token }, '*'); } catch (_) { } };
      RECV.timer = setInterval(ask, 250); ask();
    }
  }
}

/* ---------- settings kept between sessions (browser local storage) ---------- */
const SETTINGS_KEY = 'seqret-settings', PREF_KEYS = ['sim', 'diagRes', 'lineMode', 'sideHidden', 'gUnit', 'rfUnit', 'rfMode', 'autoY', 'pauseHatch', 'combineG', 'stimNorm', 'shotMode', 'volPref', 'labelsPref', 'kRange', 'kProj', 'kTraj', 'kActual', 'cc', 'echo'];
const DEFAULTS = JSON.parse(JSON.stringify({ vis: S.vis, ...Object.fromEntries(PREF_KEYS.map(k => [k, S[k]])) }));
function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify({ v: 1, app: APP.version, vis: S.vis, ...Object.fromEntries(PREF_KEYS.map(k => [k, S[k]])) })); } catch (_) { }
}
function segPress(id, v) { $(id).querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', b.dataset.v === v)); }
function applySettings(o) {
  const ok = (k, allowed) => o[k] !== undefined && (!allowed || allowed.includes(o[k]));
  if (o.vis && typeof o.vis === 'object') for (const L of LANES) if (typeof o.vis[L.key] === 'boolean') S.vis[L.key] = o.vis[L.key];
  if (!LANES.some(l => S.vis[l.key])) S.vis.gx = true;
  if (ok('gUnit', ['mT', 'Hz'])) S.gUnit = o.gUnit;
  if (ok('rfUnit', ['uT', 'Hz'])) S.rfUnit = o.rfUnit;
  if (ok('rfMode', ['mag', 'complex'])) S.rfMode = o.rfMode;
  if (ok('lineMode', ['exact', 'columns'])) S.lineMode = o.lineMode;
  if (typeof o.sideHidden === 'boolean') setSide(o.sideHidden);
  if (ok('diagRes', ['auto', 'ultra', 'high', 'standard', 'fast', 'sharp'])) S.diagRes = o.diagRes === 'sharp' ? 'high' : o.diagRes; // 'sharp' (1.17.0) was the default; takes effect at the next resize()
  for (const k of ['autoY', 'pauseHatch', 'combineG', 'labelsPref', 'kTraj', 'kActual', 'stimNorm']) if (typeof o[k] === 'boolean') S[k] = o[k];
  if (ok('shotMode', ['exc', 'prep', 'off'])) S.shotMode = o.shotMode;
  if (typeof o.volPref === 'string' && /^(auto|off|label:.+)$/.test(o.volPref)) S.volPref = S.volMode = o.volPref;
  if (ok('kRange', ['view', 'shot', 'vol'])) S.kRange = o.kRange; // "all" was removed in 1.0.2
  if (ok('kProj', ['xy', 'xz', 'yz', '3d'])) { S.kProj = o.kProj; S.kR = o.kProj === '3d' ? rot3d() : PROJ[o.kProj]; }
  if (o.cc && typeof o.cc === 'object') { const c = ccValid(o.cc); if (c) S.cc = c; }
  if (o.echo && typeof o.echo === 'object') for (const k of ['se', 'gf', 'gl', 'zoom']) if (typeof o.echo[k] === 'boolean') S.echo[k] = o.echo[k];
  if (o.sim && typeof o.sim === 'object') {
    const d = S.sim, v = o.sim;
    if (['head', 'abdomen'].includes(v.phantom)) d.phantom = v.phantom;
    if ([1.5, 3, 7].includes(v.B0)) d.B0 = v.B0;
    for (const k of ['t1', 't2', 'fatShift', 'diffusion', 'bubble', 'noise', 'fill', 'crop', 'slicePos', 'show3d']) if (typeof v[k] === 'boolean') d[k] = v[k];
    if (['mag', 'phase', 'k'].includes(v.view)) d.view = v.view;
    if (['ax', 'cor', 'sag'].includes(v.orient)) d.orient = v.orient;
    if (['off', 'typical', 'poor'].includes(v.eddy)) d.eddy = v.eddy;
  }
  syncSimControls();
  // reflect in the controls
  $('#gUnit').value = S.gUnit; $('#rfUnit').value = S.rfUnit; $('#rfMode').value = S.rfMode; $('#diagRes').value = S.diagRes; $('#lineMode').value = S.lineMode; $('#autoY').checked = S.autoY; $('#pauseHatch').checked = S.pauseHatch; $('#combG').checked = S.combineG;
  $('#shotSel').value = S.shotMode; $('#kTraj').checked = S.kTraj;
  segPress('#kRange', S.kRange); segPress('#kProj', S.kProj); segPress('#kAct', S.kActual ? 'act' : 'nom'); kActNote();
  buildChips();
}
function resetSettings() {
  try { localStorage.removeItem(SETTINGS_KEY); } catch (_) { }
  applySettings(JSON.parse(JSON.stringify(DEFAULTS)));
  resize();
  if (S.seq) { S.vis.labels = (S.seq.labels.length > 0 || S.seq.triggers.length > 0) && S.labelsPref; buildChips(); applyShots(); fillVolMenu(); applyVols(); segRegroup(); kInvalidate(); ovCache = null; renderSeqInfo(); renderBlock(); request(); requestK(); }
}
try { const o = JSON.parse(lsGet('settings') || 'null'); if (o && typeof o === 'object') applySettings(o); } catch (_) { }
// save shortly after any change made through the controls
let saveTimer = null;
const scheduleSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(saveSettings, 250); };
document.addEventListener('change', scheduleSave, true);
window.addEventListener('pagehide', saveSettings); // also when the tab closes right after a change
document.addEventListener('click', e => { if (e.target.closest('.chip, .seg button')) scheduleSave(); }, true);

/* ---------- nerve stimulation (SAFE model, see stim.js) ----------
   Parameters are confidential and are kept only in this browser (localStorage), separate from the other settings.
   The whole sequence is computed in the background in time slices; lanes draw what is done so far. */
const SAFE_KEY = 'seqret-safe';
let SAFE = { pns: null, cns: null };
try { const o = JSON.parse(lsGet('safe') || 'null'); if (o && typeof o === 'object') SAFE = { pns: o.pns || null, cns: o.cns || null }; } catch (_) { }
function saveSafe() { try { localStorage.setItem(SAFE_KEY, JSON.stringify(SAFE)); } catch (_) { } }
const STIM_NAME = { pns: 'PNS', cns: 'CNS' }, STIM_LONG = { pns: 'peripheral nerve stimulation', cns: 'cardiac nerve stimulation' };
let STIM = null, stimTimer = 0, stimLastDraw = 0;
function stimHasModel(k) { return !!(SAFE[k] && safeHwCheck(SAFE[k]).ok); }
let stimWorker = null, stimKey = '';
function stimStart(force) { // (re)compute for the current file and parameters, in a worker when possible
  const s = S.seq, keys = s ? ['pns', 'cns'].filter(stimHasModel) : [];
  const key = s && keys.length ? JSON.stringify(keys.map(k => SAFE[k])) : '';
  if (!force && STIM && STIM.seq === s && key === stimKey) return; // nothing changed (e.g. the dialog closed unchanged)
  clearTimeout(stimTimer); if (stimWorker) { stimWorker.terminate(); stimWorker = null; }
  STIM = null; stimKey = key; stimTrCache = null;
  if (!s || !keys.length) { stimChanged(); return; }
  const models = keys.map(k => ({ hw: SAFE[k] })), dt = s.raster.grad || 1e-5;
  const run = STIM = { R: { done: false, doneK: 0, N: Math.max(1, Math.round(s.totalDur / dt)), dt }, idx: Object.fromEntries(keys.map((k, i) => [k, i])), seq: s, t0: performance.now(), progress: 0 };
  stimChanged();
  const finish = r => {
    if (STIM !== run) return;
    run.R = { seq: s, models, dt, N: r.N, M: r.M, bin: r.bin, nBin: r.nBin, mn: r.mn, mx: r.mx, ck: r.ck, peak: r.peak, peakK: r.peakK, pyr: r.pyr, done: true, doneK: r.N + 1 };
    run.ms = performance.now() - run.t0; run.where = run.where || 'worker'; stimTrCache = null; stimChanged();
  };
  const onPage = () => { // fallback: time slices on the page
    if (STIM !== run) return; run.where = 'page';
    const R = run.R = stimCreate(s, models, dt);
    const tick = () => {
      if (STIM !== run) return;
      const t = performance.now(); while (!R.done && performance.now() - t < 12) stimStep(R, 20000);
      if (R.done) { run.ms = performance.now() - run.t0; stimTrCache = null; stimChanged(); return; }
      run.progress = R.doneK / R.N; if (performance.now() - stimLastDraw > 300) { stimLastDraw = performance.now(); request(); }
      stimTimer = setTimeout(tick, 0);
    };
    stimTimer = setTimeout(tick, 0);
  };
  let w; try { w = coreWorker(); } catch (_) { onPage(); return; }
  stimWorker = w;
  w.onmessage = ev => {
    const d = ev.data; if (STIM !== run) return;
    if (d.stimP !== undefined) { run.progress = d.stimP; if (performance.now() - stimLastDraw > 250) { stimLastDraw = performance.now(); request(); } return; }
    w.terminate(); if (stimWorker === w) stimWorker = null;
    if (d.stimR) finish(d.stimR); else onPage();
  };
  w.onerror = ev => { ev.preventDefault(); w.terminate(); if (stimWorker === w) stimWorker = null; onPage(); };
  w.postMessage({ stim: true, models, dt, ...stimJobPack(s) }); // copied: the page keeps its own arrays
}
function stimChanged() { updateStimStat(); if (S.seq) { renderSeqInfo(); renderBlock(); } request(); }
function stimK(t) { return STIM ? Math.floor(t / STIM.R.dt) : -1; } // interval containing t
function stimReady(kB) { return STIM && (STIM.R.done || kB < STIM.R.doneK - 1); }
/* per-pixel traces of model m (x, y, z, norm) in the format of traceChan (points plus envelope runs) */
/* per-pixel traces of every model (x, y, z, norm each), in the format of traceChan: points plus envelope runs.
   One pass serves both lanes and is cached for the view. */
let stimTrCache = null;
function stimTraces(m, t0, t1, x0, w) {
  const R = STIM.R, key = [t0, t1, x0, w, R.doneK, traceR].join();
  if (!stimTrCache || stimTrCache.key !== key || stimTrCache.R !== R) stimTrCache = { key, R, all: stimTracesAll(t0, t1, x0, w) };
  return stimTrCache.all.slice(m * 4, m * 4 + 4);
}
function stimTracesAll(t0, t1, x0, w) {
  const R = STIM.R, dt = R.dt, T = R.M * 4;
  const r = 1, sc = w / (t1 - t0), nc = Math.ceil(w * r) + 1; // one column per CSS pixel: the envelope needs no more
  const has = new Uint8Array(nc), cnt = new Uint32Array(nc), mn = new Float64Array(nc * T), mx = new Float64Array(nc * T), fi = new Float64Array(nc * T), la = new Float64Array(nc * T), xs = new Float64Array(nc);
  const colOf = k => Math.floor(((k + 0.5) * dt - t0) * sc * r);
  const add = (c, v, x, n) => {
    const b = c * T;
    if (!has[c]) { has[c] = 1; cnt[c] = n; xs[c] = x; for (let j = 0; j < T; j++) mn[b + j] = mx[b + j] = fi[b + j] = la[b + j] = v[j]; return; }
    cnt[c] += n; for (let j = 0; j < T; j++) { const u = v[j]; if (u < mn[b + j]) mn[b + j] = u; if (u > mx[b + j]) mx[b + j] = u; la[b + j] = u; }
  };
  const kA = Math.max(0, Math.floor(t0 / dt) - 1), kB = Math.min(R.done ? R.N - 1 : R.doneK - 2, Math.ceil(t1 / dt) + 1);
  if (kB >= kA) {
    const nView = kB - kA + 1;
    if (nView <= nc * 24) { // exact, from the nearest checkpoint (a few ms)
      stimExact(R, kA, kB, (k, v) => { const c = colOf(k); if (c >= 0 && c < nc) add(c, v, x0 + ((k + 0.5) * dt - t0) * sc, 1); },
        (a, b, val) => { // falling run: its first and last interval in each column
          for (let k = a; k <= b;) {
            const c = colOf(k), kc = Math.min(b, Math.max(k, Math.ceil((t0 + (c + 1) / (sc * r)) / dt - 0.5) - 1));
            if (c >= 0 && c < nc) { add(c, val(k), x0 + ((k + 0.5) * dt - t0) * sc, 1); if (kc > k) add(c, val(kc), 0, 1); }
            k = kc + 1;
          }
        });
    } else { // from the bins: the coarsest level with at least two buckets per column
      const L = R.pyr || [{ size: 1, mn: R.mn, mx: R.mx, n: R.nBin }];
      let lev = 0; const per = nView / nc; while (lev + 1 < L.length && L[lev + 1].size * R.bin * 2 <= per) lev++;
      const P = L[lev], bs = P.size * R.bin, lastQ = R.done ? P.n - 1 : Math.floor((R.doneK - 1) / bs) - 1, v = new Float64Array(T), u = new Float64Array(T);
      for (let c = 0; c < nc; c++) {
        const ka = Math.floor((t0 + c / (sc * r)) / dt), kb = Math.floor((t0 + (c + 1) / (sc * r)) / dt) - 1;
        const qa = Math.max(0, Math.floor(ka / bs)), qb = Math.min(lastQ, Math.floor(kb / bs)); if (qb < qa) continue;
        v.fill(-Infinity); u.fill(Infinity);
        for (let q = qa; q <= qb; q++) for (let j = 0; j < T; j++) { const z = P.mx[q * T + j], y = P.mn[q * T + j]; if (z > v[j]) v[j] = z; if (y < u[j]) u[j] = y; }
        add(c, v, 0, 2); for (let j = 0; j < T; j++) mn[c * T + j] = u[j]; // band from minimum to maximum; the line follows the maximum
      }
    }
  }
  // per trace one polyline: the sample where a column holds one, else the column's maximum (the envelope that matters
  // for stimulation); drawing min-max bands for eight dense traces cost several times more to paint (measured)
  const out = [];
  for (let j = 0; j < T; j++) {
    const pts = [];
    // empty columns are skipped, not broken: zoomed in, samples are sparser than pixels and the line must join them
    for (let c = 0; c < nc; c++) { if (!has[c]) continue; const q = c * T + j; pts.push(cnt[c] === 1 ? xs[c] : x0 + (c + 0.5) / r, cnt[c] === 1 ? fi[q] : mx[q]); }
    out.push(pts);
  }
  return out;
}
function stimLine(pts, yOf, color, fillBase) { // pts: x, v pairs; NaN breaks the line
  pctx.beginPath(); let pen = false, segs = [];
  for (let i = 0; i < pts.length; i += 2) { const v = pts[i + 1]; if (v !== v) { pen = false; continue; } const y = yOf(v); if (!pen) { pctx.moveTo(pts[i], y); segs.push([pts[i], pts[i]]); pen = true; } else { pctx.lineTo(pts[i], y); segs[segs.length - 1][1] = pts[i]; } }
  if (fillBase !== undefined) { // faint area under the norm: close each run down to the baseline
    const area = new Path2D(); pen = false; let x0 = 0, xl = 0;
    for (let i = 0; i < pts.length; i += 2) { const v = pts[i + 1]; if (v !== v) { if (pen) { area.lineTo(xl, fillBase); area.lineTo(x0, fillBase); area.closePath(); } pen = false; continue; } const y = yOf(v); if (!pen) { area.moveTo(pts[i], y); x0 = pts[i]; pen = true; } else area.lineTo(pts[i], y); xl = pts[i]; }
    if (pen) { area.lineTo(xl, fillBase); area.lineTo(x0, fillBase); area.closePath(); }
    pctx.globalAlpha = 0.14; pctx.fillStyle = color; pctx.fill(area); pctx.globalAlpha = 1;
  }
  pctx.strokeStyle = color; pctx.lineWidth = EXP ? EXP.lwCss : 1.3; pctx.lineJoin = EXP ? 'round' : 'bevel'; pctx.stroke();
}
function drawStimLane(L, t0, t1, x0, pw) {
  const k = L.stim, name = STIM_NAME[k], m = STIM ? STIM.idx[k] : undefined;
  pctx.fillStyle = C.ink; pctx.fillRect(8, L.y + 2, 3, L.h - 4);
  pctx.textAlign = 'left'; pctx.font = `600 12px ${C.font}`; pctx.fillStyle = C.ink;
  const twoLine = L.h > 58; pctx.fillText(name, 16, L.y + L.h / 2 - (twoLine ? 7 : 0));
  pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted; if (twoLine) pctx.fillText('% of limit', 16, L.y + L.h / 2 + 8);
  if (L.h > 80) { pctx.font = `600 11px ${C.font}`; let lx = 16; for (const [c, tx] of [['gx', 'x'], ['gy', 'y'], ['gz', 'z']].concat(S.stimNorm ? [['muted', '‖·‖']] : [])) { pctx.fillStyle = C[c]; pctx.fillText(tx, lx, L.y + L.h / 2 + 24); lx += tx.length > 1 ? 22 : 12; } }
  const msg = t => { pctx.font = `400 12px ${C.font}`; pctx.fillStyle = C.muted; pctx.textAlign = 'left'; pctx.fillText(t, x0 + 10, L.y + L.h / 2); };
  if (m === undefined) { msg(stimHasModel(k) ? 'Computing…' : `No ${name} parameters: set them under Display › System specifications`); return; }
  const R = STIM.R, pad = 4, base = L.y + L.h - pad, hh = L.h - 2 * pad;
  if (!R.done) { msg(`Computing ${name}… ${Math.round(100 * (STIM.progress || 0))} %`); return; } // results arrive when the pass is complete
  let top = Math.max(100, R.peak[m * 4 + 3] || 0, R.peak[m * 4] || 0, R.peak[m * 4 + 1] || 0, R.peak[m * 4 + 2] || 0) * 1.04;
  const traces = stimTraces(m, t0, t1, x0, pw);
  if (S.autoY) { let v = 0; for (let j = 0; j < 4; j++) if (j < 3 || S.stimNorm) for (let i = 1; i < traces[j].length; i += 2) if (traces[j][i] > v) v = traces[j][i]; if (v > 0) top = v * 1.08; }
  const yz = yZoomOf(L.key); top /= yz;
  const yOf = v => base - v / top * hh;
  // zero line and the limit (100 %)
  pctx.strokeStyle = C.line; pctx.lineWidth = 1; pctx.beginPath(); pctx.moveTo(x0, Math.round(base) + 0.5); pctx.lineTo(x0 + pw, Math.round(base) + 0.5); pctx.stroke();
  pctx.textAlign = 'right'; pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
  // axis labels: the limit (100 %) at its line; the top of the axis only where it does not crowd that label (the top
  // is 4 % above the larger of the limit and the peak, so without a peak above the limit only "100" is shown)
  const showLim = 100 <= top, topClear = !showLim || Math.abs(yOf(100) - (L.y + 7)) > 12;
  if (topClear) pctx.fillText(fmt(top, 3), x0 - 6, L.y + 7);
  pctx.fillText('0', x0 - 6, L.y + L.h - 7);
  if (showLim) {
    const y = Math.round(yOf(100)) + 0.5; pctx.strokeStyle = C.rf; pctx.globalAlpha = 0.7; pctx.setLineDash([5, 4]); pctx.beginPath(); pctx.moveTo(x0, y); pctx.lineTo(x0 + pw, y); pctx.stroke(); pctx.setLineDash([]); pctx.globalAlpha = 1;
    pctx.fillStyle = C.rf; pctx.fillText('100', x0 - 6, Math.max(y, L.y + 7));
  }
  pctx.save(); pctx.beginPath(); pctx.rect(x0, L.y - 1, pw, L.h + 2); pctx.clip();
  if (S.stimNorm) stimLine(traces[3], yOf, C.muted, base);
  stimLine(traces[0], yOf, C.gx); stimLine(traces[1], yOf, C.gy); stimLine(traces[2], yOf, C.gz);
  pctx.restore();
  if (yz !== 1 && !EXP) yZoomTag(L, x0);
}
/* the lane's y zoom factor, at the top left of its plot area, with a red cross that resets it (1.47.0). The × and
   the digits are centred on the tag's middle line from their drawn bounds, not from the font's baseline. */
const YZ_HIT = {}; // lane key → [x, y, w, h] of the reset cross (CSS px), from the last drawing
function yZoomTag(L, x0) {
  if (RPANEL) return; // Group segments: once, in the first panel
  const z = yZoomOf(L.key), n = String(z >= 10 ? Math.round(z) : +z.toFixed(z < 1 ? 2 : 1));
  const f1 = `500 10.5px ${C.font}`, f2 = `500 14px ${C.font}`, h = 17, top = L.y + 2, cy = top + h / 2, xs = 13;
  pctx.save(); pctx.textAlign = 'left'; pctx.textBaseline = 'alphabetic';
  pctx.font = f1; const wy = pctx.measureText('y').width, mn = pctx.measureText(n), wn = mn.width;
  pctx.font = f2; const mx = pctx.measureText('×'), wx = mx.width;
  const w = 6 + wy + 2 + wx + 2 + wn + 4 + xs + 2;
  pctx.fillStyle = C.plot; pctx.globalAlpha = 0.85; pctx.fillRect(x0 + 4, top, w, h); pctx.globalAlpha = 1;
  const bl = cy + ((mn.actualBoundingBoxAscent || 7.5) - (mn.actualBoundingBoxDescent || 0)) / 2; // digits centred
  let x = x0 + 10; pctx.fillStyle = C.muted;
  pctx.font = f1; pctx.fillText('y', x, bl); x += wy + 2;
  pctx.font = f2; pctx.fillText('×', x, cy + ((mx.actualBoundingBoxAscent || 7) - (mx.actualBoundingBoxDescent || 0)) / 2); x += wx + 2;
  pctx.font = f1; pctx.fillText(n, x, bl); x += wn + 4;
  const cx = x + xs / 2, r = 3.3; // the reset cross
  pctx.strokeStyle = C.bad || '#B91C1C'; pctx.lineWidth = 1.6; pctx.lineCap = 'round'; pctx.beginPath();
  pctx.moveTo(cx - r, cy - r); pctx.lineTo(cx + r, cy + r); pctx.moveTo(cx + r, cy - r); pctx.lineTo(cx - r, cy + r); pctx.stroke();
  pctx.restore();
  YZ_HIT[L.key] = [x - 1, top - 1, xs + 3, h + 2];
}
function yzCrossAt(x, y) { // the lane whose reset cross is under (x, y), or null
  for (const k in YZ_HIT) {
    if (!S.yZoom[k]) continue; const [a, b, w, h] = YZ_HIT[k];
    if (x >= a && x <= a + w && y >= b && y <= b + h) { const L = laneAtY(y); if (L && L.key === k) return k; }
  }
  return null;
}
function stimAt(t) { // values of every trace at time t, or null
  if (!STIM) return null; const k = stimK(t); if (k < 0 || !stimReady(k) || k >= STIM.R.N) return null;
  let out = null; stimExact(STIM.R, k, k, (kk, v) => { out = Float64Array.from(v); }, (a, b, val) => { out = Float64Array.from(val(a)); }); return out;
}
let stimAtMemo = null; // the overlay and the readout ask for the same cursor time
function stimAtCached(t) { const key = STIM ? t + '|' + STIM.R.doneK : ''; if (!stimAtMemo || stimAtMemo.key !== key) stimAtMemo = { key, v: stimAt(t) }; return stimAtMemo.v; }
function stimReadout(t) {
  const on = ['pns', 'cns'].filter(k => S.vis[k] && STIM && STIM.idx[k] !== undefined); if (!on.length) return '';
  const v = stimAtCached(t); if (!v) return '';
  return on.map(k => `<span class="v"><i style="--c:var(--muted)"></i>${STIM_NAME[k]} <b>${stimNum(v[STIM.idx[k] * 4 + 3])}</b> %</span>`).join('');
}
/* peak of every trace over intervals kA..kB: bins that lie wholly inside give their stored maximum (exact to Float32),
   the partial bins at the two ends are recomputed exactly */
function stimPeak(R, kA, kB) {
  const T = R.M * 4, b = R.bin, qa = Math.ceil(kA / b), qb = Math.floor((kB + 1) / b) - 1;
  if (qb < qa) return stimRangeMax(R, kA, kB).v;
  const v = new Float64Array(T).fill(-Infinity), upd = x => { for (let j = 0; j < T; j++) if (x[j] > v[j]) v[j] = x[j]; };
  for (let q = qa; q <= qb; q++) for (let j = 0; j < T; j++) if (R.mx[q * T + j] > v[j]) v[j] = R.mx[q * T + j];
  if (kA < qa * b) upd(stimRangeMax(R, kA, qa * b - 1).v);
  if ((qb + 1) * b <= kB) upd(stimRangeMax(R, (qb + 1) * b, kB).v);
  return v;
}
function fmtPct(v) { return `${stimNum(v)} %`; }
function stimNum(v) { return !(v >= 0.01) ? '< 0.01' : fmt(v, 3); } // quiet stretches decay towards zero: no 1e-10
/* rows for a time range (block, shot or volume): peak of the norm and of each axis */
function stimRows(ta, tb) {
  if (!STIM) return [];
  const R = STIM.R, kA = Math.max(0, Math.floor(ta / R.dt)), kB = Math.min(R.N - 1, Math.ceil(tb / R.dt) - 1); if (kB < kA) return [];
  if (!stimReady(kB)) return Object.keys(STIM.idx).map(k => [`${STIM_NAME[k]} peak`, '<span class="muted">computing…</span>']);
  const v = stimPeak(R, kA, kB);
  return Object.keys(STIM.idx).map(k => { const o = STIM.idx[k] * 4;
    return [`${STIM_NAME[k]} peak`, `<b>${fmtPct(v[o + 3])}</b> <span class="muted">x ${stimNum(v[o])}, y ${stimNum(v[o + 1])}, z ${stimNum(v[o + 2])}</span>`]; });
}
function stimSummaryHTML() {
  let h = `<h3>Nerve stimulation <span class="tag">SAFE model</span></h3>`;
  const keys = ['pns', 'cns'];
  if (!keys.some(k => SAFE[k])) return h + `<p class="note">Set a system's SAFE parameters to predict peripheral (PNS) and cardiac (CNS) nerve stimulation along the sequence.</p><button class="btn" data-safe-open>System specifications…</button>`;
  for (const k of keys) {
    const hw = SAFE[k]; if (!hw) continue;
    const chk = safeHwCheck(hw), lib = chk.ok ? safeLibMatch(hw) : null;
    h += `<p class="note" style="margin:8px 0 4px"><b>${STIM_NAME[k]}</b>: ${esc(hw.name || 'unnamed')}${hw.example ? ' <span class="muted">(example, not a real scanner)</span>' : ''}` +
      (lib && lib.name ? ` <span class="muted">· matches library: ${esc(lib.name)}${lib.variant > 1 ? ' (variant ' + lib.variant + ')' : ''}</span>` : '') + (chk.ok ? '' : ` <span style="color:var(--c-rf)">· ${esc(chk.msg)}</span>`) + '</p>';
    if (!chk.ok || !STIM || STIM.idx[k] === undefined) continue;
    const R = STIM.R, o = STIM.idx[k] * 4;
    if (!R.done) { h += kv([['Peaks', '<span class="muted">computing…</span>']]); continue; }
    const at = j => { const t = (R.peakK[o + j] + 0.5) * R.dt; return `<button class="btn link" data-stim-t="${t}">${fmtT(t)}</button>`; };
    h += kv([['Peak, L2 norm', `<b>${fmtPct(R.peak[o + 3])}</b> at ${at(3)}`], ...['x', 'y', 'z'].map((a, j) => [`Peak, ${a}`, `${fmtPct(R.peak[o + j])} at ${at(j)}`])]);
  }
  if (STIM && STIM.R.done) h += `<p class="note">Percent of the stimulation limit (100 %). From the physical gradients on the ${us(STIM.R.dt)} gradient raster, taking the sequence's x, y and z as the scanner's gradient axes.</p>`;
  return h + `<button class="btn" data-safe-open>System specifications…</button>`;
}
document.addEventListener('click', e => {
  const o = e.target.closest('[data-safe-open]'); if (o) { openSafeDialog(); return; }
  const b = e.target.closest('[data-stim-t]'); if (b && S.seq) { const t = tToV(+b.dataset.stimT), span = Math.min(S.t1 - S.t0, 0.01); pushHist(); setView(t - span / 2, t + span / 2); }
});
function updateStimStat() {
  const el = $('#stimStat'); if (!el) return;
  const parts = ['pns', 'cns'].map(k => SAFE[k] ? `${STIM_NAME[k]}: ${SAFE[k].name || 'unnamed'}${safeHwCheck(SAFE[k]).ok ? '' : ' (incomplete)'}` : `${STIM_NAME[k]}: not set`);
  el.textContent = parts.join('; ');
}
$('#stimNorm').checked = S.stimNorm;
$('#stimNorm').onchange = e => { S.stimNorm = e.target.checked; request(); };
/* the specifications dialog */
function openSafeDialog() { renderSafeForms(); const d = $('#safeDlg'); if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else d.setAttribute('open', ''); }
$('#stimSpecBtn').onclick = openSafeDialog; $('#specMenuBtn').onclick = openSafeDialog;
$('#safeClose').onclick = () => { const d = $('#safeDlg'); if (d.close) d.close(); else d.removeAttribute('open'); };
$('#safeDlg').addEventListener('close', () => stimStart(false));
function safeEmpty(model) { const e = {}; for (const k of SAFE_PARAMS) e[k] = undefined; return { name: '', model, x: { ...e }, y: { ...e }, z: { ...e } }; }
function renderSafeForms() {
  const host = $('#safeForms'); host.innerHTML = '';
  for (const k of ['pns', 'cns']) {
    const hw = SAFE[k] || safeEmpty(k === 'cns' ? 'Cardiac' : 'Peripheral'), chk = safeHwCheck(hw), lib = chk.ok ? safeLibMatch(hw) : null;
    const box = document.createElement('div'); box.className = 'safemodel';
    const st = !SAFE[k] ? 'Not set' : !chk.ok ? chk.msg : lib && lib.name ? `Complete; matches the library entry ${lib.name}${lib.variant > 1 ? ' (variant ' + lib.variant + ')' : ''}` : 'Complete; not in the library of known systems (it may still be right)';
    box.innerHTML = `<h3>${STIM_NAME[k]} <span class="muted" style="font-weight:400">${STIM_LONG[k]}</span></h3><p class="st ${!SAFE[k] ? '' : chk.ok ? 'ok' : 'bad'}">${esc(st)}${hw.example ? ' · example parameters, not a real scanner' : ''}</p>` +
      `<div class="safename"><label for="safeName-${k}">Name</label><input id="safeName-${k}" value="${esc(hw.name || '')}" placeholder="e.g. MP_GPA_…"></div>` +
      `<div class="safegrid"><span></span><span class="h">x</span><span class="h">y</span><span class="h">z</span>` +
      SAFE_PARAMS.map(p => `<label for="safe-${k}-x-${p}"${p === 'stim_thresh' ? ' title="Checked for completeness, as in safe_hw_check; the model does not use it"' : ''}>${p}${SAFE_UNITS[p] ? ` <span class="muted">(${SAFE_UNITS[p]}${p === 'stim_thresh' ? ', not used' : ''})</span>` : ''}</label>` +
        ['x', 'y', 'z'].map(a => `<input id="safe-${k}-${a}-${p}" inputmode="decimal" data-k="${k}" data-a="${a}" data-p="${p}" value="${hw[a][p] === undefined ? '' : hw[a][p]}" aria-label="${STIM_NAME[k]} ${a} ${p}">`).join('')).join('') + `</div>`;
    host.appendChild(box);
  }
  host.querySelectorAll('.safegrid input').forEach(inp => inp.addEventListener('change', () => {
    const k = inp.dataset.k, v = inp.value.trim() === '' ? undefined : Number(inp.value);
    inp.classList.toggle('bad', v !== undefined && !isFinite(v));
    if (!SAFE[k]) SAFE[k] = safeEmpty(k === 'cns' ? 'Cardiac' : 'Peripheral');
    SAFE[k][inp.dataset.a][inp.dataset.p] = isFinite(v) ? v : undefined; delete SAFE[k].example; saveSafe(); refreshSafeStatus();
  }));
  for (const k of ['pns', 'cns']) $(`#safeName-${k}`).addEventListener('change', e => { if (!SAFE[k]) SAFE[k] = safeEmpty(k === 'cns' ? 'Cardiac' : 'Peripheral'); SAFE[k].name = e.target.value; saveSafe(); refreshSafeStatus(); });
}
function refreshSafeStatus() { // update the status lines without rebuilding the inputs (keeps focus)
  document.querySelectorAll('#safeForms .safemodel').forEach((box, i) => {
    const k = ['pns', 'cns'][i], hw = SAFE[k], chk = safeHwCheck(hw), lib = chk.ok ? safeLibMatch(hw) : null, el = box.querySelector('.st');
    el.className = 'st ' + (!hw ? '' : chk.ok ? 'ok' : 'bad');
    el.textContent = !hw ? 'Not set' : !chk.ok ? chk.msg : lib && lib.name ? `Complete; matches the library entry ${lib.name}${lib.variant > 1 ? ' (variant ' + lib.variant + ')' : ''}` : 'Complete; not in the library of known systems (it may still be right)';
  });
  updateStimStat();
}
$('#safeLoad').onclick = () => $('#safeFile').click();
$('#safeFile').onchange = async e => {
  const files = [...e.target.files]; e.target.value = ''; if (!files.length) return;
  const list = await Promise.all(files.map(async f => ({ name: f.name, text: await f.text() })));
  const r = safeFromAscFiles(list), notes = [...new Set(r.notes)];
  for (const k of ['pns', 'cns']) if (r[k]) { const hw = r[k]; SAFE[k] = { name: hw.name, model: hw.model, x: hw.x, y: hw.y, z: hw.z, file: hw.file, checksum: hw.checksum, dependency: hw.dependency }; for (const q of hw.errors || []) notes.push(q); }
  if (!r.pns && !r.cns) notes.unshift('No SAFE parameters were found in the file' + (files.length > 1 ? 's' : '') + '.');
  else notes.unshift(`Read ${[r.pns && 'PNS', r.cns && 'CNS'].filter(Boolean).join(' and ')} parameters from ${files.map(f => f.name).join(', ')}.` + (r.pns && !r.cns ? ' This file format has no cardiac parameters.' : ''));
  saveSafe(); renderSafeForms(); $('#safeNotes').textContent = notes.join(' '); updateStimStat();
};
$('#safeExample').onclick = () => { SAFE = { pns: safeExample('pns'), cns: safeExample('cns') }; saveSafe(); renderSafeForms(); $('#safeNotes').textContent = 'Loaded the example parameters of safe_pns_prediction. They do not describe a real scanner.'; updateStimStat(); };
$('#safeClear').onclick = () => { SAFE = { pns: null, cns: null }; saveSafe(); renderSafeForms(); $('#safeNotes').textContent = 'Cleared.'; updateStimStat(); };
updateStimStat();

/* ---------- options panels ----------
   A button .optbtn[aria-controls] shows or hides its .popbody. Floating panels (header, diagram) close on a click
   outside, on Escape (focus back to the button) and when another floating panel opens; inline panels (side panel)
   stay until their button is pressed again. */
(function setupPanels() {
  const btns = [...document.querySelectorAll('.optbtn[aria-controls]')], pan = b => document.getElementById(b.getAttribute('aria-controls'));
  const isFloat = b => pan(b).classList.contains('float');
  const close = (b, focus) => { const p = pan(b); if (p.hidden) return; p.hidden = true; b.setAttribute('aria-expanded', 'false'); if (focus) b.focus(); if (p.id === 'imOpts') imSummary(); };
  const open = b => {
    const p = pan(b); for (const o of btns) if (o !== b && isFloat(o)) close(o);
    p.hidden = false; b.setAttribute('aria-expanded', 'true');
    if (isFloat(b)) { p.style.right = ''; const r = p.getBoundingClientRect(); if (r.left < 8) p.style.right = `${r.left - 8}px`; fitHeight(p); } // keep it on screen
    if (p.id === 'imOpts') imSummary();
  };
  /* never taller than the window below the panel's top (1.48.2): a short window scrolls inside the panel instead of
     pushing its lower part off screen */
  function fitHeight(p) { p.style.maxHeight = ''; const t = p.getBoundingClientRect().top; p.style.maxHeight = Math.max(160, Math.floor(window.innerHeight - t - 10)) + 'px'; }
  window.addEventListener('resize', () => { for (const b of btns) if (isFloat(b) && !pan(b).hidden) fitHeight(pan(b)); });
  for (const b of btns) b.addEventListener('click', () => pan(b).hidden ? open(b) : close(b));
  document.addEventListener('pointerdown', e => { for (const b of btns) if (isFloat(b) && !pan(b).hidden && !pan(b).contains(e.target) && !b.contains(e.target)) close(b); }, true);
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    const b = btns.find(x => isFloat(x) && !pan(x).hidden); if (!b) return;
    if (e.target.closest('select')) return; // let an open select close first
    e.stopPropagation(); e.preventDefault(); close(b, true);
  }, true);
  $('#imSum').addEventListener('click', () => { open($('#imOptBtn')); const f = $('#imOpts').querySelector('button,input,select'); if (f) f.focus(); });
  const later = () => setTimeout(imSummary, 0);
  $('#imOpts').addEventListener('change', later); $('#imOpts').addEventListener('click', later);
  imSummary();
})();

/* ---------- concomitant gradients: settings dialog, panel rows ---------- */
function ccValid(c) { // { r: [m, m, m], B0 (T), a, f (T/m), pos ('fixed' or 'slice'; missing in settings before 1.43.0) } or null
  const ok = v => typeof v === 'number' && isFinite(v);
  if (!c || !Array.isArray(c.r) || c.r.length !== 3 || !c.r.every(ok) || !ok(c.B0) || !(c.B0 > 0) || !ok(c.a) || !ok(c.f)) return null;
  return { r: c.r.slice(), B0: c.B0, a: c.a, f: c.f, pos: c.pos === 'slice' ? 'slice' : 'fixed' };
}
/* cursor readout in slice mode: the position used there */
function ccPosReadout(t) {
  const s = S.seq; if (!s.cc.sp) return '';
  const q = ccPosOf(s, blockAtTime(s, t));
  return `<span class="v" title="${q.slice ? 'Concomitant terms at the centre of the slice excited at the start of this shot (frequency / gradient along the normal)' : 'No slice-selective excitation before this point in the shot: the fixed position r from Concomitant › Settings…'}">r${q.slice ? ' (slice)' : ' (fixed)'} <b>${q.r.map(v => fmt(v * 100, 3)).join(', ')}</b> <span class="muted">cm</span></span>`;
}
const ccCm = v => +(v * 100).toPrecision(10);
function ccSync() { // dialog from S.cc
  const c = S.cc; $('#ccX').value = ccCm(c.r[0]); $('#ccY').value = ccCm(c.r[1]); $('#ccZ').value = ccCm(c.r[2]);
  $('#ccB0').value = c.B0; $('#ccA').value = c.a; $('#ccF').value = c.f; $('#ccPos').value = c.pos;
  $('#ccRLab').textContent = c.pos === 'slice' ? 'Fixed r (no slice; x, y, z)' : 'Position r (x, y, z)';
  for (const id of ['ccX', 'ccY', 'ccZ', 'ccB0', 'ccA', 'ccF']) $('#' + id).classList.remove('bad');
  ccStatus();
}
function ccStatus() {
  const el = $('#ccNote'), c = S.cc, R = Math.hypot(...c.r) * 100;
  let t = c.pos === 'slice' ? `Each shot uses the centre of the slice its excitation selects (frequency / gradient along the slice normal, no in-plane offset); r (|r| = ${fmt(R, 3)} cm) is used where there is no slice-selective excitation.` : `|r| = ${fmt(R, 3)} cm.`;
  if (S.seq && c.pos === 'slice') { ccEnsure(); const cc = S.seq.cc, n = cc.posR.length - 1, nf = cc.sp.of.reduce((x, p, i) => x + (p === 0 && S.seq.B.ccx[i] ? 1 : 0), 0); t += ` ${S.name}: ${n} slice position${n === 1 ? '' : 's'}, ${cc.ent.length - 1} block geometries computed${nf ? `; ${nf} block${nf === 1 ? ' with gradients uses' : 's with gradients use'} the fixed r` : ''}.`; }
  if (S.seq) { ccEnsure(); const m = S.seq.cc.max; t += ` Peak Gc in ${S.name}: x ${fmt(m[0] * gF(), 3)}, y ${fmt(m[1] * gF(), 3)}, z ${fmt(m[2] * gF(), 3)} ${gU()}.`; }
  if (c.f !== 0) t += ' With f ≠ 0, Gc is not zero where the gradients are off (the static f term), so kc also grows during pauses.';
  el.textContent = t;
}
function ccApply() {
  if (S.seq) ccEnsure();
  request(); if (S.seq) { renderSeqInfo(); renderBlock(); }
  if (S.kActual) { kInvalidate(); requestK(); } kActNote();
  scheduleSave(); ccStatus();
}
function ccRead() { // dialog to S.cc (only when every field is valid)
  const num = id => { const el = $('#' + id), v = el.value.trim() === '' ? NaN : Number(el.value); return { el, v }; };
  const F = { x: num('ccX'), y: num('ccY'), z: num('ccZ'), B0: num('ccB0'), a: num('ccA'), f: num('ccF') };
  let ok = true; for (const k in F) { const bad = !isFinite(F[k].v) || (k === 'B0' && !(F[k].v > 0)); F[k].el.classList.toggle('bad', bad); if (bad) ok = false; }
  if (!ok) { $('#ccNote').textContent = 'Enter a number in every field (B0 above 0).'; return; }
  S.cc = { r: [F.x.v / 100, F.y.v / 100, F.z.v / 100], B0: F.B0.v, a: F.a.v, f: F.f.v, pos: $('#ccPos').value === 'slice' ? 'slice' : 'fixed' };
  $('#ccRLab').textContent = S.cc.pos === 'slice' ? 'Fixed r (no slice; x, y, z)' : 'Position r (x, y, z)'; ccApply();
}
for (const id of ['ccX', 'ccY', 'ccZ', 'ccB0', 'ccA', 'ccF', 'ccPos']) $('#' + id).addEventListener('change', ccRead);
$('#ccDefault').onclick = () => { S.cc = { r: CC_DEF.r.slice(), B0: CC_DEF.B0, a: CC_DEF.a, f: CC_DEF.f, pos: CC_DEF.pos }; ccSync(); ccApply(); };
function openCcDialog() {
  for (const id of ['morePop', 'dispPop']) { const p = $('#' + id); if (!p.hidden) { p.hidden = true; const b = document.querySelector(`[aria-controls="${id}"]`); if (b) b.setAttribute('aria-expanded', 'false'); } }
  ccSync(); const d = $('#ccDlg'); if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else d.setAttribute('open', '');
}
$('#ccSpecBtn').onclick = openCcDialog; $('#ccMenuBtn').onclick = openCcDialog;
$('#ccClose').onclick = () => { const d = $('#ccDlg'); if (d.close) d.close(); else d.removeAttribute('open'); };
/* Selection tab, block card: the position (slice mode), peak Gc in the block, kc and k + kc at its end (when a
   concomitant lane is on) */
function ccRows(i) {
  if (!S.seq || !(S.vis.gc || S.vis.kc || S.vis.kt)) return [];
  ccEnsure(); const s = S.seq, id = s.B.ccx[i], pk = [0, 1, 2].map(a => { if (!id) return 0; const g = ccGeo(s, id).geo[a]; return Math.max(Math.abs(g.min), Math.abs(g.max)); });
  const rows = [];
  if (s.cc.sp) { const q = ccPosOf(s, i); rows.push(['Position r', `<span title="${q.slice ? `Centre of the slice excited in block ${s.B.id[q.exc]}` : 'No slice-selective excitation: the fixed r'}">(${q.r.map(v => fmt(v * 100, 4)).join(', ')}) <span class="muted">cm, ${q.slice ? 'slice centre' : 'fixed'}</span></span>`]); }
  rows.push(['Gc peak', `${pk.map(v => fmt(v * gF(), 3)).join(', ')} <span class="muted">${gU()}</span>`],
    ['kc at the end', `${[0, 1, 2].map(a => fmt(s.cc.kStart[a][i + 1] * mF(), 4)).join(', ')} <span class="muted">${mU()}</span>`]);
  if (S.vis.kt) rows.push(['k + kc at the end', `${[0, 1, 2].map(a => fmt(s.cc.ktStart[a][i + 1] * mF(), 4)).join(', ')} <span class="muted">${mU()}</span>`]);
  return rows;
}
/* Sequence tab: the parameters, peak Gc and the largest |kc| in blocks with a readout */
function ccSummaryHTML() {
  if (!S.seq || !(S.vis.gc || S.vis.kc || S.vis.kt)) return '';
  ccEnsure(); kintPyramids(KP_KC, S.seq);
  const s = S.seq, P = s.cc.P, km = [0, 0, 0], o = {};
  for (let j = 0; j < s.adcBlocks.length; j++) { const b = s.adcBlocks[j]; for (let a = 0; a < 3; a++) { blockSummary(s, KP_KC.keys[a], b, o); km[a] = Math.max(km[a], Math.abs(o.mn), Math.abs(o.mx)); } }
  const nP = s.cc.sp ? s.cc.posR.length - 1 : 0;
  return `<h3>Concomitant gradients <span class="tag">${s.cc.sp ? `at ${nP} slice centre${nP === 1 ? '' : 's'}` : `at r = (${P.r.map(ccCm).join(', ')}) cm`}</span></h3>` +
    kv([s.cc.sp ? ['Fixed r (no slice)', `(${P.r.map(ccCm).join(', ')}) <span class="muted">cm</span>`] : null,['B0, a, f', `${+P.B0.toPrecision(6)} T, ${+P.a.toPrecision(6)}, ${+P.f.toPrecision(6)} T/m`],
      ['Peak Gc x / y / z', `${s.cc.max.map(v => fmt(v * gF(), 3)).join(' / ')} <span class="muted">${gU()}</span>`],
      s.adcBlocks.length ? ['Largest |kc| in readout blocks', `${km.map(v => fmt(v * mF(), 3)).join(' / ')} <span class="muted">${mU()}</span>`] : null]) +
    `<button class="btn" data-cc-open>Concomitant gradients…</button>`;
}
document.addEventListener('click', e => { if (e.target.closest('[data-cc-open]')) openCcDialog(); });
document.addEventListener('click', e => { const p = e.target.closest('[data-peak-b]'); if (!p || !S.seq) return; const b = +p.dataset.peakB; if (!(b >= 0 && b < S.seq.nb)) return; selectBlock(b, { kind: 'block' }); pushHist(); zoomToBlock(b); });

readColors(); resize();

/* ---------- a file embedded in the page by matlab/seqret.m ---------- */
// <script type="text/plain" id="autoSeq" data-name="..."> holds the file as base64, one chunk per line
function autoLoad() {
  const a = document.getElementById('autoSeq'); if (!a) return;
  const name = a.dataset.name || 'sequence.seq', lines = a.textContent.split(/\s+/).filter(Boolean), ds = { ...a.dataset }; a.remove();
  setBusy(true, 0);
  setTimeout(() => {
    try {
      const parts = lines.map(l => atob(l)); let n = 0; for (const p of parts) n += p.length;
      const bytes = new Uint8Array(n); let o = 0;
      for (const p of parts) { for (let i = 0; i < p.length; i++) bytes[o + i] = p.charCodeAt(i); o += p.length; }
      const mt = Date.parse(ds.mtime || ''); // data-path, data-mtime: written by seqret.m 1.47 and later
      load(bytes, name, { src: { embedded: true, path: ds.path || null, mod: isFinite(mt) ? mt : null } });
    } catch (e) { setBusy(false); showError(`Could not read the embedded file ${name}: ${e.message}`); }
  }, 30);
}
/* for tests/test_browser.py: the points traceChan returns for a channel over [t0, t1] drawn w CSS px wide, with the
   given peaks mode and columns per CSS px (the settings and the drawn view are restored) */
window.__trace = (key, t0, t1, w, mode, r) => { const m = BENCH.lineMode, q = traceR; BENCH.lineMode = mode; traceR = r; try { return Array.from(traceChan(key, t0, t1, 0, w)); } finally { BENCH.lineMode = m; traceR = q; } };
window.__traceEnd = () => S.seq.blockStart[S.seq.nb];
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', autoLoad); else autoLoad();
})();


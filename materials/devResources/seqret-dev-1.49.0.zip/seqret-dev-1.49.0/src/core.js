/* ===== Seqret core (v2): memory-lean Pulseq model =====
   Nothing is expanded over the whole timeline. The block table is kept as typed columns,
   event geometry is derived once per unique event, and everything else (drawing, values,
   k-space) is computed from those on demand. */
const GAMMA = 42.57638474e6; // Hz/T (1H)

/* force (1.48.1): files older than 1.4 always store shapes compressed, so there a stored length equal to num_samples
   is a coincidence (a derivative without repeated values: short shapes, noisy waveforms), not the mark of an
   uncompressed shape. Such a shape is decompressed like any other, as MATLAB Pulseq and PyPulseq do when they read
   these files (forceConvertUncompressed in their readShapes). Before, it was taken as it stood: 0.2, 0.3, −0.1, −0.4
   stayed that, where Pulseq reads 0.2, 0.5, 0.4, 0. */
function decompressShape(packed, numSamples, force = false) {
  if (!force && packed.length === numSamples) return Float32Array.from(packed);
  const w = new Float64Array(numSamples);
  let cp = 0, cu = 0; const L = packed.length;
  while (cp < L - 1) {
    if (packed[cp] !== packed[cp + 1]) { w[cu++] = packed[cp++]; }
    else { const rep = Math.round(packed[cp + 2]) + 2, v = packed[cp]; for (let k = 0; k < rep && cu < numSamples; k++) w[cu++] = v; cp += 3; }
  }
  if (cp === L - 1 && cu < numSamples) w[cu++] = packed[cp];
  for (let i = 1; i < numSamples; i++) w[i] += w[i - 1];
  return Float32Array.from(w);
}

/* ---------- parser (works on bytes; [BLOCKS] parsed without creating strings) ---------- */
function parseSeq(input, progress) {
  const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : input;
  if (isPulseqBinary(bytes)) return parseBinary(bytes, progress);
  const N = bytes.length, warnings = [];
  const seq = {
    version: { major: 1, minor: 4, revision: 0 }, defs: {}, defOrder: [],
    rf: new Map(), grad: new Map(), adc: new Map(), delays: new Map(), shapes: new Map(),
    extList: new Map(), extTypes: new Map(), extSpecs: new Map(), signature: null, warnings
  };
  let cap = 1 << 15, nb = 0;
  let C = Array.from({ length: 8 }, (_, k) => k === 1 ? new Float64Array(cap) : new Uint32Array(cap));
  const grow = () => { cap *= 2; C = C.map(a => { const b = new a.constructor(cap); b.set(a); return b; }); };
  let section = '', curShape = null, curExt = null, pos = 0, nextProg = 0;
  const flushShape = () => { // (the version is known here: [VERSION] is the first section of a file)
    if (curShape) { const V = seq.version; seq.shapes.set(curShape.id, decompressShape(curShape.data, curShape.num == null ? curShape.data.length : curShape.num, curShape.num != null && V.major === 1 && V.minor < 4)); curShape = null; }
  };
  const lineStr = (a, b) => b - a > 8192 ? new TextDecoder().decode(bytes.subarray(a, b)) : String.fromCharCode.apply(null, bytes.subarray(a, b));
  while (pos < N) {
    let e = bytes.indexOf(10, pos); if (e < 0) e = N;
    let a = pos, b = e; pos = e + 1;
    if (progress && a >= nextProg) { progress(0.45 * a / N); nextProg = a + 4e6; }
    while (a < b && (bytes[a] === 32 || bytes[a] === 9 || bytes[a] === 13)) a++;
    if (a >= b || bytes[a] === 35) continue; // empty or comment
    if (bytes[a] === 91) { // '['
      flushShape(); curExt = null;
      const s = lineStr(a, b); section = s.slice(1, s.indexOf(']')).trim().toUpperCase(); continue;
    }
    if (section === 'BLOCKS') {
      if (nb === cap) grow();
      let col = 0, val = 0, inNum = false;
      for (let i = a; i < b; i++) {
        const c = bytes[i];
        if (c >= 48 && c <= 57) { val = val * 10 + (c - 48); inNum = true; }
        else if (c === 35) break;
        else if (inNum) { if (col < 8) C[col][nb] = val; col++; val = 0; inNum = false; }
      }
      if (inNum && col < 8) { C[col][nb] = val; col++; }
      for (; col < 8; col++) C[col][nb] = 0;
      nb++; continue;
    }
    if (section === 'SHAPES' && curShape) { // fast path: one plain number per line
      const x = parseNum(bytes, a, b);
      if (x === x) { curShape.data.push(x); continue; }
    }
    let line = lineStr(a, b); const h = line.indexOf('#'); if (h >= 0) line = line.slice(0, h);
    line = line.trim(); if (!line) continue;
    if (section === 'SHAPES') {
      const c0 = line.charCodeAt(0);
      if ((c0 >= 48 && c0 <= 57) || c0 === 45 || c0 === 46 || c0 === 43) { if (curShape) { if (line.indexOf(' ') < 0 && line.indexOf('\t') < 0) curShape.data.push(+line); else for (const t of line.split(/\s+/)) curShape.data.push(+t); } continue; }
      const tok = line.split(/\s+/);
      if (tok[0] === 'shape_id') { flushShape(); curShape = { id: +tok[1], num: null, data: [] }; }
      else if (tok[0] === 'num_samples') { if (curShape) curShape.num = +tok[1]; }
      continue;
    }
    const tok = line.split(/\s+/);
    switch (section) {
      case 'VERSION': if (tok[0] in seq.version) seq.version[tok[0]] = parseInt(tok[1], 10); break;
      case 'DEFINITIONS': {
        const key = tok[0], rest = tok.slice(1), nums = rest.map(Number);
        seq.defs[key] = rest.length && nums.every(n => !isNaN(n)) ? (nums.length === 1 ? nums[0] : nums) : rest.join(' ');
        seq.defOrder.push(key); break;
      }
      case 'RF': {
        const n = tok.map(Number); let r;
        if (tok.length >= 12) r = { id: n[0], amp: n[1], magId: n[2], phaseId: n[3], timeId: n[4], center: n[5] * 1e-6, delay: n[6] * 1e-6, freqPPM: n[7], phasePPM: n[8], freq: n[9], phase: n[10], use: tok[11] };
        else if (tok.length === 8) r = { id: n[0], amp: n[1], magId: n[2], phaseId: n[3], timeId: n[4], delay: n[5] * 1e-6, freq: n[6], phase: n[7] };
        else if (tok.length === 7) r = { id: n[0], amp: n[1], magId: n[2], phaseId: n[3], timeId: 0, delay: n[4] * 1e-6, freq: n[5], phase: n[6] };
        else { warnings.push(`Unrecognized RF line: "${line}"`); break; }
        seq.rf.set(r.id, r); break;
      }
      case 'GRADIENTS': {
        const n = tok.map(Number); let g;
        if (tok.length >= 7) g = { type: 'arb', id: n[0], amp: n[1], first: n[2], last: n[3], shapeId: n[4], timeId: n[5], delay: n[6] * 1e-6 };
        else if (tok.length === 5) g = { type: 'arb', id: n[0], amp: n[1], shapeId: n[2], timeId: n[3], delay: n[4] * 1e-6 };
        else if (tok.length === 4) g = { type: 'arb', id: n[0], amp: n[1], shapeId: n[2], timeId: 0, delay: n[3] * 1e-6 };
        else { warnings.push(`Unrecognized gradient line: "${line}"`); break; }
        seq.grad.set(g.id, g); break;
      }
      case 'TRAP': { const n = tok.map(Number); seq.grad.set(n[0], { type: 'trap', id: n[0], amp: n[1], rise: n[2] * 1e-6, flat: n[3] * 1e-6, fall: n[4] * 1e-6, delay: (n[5] || 0) * 1e-6 }); break; }
      case 'ADC': {
        const n = tok.map(Number); let d;
        if (tok.length >= 9) d = { id: n[0], num: n[1], dwell: n[2] * 1e-9, delay: n[3] * 1e-6, freqPPM: n[4], phasePPM: n[5], freq: n[6], phase: n[7], phaseId: n[8] };
        else d = { id: n[0], num: n[1], dwell: n[2] * 1e-9, delay: n[3] * 1e-6, freq: n[4] || 0, phase: n[5] || 0 };
        seq.adc.set(d.id, d); break;
      }
      case 'DELAYS': seq.delays.set(+tok[0], +tok[1] * 1e-6); break;
      case 'EXTENSIONS':
        if (tok[0] === 'extension') { curExt = +tok[2]; seq.extTypes.set(curExt, tok[1]); seq.extSpecs.set(curExt, new Map()); }
        else if (curExt == null) { const n = tok.map(Number); seq.extList.set(n[0], { type: n[1], ref: n[2], next: n[3] }); }
        else seq.extSpecs.get(curExt).set(+tok[0], tok.slice(1));
        break;
      case 'SIGNATURE':
        if (!seq.signature) seq.signature = {};
        if (/^type$/i.test(tok[0])) seq.signature.type = tok[1];
        if (/^hash$/i.test(tok[0])) seq.signature.hash = tok[1];
        break;
    }
  }
  flushShape();
  return finishBlocks(seq, C, nb);
}
/* compact the block columns (ids to the smallest integer type that fits), then the timing */
function finishBlocks(seq, C, nb) {
  const cols = {};
  ['id', '_d', 'rf', 'gx', 'gy', 'gz', 'adc', 'ext'].forEach((k, j) => {
    const src = C[j].subarray(0, nb);
    if (k === '_d') { cols[k] = src.slice(); return; }
    let mx = 0; for (let i = 0; i < nb; i++) if (src[i] > mx) mx = src[i];
    cols[k] = mx < 256 && k !== 'id' ? Uint8Array.from(src) : mx < 65536 ? Uint16Array.from(src) : src.slice();
  });
  seq.nb = nb; seq.B = cols;
  finalizeTiming(seq);
  return seq;
}

/* ---------- Pulseq binary files (MATLAB Pulseq seq.writeBinary / readBinary, format 1.5.2) ----------
   Little-endian. Header: int64 magic (bytes 01 'pulseq' 02), int64 major, minor, revision. Then sections, each
   opened by an int64 code 0xFFFFFFFF000000nn and holding a count and records. Times are int64 picoseconds,
   shape samples float32 (the text format has 9 significant digits), labels a 1-based index into MATLAB Pulseq's
   list of supported labels (custom labels have no name in the file). A signature section (code 0xFFFFFFFF00FFFFFF)
   holds the md5 of all bytes before it, and its own start position as the last int64 of the file.
   The result has the same form as parseSeq's: extension data are stored as the text format's fields (µs). */
const BIN_LABELS = ['SLC', 'SEG', 'REP', 'AVG', 'SET', 'ECO', 'PHS', 'LIN', 'PAR', 'ACQ', 'TRID', 'NAV', 'REV', 'SMS', 'REF', 'IMA', 'OFF', 'NOISE', 'PMC', 'NOROT', 'NOPOS', 'NOSCL', 'ONCE']; // mr.getSupportedLabels (1.5.2)
const BIN_SIG = 0x00FFFFFF;
function isPulseqBinary(bytes) {
  if (!bytes || bytes.length < 32 || bytes[0] !== 1 || bytes[7] !== 2) return false;
  for (let k = 0; k < 6; k++) if (bytes[1 + k] !== 'pulseq'.charCodeAt(k)) return false;
  return true;
}
function parseBinary(bytes, progress) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), N = bytes.length, warnings = [];
  let p = 8;
  const need = n => { if (p + n > N) throw new Error(`Pulseq binary file ends early (byte ${p} of ${N}).`); };
  const i32 = () => { need(4); const v = dv.getInt32(p, true); p += 4; return v; };
  const i64 = () => { need(8); const v = Number(dv.getBigInt64(p, true)); p += 8; return v; };
  const f64 = () => { need(8); const v = dv.getFloat64(p, true); p += 8; return v; };
  const str = n => { need(n); let s = ''; for (let k = 0; k < n; k++) s += String.fromCharCode(bytes[p + k]); p += n; return s.replace(/\0+$/, ''); };
  const ps = () => i64() * 1e-12, us = () => i64() * 1e-6; // picoseconds to s, or to µs (the text format's unit)
  const seq = {
    version: { major: i64(), minor: i64(), revision: i64() }, defs: {}, defOrder: [], binary: true,
    rf: new Map(), grad: new Map(), adc: new Map(), delays: new Map(), shapes: new Map(),
    extList: new Map(), extTypes: new Map(), extSpecs: new Map(), signature: null, warnings
  };
  const V = seq.version;
  if (V.major !== 1 || V.minor !== 5) warnings.push(`Pulseq binary file of version ${V.major}.${V.minor}.${V.revision}; Seqret reads the binary format of 1.5.2`);
  let C = null, nb = 0; const odd = new Set();
  const ext = (name, type) => { seq.extTypes.set(type, name); const m = new Map(); seq.extSpecs.set(type, m); return m; };
  while (p < N) {
    need(8); const hi = dv.getUint32(p + 4, true), code = dv.getUint32(p, true); p += 8;
    if (hi !== 0xFFFFFFFF) throw new Error(`Pulseq binary file: no section at byte ${p - 8}.`);
    if (progress) progress(0.45 * p / N);
    if (code === BIN_SIG) {
      const type = str(i32()), n = i32(); need(n); let h = ''; for (let k = 0; k < n; k++) h += bytes[p + k].toString(16).padStart(2, '0'); p += n; i64();
      seq.signature = { type, hash: h }; continue;
    }
    switch (code) {
      case 1: { // definitions
        const n = i64();
        for (let d = 0; d < n; d++) {
          const key = str(i32()), cnt = i32(), ty = str(1); let v;
          if (ty === 'f') { v = []; for (let k = 0; k < cnt; k++) v.push(f64()); v = v.length === 1 ? v[0] : v; }
          else if (ty === 'i') { v = []; for (let k = 0; k < cnt; k++) v.push(i32()); v = v.length === 1 ? v[0] : v; }
          else if (ty === 'c') v = str(cnt);
          else throw new Error(`Pulseq binary file: unknown definition type '${ty}'.`);
          seq.defs[key] = v; seq.defOrder.push(key);
        }
        break;
      }
      case 2: { // blocks: int64 duration (block raster), int32 rf gx gy gz adc ext
        nb = i64(); need(nb * 32);
        C = Array.from({ length: 8 }, (_, k) => k === 1 ? new Float64Array(nb) : new Uint32Array(nb));
        for (let i = 0; i < nb; i++) { C[0][i] = i + 1; C[1][i] = Number(dv.getBigInt64(p, true)); for (let k = 0; k < 6; k++) C[2 + k][i] = dv.getInt32(p + 8 + 4 * k, true); p += 32; }
        break;
      }
      case 3: { const n = i64(); for (let e = 0; e < n; e++) { const id = i32(), amp = f64(), magId = i32(), phaseId = i32(), timeId = i32(), center = ps(), delay = ps(), freqPPM = f64(), phasePPM = f64(), freq = f64(), phase = f64(), use = str(1); seq.rf.set(id, { id, amp, magId, phaseId, timeId, center, delay, freqPPM, phasePPM, freq, phase, use }); } break; }
      case 4: { const n = i64(); for (let e = 0; e < n; e++) { const id = i32(), amp = f64(), first = f64(), last = f64(), shapeId = i32(), timeId = i32(), delay = ps(); seq.grad.set(id, { type: 'arb', id, amp, first, last, shapeId, timeId, delay }); } break; }
      case 5: { const n = i64(); for (let e = 0; e < n; e++) { const id = i32(), amp = f64(), rise = ps(), flat = ps(), fall = ps(), delay = ps(); seq.grad.set(id, { type: 'trap', id, amp, rise, flat, fall, delay }); } break; }
      case 6: { const n = i64(); for (let e = 0; e < n; e++) { const id = i32(), num = i64(), dwell = ps(), delay = ps(), freqPPM = f64(), phasePPM = f64(), freq = f64(), phase = f64(), phaseId = i32(); seq.adc.set(id, { id, num, dwell, delay, freqPPM, phasePPM, freq, phase, phaseId }); } break; }
      case 7: { const n = i64(); for (let e = 0; e < n; e++) { const id = i32(); seq.delays.set(id, us() * 1e-6); } break; }
      case 8: { // shapes: int32 id, int64 samples, int64 stored samples, float32 data
        const n = i64();
        for (let e = 0; e < n; e++) {
          const id = i32(), num = i64(), nc = i64(); need(4 * nc);
          const d = new Float32Array(nc); for (let k = 0; k < nc; k++) d[k] = dv.getFloat32(p + 4 * k, true); p += 4 * nc;
          seq.shapes.set(id, decompressShape(d, num));
        }
        break;
      }
      case 9: { const n = i64(); for (let e = 0; e < n; e++) { const id = i32(), type = i32(), ref = i32(), next = i32(); seq.extList.set(id, { type, ref, next }); } break; }
      case 10: { const m = ext('TRIGGERS', i32()), n = i64(); for (let e = 0; e < n; e++) { const id = i32(), ty = i32(), ch = i32(), d = us(), du = us(); m.set(id, [ty, ch, d, du]); } break; }
      case 11: case 12: {
        const m = ext(code === 11 ? 'LABELSET' : 'LABELINC', i32()), n = i64();
        for (let e = 0; e < n; e++) {
          const id = i32(), val = i32(), li = i32(), name = BIN_LABELS[li - 1] || `LABEL${li}`;
          if (!BIN_LABELS[li - 1] && !odd.has(li)) { odd.add(li); warnings.push(`Label number ${li} is not a standard Pulseq label (a custom label, mr.addCustomLabel, has no name in a binary file); shown as ${name}`); }
          m.set(id, [val, name]);
        }
        break;
      }
      case 13: { const m = ext('DELAYS', i32()), n = i64(); for (let e = 0; e < n; e++) { const id = i32(), num = i32(), off = us(), fac = f64(), hint = str(i32()); m.set(id, [num, off, fac, hint]); } break; }
      case 14: { const m = ext('RF_SHIMS', i32()), n = i64(); for (let e = 0; e < n; e++) { const id = i32(), nc = i32(), d = [nc]; for (let k = 0; k < 2 * nc; k++) d.push(f64()); m.set(id, d); } break; }
      case 15: { const m = ext('ROTATIONS', i32()), n = i64(); for (let e = 0; e < n; e++) { const id = i32(), q = [f64(), f64(), f64(), f64()]; m.set(id, q); } break; }
      default: throw new Error(`Pulseq binary file: unknown section code ${code} at byte ${p - 8}; Seqret cannot read the rest of it.`);
    }
  }
  if (!C) { C = Array.from({ length: 8 }, (_, k) => k === 1 ? new Float64Array(0) : new Uint32Array(0)); nb = 0; }
  [...new Set([...seq.extList.values()].map(e => e.type))].forEach(t => { if (!seq.extTypes.has(t)) warnings.push(`Extension type ${t} is referenced but not defined in the file`); });
  return finishBlocks(seq, C, nb);
}
/* start of the signature section of a binary file (the last int64), or -1 */
function binarySignatureStart(bytes) {
  if (bytes.length < 40) return -1;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), q = Number(dv.getBigInt64(bytes.length - 8, true));
  return q >= 32 && q + 8 <= bytes.length - 8 && dv.getUint32(q + 4, true) === 0xFFFFFFFF && dv.getUint32(q, true) === BIN_SIG ? q : -1;
}

const P10 = Array.from({ length: 40 }, (_, i) => Math.pow(10, i));
/* decimal number from bytes[a..b) (trailing spaces allowed); NaN if not a single plain number */
function parseNum(bytes, a, b) {
  while (b > a && (bytes[b - 1] === 32 || bytes[b - 1] === 9 || bytes[b - 1] === 13)) b--;
  let i = a, neg = false, m = 0, e = 0, nd = 0;
  if (bytes[i] === 45) { neg = true; i++; } else if (bytes[i] === 43) i++;
  for (; i < b; i++) { const c = bytes[i] - 48; if (c < 0 || c > 9) break; m = m * 10 + c; nd++; }
  if (i < b && bytes[i] === 46) { i++; for (; i < b; i++) { const c = bytes[i] - 48; if (c < 0 || c > 9) break; m = m * 10 + c; e--; nd++; } }
  if (!nd || nd > 15) return NaN;
  if (i < b && (bytes[i] === 101 || bytes[i] === 69)) {
    i++; let en = false, x = 0, ne = 0; if (bytes[i] === 45) { en = true; i++; } else if (bytes[i] === 43) i++;
    for (; i < b; i++) { const c = bytes[i] - 48; if (c < 0 || c > 9) break; x = x * 10 + c; ne++; }
    if (!ne) return NaN; e += en ? -x : x;
  }
  if (i !== b || e < -39 || e > 39) return NaN;
  const v = e < 0 ? m / P10[-e] : m * P10[e];
  return neg ? -v : v;
}
function numDef(seq, k, d) { const v = seq.defs[k]; return typeof v === 'number' ? v : d; }

function finalizeTiming(seq) {
  const V = seq.version; seq.verNum = V.major * 1000000 + V.minor * 1000 + V.revision;
  seq.raster = { grad: numDef(seq, 'GradientRasterTime', 10e-6), rf: numDef(seq, 'RadiofrequencyRasterTime', 1e-6), adc: numDef(seq, 'AdcRasterTime', 100e-9), block: numDef(seq, 'BlockDurationRaster', 10e-6) };
  seq.geo = { g: [], rfm: [], rfp: [], sl: [], ss: [], rfs: [], endrf: [], endg: [], endadc: [] }; // indexed by event id
  const nb = seq.nb, B = seq.B, bs = new Float64Array(nb + 1);
  if (seq.verNum >= 1004000) {
    let ticks = 0; const r = seq.raster.block;
    for (let i = 0; i < nb; i++) { bs[i] = ticks * r; ticks += B._d[i]; }
    bs[nb] = ticks * r;
  } else {
    let t = 0;
    for (let i = 0; i < nb; i++) { bs[i] = t; t += Math.max(blockEventEnd(seq, i), seq.delays.get(B._d[i]) || 0); }
    bs[nb] = t;
  }
  seq.blockStart = bs; seq.totalDur = bs[nb];
  if (seq.verNum < 1005000) oldGradEdges(seq);
}
/* Pulseq < 1.5 files do not store the first and last values of arbitrary gradients. They are filled in as MATLAB
   Pulseq's read.m does, block by block and axis by axis: first = the last value of the gradient on the same axis
   in the previous block (0 if there was none, if it ended before its block did, or if this gradient has a delay);
   last = the value restored at the end of the last raster step (e_k+1 = 2 w_k − e_k from e_0 = first, as in
   restoreEdges), or the last sample for gradients with a time shape. As in MATLAB, the first block that plays a
   gradient decides its values (a gradient event has one first and one last value), and a block that repeats an
   event already filled in leaves the running last value of its axis unchanged. */
function oldGradEdges(seq) {
  const B = seq.B, nb = seq.nb, bs = seq.blockStart, cols = [B.gx, B.gy, B.gz], prev = [0, 0, 0], done = new Set();
  for (let i = 0; i < nb; i++) {
    const dur = bs[i + 1] - bs[i], seen = [];
    for (let a = 0; a < 3; a++) {
      const id = cols[a][i], g = id ? seq.grad.get(id) : null;
      if (!g || g.type !== 'arb') { prev[a] = 0; continue; }
      if (g.delay > 0) prev[a] = 0;
      if (done.has(id)) continue;
      const w = seq.shapes.get(g.shapeId); if (!w || !w.length) { prev[a] = 0; continue; }
      const N = w.length, gr = seq.raster.grad; let last, end;
      const first = prev[a];
      if (g.timeId > 0) { const ts = seq.shapes.get(g.timeId); last = g.amp * w[N - 1]; end = g.delay + (ts && ts.length ? ts[ts.length - 1] : N) * gr; }
      else { let e = first; for (let k = 0; k < N; k++) e = 2 * g.amp * w[k] - e; last = e; end = g.delay + N * gr; }
      if (!seen.includes(id)) { g.first = first; g.last = last; seen.push(id); } // the same event on two axes: the first axis decides
      prev[a] = end + 1e-12 < dur ? 0 : last;
    }
    for (const id of seen) done.add(id);
  }
  seq.geo = { g: [], rfm: [], rfp: [], sl: [], ss: [], rfs: [], endrf: [], endg: [], endadc: [] }; // geometry cached while timing the blocks used the old values
}

/* ---------- per-event geometry (cached per unique event id) ---------- */
function gradTimes(seq, g) {
  const gr = seq.raster.grad;
  if (g.type === 'trap') {
    const d = g.delay, t = [d, d + g.rise], v = [0, g.amp];
    if (g.flat > 0) { t.push(d + g.rise + g.flat); v.push(g.amp); }
    t.push(d + g.rise + g.flat + g.fall); v.push(0);
    return { t, v };
  }
  const w = seq.shapes.get(g.shapeId);
  if (!w) { seq.warnings.push(`Missing gradient shape ${g.shapeId}`); return { t: [g.delay], v: [0] }; }
  const N = w.length, t = [], v = [];
  if (g.timeId > 0) {
    const ts = seq.shapes.get(g.timeId);
    if (!ts || ts.length !== N) { seq.warnings.push(`Gradient ${g.id}: time shape ${g.timeId} does not match its ${N} samples`); return { t: [g.delay], v: [0] }; }
    let centres = g.first !== undefined; for (let i = 0; i < N && centres; i++) if (Math.abs(ts[i] - (i + 0.5)) > 1e-6) centres = false;
    if (!centres) { for (let i = 0; i < N; i++) { t.push(g.delay + ts[i] * gr); v.push(g.amp * w[i]); } return { t, v }; }
    // a time shape that is just the default raster centres: treated as below, as MATLAB does
  }
  const over = g.timeId === -1, step = over ? gr / 2 : gr, off = gr / 2, tEnd = over ? (N + 1) / 2 * gr : N * gr;
  let first = g.first, last = g.last;
  if (first === undefined) { // v1.4 and older: extrapolate half a raster step
    first = N > 1 ? g.amp * (1.5 * w[0] - 0.5 * w[1]) : g.amp * w[0];
    last = N > 1 ? g.amp * (1.5 * w[N - 1] - 0.5 * w[N - 2]) : g.amp * w[N - 1];
    const tol = 1e-3 * Math.abs(g.amp); if (Math.abs(first) < tol) first = 0; if (Math.abs(last) < tol) last = 0;
  }
  t.push(g.delay); v.push(first);
  if (!over && N > 1) { // samples at the raster centres: restore the raster edges as MATLAB Pulseq does
    const e = restoreEdges(w, g.amp, first, last);
    if (e) {
      for (let i = 0; i < N; i++) {
        if (i > 0 && e[i] === e[i]) { t.push(g.delay + i * gr); v.push(e[i]); } // a corner on the edge between samples i-1 and i
        t.push(g.delay + off + i * gr); v.push(g.amp * w[i]);
      }
      t.push(g.delay + tEnd); v.push(last);
      return { t, v };
    }
  }
  for (let i = 0; i < N; i++) { t.push(g.delay + off + i * step); v.push(g.amp * w[i]); }
  t.push(g.delay + tEnd); v.push(last);
  return { t, v };
}
/* Values at the raster edges of an arbitrary gradient sampled at the raster centres, as MATLAB Pulseq's
   mr.restoreAdditionalShapeSamples (used by its waveforms_and_times, plot and calculateKspacePP). A piecewise-
   linear waveform with its corners on the raster edges has the centre samples w_k = (e_k + e_k+1)/2, so the edges
   follow from the first value: e_0 = first, e_k+1 = 2 w_k − e_k. Where an edge restored this way agrees with the
   straight line between its neighbouring centre samples (within 2e-5 of the peak, MATLAB's tolerance) that line is
   kept; elsewhere there is a corner, which the line would cut by slew·Δt/4. The restored waveform's area is exactly
   Σ w_k Δt, Pulseq's area of the shape. If the last restored edge does not reach the stated last value (within the
   same tolerance; typical for spirals and other curved shapes) nothing is restored, as in MATLAB.
   Returns NaN where the straight line is kept and the restored value at a corner (index k = edge before sample k),
   or null when nothing is restored. */
function restoreEdges(w, amp, first, last) {
  const N = w.length; let mx = 0; for (let i = 0; i < N; i++) { const a = Math.abs(amp * w[i]); if (a > mx) mx = a; }
  const tol = 2e-5 * mx, e = new Float64Array(N + 1);
  e[0] = first; for (let k = 0; k < N; k++) e[k + 1] = 2 * amp * w[k] - e[k];
  if (!(Math.abs(e[N] - last) <= tol)) return null;
  const out = new Float64Array(N).fill(NaN); let any = false;
  for (let k = 1; k < N; k++) { const lin = 0.5 * amp * (w[k - 1] + w[k]); if (Math.abs(e[k] - lin) > tol + 1e-300) { out[k] = e[k]; any = true; } }
  return any ? out : null;
}
function geoFinish(t, v) {
  let mn = Infinity, mx = -Infinity, area = 0;
  for (let i = 0; i < v.length; i++) { const x = v[i]; if (x === x) { if (x < mn) mn = x; if (x > mx) mx = x; } if (i) area += 0.5 * (v[i] + v[i - 1]) * (t[i] - t[i - 1]); }
  return { t: Float64Array.from(t), v: Float32Array.from(v), n: t.length, min: mn === Infinity ? 0 : mn, max: mx === -Infinity ? 0 : mx, area: area === area ? area : 0 };
}
function geoG(seq, id) {
  let o = seq.geo.g[id]; if (o) return o;
  const g = seq.grad.get(id);
  if (!g) { seq.warnings.push(`Missing gradient ${id}`); o = geoFinish([0], [0]); }
  else { const r = gradTimes(seq, g); o = geoFinish(r.t, r.v); }
  seq.geo.g[id] = o; return o;
}
function geoSlew(seq, id) {
  let o = seq.geo.sl[id]; if (o) return o;
  const g = geoG(seq, id), t = [], v = [];
  for (let j = 1; j < g.n; j++) { const dt = g.t[j] - g.t[j - 1]; if (dt <= 1e-12) continue; const s = (g.v[j] - g.v[j - 1]) / dt; t.push(g.t[j - 1], g.t[j]); v.push(s, s); }
  if (!t.length) { t.push(g.t[0]); v.push(0); }
  o = geoFinish(t, v); seq.geo.sl[id] = o; return o;
}
function slewSum(seq, id) { // min/max and end values of slew, without keeping the waveform
  let o = seq.geo.ss[id]; if (o) return o;
  const g = geoG(seq, id); let mn = 0, mx = 0, f = NaN, l = 0, t0 = g.t[0], t1 = g.t[0];
  for (let j = 1; j < g.n; j++) { const dt = g.t[j] - g.t[j - 1]; if (dt <= 1e-12) continue; const x = (g.v[j] - g.v[j - 1]) / dt; if (f !== f) { f = x; t0 = g.t[j - 1]; } l = x; t1 = g.t[j]; if (x < mn) mn = x; if (x > mx) mx = x; }
  o = { min: mn, max: mx, t: [t0, t1], v: [f === f ? f : 0, l], n: 2 }; seq.geo.ss[id] = o; return o;
}
function rfSamples(seq, r) {
  const rr = seq.raster.rf, m = seq.shapes.get(r.magId), p = seq.shapes.get(r.phaseId);
  if (!m) { seq.warnings.push(`Missing RF magnitude shape ${r.magId}`); return { t: [], mag: [], ph: [], dur: 0, timed: false }; }
  const N = m.length, t = new Array(N), mag = new Array(N), ph = new Array(N), ts = r.timeId > 0 ? seq.shapes.get(r.timeId) : null;
  for (let i = 0; i < N; i++) { t[i] = r.delay + (ts ? ts[i] * rr : (i + 0.5) * rr); mag[i] = r.amp * m[i]; ph[i] = (p ? p[i] * 2 * Math.PI : 0) + r.phase; }
  return { t, mag, ph, dur: ts ? ts[N - 1] * rr : N * rr, timed: !!ts };
}
function rfStats(seq, r) {
  const s = rfSamples(seq, r), N = s.t.length; let re = 0, im = 0, peak = 0;
  for (let i = 0; i < N; i++) {
    const dt = s.timed ? (i > 0 ? (s.t[i] - s.t[i - 1]) / 2 : 0) + (i < N - 1 ? (s.t[i + 1] - s.t[i]) / 2 : 0) : seq.raster.rf;
    re += s.mag[i] * Math.cos(s.ph[i]) * dt; im += s.mag[i] * Math.sin(s.ph[i]) * dt;
    if (Math.abs(s.mag[i]) > peak) peak = Math.abs(s.mag[i]);
  }
  const flip = 2 * Math.PI * Math.hypot(re, im);
  let center;
  if (r.center !== undefined) center = r.delay + r.center;
  else { let i0 = -1, i1 = -1; for (let i = 0; i < N; i++) if (Math.abs(s.mag[i]) >= 0.99999 * peak) { if (i0 < 0) i0 = i; i1 = i; } center = i0 < 0 ? r.delay : (s.t[i0] + s.t[i1]) / 2; }
  let use = r.use, useGuessed = false;
  if (!use || use === 'u') { use = flip > (90.01 * Math.PI / 180) ? 'r' : 'e'; useGuessed = true; }
  return { flip, center, dur: s.dur, use, useGuessed, peak, n: N };
}
function rfSt(seq, id) { let o = seq.geo.rfs[id]; if (!o) { const r = seq.rf.get(id); o = r ? rfStats(seq, r) : { flip: 0, center: 0, dur: 0, use: 'o', n: 0, peak: 0 }; seq.geo.rfs[id] = o; } return o; }
function geoRfm(seq, id) {
  let o = seq.geo.rfm[id]; if (o) return o;
  const r = seq.rf.get(id), s = r ? rfSamples(seq, r) : { t: [], mag: [] }, t = [], v = [];
  if (s.t.length) { t.push(s.t[0]); v.push(0); for (let k = 0; k < s.t.length; k++) { t.push(s.t[k]); v.push(s.mag[k]); } t.push(s.t[s.t.length - 1]); v.push(0); }
  else { t.push(0); v.push(0); }
  o = geoFinish(t, v); seq.geo.rfm[id] = o; return o;
}
/* real or imaginary part of the RF shape: amp·mag·e^{iφ} with φ the shape's own phase (the phase offset and the
   frequency offset are not included, as in Pulseq's rf.signal), so a sinc shows its negative lobes */
function geoRfPart(seq, id, im) {
  const c = im ? (seq.geo.rfim || (seq.geo.rfim = [])) : (seq.geo.rfre || (seq.geo.rfre = [])); let o = c[id]; if (o) return o;
  const r = seq.rf.get(id), s = r ? rfSamples(seq, r) : { t: [], mag: [], ph: [] }, t = [], v = [];
  if (s.t.length) {
    t.push(s.t[0]); v.push(0);
    for (let k = 0; k < s.t.length; k++) { const p = s.ph[k] - r.phase; t.push(s.t[k]); v.push(s.mag[k] * (im ? Math.sin(p) : Math.cos(p))); }
    t.push(s.t[s.t.length - 1]); v.push(0);
  } else { t.push(0); v.push(0); }
  o = geoFinish(t, v); c[id] = o; return o;
}
function geoRfRe(seq, id) { return geoRfPart(seq, id, false); }
function geoRfIm(seq, id) { return geoRfPart(seq, id, true); }
function geoRfp(seq, id) {
  let o = seq.geo.rfp[id]; if (o) return o;
  const r = seq.rf.get(id), s = r ? rfSamples(seq, r) : { t: [], ph: [] }, t = [], v = [];
  for (let k = 0; k < s.t.length; k++) { let ph = s.ph[k] % (2 * Math.PI); if (ph > Math.PI) ph -= 2 * Math.PI; if (ph < -Math.PI) ph += 2 * Math.PI; t.push(s.t[k]); v.push(ph); }
  if (t.length) { t.push(t[t.length - 1]); v.push(NaN); } else { t.push(0); v.push(NaN); }
  o = geoFinish(t, v); seq.geo.rfp[id] = o; return o;
}
function evEnd(seq, kind, id) {
  if (!id) return 0;
  const cache = kind === 'rf' ? seq.geo.endrf : kind === 'adc' ? seq.geo.endadc : seq.geo.endg; let e = cache[id]; if (e !== undefined) return e;
  if (kind === 'rf') { const r = seq.rf.get(id); e = r ? rfSamples(seq, r).dur + r.delay : 0; }
  else if (kind === 'adc') { const d = seq.adc.get(id); e = d ? d.delay + d.num * d.dwell : 0; }
  else { const g = geoG(seq, id); e = g.t[g.n - 1]; }
  cache[id] = e; return e;
}
function blockEventEnd(seq, i) {
  const B = seq.B;
  return Math.max(evEnd(seq, 'rf', B.rf[i]), evEnd(seq, 'g', B.gx[i]), evEnd(seq, 'g', B.gy[i]), evEnd(seq, 'g', B.gz[i]), evEnd(seq, 'adc', B.adc[i]));
}
function blockObj(seq, i) { const B = seq.B; return { id: B.id[i], rf: B.rf[i], gx: B.gx[i], gy: B.gy[i], gz: B.gz[i], adc: B.adc[i], ext: B.ext[i], dur: seq.blockStart[i + 1] - seq.blockStart[i] }; }

/* channel access: key -> (column, geometry fn, kind) */
/* slew uses slewSum for summaries (see blockSummary) and geoSlew for exact drawing */
const CHANNELS = {
  gx: { col: 'pgx', fn: geoG, p: false }, gy: { col: 'pgy', fn: geoG, p: false }, gz: { col: 'pgz', fn: geoG, p: false }, // physical (after rotation)
  sx: { col: 'pgx', fn: geoSlew, p: false }, sy: { col: 'pgy', fn: geoSlew, p: false }, sz: { col: 'pgz', fn: geoSlew, p: false },
  rfMag: { col: 'rf', fn: geoRfm, p: false }, rfPh: { col: 'rf', fn: geoRfp, p: true },
  rfRe: { col: 'rf', fn: geoRfRe, p: false, lazy: true }, rfIm: { col: 'rf', fn: geoRfIm, p: false, lazy: true }, // summaries built on first use
  // concomitant gradients at the chosen position (ccState must have run): one column of combination ids for all axes
  cx: { col: 'ccx', fn: (s, id) => ccGeo(s, id).geo[0], p: false, lazy: true, cc: 0 }, cy: { col: 'ccx', fn: (s, id) => ccGeo(s, id).geo[1], p: false, lazy: true, cc: 1 },
  cz: { col: 'ccx', fn: (s, id) => ccGeo(s, id).geo[2], p: false, lazy: true, cc: 2 }
};
/* summary of channel over block i: {has, mn, mx, first, last, brk}; value is 0 outside events (NaN for phase) */
function blockSummary(seq, key, i, o) {
  if (key in KINT) return kintSummary(KINT[key][0], seq, i, KINT[key][1], o);
  const ch = CHANNELS[key], id = seq.B[ch.col][i], fn = ch.fn, kind = ch.p ? 'p' : 'g';
  if (!id) { o.n = 0; if (kind === 'p') { o.has = 0; o.brk = 0; } else { o.has = 1; o.mn = o.mx = o.first = o.last = 0; o.brk = 0; } return o; }
  const g = fn === geoSlew ? slewSum(seq, id) : fn(seq, id); o.n = g.n;
  if (kind === 'p') { o.has = 1; o.mn = g.min; o.mx = g.max; o.first = g.v[0]; o.last = g.n > 1 ? g.v[g.n - 2] : g.v[0]; o.brk = 1; return o; }
  const dur = seq.blockStart[i + 1] - seq.blockStart[i];
  o.first = g.t[0] <= 1e-9 ? g.v[0] : 0; o.last = Math.abs(g.t[g.n - 1] - dur) <= 1e-9 ? g.v[g.n - 1] : 0;
  const z = o.first === 0 || o.last === 0;
  o.mn = z ? Math.min(0, g.min) : g.min; o.mx = z ? Math.max(0, g.max) : g.max; o.has = 1; o.brk = 0;
  return o;
}
/* exact vertices of block i for drawing (absolute times); push(t, v) */
function blockVertices(seq, key, i, push) {
  if (key in KINT) return kintVertices(KINT[key][0], seq, i, KINT[key][1], push);
  const ch = CHANNELS[key], id = seq.B[ch.col][i], fn = ch.fn, kind = ch.p ? 'p' : 'g', t0 = seq.blockStart[i], t1 = seq.blockStart[i + 1];
  if (!id) { if (kind !== 'p') { push(t0, 0); push(t1, 0); } return; }
  const g = fn(seq, id);
  if (kind === 'p') { for (let k = 0; k < g.n; k++) push(t0 + g.t[k], g.v[k]); return; }
  const first = g.t[0] <= 1e-9 ? g.v[0] : 0, last = Math.abs(g.t[g.n - 1] - (t1 - t0)) <= 1e-9 ? g.v[g.n - 1] : 0;
  push(t0, first);
  if (first === 0 && g.v[0] !== 0) push(t0 + g.t[0], 0);
  for (let k = 0; k < g.n; k++) push(t0 + g.t[k], g.v[k]);
  if (last === 0 && g.v[g.n - 1] !== 0) push(t0 + g.t[g.n - 1], 0);
  push(t1, last);
}
/* ---------- zeroth moments drawn as lanes: m0 = ∫G dt (the k-vector) and kc = ∫Gc dt (concomitant) ----------
   With G in Hz/m, m0 is in 1/m and equals k: the same integral as kInBlock, reset at each excitation and sign-flipped
   at each refocusing pulse (both at the RF centre, as Pulseq's calculateKspacePP). Within a block m0 is piecewise
   quadratic, so its extremes lie at the block ends, the gradient's vertices, its zero crossings and the RF centre;
   ramps get extra points so that the curve draws smoothly. kc follows the same rules for the concomitant gradients
   (see the concomitant section below).
   A provider says what is integrated: per block the event id of each axis (ids), the geometry of an event (geo), the
   running integral's extremes over an event (ext), the values at the block starts (start) and the integral inside a
   block (inBlock). tok changes when the integrand does (new concomitant parameters), which empties the block memo.
   Keys mx, my, mz (m0) and qx, qy, qz (kc) behave as channels. */
const KP_M0 = { name: 'm0', keys: ['mx', 'my', 'mz'], start: s => s.kStart, ids: s => [s.B.pgx, s.B.pgy, s.B.pgz], tok: s => s,
  geo: (s, id) => geoG(s, id), ext: (s, id) => m0EventExt(s, id), inBlock: (s, i, rel, out, o, nq) => kInBlock(s, i, rel, out, o, nq),
  st: s => s.m0St || (s.m0St = {}), memo: { tok: null, map: new Map(), nv: 0 } };
const M0_KEYS = { mx: 0, my: 1, mz: 2 };
const KINT = { mx: [KP_M0, 0], my: [KP_M0, 1], mz: [KP_M0, 2] }; // the kc keys are added with the concomitant provider
/* { t: relative times, v: [x, y, z] values, off: [x, y, z], reset } for block i; the values are v + off.
   1.45.0: in a block without an excitation or refocusing pulse the integral is its start value plus a part that depends
   only on the events the block plays (its gradient events and duration; for kc and k + kc the combination-and-position
   id, which also holds the duration), so that part is kept once per combination (v) and the start value is off. Before,
   every block was kept on its own, up to about a million vertices: an 8,806-block free-waveform file in full view
   needed more and recomputed every block on every frame (about 0.8 s per frame in a test browser). */
function kintBlock(P, seq, i) {
  const M = P.memo, tok = P.tok(seq); if (M.tok !== tok) { M.tok = tok; M.map = new Map(); M.nv = 0; M.cmb = new Map(); M.cnv = 0; }
  const hit = M.map.get(i); if (hit) return hit;
  if (!P.nl && m0Plain(seq, i)) {
    const ids = P.ids(seq), ix = ids[0][i], iy = ids[1][i], iz = ids[2][i];
    if (P !== KP_M0 ? ix : true) { // kc, k + kc: only with a combination (without one, f ≠ 0 still gives gc that depends on the position)
      const key = P === KP_M0 ? ix + ',' + iy + ',' + iz + ',' + Math.round((seq.blockStart[i + 1] - seq.blockStart[i]) * 1e10) : ix;
      const st = P.start(seq), off = [st[0][i], st[1][i], st[2][i]];
      let c = M.cmb.get(key);
      if (!c) {
        const r = kintCompute(P, seq, i); // absolute values of this block, made relative to its start
        for (let a = 0; a < 3; a++) { const v = r.v[a]; for (let k = 0; k < v.length; k++) v[k] -= off[a]; }
        c = { t: r.t, v: r.v, reset: -1 }; M.cnv += r.t.length;
        if (M.cnv > 4e6) { M.cmb.clear(); M.cnv = r.t.length; } M.cmb.set(key, c);
      }
      return { t: c.t, v: c.v, off, reset: -1, host: c }; // host: where per-combination caches (chunk extremes) live
    }
  }
  const r = kintCompute(P, seq, i); r.off = [0, 0, 0];
  // kept up to about a million vertices (~32 MB) rather than 4,096 blocks: a ZTE view can hold thousands of excitation
  // blocks, which are drawn vertex by vertex (their reset breaks the curve), and recomputing them every frame was slow
  M.nv += r.t.length;
  if (M.nv > 1e6) { M.map.clear(); M.nv = r.t.length; } M.map.set(i, r); return r;
}
function kintCompute(P, seq, i) {
  const B = seq.B, dur = seq.blockStart[i + 1] - seq.blockStart[i], T = [0, dur], ids = P.ids(seq);
  for (let ax = 0; ax < 3; ax++) {
    const id = ids[ax][i]; if (!id) continue; const g = P.geo(seq, id, ax);
    for (let k = 0; k < g.n; k++) {
      const t = g.t[k]; if (t >= 0 && t <= dur) T.push(t);
      if (k) {
        const ta = g.t[k - 1], va = g.v[k - 1], vb = g.v[k], D = t - ta;
        if ((va !== vb || (P.nl && va !== 0)) && D > 0) { // (μ bends on plateaus too)
          if ((va < 0) !== (vb < 0) && va !== 0 && vb !== 0) T.push(ta + D * va / (va - vb)); // G = 0: an extremum of m0
          const n = Math.min(P.nl ? 24 : 8, Math.round(D / 1e-5)); for (let q = 1; q < n; q++) T.push(ta + D * q / n); // quadratic (μ: a norm of cubics): smooth curve
        }
      }
    }
  }
  let rc = -1, exc = false;
  if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e' || st.use === 'r') { rc = st.center; exc = st.use === 'e'; T.push(rc); } }
  T.sort((a, b) => a - b);
  const t = []; for (const x of T) if (!t.length || x - t[t.length - 1] > 1e-12) t.push(x);
  let reset = -1; // an excitation resets m0 to zero: the index of the first vertex after the reset (drawn as a new start)
  if (rc >= 0) { const j = t.findIndex(x => Math.abs(x - rc) <= 1e-12); if (j >= 0) { t.splice(j, 1, rc - 1e-12, rc); if (exc) reset = j + 1; } } // both sides of the jump
  const v = [new Float64Array(t.length), new Float64Array(t.length), new Float64Array(t.length)];
  P.inBlock(seq, i, Float64Array.from(t), v, 0);
  return { t, v, reset };
}
/* extremes of the running integral of one gradient event (from 0, including 0 and its total area): per event, not
   per block, because a block without an excitation or refocusing pulse only adds its start value */
function m0EventExt(seq, id) {
  const c = seq.geo.m0 || (seq.geo.m0 = {}); let o = c[id]; if (o) return o;
  const g = geoG(seq, id); let acc = 0, mn = 0, mx = 0;
  for (let k = 1; k < g.n; k++) {
    const ta = g.t[k - 1], tb = g.t[k], va = g.v[k - 1], vb = g.v[k], D = tb - ta;
    if ((va < 0) !== (vb < 0) && va !== 0 && vb !== 0 && D > 0) { const d = D * va / (va - vb), p = acc + va * d / 2; if (p < mn) mn = p; if (p > mx) mx = p; } // G = 0 inside
    acc += (va + vb) / 2 * D; if (acc < mn) mn = acc; if (acc > mx) mx = acc;
  }
  return (c[id] = { mn, mx, area: acc });
}
function m0Plain(seq, i) { const r = seq.B.rf[i]; if (!r) return true; const u = rfSt(seq, r).use; return u !== 'e' && u !== 'r'; }
function kintSummary(P, seq, i, a, o) {
  if (!P.nl && m0Plain(seq, i)) { // start value plus the event's running integral
    const k0 = P.start(seq)[a][i], id = P.ids(seq)[a][i];
    if (!id) { o.has = 1; o.brk = 0; o.n = 2; o.mn = o.mx = o.first = o.last = k0; return o; }
    const e = P.ext(seq, id, a); o.has = 1; o.brk = 0; o.n = P.geo(seq, id, a).n; o.mn = k0 + e.mn; o.mx = k0 + e.mx; o.first = k0; o.last = k0 + e.area; return o; // n: lets narrow blocks be drawn from the summary
  }
  const S0 = P.st(seq).blk; // per-block summaries kept by kintPyramids: no recomputation (the memo below holds 4096 blocks;
  if (S0) { const Q = S0[a]; o.has = 1; o.brk = 0; o.n = S0.n[i]; o.mn = Q.mn[i]; o.mx = Q.mx[i]; o.first = Q.first[i]; o.last = Q.last[i]; return o; } // a ZTE has one excitation per spoke)
  const m = kintBlock(P, seq, i), v = m.v[a], f = m.off[a]; let mn = Infinity, mx = -Infinity;
  for (let k = 0; k < v.length; k++) { if (v[k] < mn) mn = v[k]; if (v[k] > mx) mx = v[k]; }
  o.has = 1; o.brk = 0; o.n = v.length; o.mn = mn + f; o.mx = mx + f; o.first = v[0] + f; o.last = v[v.length - 1] + f; return o;
}
function kintVertices(P, seq, i, a, push) { // a NaN at an excitation's reset: the curve starts anew at zero, no line to it
  const m = kintBlock(P, seq, i), t0 = seq.blockStart[i], f = m.off[a];
  for (let k = 0; k < m.t.length; k++) { if (k === m.reset) push(t0 + m.t[k], NaN); push(t0 + m.t[k], m.v[a][k] + f); }
}
function kintValue(P, seq, a, t) { const i = blockAtTime(seq, t), out = [new Float64Array(1), new Float64Array(1), new Float64Array(1)]; P.inBlock(seq, i, Float64Array.of(t - seq.blockStart[i]), out, 0); return out[a][0]; }
/* pyramids for the provider's three keys (built on first use); P.st(seq).max = largest |value| */
function kintPyramids(P, seq) {
  if (seq.pyr[P.keys[0]]) return;
  const nb = seq.nb, nA = P.keys.length, o = {}, per = P.keys.map(() => ({ mn: new Float32Array(nb), mx: new Float32Array(nb), first: new Float32Array(nb), last: new Float32Array(nb) }));
  let big = 0;
  const nv = new Uint32Array(nb), ST = P.st(seq);
  ST.blk = null; // (summaries from kintBlock while building)
  for (let i = 0; i < nb; i++) for (let a = 0; a < nA; a++) { kintSummary(P, seq, i, a, o); if (o.n > nv[i]) nv[i] = o.n; const Q = per[a]; Q.mn[i] = o.mn; Q.mx[i] = o.mx; Q.first[i] = o.first; Q.last[i] = o.last; big = Math.max(big, Math.abs(o.mn), Math.abs(o.mx)); }
  P.keys.forEach((key, a) => {
    const P0 = per[a], out = []; let prev = null; const SIZES = pyrSizes(nb);
    for (let L = 0; L < SIZES.length; L++) {
      const sz = SIZES[L], n = Math.floor(nb / sz); if (n < 2) break;
      const Q = { size: sz, mn: new Float32Array(n), mx: new Float32Array(n), first: new Float32Array(n), last: new Float32Array(n), has: new Uint8Array(n).fill(1), brk: new Uint8Array(n) };
      for (let k = 0; k < n; k++) {
        let mn = Infinity, mx = -Infinity;
        if (!L) { for (let i = k * sz; i < (k + 1) * sz; i++) { if (P0.mn[i] < mn) mn = P0.mn[i]; if (P0.mx[i] > mx) mx = P0.mx[i]; } Q.first[k] = P0.first[k * sz]; Q.last[k] = P0.last[(k + 1) * sz - 1]; }
        else { const r = sz / prev.size; for (let j = k * r; j < (k + 1) * r; j++) { if (prev.mn[j] < mn) mn = prev.mn[j]; if (prev.mx[j] > mx) mx = prev.mx[j]; } Q.first[k] = prev.first[k * r]; Q.last[k] = prev.last[(k + 1) * r - 1]; }
        Q.mn[k] = mn; Q.mx[k] = mx;
      }
      out.push(Q); prev = Q;
    }
    seq.pyr[key] = out;
  });
  ST.max = big;
  ST.blk = Object.assign(per, { n: nv }); // per-block summaries for kintSummary
  if (P.nl) return; // μ: no per-event shortcut (it is not a sum of per-event parts)
  // tables for rangeSummary: per event and axis its integral extremes and area, per RF event whether it leaves m0 alone
  const B = seq.B, ids = P.ids(seq); let maxG = 0, maxR = 0;
  for (let i = 0; i < nb; i++) { for (let a = 0; a < 3; a++) if (ids[a][i] > maxG) maxG = ids[a][i]; if (B.rf[i] > maxR) maxR = B.rf[i]; }
  const T = { ids, mn: [0, 1, 2].map(() => new Float64Array(maxG + 1)), mx: [0, 1, 2].map(() => new Float64Array(maxG + 1)), area: [0, 1, 2].map(() => new Float64Array(maxG + 1)), plainRf: new Uint8Array(maxR + 1) };
  const seen = [0, 1, 2].map(() => new Uint8Array(maxG + 1)), seenR = new Uint8Array(maxR + 1);
  for (let i = 0; i < nb; i++) {
    for (let a = 0; a < 3; a++) { const id = ids[a][i]; if (id && !seen[a][id]) { const e = P.ext(seq, id, a); T.mn[a][id] = e.mn; T.mx[a][id] = e.mx; T.area[a][id] = e.area; seen[a][id] = 1; } }
    const r = B.rf[i]; if (r && !seenR[r]) { const u = rfSt(seq, r).use; T.plainRf[r] = u !== 'e' && u !== 'r' ? 1 : 0; seenR[r] = 1; }
  }
  ST.ev = T;
  if (P === KP_M0) seq.m0Max = big; // (kept for scripts that read it)
}
/* the k-vector under its former names */
function m0Block(seq, i) { return kintBlock(KP_M0, seq, i); }
function m0Summary(seq, i, a, o) { return kintSummary(KP_M0, seq, i, a, o); }
function m0Vertices(seq, i, a, push) { return kintVertices(KP_M0, seq, i, a, push); }
function m0Value(seq, a, t) { return kintValue(KP_M0, seq, a, t); }
function m0Pyramids(seq) { return kintPyramids(KP_M0, seq); }
/* stretches where m0 matters: from each excitation's RF centre to the end of the last readout before the next
   excitation (none if there is no readout in between): [starts, ends], sorted */
function m0Active(seq) {
  if (seq.m0Act) return seq.m0Act;
  const B = seq.B, bs = seq.blockStart, E = [];
  for (let i = 0; i < seq.nb; i++) if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e') E.push(bs[i] + st.center); }
  const a = [], b = [], T0 = seq.adcT0, T1 = seq.adcT1;
  for (let j = 0; j < E.length; j++) {
    const lim = j + 1 < E.length ? E[j + 1] : Infinity;
    let lo = 0, hi = T0.length; while (lo < hi) { const m = (lo + hi) >> 1; if (T0[m] < lim) lo = m + 1; else hi = m; } // last ADC starting before the next excitation
    const q = lo - 1; if (q >= 0 && T0[q] >= E[j]) { a.push(E[j]); b.push(T1[q]); }
  }
  return (seq.m0Act = { a: Float64Array.from(a), b: Float64Array.from(b) });
}
/* ---------- concomitant gradients ----------
   The field of the gradient coils (as in fwf.gwf.toActual by F. Szczepankiewicz, after Bernstein et al. 1998;
   method: Olsson et al., Magn Reson Med 2026;96(3):1178-1191, doi:10.1002/mrm.70422):
     Bz = B0 + g·r,   Bx = gx z − a gz x + f y,   By = gy z + (a − 1) gz y + f x
   a: asymmetry of the z coil (0.5 for a symmetric one), f: a further, non-Maxwell term (T/m), constant in time. Spins at r
   precess at γ|B|, so the gradient they see is ∇|B| = g + gc. With p = v·r, q = w·r, v = (−a gz, f, gx),
   w = (f, (a − 1) gz, gy), Bd = B0 + g·r and N = |B| = √(Bd² + p² + q²):
     ∇|B| = (Bd g + v p + w q) / N,   gc = ∇|B| − g = [v p + w q − g (p² + q²)/(Bd + N)] / N
   The second form avoids subtracting two nearly equal numbers (gc is often 10⁻⁶ of g). Computed from the physical
   (rotated) gradients at one position r in the sequence's x, y, z (taken as the scanner's, B0 along z).
   Every block is computed from the events it plays together (its "combination": the three gradient event ids and the
   block duration), once per combination. Where all three gradients are linear in time, gc is a smooth, nearly quadratic
   function of time: each such stretch is cut into up to 8 pieces, gc is evaluated exactly at the ends and the middle of
   each piece, and integrals use Simpson's rule on the pieces (exact up to cubic terms in time; the rest is of relative
   order (g·r/B0)²). Gradients are 0 outside their events; with f ≠ 0, gc is not zero there (the static f term), so
   then every block is covered from its start to its end.
   kc = ∫gc dt (1/m), the k-space shift of the spins at r, follows the k-vector's rules: reset at each excitation, sign
   flipped at each refocusing pulse, both at the RF centre.
   Position (P.pos): 'fixed' uses r everywhere; 'slice' uses, from each excitation block up to the next excitation, the
   centre of the slice that the excitation selects (rfSlice: s0 = f/|G| along n = G/|G|, with f including any ppm offset
   at B0; the point of the slice plane closest to the isocentre, with no in-plane offset), and r where there is no
   slice-selective excitation (before the first excitation, after a non-selective one). Blocks are then computed per
   combination and position, so the cost grows with the number of distinct slice positions, at most to one computation
   per block. */
const CC_DEF = { r: [0.05, 0.06, 0.07], B0: 3, a: 0.5, f: 0, pos: 'fixed' };
function ccEval(gx, gy, gz, P, out) { // g in T/m → gc in T/m
  const x = P.r[0], y = P.r[1], z = P.r[2], a = P.a, f = P.f;
  const Bd = P.B0 + gx * x + gy * y + gz * z, p = -a * gz * x + f * y + gx * z, q = f * x + (a - 1) * gz * y + gy * z;
  const N = Math.sqrt(Bd * Bd + p * p + q * q), s = (p * p + q * q) / (Bd + N);
  out[0] = (-a * gz * p + f * q - gx * s) / N; out[1] = (f * p + (a - 1) * gz * q - gy * s) / N; out[2] = (gx * p + gy * q - gz * s) / N;
  return out;
}
/* blocks grouped by the gradient events they play (physical ids) and their duration; independent of the parameters */
function ccCombos(seq) {
  if (seq.ccCombo) return seq.ccCombo;
  const B = seq.B, nb = seq.nb, bs = seq.blockStart, map = new Map(), of = new Uint32Array(nb), list = [null]; // id 0: none
  for (let i = 0; i < nb; i++) {
    const x = B.pgx[i], y = B.pgy[i], z = B.pgz[i], key = x + ',' + y + ',' + z + ',' + Math.round((bs[i + 1] - bs[i]) * 1e9);
    let c = map.get(key);
    if (c === undefined) { c = list.length; list.push({ ids: [x, y, z], dur: bs[i + 1] - bs[i], none: !x && !y && !z }); map.set(key, c); }
    of[i] = c;
  }
  return (seq.ccCombo = { of, list });
}
/* the position used for each block in 'slice' mode: { pos: [r of each position; 0 is P.r], of: Uint32Array (position index
   per block), exc: excitation block that set it (−1: none) }. Depends on the file and B0 (ppm offsets) only. */
function ccSlicePos(seq, P) {
  const B = seq.B, nb = seq.nb, pos = [P.r.slice()], map = new Map(), of = new Uint32Array(nb), exc = new Int32Array(nb).fill(-1);
  let cur = 0, e = -1;
  for (let i = 0; i < nb; i++) {
    if (B.rf[i] && rfSt(seq, B.rf[i]).use === 'e') {
      e = i; cur = 0;
      // as rfSlice (selective when |G| > 1 kHz/m at the RF centre; s0 = f/|G| along G/|G|), without its bandwidth and profile
      const r = seq.rf.get(B.rf[i]), tc = seq.blockStart[i] + rfSt(seq, B.rf[i]).center;
      const G = [channelValue(seq, 'gx', tc), channelValue(seq, 'gy', tc), channelValue(seq, 'gz', tc)], Gm = Math.hypot(G[0], G[1], G[2]);
      const q = r && Gm > 1e3 ? G.map(x => x * rfFreqHz(r, P.B0) / (Gm * Gm)) : null;
      if (q && q.every(Number.isFinite)) {
        const key = q.map(x => Math.round(x * 1e9)).join(','); // to 1 nm
        let k = map.get(key); if (k === undefined) { k = pos.length; pos.push(q); map.set(key, k); }
        cur = k;
      }
    }
    of[i] = cur; exc[i] = e;
  }
  return { pos, of, exc };
}
/* everything that depends on the parameters P = { r (m), B0 (T), a, f (T/m), pos ('fixed' or 'slice') }: the block
   column B.ccx (id of a combination and position, 0 where gc is 0 throughout), the geometries (on demand) and kc at
   every block start. Rebuilt when P changes. In 'fixed' mode the ids are the combination ids of ccCombos. */
function ccState(seq, P) {
  const mode = P.pos === 'slice' ? 'slice' : 'fixed', key = JSON.stringify([P.r, P.B0, P.a, P.f, mode]);
  if (seq.cc && seq.cc.key === key) return seq.cc;
  const C = ccCombos(seq), nb = seq.nb, B = seq.B, col = new Uint32Array(nb), ent = [null];
  const SP = mode === 'slice' ? ccSlicePos(seq, P) : null;
  if (!SP) { for (let c = 1; c < C.list.length; c++) ent.push({ c, p: 0 }); for (let i = 0; i < nb; i++) { const c = C.of[i]; col[i] = P.f === 0 && C.list[c].none ? 0 : c; } }
  else {
    const map = new Map();
    for (let i = 0; i < nb; i++) {
      const c = C.of[i]; if (P.f === 0 && C.list[c].none) continue;
      const p = SP.of[i], k = c * 65536 + p; // (unique: ids and positions are far below 2^26 and 2^16 here; else a string key)
      const kk = p < 65536 ? k : c + ',' + p;
      let id = map.get(kk); if (id === undefined) { id = ent.length; ent.push({ c, p }); map.set(kk, id); }
      col[i] = id;
    }
  }
  B.ccx = col;
  for (const k of ['cx', 'cy', 'cz', 'qx', 'qy', 'qz', 'tx', 'ty', 'tz']) { if (seq.pyr) delete seq.pyr[k]; if (seq.evt) delete seq.evt[k]; } // made with the old parameters
  seq.kcSt = {}; seq.ktSt = {};
  const cc = seq.cc = { key, P: { r: P.r.slice(), B0: P.B0, a: P.a, f: P.f, pos: mode }, geo: [], ent, sp: SP, posR: SP ? SP.pos : [P.r.slice()], kStart: null, ktStart: null, max: [0, 0, 0] };
  const kS = [new Float64Array(nb + 1), new Float64Array(nb + 1), new Float64Array(nb + 1)], raw = [0, 0, 0]; let off = [0, 0, 0];
  for (let i = 0; i < nb; i++) { // as the k-vector's start values in analyze()
    for (let a = 0; a < 3; a++) kS[a][i] = raw[a] + off[a];
    const id = col[i], G = id ? ccGeo(seq, id) : null;
    if (B.rf[i]) {
      const st = rfSt(seq, B.rf[i]);
      if (st.use === 'e' || st.use === 'r') {
        const rc = [0, 1, 2].map(a => raw[a] + (G ? ccPartial(G, a, st.center) : 0));
        off = st.use === 'e' ? rc.map(x => -x) : rc.map((x, a) => -2 * x - off[a]);
      }
    }
    if (G) for (let a = 0; a < 3; a++) raw[a] += G.area[a];
  }
  for (let a = 0; a < 3; a++) kS[a][nb] = raw[a] + off[a];
  cc.kStart = kS;
  cc.ktStart = [0, 1, 2].map(a => { const o = new Float64Array(nb + 1), m = seq.kStart[a]; for (let i = 0; i <= nb; i++) o[i] = m[i] + kS[a][i]; return o; });
  return cc;
}
/* the position (m) used for block i, and whether it is a slice centre (false: the fixed r) */
function ccPosOf(seq, i) { const cc = seq.cc; if (!cc.sp) return { r: cc.P.r, slice: false, exc: -1 }; const p = cc.sp.of[i]; return { r: cc.sp.pos[p], slice: p > 0, exc: cc.sp.exc[i] }; }
/* geometry of combination id under the current parameters: Simpson pieces (t0, t1, values at both ends and the middle,
   per axis, Hz/m), cumulative integrals, and per axis a drawing geometry (geoFinish) */
function ccGeo(seq, id) {
  const cc = seq.cc; let G = cc.geo[id]; if (G) return G;
  const E = cc.ent[id], c = seq.ccCombo.list[E.c], P = { r: cc.posR[E.p], B0: cc.P.B0, a: cc.P.a, f: cc.P.f }, L = c.ids.map(e => e ? geoG(seq, e) : null);
  const ts = []; for (const g of L) if (g) for (let k = 0; k < g.n; k++) ts.push(g.t[k]);
  if (P.f !== 0 || !ts.length) ts.push(0, c.dur);
  ts.sort((x, y) => x - y); const u = []; for (const x of ts) if (!u.length || x - u[u.length - 1] > 1e-11) u.push(x);
  const valAt = (g, t) => { // piecewise linear, 0 outside the event (t lies strictly inside a stretch between vertices)
    if (!g || t < g.t[0] || t > g.t[g.n - 1]) return 0;
    let lo = 0, hi = g.n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (g.t[m] <= t) lo = m; else hi = m; }
    const d = g.t[hi] - g.t[lo]; return d > 0 ? g.v[lo] + (g.v[hi] - g.v[lo]) * (t - g.t[lo]) / d : g.v[hi];
  };
  const T0 = [], T1 = [], V = [[[], [], []], [[], [], []], [[], [], []]]; // V[end: 0 start, 1 middle, 2 end][axis]
  const gi = 1 / GAMMA, o3 = [0, 0, 0], g25 = [0, 0, 0], g75 = [0, 0, 0];
  for (let k = 0; k + 1 < u.length; k++) {
    const ta = u[k], tb = u[k + 1], D = tb - ta; if (D <= 1e-11) continue;
    // the three gradients are linear inside (ta, tb): two inner samples give them, also at the ends (steps at the ends are
    // the neighbours' business)
    for (let a = 0; a < 3; a++) { g25[a] = valAt(L[a], ta + 0.25 * D); g75[a] = valAt(L[a], ta + 0.75 * D); }
    const flat = g25[0] === g75[0] && g25[1] === g75[1] && g25[2] === g75[2];
    const n = flat ? 1 : Math.max(1, Math.min(8, Math.round(D / 1e-5)));
    const at = (s, e) => { // gc (Hz/m) at fraction s of the stretch, into V[e]
      const w = (s - 0.25) * 2;
      ccEval((g25[0] + (g75[0] - g25[0]) * w) * gi, (g25[1] + (g75[1] - g25[1]) * w) * gi, (g25[2] + (g75[2] - g25[2]) * w) * gi, P, o3);
      for (let a = 0; a < 3; a++) V[e][a].push(o3[a] * GAMMA);
    };
    for (let q = 0; q < n; q++) { T0.push(ta + D * q / n); T1.push(ta + D * (q + 1) / n); at(q / n, 0); at((q + 0.5) / n, 1); at((q + 1) / n, 2); }
  }
  const ns = T0.length, F = a => Float64Array.from(a);
  G = { n: ns, t0: F(T0), t1: F(T1), v0: V[0].map(F), vm: V[1].map(F), v1: V[2].map(F), cum: [], area: [0, 0, 0], geo: [], ext: [] };
  for (let a = 0; a < 3; a++) {
    const cum = new Float64Array(ns + 1);
    for (let j = 0; j < ns; j++) cum[j + 1] = cum[j] + (G.t1[j] - G.t0[j]) / 6 * (G.v0[a][j] + 4 * G.vm[a][j] + G.v1[a][j]);
    G.cum[a] = cum; G.area[a] = cum[ns];
    const t = [], v = [];
    for (let j = 0; j < ns; j++) {
      const v0 = G.v0[a][j], vm = G.vm[a][j], v1 = G.v1[a][j];
      if (!j || G.t0[j] !== G.t1[j - 1] || v0 !== G.v1[a][j - 1]) { t.push(G.t0[j]); v.push(v0); }
      // the middle too where the piece bends (more than 0.1 % of its size away from the straight line)
      if (Math.abs(vm - (v0 + v1) / 2) > 1e-3 * Math.max(Math.abs(v0), Math.abs(vm), Math.abs(v1))) { t.push((G.t0[j] + G.t1[j]) / 2); v.push(vm); }
      t.push(G.t1[j]); v.push(v1);
    }
    G.geo[a] = t.length ? geoFinish(t, v) : geoFinish([0], [0]);
    cc.max[a] = Math.max(cc.max[a], Math.abs(G.geo[a].min), Math.abs(G.geo[a].max));
  }
  return (cc.geo[id] = G);
}
/* ∫gc dt (1/m) on axis a from the start of the combination's first piece to relative time r */
function ccPartial(G, a, r) {
  const n = G.n; if (!n || r <= G.t0[0]) return 0;
  if (r >= G.t1[n - 1]) return G.cum[a][n];
  let lo = 0, hi = n - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (G.t0[m] <= r) lo = m; else hi = m - 1; }
  if (r >= G.t1[lo]) return G.cum[a][lo + 1];
  const D = G.t1[lo] - G.t0[lo], s = (r - G.t0[lo]) / D, v0 = G.v0[a][lo], vm = G.vm[a][lo], v1 = G.v1[a][lo];
  return G.cum[a][lo] + D * s * (v0 + s * ((-3 * v0 + 4 * vm - v1) / 2 + s * (2 * v0 - 4 * vm + 2 * v1) / 3)); // the quadratic through the three values
}
/* kc (1/m) for sorted relative times in block i, written to out[a][o + q] (as kInBlock) */
function kcInBlock(seq, i, rel, out, o, nq = rel.length) {
  const B = seq.B, id = B.ccx[i], G = id ? ccGeo(seq, id) : null, kS = seq.cc.kStart;
  let rc = -1, use = null;
  if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e' || st.use === 'r') { rc = st.center; use = st.use; } }
  for (let a = 0; a < 3; a++) {
    const k0 = kS[a][i], pc = rc >= 0 && G ? ccPartial(G, a, rc) : 0;
    for (let q = 0; q < nq; q++) {
      const r = rel[q], p = G ? ccPartial(G, a, r) : 0;
      out[a][o + q] = rc >= 0 && r >= rc ? (use === 'e' ? p - pc : -(k0 + pc) + (p - pc)) : k0 + p;
    }
  }
}
/* extremes of the running integral of gc over a combination, from 0 (as m0EventExt) */
function ccExt(seq, id, a) {
  const G = ccGeo(seq, id); if (G.ext[a]) return G.ext[a];
  let mn = 0, mx = 0;
  for (let j = 0; j < G.n; j++) {
    const v0 = G.v0[a][j], v1 = G.v1[a][j];
    if ((v0 < 0) !== (v1 < 0) && v0 !== 0 && v1 !== 0) { const p = ccPartial(G, a, G.t0[j] + (G.t1[j] - G.t0[j]) * v0 / (v0 - v1)); if (p < mn) mn = p; if (p > mx) mx = p; }
    const c = G.cum[a][j + 1]; if (c < mn) mn = c; if (c > mx) mx = c;
  }
  return (G.ext[a] = { mn, mx, area: G.area[a] });
}
/* gc (Hz/m) at time t, from the gradients there (exact; the drawing geometry is piecewise linear between its points) */
function ccValue(seq, a, t) {
  const i = blockAtTime(seq, t); if (!seq.B.ccx[i]) return 0;
  const o3 = [0, 0, 0], gi = 1 / GAMMA, cc = seq.cc, P = cc.sp ? { r: cc.posR[cc.ent[seq.B.ccx[i]].p], B0: cc.P.B0, a: cc.P.a, f: cc.P.f } : cc.P;
  return ccEval(channelValue(seq, 'gx', t) * gi, channelValue(seq, 'gy', t) * gi, channelValue(seq, 'gz', t) * gi, P, o3)[a] * GAMMA;
}
const KP_KC = { name: 'kc', keys: ['qx', 'qy', 'qz'], start: s => s.cc.kStart, ids: s => [s.B.ccx, s.B.ccx, s.B.ccx], tok: s => s.cc,
  geo: (s, id, a) => ccGeo(s, id).geo[a], ext: (s, id, a) => ccExt(s, id, a), inBlock: (s, i, rel, out, o, nq) => kcInBlock(s, i, rel, out, o, nq),
  st: s => s.kcSt || (s.kcSt = {}), memo: { tok: null, map: new Map(), nv: 0 } };
KINT.qx = [KP_KC, 0]; KINT.qy = [KP_KC, 1]; KINT.qz = [KP_KC, 2];
/* the total dephasing vector k + kc (1/m): the k-vector plus the concomitant k-space shift at the same position, under the
   same rules (both are reset at each excitation and sign-flipped at each refocusing pulse, so their sum is too). Per
   combination and position (B.ccx; where it is 0 there are no gradients and, with f = 0, no gc, so k + kc is constant):
   the drawing geometry is g + gc on the union of their vertices (gc piecewise linear through its points; used for the
   vertex times, zero crossings and the integral's extremes), the values themselves are exact sums of kInBlock and
   kcInBlock. */
function ktGeo(seq, id) {
  const G = ccGeo(seq, id); if (G.kt) return G.kt;
  const c = seq.ccCombo.list[seq.cc.ent[id].c], out = [];
  for (let a = 0; a < 3; a++) {
    const g = c.ids[a] ? geoG(seq, c.ids[a]) : null, h = G.geo[a], ts = [];
    if (g) for (let k = 0; k < g.n; k++) ts.push(g.t[k]);
    for (let k = 0; k < h.n; k++) ts.push(h.t[k]);
    ts.sort((x, y) => x - y); const t = [], v = [];
    const lin = (q, x) => { if (!q || q.n < 1 || x < q.t[0] || x > q.t[q.n - 1]) return 0; let lo = 0, hi = q.n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (q.t[m] <= x) lo = m; else hi = m; } const d = q.t[hi] - q.t[lo]; return d > 0 ? q.v[lo] + (q.v[hi] - q.v[lo]) * (x - q.t[lo]) / d : q.v[hi]; };
    for (const x of ts) if (!t.length || x - t[t.length - 1] > 1e-12) { t.push(x); v.push(lin(g, x) + lin(h, x)); }
    out[a] = t.length ? geoFinish(t, v) : geoFinish([0], [0]);
  }
  return (G.kt = out);
}
function ktInBlock(seq, i, rel, out, o, nq = rel.length) {
  const tmp = [new Float64Array(nq), new Float64Array(nq), new Float64Array(nq)];
  kInBlock(seq, i, rel, out, o, nq); kcInBlock(seq, i, rel, tmp, 0, nq);
  for (let a = 0; a < 3; a++) for (let q = 0; q < nq; q++) out[a][o + q] += tmp[a][q];
}
/* extremes of ∫(g + gc) dt over a combination from its start, evaluated at the vertices and zero crossings of g + gc */
function ktExt(seq, id, a) {
  const G = ccGeo(seq, id); G.ktExt = G.ktExt || []; if (G.ktExt[a]) return G.ktExt[a];
  const c = seq.ccCombo.list[seq.cc.ent[id].c], gid = c.ids[a], g = gid ? geoG(seq, gid) : null, h = ktGeo(seq, id)[a];
  const pts = [];
  for (let k = 0; k < h.n; k++) { pts.push(h.t[k]); if (k) { const va = h.v[k - 1], vb = h.v[k]; if ((va < 0) !== (vb < 0) && va !== 0 && vb !== 0) pts.push(h.t[k - 1] + (h.t[k] - h.t[k - 1]) * va / (va - vb)); } }
  // ∫g from 0 to each point (sorted), walking g's vertices once; plus ∫gc (ccPartial)
  let mn = 0, mx = 0, k = 1, acc = 0;
  for (const r of pts) {
    let m = 0;
    if (g) {
      while (k < g.n && g.t[k] <= r) { acc += (g.v[k - 1] + g.v[k]) / 2 * (g.t[k] - g.t[k - 1]); k++; }
      m = acc; if (k < g.n && r > g.t[k - 1]) { const ta = g.t[k - 1], D = g.t[k] - ta; if (D > 0) { const vb = g.v[k - 1] + (g.v[k] - g.v[k - 1]) * (r - ta) / D; m += (g.v[k - 1] + vb) / 2 * (r - ta); } }
    }
    const v = m + ccPartial(G, a, r); if (v < mn) mn = v; if (v > mx) mx = v;
  }
  const area = (g ? m0EventExt(seq, gid).area : 0) + G.area[a];
  if (area < mn) mn = area; if (area > mx) mx = area;
  return (G.ktExt[a] = { mn, mx, area });
}
const KP_KT = { name: 'kt', keys: ['tx', 'ty', 'tz'], start: s => s.cc.ktStart, ids: s => [s.B.ccx, s.B.ccx, s.B.ccx], tok: s => s.cc,
  geo: (s, id, a) => ktGeo(s, id)[a], ext: (s, id, a) => ktExt(s, id, a), inBlock: (s, i, rel, out, o, nq) => ktInBlock(s, i, rel, out, o, nq),
  st: s => s.ktSt || (s.ktSt = {}), memo: { tok: null, map: new Map(), nv: 0 } };
KINT.tx = [KP_KT, 0]; KINT.ty = [KP_KT, 1]; KINT.tz = [KP_KT, 2];
/* ---------- generalized Maxwell index ----------
   μ(t) = (γ/B0) |∫₀ᵗ g(t')⊗g(t') h(t') dt'|_F in 1/m² with γ = 42.58 MHz/T (Olsson et al., Magn Reson Med
   2026;96(3):1178-1191, doi:10.1002/mrm.70422). With G = γg in Hz/m, M = ∫ G Gᵀ h dt has six distinct components (xx, yy,
   zz, xy, xz, yz) and μ = |M|_F / (γ B0), |M|_F² = Mxx² + Myy² + Mzz² + 2(Mxy² + Mxz² + Myz²). M is reset at each
   excitation and h flips at each refocusing pulse, both at the RF centre, as for the k-vector (M follows k's convention,
   −∫GGᵀh after a refocusing pulse, which leaves |M|_F unchanged). The gradients are piecewise linear, so M is piecewise
   cubic in time and is integrated exactly; μ itself is drawn through points (vertices, RF centres, and up to 8 per
   stretch where a gradient is on) and evaluated exactly at the cursor. The Frobenius norm does not change under
   rotation, so the physical and the logical gradients give the same μ. Only B0 enters (r, a and f do not). */
const MX_IJ = [[0, 0], [1, 1], [2, 2], [0, 1], [0, 2], [1, 2]], MX_W = [1, 1, 1, 2, 2, 2];
/* per combination (ccCombos): the stretches between the gradients' vertices where any gradient is on, with each axis's
   value at the start (a) and its change over the stretch (d), and M accumulated over them (cum[c][j]: before stretch j) */
function mxGeo(seq, cid) {
  const C = ccCombos(seq), st = seq.mxGeoC || (seq.mxGeoC = []); let G = st[cid]; if (G) return G;
  const c = C.list[cid], L = c.ids.map(e => e ? geoG(seq, e) : null);
  const ts = []; for (const g of L) if (g) for (let k = 0; k < g.n; k++) ts.push(g.t[k]);
  ts.sort((x, y) => x - y); const u = []; for (const x of ts) if (!u.length || x - u[u.length - 1] > 1e-11) u.push(x);
  const valAt = (g, t) => { // piecewise linear, 0 outside the event (t lies strictly inside a stretch between vertices)
    if (!g || t < g.t[0] || t > g.t[g.n - 1]) return 0;
    let lo = 0, hi = g.n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (g.t[m] <= t) lo = m; else hi = m; }
    const d = g.t[hi] - g.t[lo]; return d > 0 ? g.v[lo] + (g.v[hi] - g.v[lo]) * (t - g.t[lo]) / d : g.v[hi];
  };
  const T0 = [], DD = [], A = [[], [], []], Dv = [[], [], []];
  for (let k = 0; k + 1 < u.length; k++) {
    const ta = u[k], D = u[k + 1] - ta; if (D <= 1e-11) continue;
    let on = false; const g25 = [0, 0, 0], g75 = [0, 0, 0];
    for (let a = 0; a < 3; a++) { g25[a] = valAt(L[a], ta + 0.25 * D); g75[a] = valAt(L[a], ta + 0.75 * D); if (g25[a] || g75[a]) on = true; }
    if (!on) continue;
    T0.push(ta); DD.push(D); // linear inside: the values at the ends from the two inner samples (steps at the ends belong to the neighbours)
    for (let a = 0; a < 3; a++) { A[a].push(1.5 * g25[a] - 0.5 * g75[a]); Dv[a].push(2 * (g75[a] - g25[a])); }
  }
  const n = T0.length, F = x => Float64Array.from(x);
  G = { n, t0: F(T0), D: F(DD), a: A.map(F), d: Dv.map(F), cum: MX_IJ.map(() => new Float64Array(n + 1)) };
  for (let j = 0; j < n; j++) for (let c = 0; c < 6; c++) {
    const [i1, i2] = MX_IJ[c], a1 = G.a[i1][j], a2 = G.a[i2][j], d1 = G.d[i1][j], d2 = G.d[i2][j];
    G.cum[c][j + 1] = G.cum[c][j] + G.D[j] * (a1 * a2 + (a1 * d2 + a2 * d1) / 2 + d1 * d2 / 3);
  }
  return (st[cid] = G);
}
/* M (Hz²/m²·s) accumulated over the combination from its start to relative time r, into out[0..5] */
function mxPartial(G, r, out) {
  const n = G.n; let lo = -1;
  if (n && r > G.t0[0]) { lo = 0; let hi = n - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (G.t0[m] <= r) lo = m; else hi = m - 1; } }
  if (lo < 0) { out.fill(0, 0, 6); return out; }
  const D = G.D[lo], s = r - G.t0[lo] >= D ? 1 : (r - G.t0[lo]) / D;
  for (let c = 0; c < 6; c++) {
    if (s === 1) { out[c] = G.cum[c][lo + 1]; continue; }
    const [i1, i2] = MX_IJ[c], a1 = G.a[i1][lo], a2 = G.a[i2][lo], d1 = G.d[i1][lo], d2 = G.d[i2][lo];
    out[c] = G.cum[c][lo] + D * s * (a1 * a2 + s * ((a1 * d2 + a2 * d1) / 2 + s * d1 * d2 / 3));
  }
  return out;
}
/* M at every block start (independent of B0, made once per file), and the scale 1/(γ B0) for the current B0 */
function mxState(seq, B0) {
  if (!seq.mxRaw) {
    const C = ccCombos(seq), nb = seq.nb, B = seq.B, Ms = MX_IJ.map(() => new Float64Array(nb + 1)), raw = new Float64Array(6), pc = new Float64Array(6);
    let off = new Float64Array(6);
    for (let i = 0; i < nb; i++) {
      for (let c = 0; c < 6; c++) Ms[c][i] = raw[c] + off[c];
      const cid = C.of[i], G = C.list[cid].none ? null : mxGeo(seq, cid);
      if (B.rf[i]) {
        const st = rfSt(seq, B.rf[i]);
        if (st.use === 'e' || st.use === 'r') {
          if (G) mxPartial(G, st.center, pc); else pc.fill(0);
          const nw = new Float64Array(6); for (let c = 0; c < 6; c++) { const rc = raw[c] + pc[c]; nw[c] = st.use === 'e' ? -rc : -2 * rc - off[c]; } off = nw;
        }
      }
      if (G) for (let c = 0; c < 6; c++) raw[c] += G.cum[c][G.n];
    }
    for (let c = 0; c < 6; c++) Ms[c][nb] = raw[c] + off[c];
    seq.mxRaw = Ms;
  }
  if (seq.mx && seq.mx.B0 === B0) return seq.mx;
  if (seq.pyr) delete seq.pyr.mu; seq.muSt = {}; // made with the old B0
  return (seq.mx = { B0, sc: 1 / (GAMMA * B0) });
}
/* μ (1/m²) for sorted relative times in block i, written to out[0][o + q] (as kInBlock); mxState must have run */
function muInBlock(seq, i, rel, out, o, nq = rel.length) {
  const C = ccCombos(seq), cid = C.of[i], G = C.list[cid].none ? null : mxGeo(seq, cid), Ms = seq.mxRaw, sc = seq.mx.sc, B = seq.B;
  let rc = -1, use = null;
  if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e' || st.use === 'r') { rc = st.center; use = st.use; } }
  const k0 = new Float64Array(6), pc = new Float64Array(6), p = new Float64Array(6);
  for (let c = 0; c < 6; c++) k0[c] = Ms[c][i];
  if (rc >= 0 && G) mxPartial(G, rc, pc);
  for (let q = 0; q < nq; q++) {
    const r = rel[q]; if (G) mxPartial(G, r, p);
    let acc = 0;
    for (let c = 0; c < 6; c++) { const m = rc >= 0 && r >= rc ? (use === 'e' ? p[c] - pc[c] : -(k0[c] + pc[c]) + (p[c] - pc[c])) : k0[c] + p[c]; acc += MX_W[c] * m * m; }
    out[0][o + q] = Math.sqrt(acc) * sc;
  }
}
const KP_MU = { name: 'mu', keys: ['mu'], nl: true, start: () => null, ids: s => [s.B.pgx, s.B.pgy, s.B.pgz], tok: s => s.mx,
  geo: (s, id) => geoG(s, id), ext: null, inBlock: (s, i, rel, out, o, nq) => muInBlock(s, i, rel, out, o, nq),
  st: s => s.muSt || (s.muSt = {}), memo: { tok: null, map: new Map(), nv: 0 } };
KINT.mu = [KP_MU, 0];
function blockAtTime(seq, t) {
  const a = seq.blockStart, n = seq.nb; let lo = 0, hi = n;
  while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] <= t) lo = m + 1; else hi = m; }
  return Math.max(0, Math.min(n - 1, lo - 1));
}
function channelValue(seq, key, t) {
  if (key in KINT) return kintValue(KINT[key][0], seq, KINT[key][1], t);
  if (CHANNELS[key].cc !== undefined) return ccValue(seq, CHANNELS[key].cc, t);
  const ch = CHANNELS[key], i = blockAtTime(seq, t), id = seq.B[ch.col][i], fn = ch.fn, out = ch.p ? NaN : 0;
  if (!id) return out;
  const g = fn(seq, id), r = t - seq.blockStart[i];
  if (r < g.t[0] || r > g.t[g.n - 1]) return out;
  let lo = 0, hi = g.n; while (lo < hi) { const m = (lo + hi) >> 1; if (g.t[m] <= r) lo = m + 1; else hi = m; }
  const j = lo; if (j === 0) return g.v[0]; if (j >= g.n) return g.v[g.n - 1];
  const ta = g.t[j - 1], tb = g.t[j], va = g.v[j - 1], vb = g.v[j];
  if (va !== va || vb !== vb) return NaN;
  return tb > ta ? va + (vb - va) * (r - ta) / (tb - ta) : vb;
}

/* ---------- min/max pyramid over blocks, per channel ---------- */
/* 1.45.0: a factor of 4 between levels (before 16): a pixel column holding a few hundred blocks needed up to 15
   steps per level on each side; now at most 3. The extra levels cost about 2 % more summary memory. */
const PYR_SIZES = [16, 64, 256, 1024, 4096, 16384, 65536, 262144, 1048576];
/* summary levels: files up to a million blocks also get 4-block buckets. Zoomed out, a pixel column spans ~10-20
   blocks that rarely line up with the 16-block buckets, so most were summarised block by block; with 4-block buckets
   that is a few per column. (18 bytes per 4 blocks and channel, hence the limit.) */
function pyrSizes(nb) { return nb <= 1e6 ? [4, ...PYR_SIZES] : PYR_SIZES; }
function buildPyramid(seq, key) {
  const nb = seq.nb, out = [], ch = CHANNELS[key], ids = seq.B[ch.col], bs = seq.blockStart, isP = ch.p;
  // per unique event: summary pieces that do not depend on the block
  let maxId = 0; for (let i = 0; i < nb; i++) if (ids[i] > maxId) maxId = ids[i];
  const eMn = new Float64Array(maxId + 1), eMx = new Float64Array(maxId + 1), eF = new Float64Array(maxId + 1), eL = new Float64Array(maxId + 1), eT0 = new Float64Array(maxId + 1), eT1 = new Float64Array(maxId + 1), eOk = new Uint8Array(maxId + 1);
  for (let i = 0; i < nb; i++) {
    const id = ids[i]; if (!id || eOk[id]) continue;
    const g = ch.fn === geoSlew ? slewSum(seq, id) : ch.fn(seq, id);
    eMn[id] = g.min; eMx[id] = g.max; eF[id] = g.v[0]; eL[id] = isP ? (g.n > 1 ? g.v[g.n - 2] : g.v[0]) : g.v[g.n - 1]; eT0[id] = g.t[0]; eT1[id] = g.t[g.n - 1]; eOk[id] = 1;
  }
  (seq.evt || (seq.evt = {}))[key] = { mn: eMn, mx: eMx, f: eF, l: eL, t0: eT0, t1: eT1, ids, isP }; // for fast block summaries
  let prev = null; const SIZES = pyrSizes(nb);
  for (let L = 0; L < SIZES.length; L++) {
    const sz = SIZES[L], n = Math.floor(nb / sz); if (n < 2) break;
    const P = { size: sz, mn: new Float32Array(n), mx: new Float32Array(n), first: new Float32Array(n), last: new Float32Array(n), has: new Uint8Array(n), brk: new Uint8Array(n) };
    for (let k = 0; k < n; k++) {
      let mn = Infinity, mx = -Infinity, first = NaN, last = NaN, has = 0, brk = 0;
      if (L === 0) {
        for (let i = k * sz; i < (k + 1) * sz; i++) {
          const id = ids[i]; let bmn, bmx, bf, bl;
          if (!id) { if (isP) continue; bmn = bmx = bf = bl = 0; }
          else if (isP) { bmn = eMn[id]; bmx = eMx[id]; bf = eF[id]; bl = eL[id]; brk = 1; }
          else {
            bf = eT0[id] <= 1e-9 ? eF[id] : 0; bl = Math.abs(eT1[id] - (bs[i + 1] - bs[i])) <= 1e-9 ? eL[id] : 0;
            const z = bf === 0 || bl === 0; bmn = z && eMn[id] > 0 ? 0 : eMn[id]; bmx = z && eMx[id] < 0 ? 0 : eMx[id];
          }
          if (!has) first = bf; last = bl; has = 1; if (bmn < mn) mn = bmn; if (bmx > mx) mx = bmx;
        }
      } else {
        const r = sz / prev.size;
        for (let j = k * r; j < (k + 1) * r; j++) {
          if (prev.brk[j]) brk = 1; if (!prev.has[j]) continue;
          if (!has) first = prev.first[j]; last = prev.last[j]; has = 1; if (prev.mn[j] < mn) mn = prev.mn[j]; if (prev.mx[j] > mx) mx = prev.mx[j];
        }
      }
      P.mn[k] = mn; P.mx[k] = mx; P.first[k] = first; P.last[k] = last; P.has[k] = has; P.brk[k] = brk;
    }
    out.push(P); prev = P;
  }
  return out;
}

/* combine the summaries of blocks bA..bB (inclusive) using the fewest aligned pyramid buckets */
/* pyrLevel(pyr)[i]: the largest level whose bucket size is at most 2^i (-1: none). With it rangeSummary picks the
   level at each step from the block index's alignment and the blocks left (1.45.0), instead of trying every level */
function pyrLevel(pyr) {
  if (pyr.lv) return pyr.lv;
  const lv = new Int8Array(33).fill(-1); for (let i = 0; i <= 32; i++) for (let L = 0; L < pyr.length; L++) if (pyr[L].size <= 2 ** i) lv[i] = L;
  return (pyr.lv = lv);
}
function rangeSummary(seq, key, bA, bB, o, tmp) {
  const pyr = seq.pyr[key], KI = KINT[key], m0a = KI ? KI[1] : -1, KS = KI ? KI[0].st(seq) : null, z0 = pyr && pyr.length ? pyr[0].size - 1 : -1, lv = z0 >= 0 ? pyrLevel(pyr) : null;
  let has = 0, mn = Infinity, mx = -Infinity, first = 0, last = 0, brk = 0, b = bA;
  while (b <= bB) {
    if (z0 >= 0 && (b & z0) === 0 && b + z0 <= bB) { // sizes are powers of two: the largest bucket starting at b inside the range
      const al = b === 0 ? 32 : 31 - Math.clz32(b & -b), fit = 31 - Math.clz32(bB - b + 1), L = lv[al < fit ? al : fit];
      if (L >= 0) {
        const P = pyr[L], sz = P.size, q = b / sz; if (P.brk[q]) brk = 1;
        if (P.has[q]) { if (!has) first = P.first[q]; last = P.last[q]; has = 1; if (P.mn[q] < mn) mn = P.mn[q]; if (P.mx[q] > mx) mx = P.mx[q]; }
        b += sz; continue;
      }
    }
    if (m0a >= 0 && KS.ev) { // k-vector, kc: start value plus the event's integral extremes (blocks without excitation/refocusing)
      const T = KS.ev, r = seq.B.rf[b];
      if (!r || T.plainRf[r]) {
        const k0 = KI[0].start(seq)[m0a][b], id = T.ids[m0a][b], bmn = id ? k0 + T.mn[m0a][id] : k0, bmx = id ? k0 + T.mx[m0a][id] : k0, bl = id ? k0 + T.area[m0a][id] : k0;
        if (!has) first = k0; last = bl; has = 1; if (bmn < mn) mn = bmn; if (bmx > mx) mx = bmx;
        b++; continue;
      }
    }
    const E = seq.evt && seq.evt[key];
    if (E) { // one block from the per-event table: the same rule as blockSummary, without a call per block
      const id = E.ids[b]; let bmn, bmx, bf, bl;
      if (!id) { if (E.isP) { b++; continue; } bmn = bmx = bf = bl = 0; }
      else if (E.isP) { bmn = E.mn[id]; bmx = E.mx[id]; bf = E.f[id]; bl = E.l[id]; brk = 1; }
      else {
        const bs = seq.blockStart; bf = E.t0[id] <= 1e-9 ? E.f[id] : 0; bl = Math.abs(E.t1[id] - (bs[b + 1] - bs[b])) <= 1e-9 ? E.l[id] : 0;
        const z = bf === 0 || bl === 0; bmn = z && E.mn[id] > 0 ? 0 : E.mn[id]; bmx = z && E.mx[id] < 0 ? 0 : E.mx[id];
      }
      if (!has) first = bf; last = bl; has = 1; if (bmn < mn) mn = bmn; if (bmx > mx) mx = bmx;
      b++; continue;
    }
    blockSummary(seq, key, b, tmp); if (tmp.brk) brk = 1;
    if (tmp.has) { if (!has) first = tmp.first; last = tmp.last; has = 1; if (tmp.mn < mn) mn = tmp.mn; if (tmp.mx > mx) mx = tmp.mx; }
    b++;
  }
  o.has = has; o.mn = mn; o.mx = mx; o.first = first; o.last = last; o.brk = brk; return o;
}
/* ADC-type pyramid: highest-ranked type per bucket of ADC events */
const TYPE_RANK = [1, 4, 3, 5, 2];
function buildAdcPyramid(seq) {
  const out = [], T = seq.adcType, n0 = T.length; let prev = null;
  for (const sz of [32, 128, 512, 2048, 8192, 32768, 131072]) { // 1.45.0: factor 4 (was 32), fewer steps per pixel column
    const n = Math.floor(n0 / sz); if (n < 2) break;
    const P = { size: sz, type: new Int8Array(n) };
    for (let k = 0; k < n; k++) {
      let best = -1;
      if (!prev) { for (let j = k * sz; j < (k + 1) * sz; j++) if (best < 0 || TYPE_RANK[T[j]] > TYPE_RANK[best]) best = T[j]; }
      else { const r = sz / prev.size; for (let j = k * r; j < (k + 1) * r; j++) { const x = prev.type[j]; if (best < 0 || TYPE_RANK[x] > TYPE_RANK[best]) best = x; } }
      P.type[k] = best;
    }
    out.push(P); prev = P;
  }
  return out;
}
function adcRangeType(seq, jA, jB) {
  const pyr = seq.adcPyr, T = seq.adcType; let best = -1, j = jA;
  while (j <= jB) {
    let used = false;
    for (let L = pyr.length - 1; L >= 0; L--) { const P = pyr[L], sz = P.size; if (j % sz || j + sz - 1 > jB) continue; const x = P.type[j / sz]; if (best < 0 || TYPE_RANK[x] > TYPE_RANK[best]) best = x; j += sz; used = true; break; }
    if (used) continue;
    const x = T[j]; if (best < 0 || TYPE_RANK[x] > TYPE_RANK[best]) best = x; j++;
  }
  return best;
}

/* ---------- extensions ---------- */
function extChain(seq, id) {
  const out = []; let guard = 0;
  while (id && seq.extList.has(id) && guard++ < 1000) {
    const e = seq.extList.get(id), name = seq.extTypes.get(e.type) || `type ${e.type}`, spec = seq.extSpecs.get(e.type);
    out.push({ name, ref: e.ref, data: spec ? spec.get(e.ref) : null }); id = e.next;
  }
  return out;
}
function labelNames(seq) {
  const out = new Set();
  for (const [type, name] of seq.extTypes) if (/LABEL/i.test(name)) for (const d of seq.extSpecs.get(type).values()) if (d[1]) out.add(d[1]);
  return [...out];
}
const LABEL_ORDER = ['SLC', 'SEG', 'REP', 'AVG', 'SET', 'ECO', 'PHS', 'LIN', 'PAR', 'ACQ', 'TRID', 'NAV', 'REV', 'SMS', 'REF', 'IMA', 'NOISE', 'OFF', 'PMC', 'NOROT', 'NOPOS', 'NOSCL', 'ONCE'];
const LABEL_FLAGS = new Set(['NAV', 'REV', 'SMS', 'REF', 'IMA', 'NOISE', 'OFF', 'PMC', 'NOROT', 'NOPOS', 'NOSCL', 'ONCE']);

/* growable typed buffer */
class GBuf { constructor(T, n = 1024) { this.T = T; this.a = new T(n); this.n = 0; } push(x) { if (this.n === this.a.length) { const b = new this.T(this.n * 2); b.set(this.a); this.a = b; } this.a[this.n++] = x; } done() { return this.a.slice(0, this.n); } }

/* partial integral of a piecewise-linear geometry from its first vertex up to relative time r */
function partialArea(g, r) {
  if (r <= g.t[0]) return 0;
  let acc = 0;
  for (let j = 1; j < g.n; j++) {
    const ta = g.t[j - 1], tb = g.t[j];
    if (r >= tb) { acc += 0.5 * (g.v[j - 1] + g.v[j]) * (tb - ta); continue; }
    const d = r - ta, D = tb - ta, s = D > 0 ? (g.v[j] - g.v[j - 1]) / D : 0;
    return acc + g.v[j - 1] * d + 0.5 * s * d * d;
  }
  return acc;
}

/* When the file does not state a pulse's purpose (Pulseq < 1.5, or 'u'), rfStats guesses from the flip
   angle alone (≤ 90° excitation, otherwise refocusing). Context improves that: a refocusing pulse is always
   followed by a readout before the next excitation, a preparation pulse is not. For guessed pulses:
   - guessed refocusing with no ADC before the next excitation → inversion (flip > 150°) or saturation;
   - guessed excitation with no ADC before the next excitation, no gradient in its block and an
     off-resonance frequency (|f| > 100 Hz, or a ppm offset > 0.5 ppm, e.g. fat saturation) → saturation.
   Each pulse (RF event id) is decided by majority over its occurrences. Stated purposes are kept. */
function contextUses(seq) {
  const nb = seq.nb, B = seq.B, rfb = [];
  for (let b = 0; b < nb; b++) if (B.rf[b]) rfb.push(b);
  if (!rfb.length) return;
  const st = b => rfSt(seq, B.rf[b]), guessed = b => st(b).useGuessed;
  if (!rfb.some(guessed)) return;
  { let anyAdc = false; for (let b = 0; b < nb && !anyAdc; b++) if (B.adc[b]) anyAdc = true; if (!anyAdc) return; } // no readouts: no context
  // next ADC block after each block
  const nextAdc = new Int32Array(nb + 1).fill(nb); for (let b = nb - 1; b >= 0; b--) nextAdc[b] = B.adc[b] ? b : nextAdc[b + 1];
  // excitations: stated 'e', or guessed 'e' in a block with a gradient (slice-selective) or on resonance
  const isExc = b => { const s2 = st(b); if (!s2.useGuessed) return s2.use === 'e'; if (s2.use !== 'e') return false; const r = seq.rf.get(B.rf[b]); return B.gx[b] || B.gy[b] || B.gz[b] || (Math.abs(r.freq) <= 100 && !r.freqPPM); };
  const votes = new Map();
  for (let i = 0; i < rfb.length; i++) {
    const b = rfb[i]; if (!guessed(b)) continue;
    let ne = -1; for (let j = i + 1; j < rfb.length; j++) if (isExc(rfb[j])) { ne = rfb[j]; break; }
    const noAdc = ne >= 0 ? nextAdc[b + 1] > ne : nextAdc[b + 1] >= nb;
    const s2 = st(b), r = seq.rf.get(B.rf[b]); let v = s2.use;
    if (noAdc && ne >= 0) {
      if (s2.use === 'r') v = s2.flip > 150 * Math.PI / 180 ? 'i' : 's';
      else if (s2.use === 'e' && !(B.gx[b] || B.gy[b] || B.gz[b]) && (Math.abs(r.freq) > 100 || Math.abs(r.freqPPM || 0) > 0.5)) v = 's';
    }
    const id = B.rf[b], m = votes.get(id) || {}; m[v] = (m[v] || 0) + 1; votes.set(id, m);
  }
  for (const [id, m] of votes) {
    const best = Object.entries(m).sort((a, b) => b[1] - a[1])[0][0], o = rfSt(seq, id);
    if (best !== o.use) { o.use = best; o.useContext = true; }
  }
}

/* ---------- rotation extension (Pulseq 1.5) ----------
   A block with a ROTATIONS extension plays its gradient events (logical coordinates) rotated:
   G_physical = R · G_logical, R from the unit quaternion (w, x, y, z) (as Pulseq's toRotMat / rotate3D).
   The physical gradients live in B.pgx/pgy/pgz: the event id where a block is not rotated, otherwise a
   synthetic id whose geometry is the rotated combination (built once per rotation and event triple). */
function quatToMat(q) {
  const n = Math.hypot(q[0], q[1], q[2], q[3]) || 1, w = q[0] / n, x = q[1] / n, y = q[2] / n, z = q[3] / n;
  return [[1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
          [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
          [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]];
}
function rotationOfBlock(seq, i) { // quaternion [w, x, y, z] of block i, or null
  if (seq.rotType === undefined) { seq.rotType = null; for (const [t, name] of seq.extTypes) if (/^ROTATIONS?$/i.test(name)) seq.rotType = t; }
  if (seq.rotType === null || !seq.B.ext[i]) return null;
  let id = seq.B.ext[i], guard = 0;
  while (id && guard++ < 64) {
    const e = seq.extList.get(id); if (!e) break;
    if (e.type === seq.rotType) { const d = seq.extSpecs.get(e.type).get(e.ref); return d ? d.slice(0, 4).map(Number) : null; }
    id = e.next;
  }
  return null;
}
/* FOV definition (m) along the direction e (scanner x, y, z), or 0 when the definition does not give one FOV along e.
   The definition is in the sequence's own (logical) axes. When the readout block (ADC index j) carries a ROTATIONS
   extension, e is first turned back into those axes (Rᵀe), so a stack rotated between x and z keeps its prescribed
   FOV along the readout. A readout rotated by hand (gradient events written rotated, no extension on its block) in a
   shot whose excitation (block exc) carries a ROTATIONS extension, as MATLAB sequences that rotate only some blocks
   with the extension write: the excitation's rotation is used, but only when it turns e onto a logical axis (within
   ~5°); otherwise, and for gradients rotated by hand throughout, the logical and physical axes are taken as the same.
   A direction within ~5° of a logical axis counts as that axis (as the image axes are snapped), so a phase blip
   during the readout does not bring in a second axis. */
function fovDefAlong(seq, e, j, exc) {
  const D = Array.isArray(seq.defs.FOV) ? seq.defs.FOV : null; if (!e || !D || D.length < 2) return 0;
  const back = (q, v) => { const R = quatToMat(q); return [0, 1, 2].map(c => R[0][c] * v[0] + R[1][c] * v[1] + R[2][c] * v[2]); };
  const onAxis = v => { const a = v.map(Math.abs); return Math.max(...a) / (Math.hypot(...a) || 1) > 0.996; };
  const q = j >= 0 && seq.adcBlocks ? rotationOfBlock(seq, seq.adcBlocks[j]) : null;
  if (q) e = back(q, e);
  else if (exc >= 0) { const qe = rotationOfBlock(seq, exc); if (qe) { const v = back(qe, e); if (onAxis(v)) e = v; } }
  const a = e.map(Math.abs), L = Math.hypot(...a) || 1, im = a.indexOf(Math.max(...a));
  let f = 0;
  for (let i = 0; i < 3; i++) {
    if (a[im] / L > 0.996 ? i !== im : a[i] < 1e-3) continue;
    const v = +D[i]; if (!(v > 0)) return 0; if (f && Math.abs(v - f) > 1e-6 * f) return 0; f = v;
  }
  return f;
}
function applyRotations(seq) {
  const B = seq.B, nb = seq.nb;
  B.pgx = B.gx; B.pgy = B.gy; B.pgz = B.gz; seq.rot = { blocks: 0, distinct: 0, maxAngle: 0 };
  let any = false; for (const [, name] of seq.extTypes) if (/^ROTATIONS?$/i.test(name)) any = true;
  if (!any) return;
  const pg = [Uint32Array.from(B.gx), Uint32Array.from(B.gy), Uint32Array.from(B.gz)];
  let nextId = 1; for (const id of seq.grad.keys()) nextId = Math.max(nextId, id + 1);
  const combos = new Map(), mats = new Map();
  const valAt = (g, t) => { // piecewise-linear value, 0 outside the event
    if (!g || t < g.t[0] || t > g.t[g.n - 1]) return 0;
    let lo = 0, hi = g.n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (g.t[m] <= t) lo = m; else hi = m; }
    const d = g.t[hi] - g.t[lo]; return d > 0 ? g.v[lo] + (g.v[hi] - g.v[lo]) * (t - g.t[lo]) / d : g.v[hi];
  };
  for (let i = 0; i < nb; i++) {
    if (!B.ext[i]) continue;
    const q = rotationOfBlock(seq, i); if (!q) continue;
    const key0 = q.join(','); let M = mats.get(key0); if (!M) { M = quatToMat(q); mats.set(key0, M); }
    const ang = 2 * Math.acos(Math.min(1, Math.abs(q[0]) / (Math.hypot(...q) || 1)));
    if (ang < 1e-9) continue; // identity
    seq.rot.blocks++; seq.rot.maxAngle = Math.max(seq.rot.maxAngle, ang);
    if (!B.gx[i] && !B.gy[i] && !B.gz[i]) continue;
    // the rotated events are clipped to the block, so the block duration is part of the key
    const dur = seq.blockStart[i + 1] - seq.blockStart[i], key = key0 + '|' + B.gx[i] + ',' + B.gy[i] + ',' + B.gz[i] + '|' + Math.round(dur * 1e10);
    let ids = combos.get(key);
    if (!ids) {
      // vertex times snapped to 0.1 ns, so that the same time written by two events (0.00066 and 0.0006599999999999999)
      // is one vertex: compared exactly, the event that ends first was 0 at the other's end (a step to 0 inside the block)
      const q = x => Math.round(x * 1e10) / 1e10, dq = q(dur);
      const L = [B.gx[i], B.gy[i], B.gz[i]].map(id => { if (!id) return null; const g = geoG(seq, id); return { n: g.n, t: Float64Array.from(g.t, q), v: g.v }; });
      const ts = new Set();
      for (const g of L) if (g) { for (let k = 0; k < g.n; k++) ts.add(g.t[k]); if (g.v[0] !== 0) ts.add(g.t[0] - 1e-12); if (g.v[g.n - 1] !== 0) ts.add(g.t[g.n - 1] + 1e-12); }
      // steps at event edges, only where the event is non-zero there (1.48.4): an edge at 0 is no step, and a vertex 1 ps
      // from another axis's vertex turned the float32 rounding of a ramping axis into slew spikes (367 T/m/s)
      // kept inside the block: an edge point after the block end made a gradient that continues into the next block end at 0
      const t = [...ts].filter(x => x >= 0 && x <= dq).sort((a, b) => a - b), vals = L.map(g => t.map(x => valAt(g, x)));
      ids = [0, 1, 2].map(a => {
        const v = t.map((_, k) => M[a][0] * vals[0][k] + M[a][1] * vals[1][k] + M[a][2] * vals[2][k]);
        if (v.every(x => Math.abs(x) < 1e-9)) return 0;
        const sid = nextId++; seq.geo.g[sid] = geoFinish(t, v); return sid;
      });
      combos.set(key, ids);
    }
    pg[0][i] = ids[0]; pg[1][i] = ids[1]; pg[2][i] = ids[2];
  }
  B.pgx = pg[0]; B.pgy = pg[1]; B.pgz = pg[2]; seq.rot.distinct = mats.size;
}

/* Pulseq TRIGGERS extension: "id type channel delay duration" (µs). Type 1: digital output pulse on osc0, osc1 or ext1;
   type 2: wait for an external trigger on physio1 or physio2 (Pulseq registerControlEvent; PyPulseq the same) */
const TRIG_TYPES = { 1: { kind: 'output', ch: ['osc0', 'osc1', 'ext1'] }, 2: { kind: 'wait', ch: ['physio1', 'physio2'] } };
function trigName(type, ch) { const T = TRIG_TYPES[type]; return T && T.ch[ch - 1] ? T.ch[ch - 1] : `type ${type} ch ${ch}`; }
function trigText(type, ch) { const T = TRIG_TYPES[type], n = trigName(type, ch); return !T ? `trigger (${n})` : T.kind === 'output' ? `output pulse on ${n}` : `wait for ${n} trigger`; }
/* ---------- one pass over all blocks: stats, ADC table, labels, ADC types, triggers, k at block starts ---------- */
function analyze(seq, progress) {
  const nb = seq.nb, B = seq.B, bs = seq.blockStart, W = seq.warnings;
  applyRotations(seq); // physical gradients (B.pgx/pgy/pgz) for rotated blocks
  contextUses(seq); // before anything uses the pulse purposes (k-space resets, shots, statistics)
  const names = labelNames(seq).sort((a, b) => { const ia = LABEL_ORDER.indexOf(a), ib = LABEL_ORDER.indexOf(b); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || a.localeCompare(b); });
  const lIdx = new Map(names.map((n, i) => [n, i])), lVal = new Float64Array(names.length);
  const runs = names.map(() => ({ b: new GBuf(Uint32Array), v: new GBuf(Float64Array), mn: 0, mx: 0 }));
  runs.forEach(r => { r.b.push(0); r.v.push(0); });
  const extCache = new Map();
  const extOps = id => {
    let o = extCache.get(id); if (o) return o;
    o = { ops: [], trig: [] };
    for (const x of extChain(seq, id)) {
      if (!x.data) continue;
      if (/LABELSET/i.test(x.name) && lIdx.has(x.data[1])) o.ops.push([lIdx.get(x.data[1]), 1, +x.data[0]]);
      else if (/LABELINC/i.test(x.name) && lIdx.has(x.data[1])) o.ops.push([lIdx.get(x.data[1]), 0, +x.data[0]]);
      else if (/TRIGGER/i.test(x.name)) o.trig.push([(+x.data[2] || 0) * 1e-6, (+x.data[3] || 0) * 1e-6, +x.data[0] || 0, +x.data[1] || 0]);
    }
    // Pulseq specification: in a block, all LABELSET are applied before any LABELINC, whatever their order in the
    // extension chain (MATLAB writes the chain in reverse, and its evalLabels follows the chain)
    o.ops.sort((p, q) => q[1] - p[1]); // stable: sets in chain order, then increments in chain order
    extCache.set(id, o); return o;
  };
  const fl = n => lIdx.has(n) ? lIdx.get(n) : -1, iNOISE = fl('NOISE'), iREF = fl('REF'), iIMA = fl('IMA'), iNAV = fl('NAV');
  const adcB = new GBuf(Uint32Array), adcTy = new GBuf(Uint8Array), trig = [];
  const typeCounts = [0, 0, 0, 0, 0], uses = {};
  let nRF = 0, nSamples = 0, nWarn = 0;
  const kS = [new Float64Array(nb + 1), new Float64Array(nb + 1), new Float64Array(nb + 1)];
  const raw = [0, 0, 0]; let off = [0, 0, 0];
  const G = [B.pgx, B.pgy, B.pgz]; // physical
  let nextProg = 0;
  for (let i = 0; i < nb; i++) {
    if (progress && i >= nextProg) { progress(0.45 + 0.35 * i / nb); nextProg = i + 200000; }
    const dur = bs[i + 1] - bs[i];
    if (seq.verNum >= 1004000) { const e = blockEventEnd(seq, i); if (dur + 1e-9 < e) { nWarn++; if (nWarn <= 50) W.push(`Block ${B.id[i]}: events (${(e * 1e6).toFixed(1)} µs) exceed block duration (${(dur * 1e6).toFixed(1)} µs)`); } }
    if (B.ext[i]) {
      const o = extOps(B.ext[i]);
      for (const [li, set, val] of o.ops) {
        const nv = set ? val : lVal[li] + val;
        if (nv !== lVal[li]) {
          lVal[li] = nv; const r = runs[li];
          if (r.b.a[r.b.n - 1] === i) r.v.a[r.v.n - 1] = nv; else { r.b.push(i); r.v.push(nv); }
          if (nv < r.mn) r.mn = nv; if (nv > r.mx) r.mx = nv;
        }
      }
      for (const [d, du, ty, ch] of o.trig) trig.push({ block: i, t: bs[i] + d, dur: du, type: ty, ch });
    }
    // k at block start
    for (let a = 0; a < 3; a++) kS[a][i] = raw[a] + off[a];
    if (B.rf[i]) {
      nRF++; const st = rfSt(seq, B.rf[i]); uses[st.use] = (uses[st.use] || 0) + 1;
      if (st.use === 'e' || st.use === 'r') {
        const rc = [0, 1, 2].map(a => raw[a] + (G[a][i] ? partialArea(geoG(seq, G[a][i]), st.center) : 0));
        off = st.use === 'e' ? rc.map(x => -x) : rc.map((x, a) => -2 * x - off[a]);
      }
    }
    for (let a = 0; a < 3; a++) if (G[a][i]) raw[a] += geoG(seq, G[a][i]).area;
    if (B.adc[i]) {
      const d = seq.adc.get(B.adc[i]);
      if (d) {
        let c = 0;
        if (iNOISE >= 0 && lVal[iNOISE]) c = 3;
        else if (iREF >= 0 && lVal[iREF]) c = iIMA >= 0 && lVal[iIMA] ? 2 : 1;
        else if (iNAV >= 0 && lVal[iNAV]) c = 4;
        adcB.push(i); adcTy.push(c); typeCounts[c]++; nSamples += d.num;
      }
    }
  }
  for (let a = 0; a < 3; a++) kS[a][nb] = raw[a] + off[a];
  if (nWarn > 50) W.push(`… and ${nWarn - 50} more blocks with the same problem`);
  seq.kStart = kS;
  seq.adcBlocks = adcB.done(); seq.adcType = adcTy.done();
  const nA = seq.adcBlocks.length;
  seq.adcOff = new Float64Array(nA + 1); seq.adcT0 = new Float64Array(nA); seq.adcT1 = new Float64Array(nA);
  for (let j = 0; j < nA; j++) {
    const b = seq.adcBlocks[j], d = seq.adc.get(B.adc[b]);
    seq.adcOff[j + 1] = seq.adcOff[j] + d.num; seq.adcT0[j] = bs[b] + d.delay; seq.adcT1[j] = seq.adcT0[j] + d.num * d.dwell;
  }
  seq.triggers = trig; seq.adcTypeCounts = typeCounts;
  seq.labels = names.map((name, li) => {
    const r = runs[li], b = r.b.done(), v = r.v.done(), t = new Float64Array(b.length);
    for (let k = 0; k < b.length; k++) t[k] = bs[b[k]];
    return { name, flag: LABEL_FLAGS.has(name), b, t, v, min: Math.min(r.mn, v[0]), max: Math.max(r.mx, v[0]) };
  });
  // peaks from the unique events actually used
  const maxG = [0, 0, 0], maxSlew = [0, 0, 0]; let maxRF = 0;
  const used = [new Set(), new Set(), new Set()], usedRF = new Set();
  for (let i = 0; i < nb; i++) { for (let a = 0; a < 3; a++) if (G[a][i]) used[a].add(G[a][i]); if (B.rf[i]) usedRF.add(B.rf[i]); }
  const idG = [0, 0, 0], idS = [0, 0, 0]; // events that reach the peaks
  for (let a = 0; a < 3; a++) for (const id of used[a]) { const g = geoG(seq, id), s = slewSum(seq, id), pg = Math.max(Math.abs(g.min), Math.abs(g.max)), ps = Math.max(Math.abs(s.min), Math.abs(s.max)); if (pg > maxG[a]) { maxG[a] = pg; idG[a] = id; } if (ps > maxSlew[a]) { maxSlew[a] = ps; idS[a] = id; } }
  const maxGBlock = [-1, -1, -1], maxSlewBlock = [-1, -1, -1]; // first block that plays each peak
  for (let a = 0; a < 3; a++) for (let i = 0; i < nb && (maxGBlock[a] < 0 || maxSlewBlock[a] < 0); i++) { if (maxGBlock[a] < 0 && idG[a] && G[a][i] === idG[a]) maxGBlock[a] = i; if (maxSlewBlock[a] < 0 && idS[a] && G[a][i] === idS[a]) maxSlewBlock[a] = i; }
  for (const id of usedRF) maxRF = Math.max(maxRF, geoRfm(seq, id).max);
  seq.stats = { maxRF, maxG, maxSlew, maxGBlock, maxSlewBlock, nRF, nADC: nA, nSamples, uses, nExc: uses.e || 0, nRef: uses.r || 0 };
  // pyramids
  seq.pyr = {};
  const keys = Object.keys(CHANNELS).filter(k => !CHANNELS[k].lazy);
  keys.forEach((k, j) => { if (progress) progress(0.8 + 0.15 * j / keys.length); seq.pyr[k] = buildPyramid(seq, k); });
  seq.adcPyr = buildAdcPyramid(seq);
  seq.shots = computeShots(seq, 'exc');
  if (progress) progress(1);
  return seq;
}

/* ---------- k-space on demand ---------- */
/* k (1/m) for sorted relative times in block i, written to out[a][o + q] */
function kInBlock(seq, i, rel, out, o, nq = rel.length) {
  const B = seq.B, G = [B.pgx[i], B.pgy[i], B.pgz[i]];
  let rc = -1, use = null;
  if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e' || st.use === 'r') { rc = st.center; use = st.use; } }
  for (let a = 0; a < 3; a++) {
    const k0 = seq.kStart[a][i], g = G[a] ? geoG(seq, G[a]) : null;
    const pc = rc >= 0 && g ? partialArea(g, rc) : 0;
    // sweep through vertices once for all (sorted) times
    let j = 1, acc = 0;
    for (let q = 0; q < nq; q++) {
      const r = rel[q]; let p = 0;
      if (g && r > g.t[0]) {
        while (j < g.n && g.t[j] <= r) { acc += 0.5 * (g.v[j - 1] + g.v[j]) * (g.t[j] - g.t[j - 1]); j++; }
        if (j >= g.n) p = acc;
        else { const d = r - g.t[j - 1], D = g.t[j] - g.t[j - 1], s = D > 0 ? (g.v[j] - g.v[j - 1]) / D : 0; p = acc + g.v[j - 1] * d + 0.5 * s * d * d; }
      }
      let k;
      if (rc >= 0 && r >= rc) k = use === 'e' ? p - pc : -(k0 + pc) + (p - pc);
      else k = k0 + p;
      out[a][o + q] = k;
    }
  }
}
/* ADC samples of events j0..j1-1 (thinned by whole events to at most maxPts samples) */
function kSamples(seq, j0, j1, maxPts = Infinity, withT = false, kib = kInBlock) { // kib: kInBlock (nominal) or ktInBlock (k + kc)
  const total = seq.adcOff[j1] - seq.adcOff[j0];
  const step = total > maxPts ? Math.ceil(total / maxPts) : 1;
  let n = 0; for (let j = j0; j < j1; j += step) n += seq.adcOff[j + 1] - seq.adcOff[j];
  const out = [new Float32Array(n), new Float32Array(n), new Float32Array(n)], type = new Uint8Array(n), T = withT ? new Float64Array(n) : null;
  let o = 0; const tmp = [new Float64Array(0), new Float64Array(0), new Float64Array(0)], relCache = new Map();
  const ne = step > 1 ? Math.ceil((j1 - j0) / step) : Math.max(0, j1 - j0), ej = new Int32Array(ne), eo = new Int32Array(ne + 1); let e = 0; // ADC event of each run of samples
  for (let j = j0; j < j1; j += step) {
    ej[e] = j; eo[e++] = o;
    const b = seq.adcBlocks[j], aid = seq.B.adc[b], d = seq.adc.get(aid);
    let rel = relCache.get(aid); if (!rel) { rel = new Float64Array(d.num); for (let q = 0; q < d.num; q++) rel[q] = d.delay + (q + 0.5) * d.dwell; relCache.set(aid, rel); }
    if (tmp[0].length < d.num) for (let a = 0; a < 3; a++) tmp[a] = new Float64Array(d.num);
    kib(seq, b, rel, tmp, 0);
    for (let a = 0; a < 3; a++) for (let q = 0; q < d.num; q++) out[a][o + q] = tmp[a][q];
    type.fill(seq.adcType[j], o, o + d.num);
    if (T) for (let q = 0; q < d.num; q++) T[o + q] = seq.blockStart[b] + rel[q];
    o += d.num;
  }
  eo[e] = o;
  return { n, k: out, type, t: T, thinned: step > 1, ej, eo }; // samples eo[e]..eo[e+1]-1 come from ADC event ej[e]
}
/* Echoes of a shot by revisits: a readout that revisits a k-space line already acquired in the current echo starts the
   next echo (two EPI trains around a refocusing pulse, multi-echo GRE). Lines are compared by their end points in k
   (either direction), so turbo spin echo, whose lines are all different, stays one echo. The boundary is put at the
   largest time gap in the current run of readouts (e.g. at the refocusing pulse), so lines of the next echo acquired
   before its first revisit are not left in the previous one. js: the shot's ADC events in order; set(j, echo). */
function revisitEchoes(seq, js, set) {
  const bs = seq.blockStart, gapBefore = (jPrev, j) => bs[seq.adcBlocks[j]] - bs[seq.adcBlocks[jPrev] + 1];
  const rel = new Float64Array(2), tmp = [new Float64Array(2), new Float64Array(2), new Float64Array(2)], r = v => Math.round(v * 2) / 2;
  let echo = 0, cur = [];
  for (const j of js) {
    const b = seq.adcBlocks[j], d = seq.adc.get(seq.B.adc[b]); if (!d || !d.num) continue;
    rel[0] = d.delay + 0.5 * d.dwell; rel[1] = d.delay + (d.num - 0.5) * d.dwell; kInBlock(seq, b, rel, tmp, 0, d.num > 1 ? 2 : 1);
    const l = d.num > 1 ? 1 : 0, A = [0, 1, 2].map(x => r(tmp[x][0])).join(','), B = [0, 1, 2].map(x => r(tmp[x][l])).join(','), key = A < B ? A + '|' + B : B + '|' + A;
    if (cur.some(c => c.key === key)) { // revisit: split at the largest gap since the start of this echo (or right here)
      let m = cur.length, best = cur.length ? gapBefore(cur[cur.length - 1].j, j) : 0;
      for (let q = 1; q < cur.length; q++) { const gq = gapBefore(cur[q - 1].j, cur[q].j); if (gq > best * 1.5) { best = gq; m = q; } }
      const moved = cur.slice(m); echo++; for (const c of moved) set(c.j, echo); cur = moved;
    }
    cur.push({ j, key }); set(j, echo);
  }
}
/* Echo (contrast) of each imaging ADC event, for sequences that acquire several images per excitation (multi-echo spin
   or gradient echo, EPI trains around a refocusing pulse): Int16Array over all ADC events, 0-based echo (0 when there
   is one), -1 for other kinds. Used by the k-space groups, the line statistics and the simulation. Cached on seq per
   shot list. In order:
   1. ECO label: used when it takes more than one value at imaging ADCs.
   2. The readouts of each shot are numbered in order (position p). Positions are echoes of separate images when they
      cover the same lines across the sequence: for every p > 0, at least half of the lines of the smaller set are also
      lines of position 0. A line: its direction (either sense) and its offset across it, so a readout mirrored by a
      refocusing pulse onto the opposite line still counts (multi-spin echo without rewinders). In a turbo spin echo
      or EPI train, positions cover different lines.
   3. Otherwise revisits within each shot (revisitEchoes). */
function adcEchoes(seq, shots) {
  if (seq._echo && seq._echo.shots === shots) return seq._echo.e;
  const nA = seq.adcBlocks.length, e = new Int16Array(nA).fill(-1), AT = seq.adcType, img = j => AT[j] === 0 || AT[j] === 2;
  const done = r => { seq._echo = { shots, e: r }; return r; };
  const eco = seq.labels.find(l => l.name === 'ECO');
  if (eco) {
    let mn = Infinity, mx = -Infinity;
    for (let j = 0; j < nA; j++) if (img(j)) { const x = seq.adcBlocks[j]; let lo = 0, hi = eco.b.length; while (lo < hi) { const h = (lo + hi) >> 1; if (eco.b[h] <= x) lo = h + 1; else hi = h; } const r = lo - 1, v = r >= 0 ? eco.v[r] : 0; e[j] = v; if (v < mn) mn = v; if (v > mx) mx = v; }
    if (mx > mn) { for (let j = 0; j < nA; j++) if (e[j] >= 0) e[j] -= Math.max(0, mn); return done(e); }
    e.fill(-1);
  }
  if (!shots || !shots.length) { for (let j = 0; j < nA; j++) if (img(j)) e[j] = 0; return done(e); }
  const byRevisit = () => { for (const sh of shots) { const js = []; for (let j = sh.j0; j < sh.j1; j++) if (img(j)) js.push(j); revisitEchoes(seq, js, (j, v) => { e[j] = v; }); } return done(e); };
  // both ends of each imaging readout
  const ends = new Float64Array(6 * nA), rel = new Float64Array(2), tmp = [new Float64Array(2), new Float64Array(2), new Float64Array(2)];
  let m = 0;
  for (let j = 0; j < nA; j++) {
    if (!img(j)) continue;
    const b = seq.adcBlocks[j], d = seq.adc.get(seq.B.adc[b]); rel[0] = d.delay + 0.5 * d.dwell; rel[1] = d.delay + (d.num - 0.5) * d.dwell;
    kInBlock(seq, b, rel, tmp, 0);
    for (let a = 0; a < 3; a++) { ends[6 * j + a] = tmp[a][0]; ends[6 * j + 3 + a] = tmp[a][1]; m = Math.max(m, Math.abs(tmp[a][0]), Math.abs(tmp[a][1])); }
  }
  // a line: its direction (either sense) and where it lies across that direction (the offset of its midpoint), so a
  // readout run backwards, or mirrored by a refocusing pulse onto the opposite line, is still recognised as a line
  const q = (m || 1) * 1e-3, key = j => {
    const o = 6 * j, D = [0, 1, 2].map(a => ends[o + 3 + a] - ends[o + a]), M = [0, 1, 2].map(a => 0.5 * (ends[o + 3 + a] + ends[o + a])), L = Math.hypot(...D);
    if (L < q) return 'p' + M.map(v => Math.round(v / q)).join(',');
    let u = D.map(v => v / L); const f = u.find(v => Math.abs(v) > 1e-6); if (f < 0) u = u.map(v => -v);
    const md = M[0] * u[0] + M[1] * u[1] + M[2] * u[2];
    return u.map(v => Math.round(v * 1e3)).join(',') + ';' + M.map((v, a) => Math.round((v - md * u[a]) / q)).join(',');
  };
  const pos = new Int16Array(nA).fill(-1), sets = [];
  for (const sh of shots) { let p = 0; for (let j = sh.j0; j < sh.j1; j++) if (img(j)) { pos[j] = p; (sets[p] || (sets[p] = new Set())).add(key(j)); p++; } }
  if (sets.length < 2) return byRevisit();
  for (let p = 1; p < sets.length; p++) {
    const A = sets[0], B = sets[p]; let c = 0; for (const k of B) if (A.has(k)) c++;
    if (c < 0.5 * Math.min(A.size, B.size)) return byRevisit();
  }
  return done(pos);
}
/* trajectory through blocks b0..b1: gradient vertices (+3 subdivisions); only block starts when too many */
function kPath(seq, b0, b1, maxPts = 6e5, act = false) { // act: k + kc (seq.cc set up), otherwise the nominal k
  const kib = act ? ktInBlock : kInBlock, kS = act ? seq.cc.ktStart : seq.kStart;
  const B = seq.B, nbk = b1 - b0 + 1;
  let est = 0; for (let i = b0; i <= b1 && est <= maxPts; i++) for (const c of ['pgx', 'pgy', 'pgz']) if (B[c][i]) est += geoG(seq, B[c][i]).n * 4;
  if (est > maxPts) {
    const step = Math.max(1, Math.ceil(nbk / maxPts)), n = Math.floor(nbk / step) + 1, k = [new Float32Array(n), new Float32Array(n), new Float32Array(n)];
    let o = 0; for (let i = b0; i <= b1 && o < n; i += step, o++) for (let a = 0; a < 3; a++) k[a][o] = kS[a][i];
    return { n: o, k, coarse: true };
  }
  const K = [new GBuf(Float32Array), new GBuf(Float32Array), new GBuf(Float32Array)];
  for (let i = b0; i <= b1; i++) {
    const dur = seq.blockStart[i + 1] - seq.blockStart[i], u = [0, dur];
    for (const c of ['pgx', 'pgy', 'pgz']) if (B[c][i]) { const g = geoG(seq, B[c][i]); for (let q = 0; q < g.n; q++) u.push(g.t[q]); }
    if (B.rf[i]) u.push(rfSt(seq, B.rf[i]).center);
    u.sort((x, y) => x - y);
    const rel = [];
    for (let q = 0; q < u.length; q++) { if (q && u[q] - u[q - 1] < 1e-10) continue; if (rel.length) { const p = rel[rel.length - 1], d = u[q] - p; for (let s = 1; s < 4; s++) rel.push(p + d * s / 4); } rel.push(u[q]); }
    const R = Float64Array.from(rel), o3 = [new Float64Array(R.length), new Float64Array(R.length), new Float64Array(R.length)];
    kib(seq, i, R, o3, 0);
    for (let q = 0; q < R.length; q++) for (let a = 0; a < 3; a++) K[a].push(o3[a][q]);
  }
  const k = K.map(b => b.done());
  return { n: k[0].length, k, coarse: false };
}
function computeKspace(seq) { // full, for validation
  const s = kSamples(seq, 0, seq.adcBlocks.length, Infinity, true);
  return { tA: s.t, kA: s.k };
}

/* ---------- shots and volumes ---------- */
function computeShots(seq, mode = 'exc') {
  const nb = seq.nb, B = seq.B, use = i => B.rf[i] ? rfSt(seq, B.rf[i]).use : undefined;
  const exc = []; for (let b = 0; b < nb; b++) if (use(b) === 'e') exc.push(b);
  seq.shotMode = mode;
  if (!exc.length) return [];
  const starts = [];
  if (mode === 'prep') {
    let saw = true;
    for (let b = 0; b < nb; b++) { const u = use(b); if (u === 'e') saw = true; else if ((u === 'i' || u === 's' || u === 'p') && saw) { starts.push(b); saw = false; } }
    if (starts.length) starts[0] = 0; else return computeShots(seq, 'exc');
  } else {
    for (let k = 0; k < exc.length; k++) {
      const e = exc[k], lo = k ? exc[k - 1] + 1 : 0; let st = e;
      for (let b = e - 1; b >= lo; b--) { if (B.adc[b]) break; const u = use(b); if (u !== undefined && u !== 'r') st = b; }
      starts.push(k === 0 ? 0 : st);
    }
  }
  const shots = new Array(starts.length), AB = seq.adcBlocks;
  let j = 0;
  for (let k = 0; k < starts.length; k++) {
    const b0 = starts[k], b1 = (k + 1 < starts.length ? starts[k + 1] : nb) - 1;
    while (j < AB.length && AB[j] < b0) j++;
    const j0 = j; while (j < AB.length && AB[j] <= b1) j++;
    shots[k] = { b0, b1, t0: seq.blockStart[b0], t1: seq.blockStart[b1 + 1], j0, j1: j, nADC: j - j0, nSamples: seq.adcOff[j] - seq.adcOff[j0] };
  }
  return shots;
}
/* Volumes: groups of consecutive shots.
   mode 'auto': a new volume starts when a shot repeats the k-space sampling (up to 32 ADC samples
   spread over the shot, quantised) and the RF pulses (frequency, shape, gradients played with
   them) of a shot already seen in the current volume.
   mode 'label': a new volume starts at the shot whose ADC (any type) sees a new value of that label.
   In auto mode only imaging ADCs count; noise, reference and navigator acquisitions are ignored.
   Shots without a counted ADC directly before a boundary join the new volume. */
function computeVolumes(seq, shots, mode, label, progress) {
  if (!shots.length) return [];
  const nb = seq.nb, B = seq.B, starts = [0], AT = seq.adcType;
  // auto: only imaging ADCs count (falls back to all ADCs if none are typed as imaging); label: every ADC counts
  let isImg = j => AT[j] === 0 || AT[j] === 2;
  if (mode !== 'auto' || !AT.some((t, j) => isImg(j))) isImg = () => true;
  const nImg = shots.map(sh => { let c = 0; for (let j = sh.j0; j < sh.j1; j++) if (isImg(j)) c++; return c; });
  const pushStart = k => { const last = starts[starts.length - 1]; let j = k; while (j - 1 > last && !nImg[j - 1]) j--; if (j > last) starts.push(j); };
  if (mode === 'auto') {
    let kmax = 0; for (let a = 0; a < 3; a++) for (const v of seq.kStart[a]) if (Math.abs(v) > kmax) kmax = Math.abs(v);
    const q = kmax > 0 ? kmax * 1e-3 : 1e-3;
    // 2 x 32-bit hashes (FNV-1a style) over integers; a collision needs both to match
    const H = new Int32Array(2);
    const mix = x => { x = x | 0; H[0] = Math.imul(H[0] ^ x, 16777619); const h = H[1]; H[1] = Math.imul(h ^ (x + 0x9e3779b9), 2246822519) ^ (h >>> 13); };
    const adcDefs = []; const adcDef = id => adcDefs[id] || (adcDefs[id] = seq.adc.get(id));
    let seen = new Set(); const rel = new Float64Array(64), o3 = [new Float64Array(64), new Float64Array(64), new Float64Array(64)];
    for (let k = 0; k < shots.length; k++) {
      if (progress && (k & 16383) === 0) progress(k / shots.length);
      const sh = shots[k]; if (!nImg[k]) continue;
      H[0] = 2166136261 | 0; H[1] = 0x811c9dc5 ^ 0x5bd1e995;
      for (let b = sh.b0; b <= sh.b1; b++) if (B.rf[b]) { const r = seq.rf.get(B.rf[b]); if (r) { mix(Math.round(r.freq)); mix(Math.round((r.freqPPM || 0) * 1000)); mix(r.magId); mix(r.timeId || 0); mix(B.pgx[b]); mix(B.pgy[b]); mix(B.pgz[b]); } }
      let n = 0; for (let j = sh.j0; j < sh.j1; j++) if (isImg(j)) n += seq.adcOff[j + 1] - seq.adcOff[j];
      const st = Math.max(1, Math.floor(n / 32)); mix(n);
      let c = 0;
      for (let j = sh.j0; j < sh.j1; j++) {
        if (!isImg(j)) continue;
        const bb = seq.adcBlocks[j], d = adcDef(B.adc[bb]); let m = 0;
        for (let s = 0; s < d.num; s++, c++) if (c % st === 0 && m < 64) rel[m++] = d.delay + (s + 0.5) * d.dwell;
        if (!m) continue;
        kInBlock(seq, bb, rel, o3, 0, m);
        for (let s = 0; s < m; s++) { mix(Math.round(o3[0][s] / q)); mix(Math.round(o3[1][s] / q)); mix(Math.round(o3[2][s] / q)); }
      }
      const fp = (H[0] & 0x1fffff) * 4294967296 + (H[1] >>> 0); // 53-bit key
      if (seen.has(fp)) { pushStart(k); seen = new Set([fp]); } else seen.add(fp);
    }
  } else {
    // every shot has a label value: at its first ADC, or (no ADC, e.g. a dummy scan) at its excitation,
    // i.e. after the label updates that precede or accompany it; a new volume starts where the value changes
    const tr = seq.labels.find(x => x.name === label); if (!tr) return [];
    const valueAt = b => { let lo = 0, hi = tr.b.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (tr.b[m] <= b) lo = m; else hi = m - 1; } return tr.b[lo] <= b ? tr.v[lo] : 0; };
    // a shot without a readout (dummy scan) is read where its readout would have been: its excitation plus the
    // typical excitation-to-first-ADC time of the shots that have one (labels are often set after the excitation)
    const excOf = sh => { for (let q = sh.b0; q <= sh.b1; q++) if (B.rf[q] && rfSt(seq, B.rf[q]).use === 'e') return q; return -1; };
    const offs = [];
    for (const sh of shots) if (sh.j1 > sh.j0) { const e = excOf(sh); if (e >= 0) offs.push(seq.blockStart[seq.adcBlocks[sh.j0]] - seq.blockStart[e]); }
    offs.sort((a, b) => a - b); const off = offs.length ? offs[offs.length >> 1] : null;
    let prev = null;
    for (let k = 0; k < shots.length; k++) {
      const sh = shots[k]; let b = -1;
      if (sh.j1 > sh.j0) b = seq.adcBlocks[sh.j0];
      else {
        const e = excOf(sh);
        if (e >= 0 && off !== null) { b = blockAtTime(seq, Math.min(seq.blockStart[e] + off, seq.blockStart[sh.b1 + 1] - 1e-12)); b = Math.max(sh.b0, Math.min(sh.b1, b)); }
        else b = e >= 0 ? e : sh.b1;
      }
      const v = valueAt(b); if (prev !== null && v !== prev && k > starts[starts.length - 1]) starts.push(k); prev = v;
    }
  }
  const vols = [];
  for (let i = 0; i < starts.length; i++) {
    const s0 = starts[i], s1 = (i + 1 < starts.length ? starts[i + 1] : shots.length) - 1;
    const b0 = i === 0 ? 0 : shots[s0].b0, b1 = i + 1 < starts.length ? shots[s1].b1 : nb - 1;
    let nS = 0, nA = 0; for (let k = s0; k <= s1; k++) { nS += shots[k].nSamples; if (shots[k].nADC) nA++; }
    vols.push({ s0, s1, b0, b1, t0: seq.blockStart[b0], t1: seq.blockStart[b1 + 1], nShots: s1 - s0 + 1, nAcqShots: nA, nSamples: nS });
  }
  return vols;
}

/* ---------- MD5 (RFC 1321), streaming over a Uint8Array ---------- */
function md5(bytes) {
  const K = new Int32Array(64), S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) | 0;
  let a0 = 0x67452301, b0 = 0xefcdab89 | 0, c0 = 0x98badcfe | 0, d0 = 0x10325476;
  const W = new Int32Array(16);
  const blk = (src, o) => {
    for (let i = 0; i < 16; i++) W[i] = src[o + 4 * i] | (src[o + 4 * i + 1] << 8) | (src[o + 4 * i + 2] << 16) | (src[o + 4 * i + 3] << 24);
    let A = a0, B = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      const tmp = D; D = C; C = B; const x = (A + F + K[i] + W[g]) | 0, sh = S[(i >> 4) * 4 + (i % 4)];
      B = (B + ((x << sh) | (x >>> (32 - sh)))) | 0; A = tmp;
    }
    a0 = (a0 + A) | 0; b0 = (b0 + B) | 0; c0 = (c0 + C) | 0; d0 = (d0 + D) | 0;
  };
  const len = bytes.length, full = len - (len % 64);
  for (let o = 0; o < full; o += 64) blk(bytes, o);
  const rest = len - full, tail = new Uint8Array(rest + 8 < 64 ? 64 : 128);
  tail.set(bytes.subarray(full)); tail[rest] = 0x80;
  const bits = len * 8, L = tail.length;
  for (let i = 0; i < 4; i++) tail[L - 8 + i] = (bits >>> (8 * i)) & 255;
  const hi = Math.floor(len / 536870912); for (let i = 0; i < 4; i++) tail[L - 4 + i] = (hi >>> (8 * i)) & 255;
  for (let o = 0; o < L; o += 64) blk(tail, o);
  let hex = ''; for (const v of [a0, b0, c0, d0]) for (let i = 0; i < 4; i++) hex += ((v >>> (i * 8)) & 255).toString(16).padStart(2, '0');
  return hex;
}
/* md5 of the file up to its [SIGNATURE] section (null if there is none); independent of parsing, so it can run
   in parallel with it */
function signatureHash(bytes) {
  if (isPulseqBinary(bytes)) { const q = binarySignatureStart(bytes); return q < 0 ? null : md5(bytes.subarray(0, q)); }
  const m = new TextEncoder().encode('\n[SIGNATURE]'); let idx = -1, from = 0;
  while (true) {
    const p = bytes.indexOf(10, from); if (p < 0) break;
    let ok = true; for (let k = 1; k < m.length; k++) if (bytes[p + k] !== m[k]) { ok = false; break; }
    if (ok) { idx = p + 1; break; } from = p + 1;
  }
  if (idx < 0) return null;
  let end = idx; if (end > 0 && bytes[end - 1] === 10) end--; if (end > 0 && bytes[end - 1] === 13) end--;
  return md5(bytes.subarray(0, end));
}
function signatureStatus(seq, h) {
  if (!seq.signature || !seq.signature.hash) return { status: 'none' };
  if (!/md5/i.test(seq.signature.type || '')) return { status: 'unsupported', type: seq.signature.type };
  if (h == null) return { status: 'none' };
  return { status: h === seq.signature.hash.toLowerCase() ? 'ok' : 'mismatch', hash: h };
}
function verifySignature(bytes, seq) {
  if (!seq.signature || !seq.signature.hash) return { status: 'none' };
  if (!/md5/i.test(seq.signature.type || '')) return { status: 'unsupported', type: seq.signature.type };
  if (seq.binary) return signatureStatus(seq, signatureHash(bytes));
  const m = new TextEncoder().encode('\n[SIGNATURE]'); let idx = -1, from = 0;
  while (true) {
    const p = bytes.indexOf(10, from); if (p < 0) break;
    let ok = true; for (let k = 1; k < m.length; k++) if (bytes[p + k] !== m[k]) { ok = false; break; }
    if (ok) { idx = p + 1; break; } from = p + 1;
  }
  if (idx < 0) return { status: 'none' };
  let end = idx; if (end > 0 && bytes[end - 1] === 10) end--; if (end > 0 && bytes[end - 1] === 13) end--;
  const h = md5(bytes.subarray(0, end));
  return { status: h === seq.signature.hash.toLowerCase() ? 'ok' : 'mismatch', hash: h };
}

/* ---------- full load (used by the worker and as main-thread fallback) ---------- */
function loadSeq(bytes, progress, skipSignature) {
  const T = [Date.now()];
  const seq = parseSeq(bytes, progress); T.push(Date.now());
  if (!seq.nb) throw new Error('The [BLOCKS] section is empty or missing.');
  analyze(seq, progress); T.push(Date.now());
  if (!skipSignature) seq.sig = verifySignature(bytes, seq);
  seq.loadTimes = { parse: T[1] - T[0], analyze: T[2] - T[1] };
  return seq;
}

/* shots as typed columns: an array of ~10⁶ small objects is slow to copy between threads, typed arrays are
   transferred for free and the objects are rebuilt on the other side */
const SHOT_FIELDS = ['b0', 'b1', 't0', 't1', 'j0', 'j1', 'nADC', 'nSamples'];
function packShots(shots) { const n = shots.length, o = {}; for (const f of SHOT_FIELDS) { const a = new Float64Array(n); for (let i = 0; i < n; i++) a[i] = shots[i][f]; o[f] = a; } o.n = n; return o; }
function unpackShots(p) { const out = new Array(p.n); for (let i = 0; i < p.n; i++) { const s = {}; for (const f of SHOT_FIELDS) s[f] = p[f][i]; out[i] = s; } return out; }
/* all ArrayBuffers inside an object graph (for transferring a loaded sequence out of a worker) */
function transferList(root) {
  const bufs = new Set(), seen = new Set(), stack = [root];
  while (stack.length) {
    const o = stack.pop(); if (!o || typeof o !== 'object') continue;
    if (ArrayBuffer.isView(o)) { bufs.add(o.buffer); continue; }
    if (seen.has(o)) continue; seen.add(o);
    if (o instanceof Map) { for (const v of o.values()) stack.push(v); continue; }
    if (Array.isArray(o)) { if (o.length && typeof o[0] !== 'object') continue; for (const v of o) stack.push(v); continue; }
    for (const k in o) stack.push(o[k]);
  }
  return [...bufs];
}
if (typeof module !== 'undefined' && module.exports) module.exports = { packShots, unpackShots, signatureHash, signatureStatus, quatToMat, rotationOfBlock, applyRotations, rangeSummary, adcRangeType, transferList, GAMMA, parseSeq, analyze, loadSeq, gradTimes, rfStats, rfSt, geoG, geoSlew, geoRfm, geoRfp, geoRfRe, geoRfIm, buildPyramid, CHANNELS, blockSummary, blockVertices, channelValue, blockAtTime, blockObj, extChain, labelNames, computeShots, computeVolumes, kSamples, kPath, kInBlock, adcEchoes, revisitEchoes, computeKspace, md5, verifySignature, trigName, trigText, TRIG_TYPES, LABEL_FLAGS, M0_KEYS, m0Block, m0EventExt, m0Summary, m0Vertices, m0Value, m0Pyramids, m0Active,
  KINT, KP_M0, KP_KC, kintBlock, kintSummary, kintVertices, kintValue, kintPyramids, CC_DEF, ccEval, ccCombos, ccState, ccGeo, ccPartial, kcInBlock, ccExt, ccValue, ccSlicePos, ccPosOf, KP_KT, ktGeo, ktInBlock, ktExt,
  MX_IJ, KP_MU, mxGeo, mxPartial, mxState, muInBlock };


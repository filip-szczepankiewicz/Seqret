#!/usr/bin/env python3
"""Segmented gradient-echo EPI for Seqret's Group segments (1.49.0): 2 slices, k-space read out in 3 interleaved
segments, 96 x 96, FOV 240 mm, TE 25 ms, 250 ms per shot (1.5 s in all).

Shot order (interleaved multi-slice): seg 0 slc 0, seg 0 slc 1, seg 1 slc 0, seg 1 slc 1, seg 2 slc 0, seg 2 slc 1.
Segment s acquires ky lines s, s+3, s+6, ... (blip = 3 dky). Labels: SLC and SEG set per shot, LIN per readout.
Written with PyPulseq 1.5 (pip install pypulseq):  python3 tools/write_epi_seg3.py [out.seq]
(default tests/data/epi_seg3_2slc.seq). Every ky line is read once over the three segments.
"""
from sys import argv
import numpy as np
import pypulseq as pp

sys = pp.Opts(max_grad=32, grad_unit='mT/m', max_slew=130, slew_unit='T/m/s',
              rf_ringdown_time=30e-6, rf_dead_time=100e-6, adc_dead_time=10e-6, B0=3)
seq = pp.Sequence(sys)

fov, Nx, Ny = 240e-3, 96, 96
nSeg, nSlc = 3, 2
thk, gap = 5e-3, 5e-3
TR_shot = 250e-3          # time from one excitation to the next (any slice)
TE = 25e-3

dk = 1 / fov
rf, gz, gzr = pp.make_sinc_pulse(flip_angle=np.pi / 2, duration=2e-3, slice_thickness=thk, apodization=0.5,
                                 time_bw_product=4, system=sys, return_gz=True, use='excitation')

dwell = 5e-6
ro_time = Nx * dwell
gx = pp.make_trapezoid('x', flat_area=Nx * dk, flat_time=ro_time, system=sys)
adc = pp.make_adc(Nx, duration=ro_time, delay=gx.rise_time, system=sys)
gxpre = pp.make_trapezoid('x', area=-gx.area / 2, system=sys)
blip = pp.make_trapezoid('y', area=nSeg * dk, system=sys)
r2 = 2 * sys.grad_raster_time
blip = pp.make_trapezoid('y', area=nSeg * dk, duration=np.ceil(pp.calc_duration(blip) / r2 - 1e-9) * r2, system=sys)
blip_dur = pp.calc_duration(blip)
# put the blip across the ramps between readouts: split it in two halves
blip_h1, blip_h2 = pp.split_gradient_at(blip, blip_dur / 2, sys)
blip_h1.delay = pp.calc_duration(gx) - blip_dur / 2
blip_h2.delay = 0
blip_up_down = pp.add_gradients([blip_h2, blip_h1], system=sys)  # end of one readout + start of the next
nLin = Ny // nSeg
spoil = pp.make_trapezoid('z', area=4 * Nx * dk, system=sys)

slc_off = (np.arange(nSlc) - (nSlc - 1) / 2) * (thk + gap)

t_prev = 0.0
for s in range(nSeg):
    for sl in range(nSlc):
        rf.freq_offset = gz.amplitude * slc_off[sl]
        rf.phase_offset = -2 * np.pi * rf.freq_offset * pp.calc_rf_center(rf)[0]
        seq.add_block(rf, gz, pp.make_label(type='SET', label='SLC', value=sl),
                      pp.make_label(type='SET', label='SEG', value=s))
        ky0 = (-Ny / 2 + s) * dk  # first line of this segment
        gypre = pp.make_trapezoid('y', area=ky0, duration=pp.calc_duration(gxpre, gzr), system=sys)
        # echo time at the readout nearest ky = 0
        k_centre = int(round((Ny / 2 - s) / nSeg))
        t_ex = pp.calc_duration(rf, gz) - (rf.delay + pp.calc_rf_center(rf)[0])
        t_c = t_ex + pp.calc_duration(gxpre, gzr) + k_centre * pp.calc_duration(gx) + pp.calc_duration(gx) / 2
        dTE = np.round((TE - t_c) / sys.grad_raster_time) * sys.grad_raster_time
        assert dTE >= 0, dTE
        if dTE > 0:
            seq.add_block(pp.make_delay(dTE))
        seq.add_block(gxpre, gypre, gzr)
        for i in range(nLin):
            gx_i = pp.scale_grad(gx, (-1) ** i)
            parts = [gx_i, adc, pp.make_label(type='SET', label='LIN', value=s + i * nSeg)]
            parts.append(blip_h1 if i == 0 else blip_h2 if i == nLin - 1 else blip_up_down)
            seq.add_block(*parts)
        seq.add_block(spoil)
        t_now = seq.duration()[0]
        fill = TR_shot - (t_now - t_prev)
        fill = np.round(fill / sys.block_duration_raster) * sys.block_duration_raster
        assert fill > 0
        seq.add_block(pp.make_delay(fill))
        t_prev = seq.duration()[0]

ok, err = seq.check_timing()
print('timing ok' if ok else err[:5])
seq.set_definition('FOV', [fov, fov, thk])
seq.set_definition('Name', 'epi_seg3')
seq.write(argv[1] if len(argv) > 1 else 'tests/data/epi_seg3_2slc.seq')
print('duration', seq.duration()[0])

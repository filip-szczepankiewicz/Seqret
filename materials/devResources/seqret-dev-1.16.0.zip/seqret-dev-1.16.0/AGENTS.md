# Instructions for LLM coding assistants working on Seqret

Read DEVELOPMENT.md before changing anything. It explains the architecture, the performance rules and the
validation behind the current code. What follows are the working rules in short.

## Setup and every iteration
- Build with `python3 build.py`, which writes `dist/seqret.html`. Test with `node tests/test_core.mjs` and
  `python3 tests/test_browser.py`. Run all three after every change, and hand the person the built page.
- Work in small iterations: one feature or fix, then tests, then the person's review in their own browser.
  Don't stack unreviewed changes.
- Edit `src/` and `version.json`, never `dist/` by hand. Every release bumps the version and adds a
  user-facing changelog entry at the top of `version.json` (DEVELOPMENT.md section 10).

## Hard constraints
- Keep Seqret one self-contained HTML file: no libraries, CDNs, web fonts or network requests. It must work
  offline from disk.
- `core.js`, `sim.js` and `stim.js` also run inside web workers and in Node. Never touch the DOM there; code
  that needs the page belongs in `ui.js`.
- Never expand the whole timeline into per-sample arrays. Work from the typed block columns, the per-event
  geometry cache and the min/max pyramids, and compute only for the visible range.
- Keep the interface responsive: heavy work goes to workers, or yields to the browser and can be cancelled.

## Correctness
- Check every physics change against an independent reference (PyPulseq, safe_pns_prediction in Octave, or
  the exact slow methods in sim.js) and report the agreement as a number. The conventions to follow are
  listed in DEVELOPMENT.md section 3.
- Reproduce bugs with the person's file first, then turn them into a test. Use a generated or reduced
  sequence; never commit third-party `.seq` files.
- Any approximation must be stated in the UI. An unstated approximation is a bug.

## Performance
- Diagram: draw per pixel column from summaries, paint dense traces as spans, batch canvas calls into one
  `Path2D` per style, choose the resolution from the view rather than from timing, and redraw once per
  animation frame, only when something changed.
- Simulation: split the work into `SIM_TASKS` for the worker pool and the WebGL2 path, keep the CPU fallback
  within one grey level of the GPU, and be exact near singular features and fast elsewhere. Every fast
  method needs an exact reference with a stated error.
- Measure drawing only in a real, GPU-accelerated browser, with the Shift+D frame-time panel. Headless
  timings are software rendering and misleading; 1.14.0 was tuned that way and had to be reverted.
- Before and after any performance change, test with large files made by `tools/` (DEVELOPMENT.md
  section 8). Don't add such files to the package.

## Collaboration
- The person designs and decides; you implement. Offer options when a choice is open, but don't add
  unrequested features or settings.
- If something looks or runs worse in the person's real use, revert first and analyse afterwards.
- Keep DEVELOPMENT.md up to date, including section 12 (known issues).

#!/usr/bin/env python3
"""Browser smoke test of the built page (Playwright, Chromium):

    pip install playwright && python -m playwright install chromium
    python3 tests/test_browser.py [dist/seqret.html] [--seq file.seq ...] [--shots DIR]

Loads the demo (or the given files), visits every tab, zooms and pans the diagram, waits for the k-space and
the simulated image, and fails on any page error or console error. With --shots, saves screenshots to DIR.

Do NOT use the frame times measured here to tune drawing performance: headless Chromium renders in software,
which is slow in different places than a GPU-accelerated browser. Use the frame-time panel (Shift+D) in a
normal browser for that. This test is for correctness only.
"""
import sys, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
args = sys.argv[1:]
page_file = pathlib.Path(args[0]) if args and not args[0].startswith('--') else ROOT / 'dist' / 'seqret.html'
seqs = []
if '--seq' in args:
    i = args.index('--seq') + 1
    while i < len(args) and not args[i].startswith('--'):
        seqs.append(pathlib.Path(args[i]).resolve()); i += 1
shots = pathlib.Path(args[args.index('--shots') + 1]) if '--shots' in args else None
if shots: shots.mkdir(parents=True, exist_ok=True)

errors = []
IDLE = "() => document.querySelector('#fname').textContent.trim() !== '' && !document.querySelector('#busy').classList.contains('on')"

def check(page, label):
    page.wait_for_function(IDLE, timeout=180000)
    page.wait_for_timeout(300)
    box = page.locator('#plot').bounding_box()
    page.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
    for _ in range(6): page.mouse.wheel(0, -300); page.wait_for_timeout(50)   # zoom in
    page.mouse.down(button='right'); page.mouse.move(box['x'] + box['width'] / 3, box['y'] + box['height'] / 2); page.mouse.up(button='right')  # pan
    for _ in range(6): page.mouse.wheel(0, 300); page.wait_for_timeout(50)    # zoom out
    if shots: page.screenshot(path=str(shots / f'{label}_diagram.png'))
    for tab in ['seq', 'blk', 'k', 'img', 'defs']:
        page.click(f'.tab[data-tab="{tab}"]')
        if tab == 'k':
            page.wait_for_function("() => document.querySelector('#kInfo').textContent.trim() !== ''", timeout=60000)
        if tab == 'img':
            page.wait_for_function("() => document.querySelector('#imInfo').textContent.trim() !== '' && !document.querySelector('#imBusy').classList.contains('on')", timeout=300000)
            print(f'  image: {page.inner_text("#imInfo")[:160]!r}')
        page.wait_for_timeout(200)
        if shots: page.screenshot(path=str(shots / f'{label}_{tab}.png'))
    print(f'  loaded as: {page.inner_text("#fname")} {page.inner_text("#fmeta")}')

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={'width': 1440, 'height': 900})
    page.on('pageerror', lambda e: errors.append(f'page error: {e}'))
    page.on('console', lambda m: errors.append(f'console {m.type}: {m.text}') if m.type == 'error' else None)
    page.goto(page_file.resolve().as_uri())
    print('demo'); page.click('#demoBtn'); check(page, 'demo')
    for f in seqs:
        print(f.name); page.set_input_files('#fileIn', str(f)); check(page, f.stem)
    browser.close()

for e in errors: print('FAIL', e)
print('browser smoke test ' + ('FAILED' if errors else 'passed'))
sys.exit(1 if errors else 0)

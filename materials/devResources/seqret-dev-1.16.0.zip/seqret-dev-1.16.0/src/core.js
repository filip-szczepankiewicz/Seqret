/* ===== Seqret core (v2): memory-lean Pulseq model =====
   Nothing is expanded over the whole timeline. The block table is kept as typed columns,
   event geometry is derived once per unique event, and everything else (drawing, values,
   k-space) is computed from those on demand. */
const GAMMA = 42.57638474e6; // Hz/T (1H)

function decompressShape(packed, numSamples) {
  if (packed.length === numSamples) return Float32Array.from(packed);
  const w = new Float64Array(numSamples);
  let cp = 0, cu = 0; const L = packed.length;
  while (cp < L - 1) {
    if (packed[cp] !== packed[cp + 1]) { w[cu++] = packed[cp++]; }
    else { const rep = Math.round(packed[cp + 2]) + 2, v = packed[cp]; for (let k = 0; k < rep && cu < numSamples; k++) w[cu++] = v; cp += 3; }
  }
  if (cp === L - 1 && cu < numSamples) w[cu++] = packed[cp];
  for (let i = 1; i < numSamples; i++) w[i] += w[i - 1];
  return Float32Array.from(w);
}

/* ---------- parser (works on bytes; [BLOCKS] parsed without creating strings) ---------- */
function parseSeq(input, progress) {
  const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : input;
  const N = bytes.length, warnings = [];
  const seq = {
    version: { major: 1, minor: 4, revision: 0 }, defs: {}, defOrder: [],
    rf: new Map(), grad: new Map(), adc: new Map(), delays: new Map(), shapes: new Map(),
    extList: new Map(), extTypes: new Map(), extSpecs: new Map(), signature: null, warnings
  };
  let cap = 1 << 15, nb = 0;
  let C = Array.from({ length: 8 }, (_, k) => k === 1 ? new Float64Array(cap) : new Uint32Array(cap));
  const grow = () => { cap *= 2; C = C.map(a => { const b = new a.constructor(cap); b.set(a); return b; }); };
  let section = '', curShape = null, curExt = null, pos = 0, nextProg = 0;
  const flushShape = () => { if (curShape) { seq.shapes.set(curShape.id, decompressShape(curShape.data, curShape.num == null ? curShape.data.length : curShape.num)); curShape = null; } };
  const lineStr = (a, b) => b - a > 8192 ? new TextDecoder().decode(bytes.subarray(a, b)) : String.fromCharCode.apply(null, bytes.subarray(a, b));
  while (pos < N) {
    let e = bytes.indexOf(10, pos); if (e < 0) e = N;
    let a = pos, b = e; pos = e + 1;
    if (progress && a >= nextProg) { progress(0.45 * a / N); nextProg = a + 4e6; }
    while (a < b && (bytes[a] === 32 || bytes[a] === 9 || bytes[a] === 13)) a++;
    if (a >= b || bytes[a] === 35) continue; // empty or comment
    if (bytes[a] === 91) { // '['
      flushShape(); curExt = null;
      const s = lineStr(a, b); section = s.slice(1, s.indexOf(']')).trim().toUpperCase(); continue;
    }
    if (section === 'BLOCKS') {
      if (nb === cap) grow();
      let col = 0, val = 0, inNum = false;
      for (let i = a; i < b; i++) {
        const c = bytes[i];
        if (c >= 48 && c <= 57) { val = val * 10 + (c - 48); inNum = true; }
        else if (c === 35) break;
        else if (inNum) { if (col < 8) C[col][nb] = val; col++; val = 0; inNum = false; }
      }
      if (inNum && col < 8) { C[col][nb] = val; col++; }
      for (; col < 8; col++) C[col][nb] = 0;
      nb++; continue;
    }
    if (section === 'SHAPES' && curShape) { // fast path: one plain number per line
      const x = parseNum(bytes, a, b);
      if (x === x) { curShape.data.push(x); continue; }
    }
    let line = lineStr(a, b); const h = line.indexOf('#'); if (h >= 0) line = line.slice(0, h);
    line = line.trim(); if (!line) continue;
    if (section === 'SHAPES') {
      const c0 = line.charCodeAt(0);
      if ((c0 >= 48 && c0 <= 57) || c0 === 45 || c0 === 46 || c0 === 43) { if (curShape) { if (line.indexOf(' ') < 0 && line.indexOf('\t') < 0) curShape.data.push(+line); else for (const t of line.split(/\s+/)) curShape.data.push(+t); } continue; }
      const tok = line.split(/\s+/);
      if (tok[0] === 'shape_id') { flushShape(); curShape = { id: +tok[1], num: null, data: [] }; }
      else if (tok[0] === 'num_samples') { if (curShape) curShape.num = +tok[1]; }
      continue;
    }
    const tok = line.split(/\s+/);
    switch (section) {
      case 'VERSION': if (tok[0] in seq.version) seq.version[tok[0]] = parseInt(tok[1], 10); break;
      case 'DEFINITIONS': {
        const key = tok[0], rest = tok.slice(1), nums = rest.map(Number);
        seq.defs[key] = rest.length && nums.every(n => !isNaN(n)) ? (nums.length === 1 ? nums[0] : nums) : rest.join(' ');
        seq.defOrder.push(key); break;
      }
      case 'RF': {
        const n = tok.map(Number); let r;
        if (tok.length >= 12) r = { id: n[0], amp: n[1], magId: n[2], phaseId: n[3], timeId: n[4], center: n[5] * 1e-6, delay: n[6] * 1e-6, freqPPM: n[7], phasePPM: n[8], freq: n[9], phase: n[10], use: tok[11] };
        else if (tok.length === 8) r = { id: n[0], amp: n[1], magId: n[2], phaseId: n[3], timeId: n[4], delay: n[5] * 1e-6, freq: n[6], phase: n[7] };
        else if (tok.length === 7) r = { id: n[0], amp: n[1], magId: n[2], phaseId: n[3], timeId: 0, delay: n[4] * 1e-6, freq: n[5], phase: n[6] };
        else { warnings.push(`Unrecognized RF line: "${line}"`); break; }
        seq.rf.set(r.id, r); break;
      }
      case 'GRADIENTS': {
        const n = tok.map(Number); let g;
        if (tok.length >= 7) g = { type: 'arb', id: n[0], amp: n[1], first: n[2], last: n[3], shapeId: n[4], timeId: n[5], delay: n[6] * 1e-6 };
        else if (tok.length === 5) g = { type: 'arb', id: n[0], amp: n[1], shapeId: n[2], timeId: n[3], delay: n[4] * 1e-6 };
        else if (tok.length === 4) g = { type: 'arb', id: n[0], amp: n[1], shapeId: n[2], timeId: 0, delay: n[3] * 1e-6 };
        else { warnings.push(`Unrecognized gradient line: "${line}"`); break; }
        seq.grad.set(g.id, g); break;
      }
      case 'TRAP': { const n = tok.map(Number); seq.grad.set(n[0], { type: 'trap', id: n[0], amp: n[1], rise: n[2] * 1e-6, flat: n[3] * 1e-6, fall: n[4] * 1e-6, delay: (n[5] || 0) * 1e-6 }); break; }
      case 'ADC': {
        const n = tok.map(Number); let d;
        if (tok.length >= 9) d = { id: n[0], num: n[1], dwell: n[2] * 1e-9, delay: n[3] * 1e-6, freqPPM: n[4], phasePPM: n[5], freq: n[6], phase: n[7], phaseId: n[8] };
        else d = { id: n[0], num: n[1], dwell: n[2] * 1e-9, delay: n[3] * 1e-6, freq: n[4] || 0, phase: n[5] || 0 };
        seq.adc.set(d.id, d); break;
      }
      case 'DELAYS': seq.delays.set(+tok[0], +tok[1] * 1e-6); break;
      case 'EXTENSIONS':
        if (tok[0] === 'extension') { curExt = +tok[2]; seq.extTypes.set(curExt, tok[1]); seq.extSpecs.set(curExt, new Map()); }
        else if (curExt == null) { const n = tok.map(Number); seq.extList.set(n[0], { type: n[1], ref: n[2], next: n[3] }); }
        else seq.extSpecs.get(curExt).set(+tok[0], tok.slice(1));
        break;
      case 'SIGNATURE':
        if (!seq.signature) seq.signature = {};
        if (/^type$/i.test(tok[0])) seq.signature.type = tok[1];
        if (/^hash$/i.test(tok[0])) seq.signature.hash = tok[1];
        break;
    }
  }
  flushShape();
  // compact the block columns (ids to the smallest integer type that fits)
  const cols = {};
  ['id', '_d', 'rf', 'gx', 'gy', 'gz', 'adc', 'ext'].forEach((k, j) => {
    const src = C[j].subarray(0, nb);
    if (k === '_d') { cols[k] = src.slice(); return; }
    let mx = 0; for (let i = 0; i < nb; i++) if (src[i] > mx) mx = src[i];
    cols[k] = mx < 256 && k !== 'id' ? Uint8Array.from(src) : mx < 65536 ? Uint16Array.from(src) : src.slice();
  });
  seq.nb = nb; seq.B = cols;
  finalizeTiming(seq);
  return seq;
}

const P10 = Array.from({ length: 40 }, (_, i) => Math.pow(10, i));
/* decimal number from bytes[a..b) (trailing spaces allowed); NaN if not a single plain number */
function parseNum(bytes, a, b) {
  while (b > a && (bytes[b - 1] === 32 || bytes[b - 1] === 9 || bytes[b - 1] === 13)) b--;
  let i = a, neg = false, m = 0, e = 0, nd = 0;
  if (bytes[i] === 45) { neg = true; i++; } else if (bytes[i] === 43) i++;
  for (; i < b; i++) { const c = bytes[i] - 48; if (c < 0 || c > 9) break; m = m * 10 + c; nd++; }
  if (i < b && bytes[i] === 46) { i++; for (; i < b; i++) { const c = bytes[i] - 48; if (c < 0 || c > 9) break; m = m * 10 + c; e--; nd++; } }
  if (!nd || nd > 15) return NaN;
  if (i < b && (bytes[i] === 101 || bytes[i] === 69)) {
    i++; let en = false, x = 0, ne = 0; if (bytes[i] === 45) { en = true; i++; } else if (bytes[i] === 43) i++;
    for (; i < b; i++) { const c = bytes[i] - 48; if (c < 0 || c > 9) break; x = x * 10 + c; ne++; }
    if (!ne) return NaN; e += en ? -x : x;
  }
  if (i !== b || e < -39 || e > 39) return NaN;
  const v = e < 0 ? m / P10[-e] : m * P10[e];
  return neg ? -v : v;
}
function numDef(seq, k, d) { const v = seq.defs[k]; return typeof v === 'number' ? v : d; }

function finalizeTiming(seq) {
  const V = seq.version; seq.verNum = V.major * 1000000 + V.minor * 1000 + V.revision;
  seq.raster = { grad: numDef(seq, 'GradientRasterTime', 10e-6), rf: numDef(seq, 'RadiofrequencyRasterTime', 1e-6), adc: numDef(seq, 'AdcRasterTime', 100e-9), block: numDef(seq, 'BlockDurationRaster', 10e-6) };
  seq.geo = { g: [], rfm: [], rfp: [], sl: [], ss: [], rfs: [], endrf: [], endg: [], endadc: [] }; // indexed by event id
  const nb = seq.nb, B = seq.B, bs = new Float64Array(nb + 1);
  if (seq.verNum >= 1004000) {
    let ticks = 0; const r = seq.raster.block;
    for (let i = 0; i < nb; i++) { bs[i] = ticks * r; ticks += B._d[i]; }
    bs[nb] = ticks * r;
  } else {
    let t = 0;
    for (let i = 0; i < nb; i++) { bs[i] = t; t += Math.max(blockEventEnd(seq, i), seq.delays.get(B._d[i]) || 0); }
    bs[nb] = t;
  }
  seq.blockStart = bs; seq.totalDur = bs[nb];
}

/* ---------- per-event geometry (cached per unique event id) ---------- */
function gradTimes(seq, g) {
  const gr = seq.raster.grad;
  if (g.type === 'trap') {
    const d = g.delay, t = [d, d + g.rise], v = [0, g.amp];
    if (g.flat > 0) { t.push(d + g.rise + g.flat); v.push(g.amp); }
    t.push(d + g.rise + g.flat + g.fall); v.push(0);
    return { t, v };
  }
  const w = seq.shapes.get(g.shapeId);
  if (!w) { seq.warnings.push(`Missing gradient shape ${g.shapeId}`); return { t: [g.delay], v: [0] }; }
  const N = w.length, t = [], v = [];
  if (g.timeId > 0) { const ts = seq.shapes.get(g.timeId); for (let i = 0; i < N; i++) { t.push(g.delay + ts[i] * gr); v.push(g.amp * w[i]); } return { t, v }; }
  const over = g.timeId === -1, step = over ? gr / 2 : gr, off = gr / 2, tEnd = over ? (N + 1) / 2 * gr : N * gr;
  let first = g.first, last = g.last;
  if (first === undefined) { // v1.4 and older: extrapolate half a raster step
    first = N > 1 ? g.amp * (1.5 * w[0] - 0.5 * w[1]) : g.amp * w[0];
    last = N > 1 ? g.amp * (1.5 * w[N - 1] - 0.5 * w[N - 2]) : g.amp * w[N - 1];
    const tol = 1e-3 * Math.abs(g.amp); if (Math.abs(first) < tol) first = 0; if (Math.abs(last) < tol) last = 0;
  }
  t.push(g.delay); v.push(first);
  for (let i = 0; i < N; i++) { t.push(g.delay + off + i * step); v.push(g.amp * w[i]); }
  t.push(g.delay + tEnd); v.push(last);
  return { t, v };
}
function geoFinish(t, v) {
  let mn = Infinity, mx = -Infinity, area = 0;
  for (let i = 0; i < v.length; i++) { const x = v[i]; if (x === x) { if (x < mn) mn = x; if (x > mx) mx = x; } if (i) area += 0.5 * (v[i] + v[i - 1]) * (t[i] - t[i - 1]); }
  return { t: Float64Array.from(t), v: Float32Array.from(v), n: t.length, min: mn === Infinity ? 0 : mn, max: mx === -Infinity ? 0 : mx, area: area === area ? area : 0 };
}
function geoG(seq, id) {
  let o = seq.geo.g[id]; if (o) return o;
  const g = seq.grad.get(id);
  if (!g) { seq.warnings.push(`Missing gradient ${id}`); o = geoFinish([0], [0]); }
  else { const r = gradTimes(seq, g); o = geoFinish(r.t, r.v); }
  seq.geo.g[id] = o; return o;
}
function geoSlew(seq, id) {
  let o = seq.geo.sl[id]; if (o) return o;
  const g = geoG(seq, id), t = [], v = [];
  for (let j = 1; j < g.n; j++) { const dt = g.t[j] - g.t[j - 1]; if (dt <= 1e-12) continue; const s = (g.v[j] - g.v[j - 1]) / dt; t.push(g.t[j - 1], g.t[j]); v.push(s, s); }
  if (!t.length) { t.push(g.t[0]); v.push(0); }
  o = geoFinish(t, v); seq.geo.sl[id] = o; return o;
}
function slewSum(seq, id) { // min/max and end values of slew, without keeping the waveform
  let o = seq.geo.ss[id]; if (o) return o;
  const g = geoG(seq, id); let mn = 0, mx = 0, f = NaN, l = 0, t0 = g.t[0], t1 = g.t[0];
  for (let j = 1; j < g.n; j++) { const dt = g.t[j] - g.t[j - 1]; if (dt <= 1e-12) continue; const x = (g.v[j] - g.v[j - 1]) / dt; if (f !== f) { f = x; t0 = g.t[j - 1]; } l = x; t1 = g.t[j]; if (x < mn) mn = x; if (x > mx) mx = x; }
  o = { min: mn, max: mx, t: [t0, t1], v: [f === f ? f : 0, l], n: 2 }; seq.geo.ss[id] = o; return o;
}
function rfSamples(seq, r) {
  const rr = seq.raster.rf, m = seq.shapes.get(r.magId), p = seq.shapes.get(r.phaseId);
  if (!m) { seq.warnings.push(`Missing RF magnitude shape ${r.magId}`); return { t: [], mag: [], ph: [], dur: 0, timed: false }; }
  const N = m.length, t = new Array(N), mag = new Array(N), ph = new Array(N), ts = r.timeId > 0 ? seq.shapes.get(r.timeId) : null;
  for (let i = 0; i < N; i++) { t[i] = r.delay + (ts ? ts[i] * rr : (i + 0.5) * rr); mag[i] = r.amp * m[i]; ph[i] = (p ? p[i] * 2 * Math.PI : 0) + r.phase; }
  return { t, mag, ph, dur: ts ? ts[N - 1] * rr : N * rr, timed: !!ts };
}
function rfStats(seq, r) {
  const s = rfSamples(seq, r), N = s.t.length; let re = 0, im = 0, peak = 0;
  for (let i = 0; i < N; i++) {
    const dt = s.timed ? (i > 0 ? (s.t[i] - s.t[i - 1]) / 2 : 0) + (i < N - 1 ? (s.t[i + 1] - s.t[i]) / 2 : 0) : seq.raster.rf;
    re += s.mag[i] * Math.cos(s.ph[i]) * dt; im += s.mag[i] * Math.sin(s.ph[i]) * dt;
    if (Math.abs(s.mag[i]) > peak) peak = Math.abs(s.mag[i]);
  }
  const flip = 2 * Math.PI * Math.hypot(re, im);
  let center;
  if (r.center !== undefined) center = r.delay + r.center;
  else { let i0 = -1, i1 = -1; for (let i = 0; i < N; i++) if (Math.abs(s.mag[i]) >= 0.99999 * peak) { if (i0 < 0) i0 = i; i1 = i; } center = i0 < 0 ? r.delay : (s.t[i0] + s.t[i1]) / 2; }
  let use = r.use, useGuessed = false;
  if (!use || use === 'u') { use = flip > (90.01 * Math.PI / 180) ? 'r' : 'e'; useGuessed = true; }
  return { flip, center, dur: s.dur, use, useGuessed, peak, n: N };
}
function rfSt(seq, id) { let o = seq.geo.rfs[id]; if (!o) { const r = seq.rf.get(id); o = r ? rfStats(seq, r) : { flip: 0, center: 0, dur: 0, use: 'o', n: 0, peak: 0 }; seq.geo.rfs[id] = o; } return o; }
function geoRfm(seq, id) {
  let o = seq.geo.rfm[id]; if (o) return o;
  const r = seq.rf.get(id), s = r ? rfSamples(seq, r) : { t: [], mag: [] }, t = [], v = [];
  if (s.t.length) { t.push(s.t[0]); v.push(0); for (let k = 0; k < s.t.length; k++) { t.push(s.t[k]); v.push(s.mag[k]); } t.push(s.t[s.t.length - 1]); v.push(0); }
  else { t.push(0); v.push(0); }
  o = geoFinish(t, v); seq.geo.rfm[id] = o; return o;
}
/* real or imaginary part of the RF shape: amp·mag·e^{iφ} with φ the shape's own phase (the phase offset and the
   frequency offset are not included, as in Pulseq's rf.signal), so a sinc shows its negative lobes */
function geoRfPart(seq, id, im) {
  const c = im ? (seq.geo.rfim || (seq.geo.rfim = [])) : (seq.geo.rfre || (seq.geo.rfre = [])); let o = c[id]; if (o) return o;
  const r = seq.rf.get(id), s = r ? rfSamples(seq, r) : { t: [], mag: [], ph: [] }, t = [], v = [];
  if (s.t.length) {
    t.push(s.t[0]); v.push(0);
    for (let k = 0; k < s.t.length; k++) { const p = s.ph[k] - r.phase; t.push(s.t[k]); v.push(s.mag[k] * (im ? Math.sin(p) : Math.cos(p))); }
    t.push(s.t[s.t.length - 1]); v.push(0);
  } else { t.push(0); v.push(0); }
  o = geoFinish(t, v); c[id] = o; return o;
}
function geoRfRe(seq, id) { return geoRfPart(seq, id, false); }
function geoRfIm(seq, id) { return geoRfPart(seq, id, true); }
function geoRfp(seq, id) {
  let o = seq.geo.rfp[id]; if (o) return o;
  const r = seq.rf.get(id), s = r ? rfSamples(seq, r) : { t: [], ph: [] }, t = [], v = [];
  for (let k = 0; k < s.t.length; k++) { let ph = s.ph[k] % (2 * Math.PI); if (ph > Math.PI) ph -= 2 * Math.PI; if (ph < -Math.PI) ph += 2 * Math.PI; t.push(s.t[k]); v.push(ph); }
  if (t.length) { t.push(t[t.length - 1]); v.push(NaN); } else { t.push(0); v.push(NaN); }
  o = geoFinish(t, v); seq.geo.rfp[id] = o; return o;
}
function evEnd(seq, kind, id) {
  if (!id) return 0;
  const cache = kind === 'rf' ? seq.geo.endrf : kind === 'adc' ? seq.geo.endadc : seq.geo.endg; let e = cache[id]; if (e !== undefined) return e;
  if (kind === 'rf') { const r = seq.rf.get(id); e = r ? rfSamples(seq, r).dur + r.delay : 0; }
  else if (kind === 'adc') { const d = seq.adc.get(id); e = d ? d.delay + d.num * d.dwell : 0; }
  else { const g = geoG(seq, id); e = g.t[g.n - 1]; }
  cache[id] = e; return e;
}
function blockEventEnd(seq, i) {
  const B = seq.B;
  return Math.max(evEnd(seq, 'rf', B.rf[i]), evEnd(seq, 'g', B.gx[i]), evEnd(seq, 'g', B.gy[i]), evEnd(seq, 'g', B.gz[i]), evEnd(seq, 'adc', B.adc[i]));
}
function blockObj(seq, i) { const B = seq.B; return { id: B.id[i], rf: B.rf[i], gx: B.gx[i], gy: B.gy[i], gz: B.gz[i], adc: B.adc[i], ext: B.ext[i], dur: seq.blockStart[i + 1] - seq.blockStart[i] }; }

/* channel access: key -> (column, geometry fn, kind) */
/* slew uses slewSum for summaries (see blockSummary) and geoSlew for exact drawing */
const CHANNELS = {
  gx: { col: 'pgx', fn: geoG, p: false }, gy: { col: 'pgy', fn: geoG, p: false }, gz: { col: 'pgz', fn: geoG, p: false }, // physical (after rotation)
  sx: { col: 'pgx', fn: geoSlew, p: false }, sy: { col: 'pgy', fn: geoSlew, p: false }, sz: { col: 'pgz', fn: geoSlew, p: false },
  rfMag: { col: 'rf', fn: geoRfm, p: false }, rfPh: { col: 'rf', fn: geoRfp, p: true },
  rfRe: { col: 'rf', fn: geoRfRe, p: false, lazy: true }, rfIm: { col: 'rf', fn: geoRfIm, p: false, lazy: true } // summaries built on first use
};
/* summary of channel over block i: {has, mn, mx, first, last, brk}; value is 0 outside events (NaN for phase) */
function blockSummary(seq, key, i, o) {
  if (key in M0_KEYS) return m0Summary(seq, i, M0_KEYS[key], o);
  const ch = CHANNELS[key], id = seq.B[ch.col][i], fn = ch.fn, kind = ch.p ? 'p' : 'g';
  if (!id) { o.n = 0; if (kind === 'p') { o.has = 0; o.brk = 0; } else { o.has = 1; o.mn = o.mx = o.first = o.last = 0; o.brk = 0; } return o; }
  const g = fn === geoSlew ? slewSum(seq, id) : fn(seq, id); o.n = g.n;
  if (kind === 'p') { o.has = 1; o.mn = g.min; o.mx = g.max; o.first = g.v[0]; o.last = g.n > 1 ? g.v[g.n - 2] : g.v[0]; o.brk = 1; return o; }
  const dur = seq.blockStart[i + 1] - seq.blockStart[i];
  o.first = g.t[0] <= 1e-9 ? g.v[0] : 0; o.last = Math.abs(g.t[g.n - 1] - dur) <= 1e-9 ? g.v[g.n - 1] : 0;
  const z = o.first === 0 || o.last === 0;
  o.mn = z ? Math.min(0, g.min) : g.min; o.mx = z ? Math.max(0, g.max) : g.max; o.has = 1; o.brk = 0;
  return o;
}
/* exact vertices of block i for drawing (absolute times); push(t, v) */
function blockVertices(seq, key, i, push) {
  if (key in M0_KEYS) return m0Vertices(seq, i, M0_KEYS[key], push);
  const ch = CHANNELS[key], id = seq.B[ch.col][i], fn = ch.fn, kind = ch.p ? 'p' : 'g', t0 = seq.blockStart[i], t1 = seq.blockStart[i + 1];
  if (!id) { if (kind !== 'p') { push(t0, 0); push(t1, 0); } return; }
  const g = fn(seq, id);
  if (kind === 'p') { for (let k = 0; k < g.n; k++) push(t0 + g.t[k], g.v[k]); return; }
  const first = g.t[0] <= 1e-9 ? g.v[0] : 0, last = Math.abs(g.t[g.n - 1] - (t1 - t0)) <= 1e-9 ? g.v[g.n - 1] : 0;
  push(t0, first);
  if (first === 0 && g.v[0] !== 0) push(t0 + g.t[0], 0);
  for (let k = 0; k < g.n; k++) push(t0 + g.t[k], g.v[k]);
  if (last === 0 && g.v[g.n - 1] !== 0) push(t0 + g.t[g.n - 1], 0);
  push(t1, last);
}
/* ---------- zeroth moment m0 = ∫G dt ----------
   With G in Hz/m, m0 is in 1/m and equals k: the same integral as kInBlock, reset at each excitation and sign-flipped
   at each refocusing pulse (both at the RF centre, as Pulseq's calculateKspacePP). Within a block m0 is piecewise
   quadratic, so its extremes lie at the block ends, the gradient's vertices, its zero crossings and the RF centre;
   ramps get extra points so that the curve draws smoothly. Keys mx, my, mz behave as channels. */
const M0_KEYS = { mx: 0, my: 1, mz: 2 };
let m0Memo = { seq: null, map: new Map() }; // the last few blocks evaluated (drawing asks for x, y and z in turn)
function m0Block(seq, i) { // { t: relative times, v: [x, y, z] values } for block i
  if (m0Memo.seq !== seq) m0Memo = { seq, map: new Map() };
  const hit = m0Memo.map.get(i); if (hit) return hit;
  const B = seq.B, dur = seq.blockStart[i + 1] - seq.blockStart[i], T = [0, dur], ids = [B.pgx[i], B.pgy[i], B.pgz[i]];
  for (const id of ids) {
    if (!id) continue; const g = geoG(seq, id);
    for (let k = 0; k < g.n; k++) {
      const t = g.t[k]; if (t >= 0 && t <= dur) T.push(t);
      if (k) {
        const ta = g.t[k - 1], va = g.v[k - 1], vb = g.v[k], D = t - ta;
        if (va !== vb && D > 0) {
          if ((va < 0) !== (vb < 0) && va !== 0 && vb !== 0) T.push(ta + D * va / (va - vb)); // G = 0: an extremum of m0
          const n = Math.min(8, Math.round(D / 1e-5)); for (let q = 1; q < n; q++) T.push(ta + D * q / n); // quadratic: smooth curve
        }
      }
    }
  }
  let rc = -1;
  if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e' || st.use === 'r') { rc = st.center; T.push(rc); } }
  T.sort((a, b) => a - b);
  const t = []; for (const x of T) if (!t.length || x - t[t.length - 1] > 1e-12) t.push(x);
  if (rc >= 0) { const j = t.findIndex(x => Math.abs(x - rc) <= 1e-12); if (j >= 0) t.splice(j, 1, rc - 1e-12, rc); } // both sides of the jump
  const v = [new Float64Array(t.length), new Float64Array(t.length), new Float64Array(t.length)];
  kInBlock(seq, i, Float64Array.from(t), v, 0);
  const r = { t, v }; if (m0Memo.map.size > 4096) m0Memo.map.clear(); m0Memo.map.set(i, r); return r;
}
/* extremes of the running integral of one gradient event (from 0, including 0 and its total area): per event, not
   per block, because a block without an excitation or refocusing pulse only adds its start value */
function m0EventExt(seq, id) {
  const c = seq.geo.m0 || (seq.geo.m0 = {}); let o = c[id]; if (o) return o;
  const g = geoG(seq, id); let acc = 0, mn = 0, mx = 0;
  for (let k = 1; k < g.n; k++) {
    const ta = g.t[k - 1], tb = g.t[k], va = g.v[k - 1], vb = g.v[k], D = tb - ta;
    if ((va < 0) !== (vb < 0) && va !== 0 && vb !== 0 && D > 0) { const d = D * va / (va - vb), p = acc + va * d / 2; if (p < mn) mn = p; if (p > mx) mx = p; } // G = 0 inside
    acc += (va + vb) / 2 * D; if (acc < mn) mn = acc; if (acc > mx) mx = acc;
  }
  return (c[id] = { mn, mx, area: acc });
}
function m0Plain(seq, i) { const r = seq.B.rf[i]; if (!r) return true; const u = rfSt(seq, r).use; return u !== 'e' && u !== 'r'; }
function m0Summary(seq, i, a, o) {
  if (m0Plain(seq, i)) { // start value plus the event's running integral
    const k0 = seq.kStart[a][i], id = [seq.B.pgx, seq.B.pgy, seq.B.pgz][a][i];
    if (!id) { o.has = 1; o.brk = 0; o.n = 2; o.mn = o.mx = o.first = o.last = k0; return o; }
    const e = m0EventExt(seq, id); o.has = 1; o.brk = 0; o.n = geoG(seq, id).n; o.mn = k0 + e.mn; o.mx = k0 + e.mx; o.first = k0; o.last = k0 + e.area; return o; // n: lets narrow blocks be drawn from the summary
  }
  const m = m0Block(seq, i), v = m.v[a]; let mn = Infinity, mx = -Infinity;
  for (let k = 0; k < v.length; k++) { if (v[k] < mn) mn = v[k]; if (v[k] > mx) mx = v[k]; }
  o.has = 1; o.brk = 0; o.n = v.length; o.mn = mn; o.mx = mx; o.first = v[0]; o.last = v[v.length - 1]; return o;
}
function m0Vertices(seq, i, a, push) { const m = m0Block(seq, i), t0 = seq.blockStart[i]; for (let k = 0; k < m.t.length; k++) push(t0 + m.t[k], m.v[a][k]); }
function m0Value(seq, a, t) { const i = blockAtTime(seq, t), out = [new Float64Array(1), new Float64Array(1), new Float64Array(1)]; kInBlock(seq, i, Float64Array.of(t - seq.blockStart[i]), out, 0); return out[a][0]; }
/* pyramids for mx, my, mz (built on first use); seq.m0Max = largest |m0| */
function m0Pyramids(seq) {
  if (seq.pyr.mx) return;
  const nb = seq.nb, o = {}, per = [0, 1, 2].map(() => ({ mn: new Float32Array(nb), mx: new Float32Array(nb), first: new Float32Array(nb), last: new Float32Array(nb) }));
  let big = 0;
  for (let i = 0; i < nb; i++) for (let a = 0; a < 3; a++) { m0Summary(seq, i, a, o); const P = per[a]; P.mn[i] = o.mn; P.mx[i] = o.mx; P.first[i] = o.first; P.last[i] = o.last; big = Math.max(big, Math.abs(o.mn), Math.abs(o.mx)); }
  ['mx', 'my', 'mz'].forEach((key, a) => {
    const P0 = per[a], out = []; let prev = null; const SIZES = pyrSizes(nb);
    for (let L = 0; L < SIZES.length; L++) {
      const sz = SIZES[L], n = Math.floor(nb / sz); if (n < 2) break;
      const P = { size: sz, mn: new Float32Array(n), mx: new Float32Array(n), first: new Float32Array(n), last: new Float32Array(n), has: new Uint8Array(n).fill(1), brk: new Uint8Array(n) };
      for (let k = 0; k < n; k++) {
        let mn = Infinity, mx = -Infinity;
        if (!L) { for (let i = k * sz; i < (k + 1) * sz; i++) { if (P0.mn[i] < mn) mn = P0.mn[i]; if (P0.mx[i] > mx) mx = P0.mx[i]; } P.first[k] = P0.first[k * sz]; P.last[k] = P0.last[(k + 1) * sz - 1]; }
        else { const r = sz / prev.size; for (let j = k * r; j < (k + 1) * r; j++) { if (prev.mn[j] < mn) mn = prev.mn[j]; if (prev.mx[j] > mx) mx = prev.mx[j]; } P.first[k] = prev.first[k * r]; P.last[k] = prev.last[(k + 1) * r - 1]; }
        P.mn[k] = mn; P.mx[k] = mx;
      }
      out.push(P); prev = P;
    }
    seq.pyr[key] = out;
  });
  seq.m0Max = big;
  // tables for rangeSummary: per gradient event its integral extremes and area, per RF event whether it leaves m0 alone
  const B = seq.B, ids = [B.pgx, B.pgy, B.pgz]; let maxG = 0, maxR = 0;
  for (let i = 0; i < nb; i++) { for (let a = 0; a < 3; a++) if (ids[a][i] > maxG) maxG = ids[a][i]; if (B.rf[i] > maxR) maxR = B.rf[i]; }
  const T = { ids, mn: new Float64Array(maxG + 1), mx: new Float64Array(maxG + 1), area: new Float64Array(maxG + 1), plainRf: new Uint8Array(maxR + 1) };
  const seenG = new Uint8Array(maxG + 1), seenR = new Uint8Array(maxR + 1);
  for (let i = 0; i < nb; i++) {
    for (let a = 0; a < 3; a++) { const id = ids[a][i]; if (id && !seenG[id]) { const e = m0EventExt(seq, id); T.mn[id] = e.mn; T.mx[id] = e.mx; T.area[id] = e.area; seenG[id] = 1; } }
    const r = B.rf[i]; if (r && !seenR[r]) { const u = rfSt(seq, r).use; T.plainRf[r] = u !== 'e' && u !== 'r' ? 1 : 0; seenR[r] = 1; }
  }
  seq.m0Ev = T;
}
/* stretches where m0 matters: from each excitation's RF centre to the end of the last readout before the next
   excitation (none if there is no readout in between): [starts, ends], sorted */
function m0Active(seq) {
  if (seq.m0Act) return seq.m0Act;
  const B = seq.B, bs = seq.blockStart, E = [];
  for (let i = 0; i < seq.nb; i++) if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e') E.push(bs[i] + st.center); }
  const a = [], b = [], T0 = seq.adcT0, T1 = seq.adcT1;
  for (let j = 0; j < E.length; j++) {
    const lim = j + 1 < E.length ? E[j + 1] : Infinity;
    let lo = 0, hi = T0.length; while (lo < hi) { const m = (lo + hi) >> 1; if (T0[m] < lim) lo = m + 1; else hi = m; } // last ADC starting before the next excitation
    const q = lo - 1; if (q >= 0 && T0[q] >= E[j]) { a.push(E[j]); b.push(T1[q]); }
  }
  return (seq.m0Act = { a: Float64Array.from(a), b: Float64Array.from(b) });
}
function blockAtTime(seq, t) {
  const a = seq.blockStart, n = seq.nb; let lo = 0, hi = n;
  while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] <= t) lo = m + 1; else hi = m; }
  return Math.max(0, Math.min(n - 1, lo - 1));
}
function channelValue(seq, key, t) {
  if (key in M0_KEYS) return m0Value(seq, M0_KEYS[key], t);
  const ch = CHANNELS[key], i = blockAtTime(seq, t), id = seq.B[ch.col][i], fn = ch.fn, out = ch.p ? NaN : 0;
  if (!id) return out;
  const g = fn(seq, id), r = t - seq.blockStart[i];
  if (r < g.t[0] || r > g.t[g.n - 1]) return out;
  let lo = 0, hi = g.n; while (lo < hi) { const m = (lo + hi) >> 1; if (g.t[m] <= r) lo = m + 1; else hi = m; }
  const j = lo; if (j === 0) return g.v[0]; if (j >= g.n) return g.v[g.n - 1];
  const ta = g.t[j - 1], tb = g.t[j], va = g.v[j - 1], vb = g.v[j];
  if (va !== va || vb !== vb) return NaN;
  return tb > ta ? va + (vb - va) * (r - ta) / (tb - ta) : vb;
}

/* ---------- min/max pyramid over blocks, per channel ---------- */
const PYR_SIZES = [16, 256, 4096, 65536, 1048576];
/* summary levels: files up to a million blocks also get 4-block buckets. Zoomed out, a pixel column spans ~10-20
   blocks that rarely line up with the 16-block buckets, so most were summarised block by block; with 4-block buckets
   that is a few per column. (18 bytes per 4 blocks and channel, hence the limit.) */
function pyrSizes(nb) { return nb <= 1e6 ? [4, ...PYR_SIZES] : PYR_SIZES; }
function buildPyramid(seq, key) {
  const nb = seq.nb, out = [], ch = CHANNELS[key], ids = seq.B[ch.col], bs = seq.blockStart, isP = ch.p;
  // per unique event: summary pieces that do not depend on the block
  let maxId = 0; for (let i = 0; i < nb; i++) if (ids[i] > maxId) maxId = ids[i];
  const eMn = new Float64Array(maxId + 1), eMx = new Float64Array(maxId + 1), eF = new Float64Array(maxId + 1), eL = new Float64Array(maxId + 1), eT0 = new Float64Array(maxId + 1), eT1 = new Float64Array(maxId + 1), eOk = new Uint8Array(maxId + 1);
  for (let i = 0; i < nb; i++) {
    const id = ids[i]; if (!id || eOk[id]) continue;
    const g = ch.fn === geoSlew ? slewSum(seq, id) : ch.fn(seq, id);
    eMn[id] = g.min; eMx[id] = g.max; eF[id] = g.v[0]; eL[id] = isP ? (g.n > 1 ? g.v[g.n - 2] : g.v[0]) : g.v[g.n - 1]; eT0[id] = g.t[0]; eT1[id] = g.t[g.n - 1]; eOk[id] = 1;
  }
  (seq.evt || (seq.evt = {}))[key] = { mn: eMn, mx: eMx, f: eF, l: eL, t0: eT0, t1: eT1, ids, isP }; // for fast block summaries
  let prev = null; const SIZES = pyrSizes(nb);
  for (let L = 0; L < SIZES.length; L++) {
    const sz = SIZES[L], n = Math.floor(nb / sz); if (n < 2) break;
    const P = { size: sz, mn: new Float32Array(n), mx: new Float32Array(n), first: new Float32Array(n), last: new Float32Array(n), has: new Uint8Array(n), brk: new Uint8Array(n) };
    for (let k = 0; k < n; k++) {
      let mn = Infinity, mx = -Infinity, first = NaN, last = NaN, has = 0, brk = 0;
      if (L === 0) {
        for (let i = k * sz; i < (k + 1) * sz; i++) {
          const id = ids[i]; let bmn, bmx, bf, bl;
          if (!id) { if (isP) continue; bmn = bmx = bf = bl = 0; }
          else if (isP) { bmn = eMn[id]; bmx = eMx[id]; bf = eF[id]; bl = eL[id]; brk = 1; }
          else {
            bf = eT0[id] <= 1e-9 ? eF[id] : 0; bl = Math.abs(eT1[id] - (bs[i + 1] - bs[i])) <= 1e-9 ? eL[id] : 0;
            const z = bf === 0 || bl === 0; bmn = z && eMn[id] > 0 ? 0 : eMn[id]; bmx = z && eMx[id] < 0 ? 0 : eMx[id];
          }
          if (!has) first = bf; last = bl; has = 1; if (bmn < mn) mn = bmn; if (bmx > mx) mx = bmx;
        }
      } else {
        const r = sz / prev.size;
        for (let j = k * r; j < (k + 1) * r; j++) {
          if (prev.brk[j]) brk = 1; if (!prev.has[j]) continue;
          if (!has) first = prev.first[j]; last = prev.last[j]; has = 1; if (prev.mn[j] < mn) mn = prev.mn[j]; if (prev.mx[j] > mx) mx = prev.mx[j];
        }
      }
      P.mn[k] = mn; P.mx[k] = mx; P.first[k] = first; P.last[k] = last; P.has[k] = has; P.brk[k] = brk;
    }
    out.push(P); prev = P;
  }
  return out;
}

/* combine the summaries of blocks bA..bB (inclusive) using the fewest aligned pyramid buckets */
function rangeSummary(seq, key, bA, bB, o, tmp) {
  const pyr = seq.pyr[key], m0a = key in M0_KEYS ? M0_KEYS[key] : -1, z0 = pyr && pyr.length ? pyr[0].size - 1 : -1;
  let has = 0, mn = Infinity, mx = -Infinity, first = 0, last = 0, brk = 0, b = bA;
  while (b <= bB) {
    let used = false;
    if (z0 >= 0 && (b & z0) === 0 && b + z0 <= bB) for (let L = pyr.length - 1; L >= 0; L--) { // sizes are powers of two
      const P = pyr[L], sz = P.size; if (b % sz || b + sz - 1 > bB) continue;
      const q = b / sz; if (P.brk[q]) brk = 1;
      if (P.has[q]) { if (!has) first = P.first[q]; last = P.last[q]; has = 1; if (P.mn[q] < mn) mn = P.mn[q]; if (P.mx[q] > mx) mx = P.mx[q]; }
      b += sz; used = true; break;
    }
    if (used) continue;
    if (m0a >= 0 && seq.m0Ev) { // k-vector: start value plus the event's integral extremes (blocks without excitation/refocusing)
      const T = seq.m0Ev, r = seq.B.rf[b];
      if (!r || T.plainRf[r]) {
        const k0 = seq.kStart[m0a][b], id = T.ids[m0a][b], bmn = id ? k0 + T.mn[id] : k0, bmx = id ? k0 + T.mx[id] : k0, bl = id ? k0 + T.area[id] : k0;
        if (!has) first = k0; last = bl; has = 1; if (bmn < mn) mn = bmn; if (bmx > mx) mx = bmx;
        b++; continue;
      }
    }
    const E = seq.evt && seq.evt[key];
    if (E) { // one block from the per-event table: the same rule as blockSummary, without a call per block
      const id = E.ids[b]; let bmn, bmx, bf, bl;
      if (!id) { if (E.isP) { b++; continue; } bmn = bmx = bf = bl = 0; }
      else if (E.isP) { bmn = E.mn[id]; bmx = E.mx[id]; bf = E.f[id]; bl = E.l[id]; brk = 1; }
      else {
        const bs = seq.blockStart; bf = E.t0[id] <= 1e-9 ? E.f[id] : 0; bl = Math.abs(E.t1[id] - (bs[b + 1] - bs[b])) <= 1e-9 ? E.l[id] : 0;
        const z = bf === 0 || bl === 0; bmn = z && E.mn[id] > 0 ? 0 : E.mn[id]; bmx = z && E.mx[id] < 0 ? 0 : E.mx[id];
      }
      if (!has) first = bf; last = bl; has = 1; if (bmn < mn) mn = bmn; if (bmx > mx) mx = bmx;
      b++; continue;
    }
    blockSummary(seq, key, b, tmp); if (tmp.brk) brk = 1;
    if (tmp.has) { if (!has) first = tmp.first; last = tmp.last; has = 1; if (tmp.mn < mn) mn = tmp.mn; if (tmp.mx > mx) mx = tmp.mx; }
    b++;
  }
  o.has = has; o.mn = mn; o.mx = mx; o.first = first; o.last = last; o.brk = brk; return o;
}
/* ADC-type pyramid: highest-ranked type per bucket of ADC events */
const TYPE_RANK = [1, 4, 3, 5, 2];
function buildAdcPyramid(seq) {
  const out = [], T = seq.adcType, n0 = T.length; let prev = null;
  for (const sz of [32, 1024, 32768]) {
    const n = Math.floor(n0 / sz); if (n < 2) break;
    const P = { size: sz, type: new Int8Array(n) };
    for (let k = 0; k < n; k++) {
      let best = -1;
      if (!prev) { for (let j = k * sz; j < (k + 1) * sz; j++) if (best < 0 || TYPE_RANK[T[j]] > TYPE_RANK[best]) best = T[j]; }
      else { const r = sz / prev.size; for (let j = k * r; j < (k + 1) * r; j++) { const x = prev.type[j]; if (best < 0 || TYPE_RANK[x] > TYPE_RANK[best]) best = x; } }
      P.type[k] = best;
    }
    out.push(P); prev = P;
  }
  return out;
}
function adcRangeType(seq, jA, jB) {
  const pyr = seq.adcPyr, T = seq.adcType; let best = -1, j = jA;
  while (j <= jB) {
    let used = false;
    for (let L = pyr.length - 1; L >= 0; L--) { const P = pyr[L], sz = P.size; if (j % sz || j + sz - 1 > jB) continue; const x = P.type[j / sz]; if (best < 0 || TYPE_RANK[x] > TYPE_RANK[best]) best = x; j += sz; used = true; break; }
    if (used) continue;
    const x = T[j]; if (best < 0 || TYPE_RANK[x] > TYPE_RANK[best]) best = x; j++;
  }
  return best;
}

/* ---------- extensions ---------- */
function extChain(seq, id) {
  const out = []; let guard = 0;
  while (id && seq.extList.has(id) && guard++ < 1000) {
    const e = seq.extList.get(id), name = seq.extTypes.get(e.type) || `type ${e.type}`, spec = seq.extSpecs.get(e.type);
    out.push({ name, ref: e.ref, data: spec ? spec.get(e.ref) : null }); id = e.next;
  }
  return out;
}
function labelNames(seq) {
  const out = new Set();
  for (const [type, name] of seq.extTypes) if (/LABEL/i.test(name)) for (const d of seq.extSpecs.get(type).values()) if (d[1]) out.add(d[1]);
  return [...out];
}
const LABEL_ORDER = ['SLC', 'SEG', 'REP', 'AVG', 'SET', 'ECO', 'PHS', 'LIN', 'PAR', 'ACQ', 'TRID', 'NAV', 'REV', 'SMS', 'REF', 'IMA', 'NOISE', 'PMC', 'NOROT', 'NOPOS', 'NOSCL', 'ONCE'];
const LABEL_FLAGS = new Set(['NAV', 'REV', 'SMS', 'REF', 'IMA', 'NOISE', 'PMC', 'NOROT', 'NOPOS', 'NOSCL', 'ONCE']);
const ADC_TYPES = ['imaging', 'reference', 'reference + imaging', 'noise', 'navigator'];

/* growable typed buffer */
class GBuf { constructor(T, n = 1024) { this.T = T; this.a = new T(n); this.n = 0; } push(x) { if (this.n === this.a.length) { const b = new this.T(this.n * 2); b.set(this.a); this.a = b; } this.a[this.n++] = x; } done() { return this.a.slice(0, this.n); } }

/* partial integral of a piecewise-linear geometry from its first vertex up to relative time r */
function partialArea(g, r) {
  if (r <= g.t[0]) return 0;
  let acc = 0;
  for (let j = 1; j < g.n; j++) {
    const ta = g.t[j - 1], tb = g.t[j];
    if (r >= tb) { acc += 0.5 * (g.v[j - 1] + g.v[j]) * (tb - ta); continue; }
    const d = r - ta, D = tb - ta, s = D > 0 ? (g.v[j] - g.v[j - 1]) / D : 0;
    return acc + g.v[j - 1] * d + 0.5 * s * d * d;
  }
  return acc;
}

/* When the file does not state a pulse's purpose (Pulseq < 1.5, or 'u'), rfStats guesses from the flip
   angle alone (≤ 90° excitation, otherwise refocusing). Context improves that: a refocusing pulse is always
   followed by a readout before the next excitation, a preparation pulse is not. For guessed pulses:
   - guessed refocusing with no ADC before the next excitation → inversion (flip > 150°) or saturation;
   - guessed excitation with no ADC before the next excitation, no gradient in its block and an
     off-resonance frequency (|f| > 100 Hz, or a ppm offset > 0.5 ppm, e.g. fat saturation) → saturation.
   Each pulse (RF event id) is decided by majority over its occurrences. Stated purposes are kept. */
function contextUses(seq) {
  const nb = seq.nb, B = seq.B, rfb = [];
  for (let b = 0; b < nb; b++) if (B.rf[b]) rfb.push(b);
  if (!rfb.length) return;
  const st = b => rfSt(seq, B.rf[b]), guessed = b => st(b).useGuessed;
  if (!rfb.some(guessed)) return;
  { let anyAdc = false; for (let b = 0; b < nb && !anyAdc; b++) if (B.adc[b]) anyAdc = true; if (!anyAdc) return; } // no readouts: no context
  // next ADC block after each block
  const nextAdc = new Int32Array(nb + 1).fill(nb); for (let b = nb - 1; b >= 0; b--) nextAdc[b] = B.adc[b] ? b : nextAdc[b + 1];
  // excitations: stated 'e', or guessed 'e' in a block with a gradient (slice-selective) or on resonance
  const isExc = b => { const s2 = st(b); if (!s2.useGuessed) return s2.use === 'e'; if (s2.use !== 'e') return false; const r = seq.rf.get(B.rf[b]); return B.gx[b] || B.gy[b] || B.gz[b] || (Math.abs(r.freq) <= 100 && !r.freqPPM); };
  const votes = new Map();
  for (let i = 0; i < rfb.length; i++) {
    const b = rfb[i]; if (!guessed(b)) continue;
    let ne = -1; for (let j = i + 1; j < rfb.length; j++) if (isExc(rfb[j])) { ne = rfb[j]; break; }
    const noAdc = ne >= 0 ? nextAdc[b + 1] > ne : nextAdc[b + 1] >= nb;
    const s2 = st(b), r = seq.rf.get(B.rf[b]); let v = s2.use;
    if (noAdc && ne >= 0) {
      if (s2.use === 'r') v = s2.flip > 150 * Math.PI / 180 ? 'i' : 's';
      else if (s2.use === 'e' && !(B.gx[b] || B.gy[b] || B.gz[b]) && (Math.abs(r.freq) > 100 || Math.abs(r.freqPPM || 0) > 0.5)) v = 's';
    }
    const id = B.rf[b], m = votes.get(id) || {}; m[v] = (m[v] || 0) + 1; votes.set(id, m);
  }
  for (const [id, m] of votes) {
    const best = Object.entries(m).sort((a, b) => b[1] - a[1])[0][0], o = rfSt(seq, id);
    if (best !== o.use) { o.use = best; o.useContext = true; }
  }
}

/* ---------- rotation extension (Pulseq 1.5) ----------
   A block with a ROTATIONS extension plays its gradient events (logical coordinates) rotated:
   G_physical = R · G_logical, R from the unit quaternion (w, x, y, z) (as Pulseq's toRotMat / rotate3D).
   The physical gradients live in B.pgx/pgy/pgz: the event id where a block is not rotated, otherwise a
   synthetic id whose geometry is the rotated combination (built once per rotation and event triple). */
function quatToMat(q) {
  const n = Math.hypot(q[0], q[1], q[2], q[3]) || 1, w = q[0] / n, x = q[1] / n, y = q[2] / n, z = q[3] / n;
  return [[1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
          [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
          [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]];
}
function rotationOfBlock(seq, i) { // quaternion [w, x, y, z] of block i, or null
  if (seq.rotType === undefined) { seq.rotType = null; for (const [t, name] of seq.extTypes) if (/^ROTATIONS?$/i.test(name)) seq.rotType = t; }
  if (seq.rotType === null || !seq.B.ext[i]) return null;
  let id = seq.B.ext[i], guard = 0;
  while (id && guard++ < 64) {
    const e = seq.extList.get(id); if (!e) break;
    if (e.type === seq.rotType) { const d = seq.extSpecs.get(e.type).get(e.ref); return d ? d.slice(0, 4).map(Number) : null; }
    id = e.next;
  }
  return null;
}
function applyRotations(seq) {
  const B = seq.B, nb = seq.nb;
  B.pgx = B.gx; B.pgy = B.gy; B.pgz = B.gz; seq.rot = { blocks: 0, distinct: 0, maxAngle: 0 };
  let any = false; for (const [, name] of seq.extTypes) if (/^ROTATIONS?$/i.test(name)) any = true;
  if (!any) return;
  const pg = [Uint32Array.from(B.gx), Uint32Array.from(B.gy), Uint32Array.from(B.gz)];
  let nextId = 1; for (const id of seq.grad.keys()) nextId = Math.max(nextId, id + 1);
  const combos = new Map(), mats = new Map();
  const valAt = (g, t) => { // piecewise-linear value, 0 outside the event
    if (!g || t < g.t[0] || t > g.t[g.n - 1]) return 0;
    let lo = 0, hi = g.n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (g.t[m] <= t) lo = m; else hi = m; }
    const d = g.t[hi] - g.t[lo]; return d > 0 ? g.v[lo] + (g.v[hi] - g.v[lo]) * (t - g.t[lo]) / d : g.v[hi];
  };
  for (let i = 0; i < nb; i++) {
    if (!B.ext[i]) continue;
    const q = rotationOfBlock(seq, i); if (!q) continue;
    const key0 = q.join(','); let M = mats.get(key0); if (!M) { M = quatToMat(q); mats.set(key0, M); }
    const ang = 2 * Math.acos(Math.min(1, Math.abs(q[0]) / (Math.hypot(...q) || 1)));
    if (ang < 1e-9) continue; // identity
    seq.rot.blocks++; seq.rot.maxAngle = Math.max(seq.rot.maxAngle, ang);
    if (!B.gx[i] && !B.gy[i] && !B.gz[i]) continue;
    const key = key0 + '|' + B.gx[i] + ',' + B.gy[i] + ',' + B.gz[i];
    let ids = combos.get(key);
    if (!ids) {
      const L = [B.gx[i], B.gy[i], B.gz[i]].map(id => id ? geoG(seq, id) : null);
      const ts = new Set();
      for (const g of L) if (g) { for (let k = 0; k < g.n; k++) ts.add(g.t[k]); ts.add(g.t[0] - 1e-12); ts.add(g.t[g.n - 1] + 1e-12); } // steps at event edges
      const t = [...ts].filter(x => x >= 0).sort((a, b) => a - b), vals = L.map(g => t.map(x => valAt(g, x)));
      ids = [0, 1, 2].map(a => {
        const v = t.map((_, k) => M[a][0] * vals[0][k] + M[a][1] * vals[1][k] + M[a][2] * vals[2][k]);
        if (v.every(x => Math.abs(x) < 1e-9)) return 0;
        const sid = nextId++; seq.geo.g[sid] = geoFinish(t, v); return sid;
      });
      combos.set(key, ids);
    }
    pg[0][i] = ids[0]; pg[1][i] = ids[1]; pg[2][i] = ids[2];
  }
  B.pgx = pg[0]; B.pgy = pg[1]; B.pgz = pg[2]; seq.rot.distinct = mats.size;
}

/* ---------- one pass over all blocks: stats, ADC table, labels, ADC types, triggers, k at block starts ---------- */
function analyze(seq, progress) {
  const nb = seq.nb, B = seq.B, bs = seq.blockStart, W = seq.warnings;
  applyRotations(seq); // physical gradients (B.pgx/pgy/pgz) for rotated blocks
  contextUses(seq); // before anything uses the pulse purposes (k-space resets, shots, statistics)
  const names = labelNames(seq).sort((a, b) => { const ia = LABEL_ORDER.indexOf(a), ib = LABEL_ORDER.indexOf(b); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || a.localeCompare(b); });
  const lIdx = new Map(names.map((n, i) => [n, i])), lVal = new Float64Array(names.length);
  const runs = names.map(() => ({ b: new GBuf(Uint32Array), v: new GBuf(Float64Array), mn: 0, mx: 0 }));
  runs.forEach(r => { r.b.push(0); r.v.push(0); });
  const extCache = new Map();
  const extOps = id => {
    let o = extCache.get(id); if (o) return o;
    o = { ops: [], trig: [] };
    for (const x of extChain(seq, id)) {
      if (!x.data) continue;
      if (/LABELSET/i.test(x.name) && lIdx.has(x.data[1])) o.ops.push([lIdx.get(x.data[1]), 1, +x.data[0]]);
      else if (/LABELINC/i.test(x.name) && lIdx.has(x.data[1])) o.ops.push([lIdx.get(x.data[1]), 0, +x.data[0]]);
      else if (/TRIGGER/i.test(x.name)) o.trig.push([(+x.data[2] || 0) * 1e-6, (+x.data[3] || 0) * 1e-6]);
    }
    extCache.set(id, o); return o;
  };
  const fl = n => lIdx.has(n) ? lIdx.get(n) : -1, iNOISE = fl('NOISE'), iREF = fl('REF'), iIMA = fl('IMA'), iNAV = fl('NAV');
  const adcB = new GBuf(Uint32Array), adcTy = new GBuf(Uint8Array), trig = [];
  const typeCounts = [0, 0, 0, 0, 0], uses = {};
  let nRF = 0, nSamples = 0, nWarn = 0;
  const kS = [new Float64Array(nb + 1), new Float64Array(nb + 1), new Float64Array(nb + 1)];
  const raw = [0, 0, 0]; let off = [0, 0, 0];
  const G = [B.pgx, B.pgy, B.pgz]; // physical
  let nextProg = 0;
  for (let i = 0; i < nb; i++) {
    if (progress && i >= nextProg) { progress(0.45 + 0.35 * i / nb); nextProg = i + 200000; }
    const dur = bs[i + 1] - bs[i];
    if (seq.verNum >= 1004000) { const e = blockEventEnd(seq, i); if (dur + 1e-9 < e) { nWarn++; if (nWarn <= 50) W.push(`Block ${B.id[i]}: events (${(e * 1e6).toFixed(1)} µs) exceed block duration (${(dur * 1e6).toFixed(1)} µs)`); } }
    if (B.ext[i]) {
      const o = extOps(B.ext[i]);
      for (const [li, set, val] of o.ops) {
        const nv = set ? val : lVal[li] + val;
        if (nv !== lVal[li]) {
          lVal[li] = nv; const r = runs[li];
          if (r.b.a[r.b.n - 1] === i) r.v.a[r.v.n - 1] = nv; else { r.b.push(i); r.v.push(nv); }
          if (nv < r.mn) r.mn = nv; if (nv > r.mx) r.mx = nv;
        }
      }
      for (const [d, du] of o.trig) trig.push({ block: i, t: bs[i] + d, dur: du });
    }
    // k at block start
    for (let a = 0; a < 3; a++) kS[a][i] = raw[a] + off[a];
    if (B.rf[i]) {
      nRF++; const st = rfSt(seq, B.rf[i]); uses[st.use] = (uses[st.use] || 0) + 1;
      if (st.use === 'e' || st.use === 'r') {
        const rc = [0, 1, 2].map(a => raw[a] + (G[a][i] ? partialArea(geoG(seq, G[a][i]), st.center) : 0));
        off = st.use === 'e' ? rc.map(x => -x) : rc.map((x, a) => -2 * x - off[a]);
      }
    }
    for (let a = 0; a < 3; a++) if (G[a][i]) raw[a] += geoG(seq, G[a][i]).area;
    if (B.adc[i]) {
      const d = seq.adc.get(B.adc[i]);
      if (d) {
        let c = 0;
        if (iNOISE >= 0 && lVal[iNOISE]) c = 3;
        else if (iREF >= 0 && lVal[iREF]) c = iIMA >= 0 && lVal[iIMA] ? 2 : 1;
        else if (iNAV >= 0 && lVal[iNAV]) c = 4;
        adcB.push(i); adcTy.push(c); typeCounts[c]++; nSamples += d.num;
      }
    }
  }
  for (let a = 0; a < 3; a++) kS[a][nb] = raw[a] + off[a];
  if (nWarn > 50) W.push(`… and ${nWarn - 50} more blocks with the same problem`);
  seq.kStart = kS;
  seq.adcBlocks = adcB.done(); seq.adcType = adcTy.done();
  const nA = seq.adcBlocks.length;
  seq.adcOff = new Float64Array(nA + 1); seq.adcT0 = new Float64Array(nA); seq.adcT1 = new Float64Array(nA);
  for (let j = 0; j < nA; j++) {
    const b = seq.adcBlocks[j], d = seq.adc.get(B.adc[b]);
    seq.adcOff[j + 1] = seq.adcOff[j] + d.num; seq.adcT0[j] = bs[b] + d.delay; seq.adcT1[j] = seq.adcT0[j] + d.num * d.dwell;
  }
  seq.triggers = trig; seq.adcTypeCounts = typeCounts;
  seq.labels = names.map((name, li) => {
    const r = runs[li], b = r.b.done(), v = r.v.done(), t = new Float64Array(b.length);
    for (let k = 0; k < b.length; k++) t[k] = bs[b[k]];
    return { name, flag: LABEL_FLAGS.has(name), b, t, v, min: Math.min(r.mn, v[0]), max: Math.max(r.mx, v[0]) };
  });
  // peaks from the unique events actually used
  const maxG = [0, 0, 0], maxSlew = [0, 0, 0]; let maxRF = 0;
  const used = [new Set(), new Set(), new Set()], usedRF = new Set();
  for (let i = 0; i < nb; i++) { for (let a = 0; a < 3; a++) if (G[a][i]) used[a].add(G[a][i]); if (B.rf[i]) usedRF.add(B.rf[i]); }
  for (let a = 0; a < 3; a++) for (const id of used[a]) { const g = geoG(seq, id), s = slewSum(seq, id); maxG[a] = Math.max(maxG[a], Math.abs(g.min), Math.abs(g.max)); maxSlew[a] = Math.max(maxSlew[a], Math.abs(s.min), Math.abs(s.max)); }
  for (const id of usedRF) maxRF = Math.max(maxRF, geoRfm(seq, id).max);
  seq.stats = { maxRF, maxG, maxSlew, nRF, nADC: nA, nSamples, uses, nExc: uses.e || 0, nRef: uses.r || 0 };
  // pyramids
  seq.pyr = {};
  const keys = Object.keys(CHANNELS).filter(k => !CHANNELS[k].lazy);
  keys.forEach((k, j) => { if (progress) progress(0.8 + 0.15 * j / keys.length); seq.pyr[k] = buildPyramid(seq, k); });
  seq.adcPyr = buildAdcPyramid(seq);
  seq.shots = computeShots(seq, 'exc');
  if (progress) progress(1);
  return seq;
}

/* ---------- k-space on demand ---------- */
/* k (1/m) for sorted relative times in block i, written to out[a][o + q] */
function kInBlock(seq, i, rel, out, o, nq = rel.length) {
  const B = seq.B, G = [B.pgx[i], B.pgy[i], B.pgz[i]];
  let rc = -1, use = null;
  if (B.rf[i]) { const st = rfSt(seq, B.rf[i]); if (st.use === 'e' || st.use === 'r') { rc = st.center; use = st.use; } }
  for (let a = 0; a < 3; a++) {
    const k0 = seq.kStart[a][i], g = G[a] ? geoG(seq, G[a]) : null;
    const pc = rc >= 0 && g ? partialArea(g, rc) : 0;
    // sweep through vertices once for all (sorted) times
    let j = 1, acc = 0;
    for (let q = 0; q < nq; q++) {
      const r = rel[q]; let p = 0;
      if (g && r > g.t[0]) {
        while (j < g.n && g.t[j] <= r) { acc += 0.5 * (g.v[j - 1] + g.v[j]) * (g.t[j] - g.t[j - 1]); j++; }
        if (j >= g.n) p = acc;
        else { const d = r - g.t[j - 1], D = g.t[j] - g.t[j - 1], s = D > 0 ? (g.v[j] - g.v[j - 1]) / D : 0; p = acc + g.v[j - 1] * d + 0.5 * s * d * d; }
      }
      let k;
      if (rc >= 0 && r >= rc) k = use === 'e' ? p - pc : -(k0 + pc) + (p - pc);
      else k = k0 + p;
      out[a][o + q] = k;
    }
  }
}
/* ADC samples of events j0..j1-1 (thinned by whole events to at most maxPts samples) */
function kSamples(seq, j0, j1, maxPts = Infinity, withT = false) {
  const total = seq.adcOff[j1] - seq.adcOff[j0];
  const step = total > maxPts ? Math.ceil(total / maxPts) : 1;
  let n = 0; for (let j = j0; j < j1; j += step) n += seq.adcOff[j + 1] - seq.adcOff[j];
  const out = [new Float32Array(n), new Float32Array(n), new Float32Array(n)], type = new Uint8Array(n), T = withT ? new Float64Array(n) : null;
  let o = 0; const tmp = [new Float64Array(0), new Float64Array(0), new Float64Array(0)], relCache = new Map();
  for (let j = j0; j < j1; j += step) {
    const b = seq.adcBlocks[j], aid = seq.B.adc[b], d = seq.adc.get(aid);
    let rel = relCache.get(aid); if (!rel) { rel = new Float64Array(d.num); for (let q = 0; q < d.num; q++) rel[q] = d.delay + (q + 0.5) * d.dwell; relCache.set(aid, rel); }
    if (tmp[0].length < d.num) for (let a = 0; a < 3; a++) tmp[a] = new Float64Array(d.num);
    kInBlock(seq, b, rel, tmp, 0);
    for (let a = 0; a < 3; a++) for (let q = 0; q < d.num; q++) out[a][o + q] = tmp[a][q];
    type.fill(seq.adcType[j], o, o + d.num);
    if (T) for (let q = 0; q < d.num; q++) T[o + q] = seq.blockStart[b] + rel[q];
    o += d.num;
  }
  return { n, k: out, type, t: T, thinned: step > 1 };
}
/* trajectory through blocks b0..b1: gradient vertices (+3 subdivisions); only block starts when too many */
function kPath(seq, b0, b1, maxPts = 6e5) {
  const B = seq.B, nbk = b1 - b0 + 1;
  let est = 0; for (let i = b0; i <= b1 && est <= maxPts; i++) for (const c of ['pgx', 'pgy', 'pgz']) if (B[c][i]) est += geoG(seq, B[c][i]).n * 4;
  if (est > maxPts) {
    const step = Math.max(1, Math.ceil(nbk / maxPts)), n = Math.floor(nbk / step) + 1, k = [new Float32Array(n), new Float32Array(n), new Float32Array(n)];
    let o = 0; for (let i = b0; i <= b1 && o < n; i += step, o++) for (let a = 0; a < 3; a++) k[a][o] = seq.kStart[a][i];
    return { n: o, k, coarse: true };
  }
  const K = [new GBuf(Float32Array), new GBuf(Float32Array), new GBuf(Float32Array)], tmp = [[], [], []];
  for (let i = b0; i <= b1; i++) {
    const dur = seq.blockStart[i + 1] - seq.blockStart[i], u = [0, dur];
    for (const c of ['pgx', 'pgy', 'pgz']) if (B[c][i]) { const g = geoG(seq, B[c][i]); for (let q = 0; q < g.n; q++) u.push(g.t[q]); }
    if (B.rf[i]) u.push(rfSt(seq, B.rf[i]).center);
    u.sort((x, y) => x - y);
    const rel = [];
    for (let q = 0; q < u.length; q++) { if (q && u[q] - u[q - 1] < 1e-10) continue; if (rel.length) { const p = rel[rel.length - 1], d = u[q] - p; for (let s = 1; s < 4; s++) rel.push(p + d * s / 4); } rel.push(u[q]); }
    const R = Float64Array.from(rel), o3 = [new Float64Array(R.length), new Float64Array(R.length), new Float64Array(R.length)];
    kInBlock(seq, i, R, o3, 0);
    for (let q = 0; q < R.length; q++) for (let a = 0; a < 3; a++) K[a].push(o3[a][q]);
  }
  const k = K.map(b => b.done());
  return { n: k[0].length, k, coarse: false };
}
function computeKspace(seq) { // full, for validation
  const s = kSamples(seq, 0, seq.adcBlocks.length, Infinity, true);
  return { tA: s.t, kA: s.k };
}

/* ---------- shots and volumes ---------- */
function computeShots(seq, mode = 'exc') {
  const nb = seq.nb, B = seq.B, use = i => B.rf[i] ? rfSt(seq, B.rf[i]).use : undefined;
  const exc = []; for (let b = 0; b < nb; b++) if (use(b) === 'e') exc.push(b);
  seq.shotMode = mode;
  if (!exc.length) return [];
  const starts = [];
  if (mode === 'prep') {
    let saw = true;
    for (let b = 0; b < nb; b++) { const u = use(b); if (u === 'e') saw = true; else if ((u === 'i' || u === 's' || u === 'p') && saw) { starts.push(b); saw = false; } }
    if (starts.length) starts[0] = 0; else return computeShots(seq, 'exc');
  } else {
    for (let k = 0; k < exc.length; k++) {
      const e = exc[k], lo = k ? exc[k - 1] + 1 : 0; let st = e;
      for (let b = e - 1; b >= lo; b--) { if (B.adc[b]) break; const u = use(b); if (u !== undefined && u !== 'r') st = b; }
      starts.push(k === 0 ? 0 : st);
    }
  }
  const shots = new Array(starts.length), AB = seq.adcBlocks;
  let j = 0;
  for (let k = 0; k < starts.length; k++) {
    const b0 = starts[k], b1 = (k + 1 < starts.length ? starts[k + 1] : nb) - 1;
    while (j < AB.length && AB[j] < b0) j++;
    const j0 = j; while (j < AB.length && AB[j] <= b1) j++;
    shots[k] = { b0, b1, t0: seq.blockStart[b0], t1: seq.blockStart[b1 + 1], j0, j1: j, nADC: j - j0, nSamples: seq.adcOff[j] - seq.adcOff[j0] };
  }
  return shots;
}
/* Volumes: groups of consecutive shots.
   mode 'auto': a new volume starts when a shot repeats the k-space sampling (up to 32 ADC samples
   spread over the shot, quantised) and the RF pulses (frequency, shape, gradients played with
   them) of a shot already seen in the current volume.
   mode 'label': a new volume starts at the shot whose ADC (any type) sees a new value of that label.
   In auto mode only imaging ADCs count; noise, reference and navigator acquisitions are ignored.
   Shots without a counted ADC directly before a boundary join the new volume. */
function computeVolumes(seq, shots, mode, label, progress) {
  if (!shots.length) return [];
  const nb = seq.nb, B = seq.B, starts = [0], AT = seq.adcType;
  // auto: only imaging ADCs count (falls back to all ADCs if none are typed as imaging); label: every ADC counts
  let isImg = j => AT[j] === 0 || AT[j] === 2;
  if (mode !== 'auto' || !AT.some((t, j) => isImg(j))) isImg = () => true;
  const nImg = shots.map(sh => { let c = 0; for (let j = sh.j0; j < sh.j1; j++) if (isImg(j)) c++; return c; });
  const pushStart = k => { const last = starts[starts.length - 1]; let j = k; while (j - 1 > last && !nImg[j - 1]) j--; if (j > last) starts.push(j); };
  if (mode === 'auto') {
    let kmax = 0; for (let a = 0; a < 3; a++) for (const v of seq.kStart[a]) if (Math.abs(v) > kmax) kmax = Math.abs(v);
    const q = kmax > 0 ? kmax * 1e-3 : 1e-3;
    // 2 x 32-bit hashes (FNV-1a style) over integers; a collision needs both to match
    const H = new Int32Array(2);
    const mix = x => { x = x | 0; H[0] = Math.imul(H[0] ^ x, 16777619); const h = H[1]; H[1] = Math.imul(h ^ (x + 0x9e3779b9), 2246822519) ^ (h >>> 13); };
    const adcDefs = []; const adcDef = id => adcDefs[id] || (adcDefs[id] = seq.adc.get(id));
    let seen = new Set(); const rel = new Float64Array(64), o3 = [new Float64Array(64), new Float64Array(64), new Float64Array(64)];
    for (let k = 0; k < shots.length; k++) {
      if (progress && (k & 16383) === 0) progress(k / shots.length);
      const sh = shots[k]; if (!nImg[k]) continue;
      H[0] = 2166136261 | 0; H[1] = 0x811c9dc5 ^ 0x5bd1e995;
      for (let b = sh.b0; b <= sh.b1; b++) if (B.rf[b]) { const r = seq.rf.get(B.rf[b]); if (r) { mix(Math.round(r.freq)); mix(Math.round((r.freqPPM || 0) * 1000)); mix(r.magId); mix(r.timeId || 0); mix(B.pgx[b]); mix(B.pgy[b]); mix(B.pgz[b]); } }
      let n = 0; for (let j = sh.j0; j < sh.j1; j++) if (isImg(j)) n += seq.adcOff[j + 1] - seq.adcOff[j];
      const st = Math.max(1, Math.floor(n / 32)); mix(n);
      let c = 0;
      for (let j = sh.j0; j < sh.j1; j++) {
        if (!isImg(j)) continue;
        const bb = seq.adcBlocks[j], d = adcDef(B.adc[bb]); let m = 0;
        for (let s = 0; s < d.num; s++, c++) if (c % st === 0 && m < 64) rel[m++] = d.delay + (s + 0.5) * d.dwell;
        if (!m) continue;
        kInBlock(seq, bb, rel, o3, 0, m);
        for (let s = 0; s < m; s++) { mix(Math.round(o3[0][s] / q)); mix(Math.round(o3[1][s] / q)); mix(Math.round(o3[2][s] / q)); }
      }
      const fp = (H[0] & 0x1fffff) * 4294967296 + (H[1] >>> 0); // 53-bit key
      if (seen.has(fp)) { pushStart(k); seen = new Set([fp]); } else seen.add(fp);
    }
  } else {
    // every shot has a label value: at its first ADC, or (no ADC, e.g. a dummy scan) at its excitation,
    // i.e. after the label updates that precede or accompany it; a new volume starts where the value changes
    const tr = seq.labels.find(x => x.name === label); if (!tr) return [];
    const valueAt = b => { let lo = 0, hi = tr.b.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (tr.b[m] <= b) lo = m; else hi = m - 1; } return tr.b[lo] <= b ? tr.v[lo] : 0; };
    // a shot without a readout (dummy scan) is read where its readout would have been: its excitation plus the
    // typical excitation-to-first-ADC time of the shots that have one (labels are often set after the excitation)
    const excOf = sh => { for (let q = sh.b0; q <= sh.b1; q++) if (B.rf[q] && rfSt(seq, B.rf[q]).use === 'e') return q; return -1; };
    const offs = [];
    for (const sh of shots) if (sh.j1 > sh.j0) { const e = excOf(sh); if (e >= 0) offs.push(seq.blockStart[seq.adcBlocks[sh.j0]] - seq.blockStart[e]); }
    offs.sort((a, b) => a - b); const off = offs.length ? offs[offs.length >> 1] : null;
    let prev = null;
    for (let k = 0; k < shots.length; k++) {
      const sh = shots[k]; let b = -1;
      if (sh.j1 > sh.j0) b = seq.adcBlocks[sh.j0];
      else {
        const e = excOf(sh);
        if (e >= 0 && off !== null) { b = blockAtTime(seq, Math.min(seq.blockStart[e] + off, seq.blockStart[sh.b1 + 1] - 1e-12)); b = Math.max(sh.b0, Math.min(sh.b1, b)); }
        else b = e >= 0 ? e : sh.b1;
      }
      const v = valueAt(b); if (prev !== null && v !== prev && k > starts[starts.length - 1]) starts.push(k); prev = v;
    }
  }
  const vols = [];
  for (let i = 0; i < starts.length; i++) {
    const s0 = starts[i], s1 = (i + 1 < starts.length ? starts[i + 1] : shots.length) - 1;
    const b0 = i === 0 ? 0 : shots[s0].b0, b1 = i + 1 < starts.length ? shots[s1].b1 : nb - 1;
    let nS = 0, nA = 0; for (let k = s0; k <= s1; k++) { nS += shots[k].nSamples; if (shots[k].nADC) nA++; }
    vols.push({ s0, s1, b0, b1, t0: seq.blockStart[b0], t1: seq.blockStart[b1 + 1], nShots: s1 - s0 + 1, nAcqShots: nA, nSamples: nS });
  }
  return vols;
}

/* ---------- MD5 (RFC 1321), streaming over a Uint8Array ---------- */
function md5(bytes) {
  const K = new Int32Array(64), S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) | 0;
  let a0 = 0x67452301, b0 = 0xefcdab89 | 0, c0 = 0x98badcfe | 0, d0 = 0x10325476;
  const W = new Int32Array(16);
  const blk = (src, o) => {
    for (let i = 0; i < 16; i++) W[i] = src[o + 4 * i] | (src[o + 4 * i + 1] << 8) | (src[o + 4 * i + 2] << 16) | (src[o + 4 * i + 3] << 24);
    let A = a0, B = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      const tmp = D; D = C; C = B; const x = (A + F + K[i] + W[g]) | 0, sh = S[(i >> 4) * 4 + (i % 4)];
      B = (B + ((x << sh) | (x >>> (32 - sh)))) | 0; A = tmp;
    }
    a0 = (a0 + A) | 0; b0 = (b0 + B) | 0; c0 = (c0 + C) | 0; d0 = (d0 + D) | 0;
  };
  const len = bytes.length, full = len - (len % 64);
  for (let o = 0; o < full; o += 64) blk(bytes, o);
  const rest = len - full, tail = new Uint8Array(rest + 8 < 64 ? 64 : 128);
  tail.set(bytes.subarray(full)); tail[rest] = 0x80;
  const bits = len * 8, L = tail.length;
  for (let i = 0; i < 4; i++) tail[L - 8 + i] = (bits >>> (8 * i)) & 255;
  const hi = Math.floor(len / 536870912); for (let i = 0; i < 4; i++) tail[L - 4 + i] = (hi >>> (8 * i)) & 255;
  for (let o = 0; o < L; o += 64) blk(tail, o);
  let hex = ''; for (const v of [a0, b0, c0, d0]) for (let i = 0; i < 4; i++) hex += ((v >>> (i * 8)) & 255).toString(16).padStart(2, '0');
  return hex;
}
/* md5 of the file up to its [SIGNATURE] section (null if there is none); independent of parsing, so it can run
   in parallel with it */
function signatureHash(bytes) {
  const m = new TextEncoder().encode('\n[SIGNATURE]'); let idx = -1, from = 0;
  while (true) {
    const p = bytes.indexOf(10, from); if (p < 0) break;
    let ok = true; for (let k = 1; k < m.length; k++) if (bytes[p + k] !== m[k]) { ok = false; break; }
    if (ok) { idx = p + 1; break; } from = p + 1;
  }
  if (idx < 0) return null;
  let end = idx; if (end > 0 && bytes[end - 1] === 10) end--; if (end > 0 && bytes[end - 1] === 13) end--;
  return md5(bytes.subarray(0, end));
}
function signatureStatus(seq, h) {
  if (!seq.signature || !seq.signature.hash) return { status: 'none' };
  if (!/md5/i.test(seq.signature.type || '')) return { status: 'unsupported', type: seq.signature.type };
  if (h == null) return { status: 'none' };
  return { status: h === seq.signature.hash.toLowerCase() ? 'ok' : 'mismatch', hash: h };
}
function verifySignature(bytes, seq) {
  if (!seq.signature || !seq.signature.hash) return { status: 'none' };
  if (!/md5/i.test(seq.signature.type || '')) return { status: 'unsupported', type: seq.signature.type };
  const m = new TextEncoder().encode('\n[SIGNATURE]'); let idx = -1, from = 0;
  while (true) {
    const p = bytes.indexOf(10, from); if (p < 0) break;
    let ok = true; for (let k = 1; k < m.length; k++) if (bytes[p + k] !== m[k]) { ok = false; break; }
    if (ok) { idx = p + 1; break; } from = p + 1;
  }
  if (idx < 0) return { status: 'none' };
  let end = idx; if (end > 0 && bytes[end - 1] === 10) end--; if (end > 0 && bytes[end - 1] === 13) end--;
  const h = md5(bytes.subarray(0, end));
  return { status: h === seq.signature.hash.toLowerCase() ? 'ok' : 'mismatch', hash: h };
}

/* ---------- full load (used by the worker and as main-thread fallback) ---------- */
function loadSeq(bytes, progress, skipSignature) {
  const T = [Date.now()];
  const seq = parseSeq(bytes, progress); T.push(Date.now());
  if (!seq.nb) throw new Error('The [BLOCKS] section is empty or missing.');
  analyze(seq, progress); T.push(Date.now());
  if (!skipSignature) seq.sig = verifySignature(bytes, seq);
  seq.loadTimes = { parse: T[1] - T[0], analyze: T[2] - T[1] };
  return seq;
}

/* shots as typed columns: an array of ~10⁶ small objects is slow to copy between threads, typed arrays are
   transferred for free and the objects are rebuilt on the other side */
const SHOT_FIELDS = ['b0', 'b1', 't0', 't1', 'j0', 'j1', 'nADC', 'nSamples'];
function packShots(shots) { const n = shots.length, o = {}; for (const f of SHOT_FIELDS) { const a = new Float64Array(n); for (let i = 0; i < n; i++) a[i] = shots[i][f]; o[f] = a; } o.n = n; return o; }
function unpackShots(p) { const out = new Array(p.n); for (let i = 0; i < p.n; i++) { const s = {}; for (const f of SHOT_FIELDS) s[f] = p[f][i]; out[i] = s; } return out; }
/* all ArrayBuffers inside an object graph (for transferring a loaded sequence out of a worker) */
function transferList(root) {
  const bufs = new Set(), seen = new Set(), stack = [root];
  while (stack.length) {
    const o = stack.pop(); if (!o || typeof o !== 'object') continue;
    if (ArrayBuffer.isView(o)) { bufs.add(o.buffer); continue; }
    if (seen.has(o)) continue; seen.add(o);
    if (o instanceof Map) { for (const v of o.values()) stack.push(v); continue; }
    if (Array.isArray(o)) { if (o.length && typeof o[0] !== 'object') continue; for (const v of o) stack.push(v); continue; }
    for (const k in o) stack.push(o[k]);
  }
  return [...bufs];
}
if (typeof module !== 'undefined' && module.exports) module.exports = { packShots, unpackShots, signatureHash, signatureStatus, quatToMat, rotationOfBlock, applyRotations, rangeSummary, adcRangeType, transferList, GAMMA, parseSeq, analyze, loadSeq, gradTimes, rfStats, rfSt, geoG, geoSlew, geoRfm, geoRfp, geoRfRe, geoRfIm, buildPyramid, CHANNELS, blockSummary, blockVertices, channelValue, blockAtTime, blockObj, extChain, labelNames, computeShots, computeVolumes, kSamples, kPath, kInBlock, computeKspace, md5, verifySignature, ADC_TYPES, LABEL_FLAGS, M0_KEYS, m0Block, m0EventExt, m0Summary, m0Vertices, m0Value, m0Pyramids, m0Active };


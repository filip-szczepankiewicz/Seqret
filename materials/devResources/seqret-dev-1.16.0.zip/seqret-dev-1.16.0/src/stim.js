/* ===== nerve stimulation: the SAFE model (Hebrank & Gebhardt, ISMRM 2000, abstract 2007) as implemented in
   safe_pns_prediction by F. Szczepankiewicz and T. Witzel (github.com/filip-szczepankiewicz/safe_pns_prediction).
   Per physical axis, with dG/dt in T/m/s and time constants in ms (safe_pns_model.m):
     α_i = dt / (τ_i + dt),   y_i[k] = α_i u_i[k] + (1 − α_i) y_i[k−1],  y_i[−1] = 0
     u_1 = u_3 = dG/dt, u_2 = |dG/dt|
     stim = (a1 |y_1| + a2 y_2 + a3 |y_3|) / stim_limit · g_scale · 100   (percent of the limit)
   The same model gives peripheral (PNS) or cardiac (CNS) stimulation depending on the parameters. Seqret samples
   the physical (rotated) gradients on the file's gradient raster (dt), takes dG/dt = diff(G)/dt as the MATLAB code
   does, and runs the recursion over the whole sequence from rest. Blocks without gradients are advanced in closed
   form: with zero input every filter decays as (1 − α)^n, so each |y_i| and the stimulation fall monotonically. ===== */
const SAFE_PARAMS = ['tau1', 'tau2', 'tau3', 'a1', 'a2', 'a3', 'stim_limit', 'stim_thresh', 'g_scale'];
const SAFE_UNITS = { tau1: 'ms', tau2: 'ms', tau3: 'ms', a1: '', a2: '', a3: '', stim_limit: 'T/m/s', stim_thresh: 'T/m/s', g_scale: '' };
const SAFE_GAMMA = 42.576e6; // Hz/T, Pulseq's default γ̄ for converting Hz/m to T/m

/* safe_hw_check.m: every parameter present and finite, a1 + a2 + a3 = 1 (±0.001) on every axis. Plus positivity of
   the time constants and the limit, which the model needs to be meaningful. */
function safeHwCheck(hw) {
  if (!hw) return { ok: false, msg: 'No parameters' };
  for (const ax of 'xyz') {
    const p = hw[ax]; if (!p) return { ok: false, msg: `Axis ${ax} is missing` };
    for (const k of SAFE_PARAMS) if (typeof p[k] !== 'number' || !isFinite(p[k])) return { ok: false, msg: `${ax}.${k} is missing` };
    if (Math.abs(p.a1 + p.a2 + p.a3 - 1) > 0.001) return { ok: false, msg: `a1 + a2 + a3 must be 1 (axis ${ax}: ${+(p.a1 + p.a2 + p.a3).toFixed(4)})` };
    if (!(p.tau1 > 0 && p.tau2 > 0 && p.tau3 > 0)) return { ok: false, msg: `Time constants must be positive (axis ${ax})` };
    if (!(p.stim_limit > 0)) return { ok: false, msg: `stim_limit must be positive (axis ${ax})` };
  }
  return { ok: true, msg: '' };
}
/* example parameters from safe_example_hw_peripheral.m and safe_example_hw_cardiac.m (not a real scanner) */
function safeExample(model) {
  const P = (tau1, tau2, tau3, a1, a2, a3, stim_limit, stim_thresh, g_scale) => ({ tau1, tau2, tau3, a1, a2, a3, stim_limit, stim_thresh, g_scale });
  if (model === 'cns') return { name: 'MP_GPA_EXAMPLE_CNS', model: 'Cardiac', example: true,
    x: P(3.2, 2, 1.1, 0.7, 0.25, 0.05, 20, 10, 0.35), y: P(3.2, 2, 1.1, 0.7, 0.25, 0.05, 20, 10, 0.35), z: P(3.2, 2, 1.1, 0.7, 0.25, 0.05, 13, 10, 0.30) };
  return { name: 'MP_GPA_EXAMPLE_PNS', model: 'Peripheral', example: true,
    x: P(0.2, 0.03, 3, 0.4, 0.1, 0.5, 30, 24, 0.35), y: P(1.5, 2.5, 0.15, 0.55, 0.15, 0.3, 15, 12, 0.31), z: P(2, 0.12, 1, 0.42, 0.4, 0.18, 25, 20, 0.25) };
}

/* ---------- hardware files: port of safe_hw_from_asc.m and safe_asc_fn_to_mode.m ----------
   Whitespace is removed and matching is case-insensitive, as in the MATLAB code. MP_GPA_* files (older format) give
   peripheral parameters without a prefix; MP_GradSys_* files carry '.PNS.' and '.CarNS.' blocks. A file may name
   another file ($INCLUDE) whose non-empty parameters complete it (safe_hw_mergeIfNotEmpty.m). */
function safeAscMode(fileName, text) {
  const b = fileName.replace(/^.*[\\/]/, '');
  if (/^MP_GPA/i.test(b)) return ['old'];
  if (/^MP_GradSys/i.test(b)) return ['pns', 'cns'];
  const s = text.replace(/\s/g, '').toLowerCase(); // other names: decide from the content
  if (s.includes('.pns.flgswd') || s.includes('.carns.flgswd')) return ['pns', 'cns'].filter(m => s.includes(m === 'pns' ? '.pns.flgswd' : '.carns.flgswd'));
  return s.includes('flgswd') ? ['old'] : [];
}
/* the file named after $INCLUDE. Taken from the text with its whitespace: safe_hw_from_asc.m removes whitespace
   first, so a next line starting with a letter would be glued onto the name. Same result whenever that is right. */
function safeAscInclude(text) { const m = /\$include\s*([\w.-]+)/i.exec(text); return m ? m[1].replace(/\.asc$/i, '') : ''; }
function safeFromAsc(text, fileName, mode) {
  const STR = text.replace(/\s/g, ''), str = STR.toLowerCase(), prefix = mode === 'pns' ? '.PNS.' : mode === 'cns' ? '.CarNS.' : '';
  const base = fileName.replace(/^.*[\\/]/, '').replace(/\.[^.]*$/, '');
  const hw = { name: base, model: mode === 'cns' ? 'Cardiac' : 'Peripheral', file: fileName, x: {}, y: {}, z: {}, checksum: '', dependency: '', errors: [] };
  const all = key => { const k = key.toLowerCase(), out = []; let i = str.indexOf(k); while (i >= 0) { out.push(i + k.length); i = str.indexOf(k, i + 1); } return out; };
  const num = i => { const m = /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/.exec(str.slice(i)); return m ? parseFloat(m[0]) : undefined; };
  { const i = all('checksum='); if (i.length) { const m = /\d+/.exec(str.slice(i[0] + 4)); hw.checksum = m ? m[0] : ''; } }
  hw.dependency = safeAscInclude(text); // read before whitespace is removed (see safeAscInclude)
  for (const ax of 'XYZ') {
    const a = ax.toLowerCase(), g = all('GScaleFactor' + ax + '=').map(num);
    if (g.length === 1) hw[a].g_scale = g[0];
    else if (g.length > 1) { if (g.some(v => v !== g[0])) hw.errors.push(`Several different GScaleFactor${ax} values; the right one cannot be decided`); else hw[a].g_scale = g[0]; }
    const one = (key, field) => {
      const i = all(prefix + key); if (!i.length) return;
      if (i.length > 1) { hw.errors.push(`${prefix}${key} appears ${i.length} times; the match is not unique`); return; }
      hw[a][field] = num(i[0]);
    };
    one(`flgSWDStimulationLimit${ax}=`, 'stim_limit'); one(`flgSWDStimulationThreshold${ax}=`, 'stim_thresh');
    for (let j = 0; j < 3; j++) { one(`flgSWDTau${ax}[${j}]=`, 'tau' + (j + 1)); one(`flgSWDA${ax}[${j}]=`, 'a' + (j + 1)); }
  }
  return hw;
}
function safeMerge(hw, dep) { // parameters of the dependency fill in (and, as in MATLAB, replace) those it has
  const o = JSON.parse(JSON.stringify(hw));
  for (const ax of 'xyz') for (const k of Object.keys(dep[ax] || {})) if (typeof dep[ax][k] === 'number') o[ax][k] = dep[ax][k];
  o.mergedFrom = dep.name; return o;
}
/* read a set of .asc files: returns { pns, cns, notes[] }; dependencies are looked up among the files given */
function safeFromAscFiles(files) { // files: [{ name, text }]
  const byBase = new Map(files.map(f => [f.name.replace(/^.*[\\/]/, '').replace(/\.[^.]*$/, '').toLowerCase(), f]));
  const notes = [], res = { pns: null, cns: null, notes };
  const load = (f, mode, depth = 0) => {
    let hw = safeFromAsc(f.text, f.name, mode);
    if (hw.dependency) {
      const d = byBase.get(hw.dependency.toLowerCase());
      if (d && depth < 4) { hw = safeMerge(hw, load(d, mode, depth + 1)); notes.push(`${hw.name} takes parameters from ${hw.dependency}`); }
      else notes.push(`${hw.name} takes parameters from ${hw.dependency}.asc: load that file together with it`);
    }
    return hw;
  };
  // a file included by another is only a dependency, not a system of its own
  const included = new Set(); for (const f of files) { const d = safeAscInclude(f.text); if (d) included.add(d.toLowerCase()); }
  for (const f of files) {
    const base = f.name.replace(/^.*[\\/]/, '').replace(/\.[^.]*$/, '').toLowerCase();
    if (included.has(base) && files.length > 1) continue;
    const modes = safeAscMode(f.name, f.text);
    if (!modes.length) { notes.push(`${f.name}: no SAFE parameters found`); continue; }
    for (const m of modes) {
      const hw = load(f, m), key = m === 'cns' ? 'cns' : 'pns';
      if (res[key]) notes.push(`More than one ${key.toUpperCase()} specification; using ${res[key].name}`); else res[key] = hw;
    }
  }
  return res;
}

/* ---------- library of known systems (safe_hw_lib.mat): SHA-256 of the parameters, as in safe_hw_to_sha.m ---------- */
const SAFE_LIB = [
  ["818F4032306298B04C11679074CC04E5931B47C4AEB117E8F663EBB8C0BCC1AE", "MP_GPA_EXAMPLE", 1, "Peripheral"],
  ["14F646B532AEA0288CCF9181C2E93429CBFD6D3CF012F3A50E23FDF8D90954E6", "MP_GPA_K2259_1500V_550A_AS05", 1, "Peripheral"],
  ["3FDEAA1CF306334DA1076B59E58EDB2613945D01E70968A761EB7BC65F8DD232", "MP_GPA_K2279_1200V_150A_GC60", 1, "Peripheral"],
  ["CE3EEF736FDB7D31F64DFF4774FE874EB4CA09CEE39AF934FF2855723397FA05", "MP_GPA_K2279_1200V_150A_GC60_FB", 1, "Peripheral"],
  ["73BF0D2D2EDA8784E1287F770CB1BFA351BFA1D0443100F82A97AA5F3E4E2A5C", "MP_GPA_K2298_2250V_950A_AS097", 1, "Peripheral"],
  ["D86FDB24EE238F0F448F5207983A884403AA0B0A6E51EC67E4F47FEAD366E614", "MP_GPA_K2309_2000V_651A_GC98Q", 1, "Peripheral"],
  ["C341760C3BD93146402DCDDF7BD8C46DD6E70FBA7A8B1D18D11AA0EDC7B69EF2", "MP_GPA_K2309_2000V_651A_GC99", 1, "Peripheral"],
  ["B1633BC96C527776B525E8177FBEF4B9521D96867FFFCC9F95906A65B12A164F", "MP_GPA_K2309_2250V_951A_AS82", 1, "Peripheral"],
  ["00F18AE456B7917B07FEF1E5618907F99E0607F41B356EB9F1AE491F92DDD955", "MP_GPA_K2309_2250V_951A_GC98SQ", 1, "Peripheral"],
  ["298592622E97FB208BB43FD715262DEA38BC3BA5E3335CEBACEED904B6FEE96E", "MP_GPA_K2309_2250V_951A_AS82", 2, "Peripheral"],
  ["F63552892E0411B1BD76CD190B3A1C5E9F0A90B19BA7EC44759305A554CE17D5", "MP_GPA_K2298_2250V_793A_SC72CD", 1, "Peripheral"],
  ["B64CE7FD64B6DFA2B59DAF954817543B783F2973499A0278F3882E0ECEF1DA1F", "MP_GPA_K2298_2250V_950A_XJ_SC72CD", 1, "Peripheral"],
  ["3E7417B4748CA7ED43D8E8E6D913D5F7500977868605376052A3A002BCDA8716", "MP_GPA_K2309_2000V_651A_GC04XJ", 1, "Peripheral"],
  ["2C0A8B12A738C8A2B0F7C29CFD8E03BF99A6D4E55D32B612167C4AEA0B66ACF7", "MP_GPA_K2309_2250V_1250A_GC25plus", 1, "Peripheral"],
  ["8A04A3EA7D44621450BF491A11B253B579B5F099A9B4613CE6F7F93FD5709F35", "MP_GPA_K2309_2250V_951A_AS302", 1, "Peripheral"],
  ["F9EF15089A909242721F15F6F8EAB018DB1F60A54437C11CDABAB3F44E5294B8", "MP_GPA_K2309_2250V_951A_GC04XQ", 1, "Peripheral"],
  ["4DDC8620BC17AF5F0F479D46D0110E1EB7E61CA505A5CC3DC65446FB4994B5BC", "MP_GPA_K2368_2250V_1250A_GC25", 1, "Peripheral"],
  ["78599DA11350D7672B376305F1F45EAF9E082E89B15868DA7E9E2B09EB3663D6", "MP_GPA_K2399_2000V_651A_GC04XJ", 1, "Peripheral"],
  ["5015CD9B55B02FE2176FBF45B49BAAB914782CF7CFC61BB0B223B312D17B9018", "MP_GPA_K2399_2250V_951A_GC04XQ", 1, "Peripheral"],
  ["8CE3C914BD0C5113586B78884F264764AFB6D9F43FDA0982E18CB98165B73940", "MP_GradSys_K2298_2250V_1250A_IX_IMPULSE", 1, "Peripheral"],
  ["5F50234E6D3D878A60BC7B7E87377220677247BFD5EF7368400184F055EC9A8D", "MP_GradSys_K2298_2250V_1250A_T60_SC72CD", 1, "Cardiac"],
  ["ED502A4235F74FF3FFE4E96CB4E901A1841F14B747C635FB8DC78C59904F2B3C", "MP_GradSys_K2399_2250V_950A_J80_GC050", 1, "Peripheral"],
  ["46541D7796E58B90DAD4CF77DF830EB9EF7FC87B27C9C451CCC03C9674F2C549", "MP_GradSys_P034_X60", 1, "Peripheral"],
  ["3A0A3F7DFD16B262462C17CC9AC78114418141BC077DBF81202DF3F39D412669", "MP_GradSys_P034_X60", 2, "Cardiac"],
  ["26307395B3DC323EE324C6C382B370C92A7D1A77500B52C35F8FC804DF0D34FB", "MP_GradSys_K2368_2250V_950A_XQ_GC037", 1, "Peripheral"],
  ["3C232E2BC5ECB8EF01173E847CEFCEB217E4B042FEC97F466FE98415A011199A", "MP_GradSys_P034_c_CX600", 1, "Peripheral"]
];
function safeHwString(hw) { // num2str(value, '%012.6f') for x, y, z × tau1..g_scale
  const f = v => { const s = Math.abs(v).toFixed(6), p = (v < 0 || Object.is(v, -0) ? '-' : ''); return p + s.padStart(12 - p.length, '0'); };
  let s = ''; for (const ax of 'xyz') for (const k of SAFE_PARAMS) s += f(hw[ax][k]); return s;
}
function sha256hex(str) { // SHA-256 of an ASCII string, upper-case hex (FIPS 180-4)
  const K = new Uint32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
  const bytes = []; for (let i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i) & 255);
  const l = bytes.length; bytes.push(0x80); while (bytes.length % 64 !== 56) bytes.push(0);
  const bits = l * 8; for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? Math.floor(bits / 2 ** (8 * i)) & 255 : (bits >>> (8 * i)) & 255);
  const H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]), w = new Uint32Array(64);
  const r = (x, n) => (x >>> n) | (x << (32 - n));
  for (let o = 0; o < bytes.length; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = (bytes[o + 4 * i] << 24) | (bytes[o + 4 * i + 1] << 16) | (bytes[o + 4 * i + 2] << 8) | bytes[o + 4 * i + 3];
    for (let i = 16; i < 64; i++) { const s0 = r(w[i - 15], 7) ^ r(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = r(w[i - 2], 17) ^ r(w[i - 2], 19) ^ (w[i - 2] >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0; }
    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (r(e, 6) ^ r(e, 11) ^ r(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0, t2 = ((r(a, 2) ^ r(a, 13) ^ r(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H[0] += a; H[1] += b; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
  }
  return Array.from(H, x => x.toString(16).padStart(8, '0')).join('').toUpperCase();
}
function safeLibMatch(hw) {
  if (!safeHwCheck(hw).ok) return null;
  const h = sha256hex(safeHwString(hw)), e = SAFE_LIB.find(x => x[0] === h);
  return e ? { sha: h, name: e[1], variant: e[2], model: e[3] } : { sha: h, name: null };
}

/* ---------- the engine ----------
   models: [{ hw }, …] (1 or 2). Samples k = 0 … N at t = k·dt; interval k (k … k+1) has u = (G[k+1] − G[k]) / dt,
   and its output is placed at the interval centre. State per model and axis: y1, y2, y3. */
function stimCoeffs(hw, dt) {
  return ['x', 'y', 'z'].map(ax => {
    const p = hw[ax], al = [p.tau1, p.tau2, p.tau3].map(t => dt / (t * 1e-3 + dt));
    // dG/dt comes in Hz/m/s: the model is linear in it, so the conversion to T/m/s joins the output scale
    return { al1: al[0], al2: al[1], al3: al[2], b1: 1 - al[0], b2: 1 - al[1], b3: 1 - al[2], a1: p.a1, a2: p.a2, a3: p.a3, sc: p.g_scale * 100 / (p.stim_limit * SAFE_GAMMA) };
  });
}
/* a resumable pass over the sequence. sink(k, M, s) receives, for interval k, s[m*4 + a] (a = 0..2 axes, 3 = norm);
   sinkRun(k, n, M, sFirst, sLast, st) receives n zero-input intervals starting at k (values fall monotonically). */
class StimPass {
  constructor(seq, models, dt) {
    this.seq = seq; this.dt = dt; this.M = models.length; this.co = models.map(m => stimCoeffs(m.hw, dt));
    this.N = Math.max(1, Math.round(seq.totalDur / dt)); // samples 0..N; intervals 0..N-1
    this.y = new Float64Array(this.M * 9); this.G = new Float64Array(3); this.s = new Float64Array(this.M * 4); this.s2 = new Float64Array(this.M * 4);
    this.b = 0; this.k = 0; // next block, next sample index to read
    this.geo = [null, null, null]; this.ptr = [0, 0, 0]; this.gb = -1;
  }
  /* restart at sample kc with filter state yc (state before interval kc) */
  seek(kc, yc) {
    this.k = kc; if (yc) this.y.set(yc); else this.y.fill(0);
    this.b = blockAtTime(this.seq, kc * this.dt); this.gb = -1;
    for (let a = 0; a < 3; a++) this.G[a] = this.gAt(a, kc); // G[kc]
    this.k = kc + 1;
  }
  gAt(a, k) { // physical gradient (Hz/m) at sample k, from the block containing t = k·dt
    const seq = this.seq, bs = seq.blockStart, t = k * this.dt;
    let b = this.b; while (b < seq.nb - 1 && bs[b + 1] <= t + 1e-12) b++; while (b > 0 && bs[b] > t + 1e-12) b--;
    if (b !== this.gb) { this.gb = b; const ids = [seq.B.pgx[b], seq.B.pgy[b], seq.B.pgz[b]]; for (let q = 0; q < 3; q++) { this.geo[q] = ids[q] ? geoG(seq, ids[q]) : null; this.ptr[q] = 0; } }
    this.b = b;
    const g = this.geo[a]; if (!g || t >= bs[b + 1] - 1e-12 && b < seq.nb - 1) return 0;
    const r = t - bs[b], gt = g.t, n = g.n;
    if (r < gt[0] - 1e-12 || r > gt[n - 1] + 1e-12) return 0;
    let j = this.ptr[a]; if (j > 0 && gt[j - 1] > r) j = 0;
    while (j < n && gt[j] <= r) j++; this.ptr[a] = j;
    if (j === 0) return g.v[0]; if (j >= n) return g.v[n - 1];
    const ta = gt[j - 1], tb = gt[j]; return tb > ta ? g.v[j - 1] + (g.v[j] - g.v[j - 1]) * (r - ta) / (tb - ta) : g.v[j];
  }
  stimOf(y, out) { // stimulation of every model and axis from the filter states
    const M = this.M;
    for (let m = 0; m < M; m++) {
      let nn = 0;
      for (let a = 0; a < 3; a++) { const c = this.co[m][a], o = m * 9 + a * 3, v = (c.a1 * Math.abs(y[o]) + c.a2 * y[o + 1] + c.a3 * Math.abs(y[o + 2])) * c.sc; out[m * 4 + a] = v; nn += v * v; }
      out[m * 4 + 3] = Math.sqrt(nn);
    }
  }
  /* advance until sample kEnd (exclusive) or until `budget` samples were read; returns true when done.
     sink(k, s): interval k, values s. sinkRun(k0, n, yb): n zero-input intervals from k0, yb = state before them.
     onCk(k, y): state before interval k, for every k that is a multiple of STIM_CK. */
  run(kEnd, sink, sinkRun, budget = Infinity, onCk = null) {
    const seq = this.seq, bs = seq.blockStart, dt = this.dt, M = this.M, y = this.y, G = this.G, s = this.s, co = this.co, B = seq.B;
    kEnd = Math.min(kEnd, this.N + 1); let done = 0;
    const yb = this.yb || (this.yb = new Float64Array(y.length));
    while (this.k < kEnd && done < budget) {
      const k = this.k, t = k * dt;
      let b = this.b; while (b < seq.nb - 1 && bs[b + 1] <= t + 1e-12) b++; this.b = b;
      const kLast = sinkRun ? this.flatUntil(k, kEnd) : -1;
      if (kLast > k) {
        // G[k … kLast] all equal G[k−1] (a flat top, a constant gradient or no gradient): intervals k−1 … kLast−1 have zero input
        const n = Math.min(kLast - k + 1, budget - done);
        if (n > 1) {
          yb.set(y);
          if (onCk) for (let kc = Math.ceil((k - 1) / STIM_CK) * STIM_CK; kc <= k + n - 2; kc += STIM_CK) onCk(kc, this.decayed(yb, kc - (k - 1), this.yTmp2 || (this.yTmp2 = new Float64Array(y.length))));
          this.decayed(yb, n, y);
          sinkRun(k - 1, n, yb);
          this.k += n; done += n; continue;
        }
      }
      if (onCk && (k - 1) % STIM_CK === 0) onCk(k - 1, y);
      // one sample: interval k−1 with u = (G[k] − G[k−1]) / dt
      const reuse = this.gkK === k;
      for (let a = 0; a < 3; a++) {
        const g = reuse ? this.gk[a] : this.gAt(a, k), u = (g - G[a]) / dt, au = Math.abs(u); G[a] = g;
        for (let m = 0; m < M; m++) { const c = co[m][a], o = m * 9 + a * 3; y[o] = c.al1 * u + c.b1 * y[o]; y[o + 1] = c.al2 * au + c.b2 * y[o + 1]; y[o + 2] = c.al3 * u + c.b3 * y[o + 2]; }
      }
      this.stimOf(y, s); sink(k - 1, s);
      this.k++; done++;
    }
    return this.k >= kEnd;
  }
  /* last sample K ≥ k such that the gradient at samples k … K equals G (the value at k−1) on all three axes, or −1.
     Per axis: the piece of the event holding t_k must be flat at that value (or the axis must be off at 0); it lasts
     until the end of that piece (exclusive), and never past the block. */
  flatUntil(k, kEnd) {
    const seq = this.seq, bs = seq.blockStart, dt = this.dt, b = this.b, G = this.G;
    let K = Math.min(kEnd - 1, Math.ceil(bs[b + 1] / dt - 1e-9) - 1);
    if (K <= k) { this.gkK = -1; return -1; }
    const gk = this.gk || (this.gk = new Float64Array(3)); this.gkK = k;
    for (let a = 0; a < 3; a++) gk[a] = this.gAt(a, k); // kept for the per-sample step if this is not flat
    for (let a = 0; a < 3; a++) {
      if (gk[a] !== G[a]) return -1;
      const g = this.geo[a], r = k * dt - bs[b];
      let end;
      if (!g) end = Infinity;
      else {
        const j = this.ptr[a], gt = g.t, n = g.n;
        if (r < gt[0] - 1e-12) end = gt[0];                      // before the event: 0 until it starts
        else if (j >= n) end = r > gt[n - 1] + 1e-12 ? Infinity : gt[n - 1]; // after it: 0 to the end of the block
        else if (j > 0 && g.v[j - 1] === g.v[j]) end = gt[j];      // on a flat piece
        else return -1;
      }
      if (end !== Infinity) K = Math.min(K, Math.ceil((bs[b] + end) / dt - 1e-9) - 1);
      if (K <= k) return -1;
    }
    return K;
  }
  decayed(y0, n, out) { // filter state after n zero-input intervals from y0
    for (let m = 0; m < this.M; m++) for (let a = 0; a < 3; a++) { const c = this.co[m][a], o = m * 9 + a * 3; out[o] = y0[o] * Math.pow(c.b1, n); out[o + 1] = y0[o + 1] * Math.pow(c.b2, n); out[o + 2] = y0[o + 2] * Math.pow(c.b3, n); }
    return out;
  }
  runValue(yb, k0, idx, out) { // stimulation at interval idx of a zero-input run that starts at k0 from state yb
    const tmp = this.yTmp3 || (this.yTmp3 = new Float64Array(yb.length));
    this.decayed(yb, idx - k0 + 1, tmp); this.stimOf(tmp, out); return out;
  }
}

/* ---------- whole-sequence result: min/max bins with pyramids, checkpoints, peaks ---------- */
const STIM_CK = 4096; // samples between checkpoints of the filter state
function stimCreate(seq, models, dt) {
  const N = Math.max(1, Math.round(seq.totalDur / dt)), M = models.length;
  let bin = 16; while (N / bin > 524288) bin *= 2; // at most 2^19 bins
  const nBin = Math.ceil(N / bin), T = M * 4;
  const R = { seq, models, dt, N, M, bin, nBin, mn: new Float32Array(nBin * T).fill(Infinity), mx: new Float32Array(nBin * T).fill(-Infinity),
    ck: new Float64Array((Math.floor(N / STIM_CK) + 1) * M * 9), peak: new Float64Array(T), peakK: new Int32Array(T).fill(-1), doneK: 0, done: false, pyr: null };
  R.pass = new StimPass(seq, models, dt); R.pass.seek(0, null);
  return R;
}
function stimAdd(R, k, s, T) {
  const q = Math.floor(k / R.bin) * T;
  for (let j = 0; j < T; j++) { const v = s[j]; if (v < R.mn[q + j]) R.mn[q + j] = v; if (v > R.mx[q + j]) R.mx[q + j] = v; if (v > R.peak[j]) { R.peak[j] = v; R.peakK[j] = k; } }
}
/* run up to `budget` samples; returns the fraction done */
function stimStep(R, budget) {
  const P = R.pass, T = R.M * 4, S9 = R.M * 9, va = new Float64Array(T), vb = new Float64Array(T);
  const sink = (k, s) => stimAdd(R, k, s, T);
  const sinkRun = (k0, n, yb) => { // values fall monotonically: per bin, the maximum at its first interval, the minimum at its last
    for (let kb = k0; kb < k0 + n;) {
      const ke = Math.min(k0 + n, (Math.floor(kb / R.bin) + 1) * R.bin);
      stimAdd(R, kb, P.runValue(yb, k0, kb, va), T); stimAdd(R, ke - 1, P.runValue(yb, k0, ke - 1, vb), T);
      kb = ke;
    }
  };
  const onCk = (k, y) => R.ck.set(y, (k / STIM_CK) * S9);
  if (P.run(R.N + 1, sink, sinkRun, budget, onCk)) { R.done = true; stimPyramid(R); }
  R.doneK = P.k - 1;
  return Math.min(1, R.doneK / R.N);
}
function stimPyramid(R) {
  const T = R.M * 4, L = [{ size: 1, mn: R.mn, mx: R.mx, n: R.nBin }];
  while (L[L.length - 1].n > 4) {
    const p = L[L.length - 1], n = Math.ceil(p.n / 4), mn = new Float32Array(n * T).fill(Infinity), mx = new Float32Array(n * T).fill(-Infinity);
    for (let i = 0; i < p.n; i++) { const q = (i >> 2) * T, o = i * T; for (let j = 0; j < T; j++) { if (p.mn[o + j] < mn[q + j]) mn[q + j] = p.mn[o + j]; if (p.mx[o + j] > mx[q + j]) mx[q + j] = p.mx[o + j]; } }
    L.push({ size: p.size * 4, mn, mx, n });
  }
  R.pyr = L;
}
/* exact values for intervals kA..kB, recomputed from the nearest checkpoint: each(k, s) per interval, or, for a run of
   zero-input intervals, eachRun(a, b, value) with value(k) giving s at any interval of the run (falling monotonically) */
function stimExact(R, kA, kB, each, eachRun) {
  const S9 = R.M * 9; kA = Math.max(0, kA); kB = Math.min(kB, R.doneK - 1, R.N - 1); if (kB < kA) return;
  const c = Math.floor(kA / STIM_CK), P = new StimPass(R.seq, R.models, R.dt), T = R.M * 4, out = new Float64Array(T);
  P.seek(c * STIM_CK, R.ck.subarray(c * S9, c * S9 + S9));
  const sink = (k, s) => { if (k >= kA && k <= kB) each(k, s); };
  const sinkRun = (k0, n, yb) => {
    const a0 = Math.max(k0, kA), a1 = Math.min(k0 + n - 1, kB); if (a1 < a0) return;
    const ybc = Float64Array.from(yb), val = k => P.runValue(ybc, k0, k, out);
    if (eachRun) eachRun(a0, a1, val); else for (let k = a0; k <= a1; k++) each(k, val(k));
  };
  P.run(kB + 2, sink, sinkRun, Infinity, null);
}
/* maximum of every trace over intervals kA..kB: { v: Float64Array(T), k: Int32Array(T) } */
function stimRangeMax(R, kA, kB) {
  const T = R.M * 4, v = new Float64Array(T).fill(-Infinity), kk = new Int32Array(T).fill(-1);
  stimExact(R, kA, kB, (k, s) => { for (let j = 0; j < T; j++) if (s[j] > v[j]) { v[j] = s[j]; kk[j] = k; } },
    (a, b, val) => { const s = val(a); for (let j = 0; j < T; j++) if (s[j] > v[j]) { v[j] = s[j]; kk[j] = a; } });
  return { v, k: kk };
}

/* ---------- the pass in a worker ----------
   The page sends only what the model needs: block start times, the physical gradient ids of every block and the
   geometry of each distinct gradient (pre-filled into the geometry cache, so StimPass runs unchanged). */
function stimJobPack(seq) {
  const B = seq.B, used = new Set();
  for (const col of ['pgx', 'pgy', 'pgz']) { const a = B[col]; for (let i = 0; i < seq.nb; i++) if (a[i]) used.add(a[i]); }
  const geo = {}; for (const id of used) { const g = geoG(seq, id); geo[id] = { t: g.t, v: g.v, n: g.n, min: g.min, max: g.max }; }
  return { blockStart: seq.blockStart, nb: seq.nb, totalDur: seq.totalDur, pgx: B.pgx, pgy: B.pgy, pgz: B.pgz, geo };
}
function stimJobRun(d, progress) {
  const seq = { blockStart: d.blockStart, nb: d.nb, totalDur: d.totalDur, B: { pgx: d.pgx, pgy: d.pgy, pgz: d.pgz }, geo: { g: d.geo }, grad: new Map(), warnings: [] };
  const R = stimCreate(seq, d.models, d.dt); let last = Date.now();
  while (!R.done) { stimStep(R, 200000); if (progress && Date.now() - last > 150) { last = Date.now(); progress(R.doneK / R.N); } }
  return { N: R.N, M: R.M, bin: R.bin, nBin: R.nBin, mn: R.mn, mx: R.mx, ck: R.ck, peak: R.peak, peakK: R.peakK, pyr: R.pyr.map(L => ({ size: L.size, mn: L.mn, mx: L.mx, n: L.n })) };
}
if (typeof module !== 'undefined' && module.exports) Object.assign(module.exports, { SAFE_PARAMS, SAFE_UNITS, SAFE_LIB, safeHwCheck, safeExample, safeAscMode, safeAscInclude, safeFromAsc, safeFromAscFiles, safeMerge, safeHwString, sha256hex, safeLibMatch, stimCoeffs, StimPass, stimCreate, stimStep, stimExact, stimRangeMax, stimJobPack, stimJobRun, STIM_CK });


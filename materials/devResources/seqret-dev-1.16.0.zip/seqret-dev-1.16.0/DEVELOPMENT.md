# Seqret development guide

This document explains how Seqret is built. It covers the design strategy, how it stays fast, how changes are validated and how releases are made. It is written for developers and for LLM coding assistants. The details are specific to version 1.16.0; check them against the code when in doubt, since the code is the ground truth.

## 1. What Seqret is, and the constraints that shape it

Seqret is a viewer for Pulseq `.seq` files (formats 1.2–1.5). It ships as **one self-contained HTML file** with no install, no server and no network requests. It works offline, opened straight from disk. The following constraints are deliberate; keep them:

- **One file, no dependencies.** There are no frameworks, no CDN libraries and no web fonts; the page uses the operating system's interface font. Everything is plain JavaScript, Canvas 2D and WebGL2.
- **Files never leave the machine.** They are read with the File API (or the File System Access API in Chrome/Edge, for Reload).
- **Large files must work.** The practical ceiling is ~100 MB, about a million blocks. Beyond 250 MB the page refuses the file.
- **Physics shown to the user must be right, or clearly labelled approximate.** The image simulation is illustrative, but the diagram, the k-space, the stimulation and the slice geometry are checked against reference implementations (section 7).
- **The interface stays responsive.** Heavy work runs in workers or yields to the browser. The page never freezes.

## 2. Layout and build

```
src/template.html   skeleton with {{VERSION}} {{DATE}} {{STYLE}} {{DEMO}} {{APP}} {{CORE}} {{SIMGL}} {{UI}}
src/style.css       -> <style>
src/demo.seq        -> <script type="text/plain" id="demoSeq">
version.json        -> <script>const APP = {...};</script>   (also fills version/date in the head and header)
src/core.js + sim.js + stim.js  -> <script id="core">   (ALSO the source of every web worker)
src/simgl.js + ui.js            -> <script>              (page only; ui.js is one IIFE)
```

`python3 build.py` writes `dist/seqret.html`. `python3 build.py --check some.html` verifies byte-identity. The package was made by splitting the released 1.16.0, and the rebuild reproduces it exactly.

**The #core rule.** The page creates its workers from the text of `<script id="core">` plus some glue (`WORKER_GLUE` and `POOL_GLUE` in ui.js), through a Blob URL. Everything in core.js, sim.js and stim.js must therefore run without a DOM: no `document`, no `window`, no canvas. It must also be safe to run twice, once on the page and once in each worker. Code that needs the page goes in ui.js. The same property lets the Node tests load the core (`tests/load_core.mjs`).

No source may contain `</script` (the build checks). Keep the `module.exports` lines at the end of each core file; the Node tests read globals through a VM context, not the exports.

## 3. The sequence model (core.js)

The central idea is **that nothing is expanded over the whole timeline.** A 100 MB file can hold 10⁶ blocks and 10⁸ gradient samples. Expanding that into per-sample arrays would cost gigabytes and seconds. Instead:

- **The block table is typed columns.** `seq.B` holds `Uint8/16/32Array` columns for rf, gx, gy, gz, adc and ext ids, plus the physical gradient ids `pgx/pgy/pgz` after rotation. `seq.blockStart` is a `Float64Array` of start times. `[BLOCKS]` is parsed from bytes without creating strings.
- **Event geometry is computed once per unique event.** `geoG`, `geoRfm`, `geoRfp`, `geoSlew` and friends compute it and cache it in `seq.geo`. A sequence has thousands of blocks but few distinct events.
- **Min/max pyramids per channel.** Summaries are kept over 4 (files up to 10⁶ blocks), 16, 256, 4096, 65536 and 1048576 blocks (`buildPyramid`). Drawing a zoomed-out view reads a few summaries per pixel column instead of every block.
- **One pass at load does the rest.** `analyze` computes statistics, the ADC table, labels, ADC types from the flag labels, triggers, rotations and k at block starts. `computeShots` and `computeVolumes` group blocks into shots (excitation to excitation) and volumes (auto: repetition of the k-space pattern, hashed; or by a label such as SET or REP).
- **Everything else is computed on demand, for the visible range only.** This covers waveform values, k-space samples (`kSamples`), the M0/k-vector lane and slice geometry.

**Load pipeline.** A worker runs `parseSeq → analyze → computeVolumes`, and the md5 check runs in a second worker in parallel. Results come back as transferred typed arrays. Shots are packed into columns (`packShots`), because 10⁶ small objects are slow to clone between threads.

**Pulseq conventions (follow them exactly).**
- k is reset at excitation pulses and mirrored at refocusing pulses, evaluated at the RF centre, as in Pulseq's `calculateKspacePP`.
- For the ROTATIONS extension, G_physical = R·G_logical, with R from the unit quaternion (w, x, y, z). Everything downstream uses physical gradients.
- `freqPPM` and `phasePPM` (Pulseq 1.5) are applied at the Image tab's B0.
- An RF purpose stated in the file is never changed. When it is missing (Pulseq < 1.5, or 'u'), it is inferred from context. A pulse with no readout before the next excitation is a preparation pulse, and an off-resonant pulse without a gradient is a saturation pulse.
- Shape decompression and time shapes follow the Pulseq format specification. Oversampled gradient shapes (1.5) are supported.

## 4. The diagram: how it stays fast

The diagram is redrawn on every pan and zoom, so it has a budget of a few milliseconds per frame on the main thread. These rules came from measurement; don't undo them without measuring again.

1. **Draw per pixel column, from summaries.** `traceChan` merges pyramid buckets and single blocks that fall inside one pixel column from their min/max summaries. Only blocks wider than a column contribute exact vertices. Cost scales with the plot width, not the file size.
2. **Dense traces are spans, not strokes.** Where columns hold many samples, a trace is painted as vertical min–max rectangles. A long anti-aliased polyline that doubles back on itself is among the slowest things a canvas can draw. Sparse stretches stay as paths (`SPAN_MIN`).
3. **Batch canvas calls.** Rectangles of the same style are merged along rows, collected in one `Path2D` and filled once (`rectRun`). Before 1.14.2 a zoomed-out frame made up to 32,000 canvas calls; now it makes at most about 600. Each call costs main-thread time, even when the GPU draws it.
4. **Choose the resolution from the view, not from timing.** Traces use two columns per CSS pixel on high-density screens only when zoomed in (`chooseTraceR`). An earlier timing-based switch oscillated: a slow frame made it coarse, and the fast coarse frame made it fine again.
5. **Keep decisions per item, not per view.** Block shading is decided per block from its width on screen, fading between 2 and 6 px. Deciding it from how many blocks are in view made it flicker while panning.
6. **Redraw only what changed, once per animation frame.** `request()` and `requestOverlay()` coalesce redraws into one `requestAnimationFrame`. The crosshair and values live on a separate overlay canvas, so moving the mouse does not redraw the traces. Canvases are resized only when their size really changes; a readout that wrapped to two lines once caused a resize/redraw loop.
7. **k-space.** ADC points are written straight into a pixel buffer, and the path is simplified in screen space. Display caps are 500,000 points and 200,000 path vertices (`K_MAX_PTS`, `K_MAX_PATH`); more is invisible at this size. Nothing is redrawn when nothing changed.
8. **Long passes run in workers and are drawn from binned results.** The stimulation lanes are an example: the worker returns min/max bins with pyramids, and the page draws their envelope.

**Measuring.** Use the frame-time panel (Shift+D, or ⋯ › Show frame times) in a **normal, GPU-accelerated browser on a real machine**. It shows Seqret's own time per frame and per lane, and the frame rate while the view moves.

**Do not tune drawing with headless-browser timings.** Headless Chromium renders in software (SwiftShader), and its costs are distributed differently. Version 1.14.0 was tuned that way: overview bars, stretched previews while zooming, banded label rows. It looked worse and ran worse in real use and was reverted in 1.14.1. Headless tests are for correctness only.

For a drawing change, report before and after numbers from Shift+D at three zoom levels: whole file, one volume, one shot. Use the demo repeated to about 1M blocks (section 8), and the same window size.

## 5. The image simulation (sim.js, simgl.js)

**The strategy is a forward model at the sequence's own samples.** For every imaging ADC sample j of the chosen image, the signal is computed analytically at that sample's actual k-space position and time. This lets T2/T2′ decay during the readout, fat shift, off-resonance, EPI ghosts from timing, eddy-current k errors and diffusion weighting all emerge from the sequence itself, rather than being painted on.

- **Phantoms.** The phantoms are 3D and analytic: a Shepp–Logan-style head with nose, neck and brainstem, and an abdomen. Each image is a section at the slice the sequence excites. The position comes from the RF frequency and the slice gradient, the thickness from the RF bandwidth, and the orientation from the gradient during the pulse and the principal axes of k-space. The section's regions have closed-form 2D Fourier transforms (ellipse: Bessel J1; rectangle: sinc). Overlapping regions subtract the double-counted signal exactly.
- **Signal model.** The model is documented in the header of sim.js. It covers PD, steady-state Mz for flip angle and TR, inversion cycles, frequency-selective saturation, T2 and T2′ with the dephasing time τ flipped at each refocusing pulse, six-peak fat, and b-values from the gradient waveform. Optional effects are noise scaled with bandwidth, an air bubble (3D dipole field) and illustrative eddy currents. There is no spin history beyond that; this is deliberate and stated in the UI.
- **Reconstruction.** Cartesian data is evaluated exactly on the grid, with the sample timing interpolated. Non-Cartesian data uses the exact inverse Fourier sum. Lines that were not acquired (parallel imaging, partial Fourier) are either filled as an ideal reconstruction would or zero-filled. Multiple echoes per shot are split into separate images. Readout oversampling is detected and either cropped or shown in full.

**How it stays fast and responsive.**
1. **Separate work by cost, and make the expensive part exact only where it matters.** The air bubble is the example. Near the sphere it uses an exact direct sum over refined surface patches. Elsewhere it uses a power series in the phase through oversampled FFT maps (at most 1024²). Rows that share a timing pattern share one FFT. This made it 20–400× faster and more accurate than the first version.
2. **Split work into tasks and run them in parallel.** The heavy kernels are phantom evaluation, the direct inverse sum and the bubble direct sum. They are expressed as `SIM_TASKS`, run on a pool of workers (cores − 1, at most 8), and chunked so the page only does setup.
3. **Use the GPU when there is a real one.** simgl.js implements the same tasks as WebGL2 fragment shaders, with inputs in RGBA32F textures and outputs read back as floats. Long sums run in passes and are accumulated in double precision on the CPU. Any failure falls back to the CPU: no WebGL2, software-emulated WebGL, no float render targets, or an error mid-run. GPU and CPU images must agree to within one grey level. The info line tells the user which engine ran.
4. **Never block the page.** Long loops yield (`tick`). Requests are debounced (200 ms) and cancelled by a run id when the user moves on. The last 12 images are cached, so stepping back is instant.
5. **Use approximations only with numbers.** Every fast method has an exact reference in the code ("exact references (slow; used to test the fast methods)"). A new approximation needs a stated error against it. For example, the FFT maps for non-Cartesian data are within 1% of the exact sum.

The 3D view is per-pixel ray casting through the analytic ellipsoids, giving exact entry/exit and real occlusion. It runs on WebGL2, with the same algorithm on the CPU as a fallback.

For a simulation change, report the time for the demo image and for a large spiral. Report both the CPU path (`node tests/test_core.mjs --bench`, one thread) and the page (info line), and check that the image is unchanged where it should be.

## 6. Nerve stimulation (stim.js)

This is the SAFE model (Hebrank & Gebhardt), ported from safe_pns_prediction (F. Szczepankiewicz, T. Witzel), including:
- `.asc` parsing (`safe_hw_from_asc`, `$INCLUDE`)
- the hardware check (`safe_hw_check`)
- the library of known systems, matched by SHA-256 of the parameters (`safe_hw_verify`)

It is computed on the gradient raster from the physical gradients over the whole sequence, in a worker. The result is kept as min/max bins with pyramids, plus checkpoints, so any range can be redrawn or re-evaluated exactly (`stimExact`) without rerunning the whole pass. On one thread, the pass for a 1-hour sequence takes minutes, which is why it must stay in the worker.

## 7. Validation: every change is checked against something independent

Being "plausible" is not enough; each change needs an independent check. The references used so far:

| What | Reference | Agreement reached |
|---|---|---|
| File reading, gradient waveforms, k-space | PyPulseq (`pip install pypulseq`): its test-suite `.seq` files; `seq.calculate_kspace()`, waveforms | ≤ 1e-7 relative |
| RF shape as real/imaginary | PyPulseq `rf.signal` | 1e-7 of peak |
| M0 / k-vector lane | PyPulseq gradients, their integral, RF times | ≤ 1e-7 relative |
| Rotations | same sequence with and without ROTATIONS: rotated k equals k of the rotated sequence | quaternion rounding |
| Nerve stimulation | safe_pns_prediction in Octave (`safe_gwf_to_pns`) on the same gradients | ~1e-15 relative |
| md5 | RFC 1321 vectors; the files' own signatures | exact |
| GPU simulation | CPU path | within 1 grey level |
| Fast simulation methods | exact references in sim.js | stated per method |

To get the references:

    pip install pypulseq numpy
    git clone https://github.com/imr-framework/pypulseq          # test sequences: tests/expected_output/*.seq
    git clone https://github.com/filip-szczepankiewicz/safe_pns_prediction
    # Octave: addpath safe_pns_prediction; then safe_gwf_to_pns(gwf, rf, dt, hw, 0)

A practical way to compare is to load the core in Node (as `tests/load_core.mjs` does), dump arrays to JSON, and compare with numpy. Keep such comparison scripts in `tests/` when they are small. Do not commit third-party `.seq` files; fetch them.

Automated tests:
- `node tests/test_core.mjs` covers the core and the demo's counts, and runs the simulation and stimulation. Extend it with every bug fix: first a failing test, then the fix.
- `python3 tests/test_browser.py [--seq files...] [--shots DIR]` loads the page, visits every tab, zooms and pans, and fails on any page or console error. Screenshots are for review by eye.

The original development used about 25 Playwright scenarios (tab linking, reload, settings migration, stepping, the specifications dialog, and more). Only the smoke test is included here. Grow it back as features are touched.

## 8. Stress tests (make the files, do not store them)

Two generators live in `tools/`. Neither output is included in the package: they are large and quick to regenerate.

**`tools/stress_repeat.py`** needs only the standard library. It repeats the block table of any small file. The events are shared, so it grows only about 30 bytes per block, and the md5 signature is rewritten.

    python3 tools/stress_repeat.py src/demo.seq --blocks 1000000 -o stress_1M.seq   # ~24 MB, ~1M blocks
    python3 tools/stress_repeat.py src/demo.seq --mb 100 -o stress_100MB.seq          # ~4M blocks
    python3 tools/stress_repeat.py src/demo.seq -n 50 -o stress_x50.seq

Use it for loading, pyramids and drawing at scale, shot and volume detection, and the stimulation pass. It is not realistic: every copy repeats the same volumes and labels.

**`tools/make_stress_seq.py`** uses PyPulseq and writes realistic files that pass PyPulseq's timing check.

    python3 tools/make_stress_seq.py epi    -o stress_epi.seq    --slices 30 --volumes 100 --matrix 64      # fMRI-like, many shots
    python3 tools/make_stress_seq.py gre3d  -o stress_gre3d.seq  --matrix 128 --partitions 64               # 3D, RF spoiling
    python3 tools/make_stress_seq.py spiral -o stress_spiral.seq --interleaves 48 --slices 20 --volumes 10  # arbitrary gradients

Scale the counts up for bigger files; PyPulseq takes roughly 1–3 minutes per million blocks.

Then run:

    node --max-old-space-size=8000 tests/test_core.mjs --bench stress_1M.seq [--no-sim] [--no-stim]
    python3 tests/test_browser.py --seq stress_epi.seq stress_spiral.seq --shots tests/out

Reference points from Node on one thread, in a container (for a sense of scale, not targets):
- demo: load about 0.2 s, image about 1.5 s
- 1M blocks (24 MB): load about 5 s, volume detection about 1.3 s, stimulation pass about 90 s

In the page, the stimulation pass runs in the background and the diagram is usable immediately.

## 9. Interface conventions

- **State.** State lives in the object `S` in ui.js. Persistent preferences are listed in `PREF_KEYS` and kept in localStorage under `seqret-settings`, alongside `seqret-theme` and `seqret-safe`. Keys from the earlier name (`seqview-*`) are read when the new ones are absent. If you rename or restructure a setting, migrate it; don't silently reset users.
- **Tab linking.** Linked tabs synchronise the same time, shot or volume through `BroadcastChannel('seqret-link')`.
- **Layout.** The top bar holds only the Volume, Shot and Block steppers and the zoom buttons. Everything else goes into panels (Display, ⋯, options buttons) that close on outside click or Escape. Keys pressed inside a panel don't act on the diagram.
- **Wording.** User-facing text is short, plain and exact. It uses units and numbers, and says when something is approximate. Tooltips hold the full explanations.
- **Every release gets a user-facing changelog entry** in `version.json`, shown in the About dialog. Write what changed for the user, what was fixed and how it was checked. Mark reverts as reverts.

## 10. Release procedure

1. Edit `src/`, then `python3 build.py`.
2. Run `node tests/test_core.mjs` and `python3 tests/test_browser.py`. For physics changes, also run the relevant comparison from section 7. For performance changes, compare Shift+D numbers in a real browser (section 4).
3. In `version.json`, bump `version` (semantic: patch for fixes, minor for features), set `date`, and add a changelog entry **at the top** of `changelog`. The build puts the version into the head, header and About dialog.
4. Rebuild, and open `dist/seqret.html` by hand in a normal browser. Check the changed feature with the demo and with one real sequence.
5. The deliverables are `dist/seqret.html` and `matlab/seqret.m`; `python3 build.py --zip DIR` also writes the development package `seqret-dev-<version>.zip` (top folder `seqret-dev-<version>/`; generated stress files and test output are left out). Never hand out two different packages with the same version: bump the version first. `seqret.m` looks for `seqret.html` next to itself, then `../dist/seqret.html`.

## 11. Working with an LLM on Seqret: the method that worked

- **Short iterations.** Implement one feature or fix, run the tests, and hand the built page to the person for review in their own browser. Wait for feedback before building on it. Terse feedback such as "still does not work for this file" means: reproduce it with that file, then fix it.
- **The person designs, the LLM implements.** Propose options when a design choice is open, but don't add features, toggles or UI that were not asked for.
- **Ask for the failing file.** Most bugs were specific to real sequences: labels set after the excitation, dummy scans without ADCs, saturation pulses above 90°, ppm offsets, oversampled readouts. Turn each one into a test case, generated or reduced, never a third-party file committed to the repository.
- **State approximations.** An approximation is acceptable when the UI says it is approximate and it keeps the page responsive. An unstated approximation is a bug.
- **Protect validated code.** The parser, k-space, rotations, stimulation and slice geometry were checked against references. If you touch them, re-run the comparison and report the numbers.
- **Revert quickly.** If a change looks or runs worse in the person's real use, revert it first and analyse afterwards (1.14.0 → 1.14.1).
- **Keep this document current.** Update it when architecture, conventions or known issues change.

## 12. Known issues and open items

- **3D slab-selective scans can get the wrong image plane.** This happens when the partitions span a larger k-range than the phase-encode lines, for example a 64×64 matrix with 8 partitions in a 24 mm slab. The simulation then images kx–kz instead of kx–ky, and the geometry becomes inconsistent: one in-plane axis equals the slab normal. The cause is in `simulateImage` in sim.js. When the two phase-encoded axes have similar spread, the second image axis is taken as the one with the larger k spread, ignoring the slab-select direction. A likely fix is to exclude the slice/slab-select axis (from the gradient during the RF pulse) from the candidates. Reproduce it with `tools/make_stress_seq.py gre3d --matrix 64 --partitions 8`.
- **An outdated comment.** The header comment of sim.js still says "the image plane is (kx, ky)". The plane is actually chosen from the principal axes of k-space.
- **Reload in other browsers.** Reload follows changes on disk only in Chrome and Edge (File System Access API). Other browsers keep the file as it was given.
- **Embedded files.** Files embedded by `seqret.m` have no Reload.
- **seqret.m.** In this package it was rewritten from its documented behaviour and tested in Octave only. Test the MATLAB path (`web(..., '-browser')`) and the `mr.Sequence` input before relying on it.
- **Windows helper.** ui.js mentions a Windows "open with Seqret" helper, which uses the same embedding as seqret.m. It is not part of this package.
- **Scope of the simulation.** The simulation has no realistic slice profiles, shows one partition for 3D scans, and uses illustrative eddy-current presets. These are known and accepted simplifications, stated in the UI.

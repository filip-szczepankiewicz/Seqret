#!/usr/bin/env python3
"""Build dist/seqret.html from src/ and version.json (Python 3 standard library only).

    python3 build.py                 # writes dist/seqret.html
    python3 build.py --check FILE    # also verifies the build is byte-identical to FILE
    python3 build.py --zip [DIR]     # also writes the development package DIR/seqret-dev-<version>.zip

The page is one self-contained file. The #core script (core.js + sim.js + stim.js) is also the source of
the web workers (the page turns its text into a Blob URL), so it must not touch the DOM.
"""
import json, sys, pathlib, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
SRC = ROOT / 'src'

def read(name):
    return (SRC / name).read_text(encoding='utf-8')

def build():
    app = json.loads((ROOT / 'version.json').read_text(encoding='utf-8'))
    for name in ('demo.seq', 'core.js', 'sim.js', 'stim.js'):
        if '</script' in read(name).lower():
            sys.exit(f'{name} contains "</script", which would end its script element early')
    core = read('core.js') + read('sim.js') + read('stim.js')
    parts = {
        '{{VERSION}}': app['version'],
        '{{DATE}}': app['date'],
        '{{STYLE}}': read('style.css'),
        '{{DEMO}}': read('demo.seq'),
        '{{APP}}': json.dumps(app, ensure_ascii=False),
        '{{CORE}}': core,
        '{{SIMGL}}': read('simgl.js'),
        '{{UI}}': read('ui.js'),
    }
    html = read('template.html')
    # replace the code placeholders last, so that "{{...}}" inside code is never substituted
    for key in ('{{VERSION}}', '{{DATE}}'):
        html = html.replace(key, parts[key])
    for key in ('{{STYLE}}', '{{DEMO}}', '{{APP}}', '{{CORE}}', '{{SIMGL}}', '{{UI}}'):
        if html.count(key) != 1:
            sys.exit(f'template.html must contain {key} exactly once')
        a, b = html.split(key)
        html = a + parts[key] + b
    return html

if __name__ == '__main__':
    html = build()
    out = ROOT / 'dist' / 'seqret.html'
    out.parent.mkdir(exist_ok=True)
    out.write_text(html, encoding='utf-8', newline='\n')
    print(f'wrote {out.relative_to(ROOT)} ({len(html.encode("utf-8")) / 1e3:.0f} kB)')
    if '--check' in sys.argv:
        ref = pathlib.Path(sys.argv[sys.argv.index('--check') + 1]).read_bytes()
        mine = out.read_bytes()
        if ref == mine:
            print('identical to', sys.argv[sys.argv.index('--check') + 1])
        else:
            i = next((k for k in range(min(len(ref), len(mine))) if ref[k] != mine[k]), min(len(ref), len(mine)))
            sys.exit(f'differs from the reference at byte {i}: ...{mine[max(0, i - 60):i + 60]!r}')

    if '--zip' in sys.argv:
        k = sys.argv.index('--zip') + 1
        outdir = pathlib.Path(sys.argv[k]) if k < len(sys.argv) and not sys.argv[k].startswith('--') else ROOT.parent
        ver = json.loads((ROOT / 'version.json').read_text(encoding='utf-8'))['version']
        name = f'seqret-dev-{ver}'
        zpath = outdir / f'{name}.zip'
        skip = {'__pycache__', 'node_modules', '.git'}
        with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
            for f in sorted(ROOT.rglob('*')):
                rel = f.relative_to(ROOT)
                if f.is_dir() or skip & set(rel.parts) or rel.parts[:2] == ('tests', 'out') or f.suffix == '.zip':
                    continue
                if f.suffix == '.seq' and rel != pathlib.Path('src/demo.seq'):
                    continue  # stress-test files are generated, not packaged
                z.write(f, f'{name}/{rel.as_posix()}')
        print(f'wrote {zpath}')

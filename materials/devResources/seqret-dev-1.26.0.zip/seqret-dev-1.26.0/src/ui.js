(function () {
'use strict';
const $ = s => document.querySelector(s);
const S = {
  seq: null, name: '', t0: 0, t1: 1, sel: -1, hoverT: null, autoY: false,
  gUnit: 'mT', rfUnit: 'uT', tab: 'seq', diagRes: 'high', lineMode: 'exact', sideHidden: false,
  vis: { labels: true, adc: false, rfMag: true, rfPh: false, gx: true, gy: true, gz: true, slew: false, m0: false, pns: false, cns: false },
  stimNorm: true, combineG: true, rfMode: 'mag', kColor: 'order', linkMode: 'off',
  sim: { eddy: 'off', slicePos: true, show3d: true, orient: 'ax', phantom: 'head', B0: 3, t1: true, t2: true, fatShift: true, diffusion: true, bubble: false, noise: false, fill: true, crop: true, view: 'mag' }, labelsPref: true, volPref: 'auto', shotMode: 'exc', volMode: 'auto', vols: [], selKind: null, hist: [],
  kRange: 'shot', kProj: 'xy', kTraj: true, kR: null, kZoom: 1, kPan: [0, 0]
};
const LANES = [
  { key: 'adc', label: 'ADC', w: 0.42, col: 'adc' },
  { key: 'rfMag', label: 'RF |B1|', w: 1, col: 'rf', kind: 'pos' },
  { key: 'rfPh', label: 'RF phase', w: 0.62, col: 'ph', kind: 'phase' },
  { key: 'gx', label: 'Gx', w: 1, col: 'gx', kind: 'sym' },
  { key: 'gy', label: 'Gy', w: 1, col: 'gy', kind: 'sym' },
  { key: 'gz', label: 'Gz', w: 1, col: 'gz', kind: 'sym' },
  { key: 'slew', label: 'Slew', w: 1, col: 'gx', kind: 'sym' },
  { key: 'm0', label: 'k-vector', w: 1, col: 'gx', kind: 'sym' },
  { key: 'pns', label: 'PNS', w: 0.9, col: 'muted', kind: 'pos', stim: 'pns' },
  { key: 'cns', label: 'CNS', w: 0.9, col: 'muted', kind: 'pos', stim: 'cns' },
  { key: 'labels', label: 'Labels', w: 0, col: 'ink', fixed: true }
];
const TYPE_COL = ['adc', 'ref', 'refima', 'noise', 'nav'];
const TYPE_NAME = ['imaging', 'reference', 'reference + imaging', 'noise', 'navigator'];
const TYPE_RANK = [1, 4, 3, 5, 2]; // which type wins a pixel column when zoomed out
const FLAG_COL = { NAV: 'nav', REF: 'ref', NOISE: 'noise', IMA: 'adc' };
function labelRows() {
  const s = S.seq, rows = [];
  if (s.adcBlocks.length) rows.push({ kind: 'type', name: 'ADC type' });
  for (const tr of s.labels) rows.push({ kind: tr.flag ? 'flag' : 'count', name: tr.name, tr });
  return rows;
}
function labelsLaneH(availH) {
  const n = labelRows().length; if (!n) return 0;
  const rh = Math.max(11, Math.min(18, (availH * 0.42 - 6) / n));
  return n * rh + 6;
}
const GLANE = { key: 'g', label: 'Gradients', w: 1.9, col: 'gx', kind: 'sym' };
const USE = { e: 'excitation', r: 'refocusing', i: 'inversion', s: 'saturation', p: 'preparation', o: 'other', u: 'undefined' };
let C = {}; // resolved colors
function readColors() {
  const cs = getComputedStyle(document.documentElement);
  for (const k of ['bg', 'plot', 'ink', 'muted', 'faint', 'line', 'line-soft', 'c-rf', 'c-ph', 'c-gx', 'c-gy', 'c-gz', 'c-adc', 'c-ref', 'c-refima', 'c-noise', 'c-nav', 'sel', 'shade'])
    C[k.replace('c-', '')] = cs.getPropertyValue('--' + k).trim();
  C.font = cs.getPropertyValue('--font');
}

/* ---------- units ---------- */
const gF = () => S.gUnit === 'mT' ? 1 / (GAMMA * 1e-3) : 1e-3;
const gU = () => S.gUnit === 'mT' ? 'mT/m' : 'kHz/m';
const sF = () => S.gUnit === 'mT' ? 1 / GAMMA : 1e-6;
const sU = () => S.gUnit === 'mT' ? 'T/m/s' : 'kHz/m/ms';
const rF = () => S.rfUnit === 'uT' ? 1e6 / GAMMA : 1;
const rU = () => S.rfUnit === 'uT' ? 'µT' : 'Hz';
function laneFactor(k) { return k === 'rfMag' ? rF() : (k === 'rfPh' || k === 'adc') ? 1 : k === 'slew' ? sF() : k === 'm0' ? mF() : gF(); }
function laneUnit(k) { return k === 'rfMag' ? rU() : k === 'rfPh' ? 'rad' : k === 'slew' ? sU() : k === 'adc' ? '' : k === 'm0' ? mU() : gU(); }
const mF = () => 1; // k-vector: ∫G dt with G in Hz/m, in 1/m whatever the gradient unit
const mU = () => '1/m';

function fmt(v, d = 3) {
  if (v === 0) return '0';
  if (!isFinite(v)) return '–';
  const a = Math.abs(v);
  if (a >= 1e5 || a < 1e-3) return v.toExponential(2);
  const p = Math.max(0, d - 1 - Math.floor(Math.log10(a)));
  return v.toFixed(Math.min(p, 6));
}
function fmtT(s) { // seconds -> auto string
  const a = Math.abs(s);
  if (a >= 1) return fmt(s, 5) + ' s';
  if (a >= 1e-3) return fmt(s * 1e3, 5) + ' ms';
  return fmt(s * 1e6, 4) + ' µs';
}
const us = s => fmt(s * 1e6, 5) + ' µs';

/* ---------- search helpers ---------- */
function lb(a, x, n = a.length) { let lo = 0, hi = n; while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] < x) lo = m + 1; else hi = m; } return lo; }
function ub(a, x, n = a.length) { let lo = 0, hi = n; while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] <= x) lo = m + 1; else hi = m; } return lo; }
function blockAt(t) { const s = S.seq; if (!s) return -1; return blockAtTime(s, t); }

/* ---------- canvas setup ---------- */
const plot = $('#plot'), ovl = $('#ovl'), ov = $('#ov'), kc = $('#kc'), ic = $('#ic'), i3 = $('#i3');
const pctx = plot.getContext('2d'), octx = ovl.getContext('2d'), vctx = ov.getContext('2d'), kctx = kc.getContext('2d'), ictx = ic.getContext('2d'), i3ctx = i3.getContext('2d');
let IW = 0, I3W = 0, I3H = 0;
let W = 0, H = 0, OW = 0, OH = 0, KW = 0, dpr = 1;
/* pixel density of the diagram and the overview (pdpr): the screen's (dpr) when sharp; at most 1 when fast (Display ›
   Diagram resolution), which on a high-density screen draws a quarter of the pixels at 2× and lets the browser scale
   them up. For browsers whose drawing is limited by the number of pixels. The cursor overlay, k-space and image stay at
   the screen's density. PNG export always draws at the screen's density (PNG_FULL). */
let pdpr = 1, PNG_FULL = false;
const GUT = 84, AXH = 26, SHOTH = 20;
const shotsOn = () => S.seq && S.shotMode !== 'off' && S.seq.shots.length > 0;
const volsOn = () => S.seq && S.volMode !== 'off' && S.vols.length > 0;
const volY = () => 4, shotY = () => 4 + (volsOn() ? SHOTH + 4 : 0);
const topH = () => (shotsOn() ? shotY() + SHOTH + 8 : volsOn() ? volY() + SHOTH + 8 : 6);
function sizeCanvas(cv, ctx, w, h, d = dpr) { // only touch the canvas when its size really changes (resizing clears it)
  const W2 = Math.round(w * d), H2 = Math.round(h * d);
  if (cv.width !== W2 || cv.height !== H2) { cv.width = W2; cv.height = H2; }
  ctx.setTransform(d, 0, 0, d, 0, 0);
}
function resize() {
  dpr = window.devicePixelRatio || 1;
  pdpr = PNG_FULL || (BENCH.quality || S.diagRes) !== 'fast' ? dpr : Math.min(1, dpr);
  const r = $('#plotwrap').getBoundingClientRect(); W = r.width; H = r.height;
  sizeCanvas(plot, pctx, W, H, pdpr); sizeCanvas(ovl, octx, W, H);
  const o = ov.parentElement.getBoundingClientRect(); OW = o.width; OH = o.height;
  sizeCanvas(ov, vctx, OW, OH, pdpr);
  const kk = kc.parentElement.getBoundingClientRect(); KW = kk.width;
  if (KW > 0) sizeCanvas(kc, kctx, KW, KW);
  const ii = ic.parentElement.getBoundingClientRect(); if (ii.width > 0 && Math.abs(ii.width - IW) > 0.5) { IW = ii.width; sizeCanvas(ic, ictx, IW, IW); drawImg(); }
  const j3 = i3.parentElement.getBoundingClientRect(); if (j3.width > 0 && (Math.abs(j3.width - I3W) > 0.5 || Math.abs(j3.height - I3H) > 0.5)) { I3W = j3.width; I3H = j3.height; sizeCanvas(i3, i3ctx, I3W, I3H); drawSlice3D(); }
  ovCache = null; kInvalidate(); request(); requestK();
}
new ResizeObserver(resize).observe($('#plotwrap'));
new ResizeObserver(resize).observe(kc.parentElement);
new ResizeObserver(resize).observe(ic.parentElement);
new ResizeObserver(resize).observe(i3.parentElement);
new ResizeObserver(resize).observe(ov.parentElement);

/* ---------- lane geometry ---------- */
function lanesGeom() {
  const vis = [];
  for (const l of LANES) {
    const isG = l.key === 'gx' || l.key === 'gy' || l.key === 'gz';
    if (isG && S.combineG) { if (!vis.includes(GLANE) && (S.vis.gx || S.vis.gy || S.vis.gz)) vis.push(GLANE); continue; }
    if (S.vis[l.key]) vis.push(l.key === 'rfMag' && S.rfMode === 'complex' ? { ...l, kind: 'sym', label: 'RF B1' } : l);
  }
  const tot = vis.reduce((s, l) => s + l.w, 0) || 1, TOP = topH();
  const gap = 8, avail0 = H - AXH - TOP - gap * (vis.length - 1);
  const fixedH = l => l.fixed ? labelsLaneH(avail0) : 0;
  const avail = avail0 - vis.reduce((s, l) => s + fixedH(l), 0);
  let y = TOP; const out = [];
  for (const l of vis) { const h = l.fixed ? fixedH(l) : avail * l.w / tot; out.push({ ...l, y, h }); y += h + gap; }
  return out;
}
function laneChannels(l) {
  if (l.key === 'slew') return [['gx', 'sx'], ['gy', 'sy'], ['gz', 'sz']];
  if (l.key === 'm0') return [['gx', 'mx'], ['gy', 'my'], ['gz', 'mz']];
  if (l.key === 'rfMag' && S.rfMode === 'complex') return [['ph', 'rfIm'], ['rf', 'rfRe']]; // imaginary first: the real part is drawn on top
  if (l.key === 'g') return ['gx', 'gy', 'gz'].filter(k => S.vis[k]).map(k => [k, k]);
  return [[l.col, l.key]];
}
function laneMax(l) {
  const st = S.seq.stats;
  if (l.key === 'rfMag') return st.maxRF;
  if (l.key === 'rfPh') return Math.PI;
  if (l.key === 'adc') return 1;
  if (l.key === 'slew') return Math.max(...st.maxSlew);
  if (l.key === 'm0') { m0Pyramids(S.seq); return S.seq.m0Max; }
  return Math.max(...st.maxG); // shared scale across gradient axes
}

/* ---------- decimating polyline ---------- */
let colMin = new Float64Array(0), colMax, colFirst, colLast, colHas, colBrk;
/* a break inside a column (the k-vector's reset at an excitation): the part before it, emitted before the break */
let preHas = new Uint8Array(0), preMin, preMax, preFirst, preLast, preN, preX, brkPre;
/* times of each column's first, minimum, maximum and last value, and whether they are exact (1.24.0): with them, a
   short feature is drawn through its extremes where they happen (M4, Jugel et al., PVLDB 7(10) 2014), instead of as a
   bar at the column's centre */
let colTf = new Float64Array(0), colTmn, colTmx, colTl, colEx, colRun;
function ensureTimes(n) { if (colTf.length < n) { colTf = new Float64Array(n); colTmn = new Float64Array(n); colTmx = new Float64Array(n); colTl = new Float64Array(n); colEx = new Uint8Array(n); colRun = new Int32Array(n); } }
function ensureCols(n) { if (colMin.length < n) { colMin = new Float64Array(n); colMax = new Float64Array(n); colFirst = new Float64Array(n); colLast = new Float64Array(n); colHas = new Uint8Array(n); colBrk = new Uint8Array(n); } }
function ensurePre(n) { if (preHas.length < n) { preHas = new Uint8Array(n); brkPre = new Uint8Array(n); preMin = new Float64Array(n); preMax = new Float64Array(n); preFirst = new Float64Array(n); preLast = new Float64Array(n); preN = new Float64Array(n); preX = new Float64Array(n); } }
function tracePoints(c, t0, t1, x0, w) {
  // returns flat array [x,y(value),...] with NaN value for pen-up
  const n = c.t.length, pts = []; if (!n) return pts;
  const i0 = Math.max(0, ub(c.t, t0) - 1), i1 = Math.min(n - 1, lb(c.t, t1));
  const sc = w / (t1 - t0);
  const X = t => x0 + (t - t0) * sc;
  if (i1 - i0 < 3 * w) {
    for (let i = i0; i <= i1; i++) pts.push(X(c.t[i]), c.v[i]);
    return pts;
  }
  const nc = Math.ceil(w) + 1; ensureCols(nc); colHas.fill(0, 0, nc); colBrk.fill(0, 0, nc);
  let s = i0, e = i1;
  if (c.t[i0] < t0) { pts.push(X(c.t[i0]), c.v[i0]); s++; }
  const tail = c.t[i1] > t1; if (tail) e--;
  const pyr = c.pyr || (c.pyr = buildPyr(c));
  const col = t => { let k = Math.floor((t - t0) * sc); return k < 0 ? 0 : k >= nc ? nc - 1 : k; };
  let i = s;
  while (i <= e) {
    let used = false;
    for (let L = pyr.length - 1; L >= 0; L--) {
      const P = pyr[L], sz = P.size;
      if (i % sz || i + sz - 1 > e) continue;
      const b = i / sz, k = col(P.t0[b]);
      if (k !== col(P.t1[b])) continue;
      if (P.nan[b]) colBrk[k] = 1;
      if (P.has[b]) {
        if (!colHas[k]) { colHas[k] = 1; colMin[k] = P.mn[b]; colMax[k] = P.mx[b]; colFirst[k] = P.first[b]; }
        else { if (P.mn[b] < colMin[k]) colMin[k] = P.mn[b]; if (P.mx[b] > colMax[k]) colMax[k] = P.mx[b]; }
        colLast[k] = P.last[b];
      }
      i += sz; used = true; break;
    }
    if (used) continue;
    const k = col(c.t[i]), v = c.v[i]; i++;
    if (v !== v) { colBrk[k] = 1; continue; }
    if (!colHas[k]) { colHas[k] = 1; colMin[k] = colMax[k] = colFirst[k] = colLast[k] = v; }
    else { if (v < colMin[k]) colMin[k] = v; if (v > colMax[k]) colMax[k] = v; colLast[k] = v; }
  }
  for (let k = 0; k < nc; k++) {
    const x = x0 + k + 0.5;
    if (colHas[k]) { pts.push(x, colFirst[k], x, colMin[k], x, colMax[k], x, colLast[k]); }
    if (colBrk[k]) pts.push(x, NaN);
  }
  if (tail) pts.push(X(c.t[i1]), c.v[i1]);
  return pts;
}
function buildPyr(c) {
  // min/max summaries over fixed-size vertex buckets, for fast zoomed-out drawing
  const out = [], n = c.t.length;
  for (const sz of [32, 1024, 32768]) {
    const nb = Math.floor(n / sz); if (nb < 2) break;
    const P = { size: sz, t0: new Float64Array(nb), t1: new Float64Array(nb), mn: new Float64Array(nb), mx: new Float64Array(nb), first: new Float64Array(nb), last: new Float64Array(nb), has: new Uint8Array(nb), nan: new Uint8Array(nb) };
    for (let b = 0; b < nb; b++) {
      const a = b * sz; let mn = Infinity, mx = -Infinity, f = NaN, l = NaN, nan = 0;
      for (let i = a; i < a + sz; i++) { const v = c.v[i]; if (v !== v) { nan = 1; continue; } if (f !== f) f = v; l = v; if (v < mn) mn = v; if (v > mx) mx = v; }
      P.t0[b] = c.t[a]; P.t1[b] = c.t[a + sz - 1]; P.mn[b] = mn; P.mx[b] = mx; P.first[b] = f; P.last[b] = l; P.has[b] = f === f ? 1 : 0; P.nan[b] = nan;
    }
    out.push(P);
  }
  return out;
}
/* Channel tracing on the block model: pyramid buckets and single blocks that fall inside one pixel
   column are merged from their min/max summaries; wider blocks contribute exact vertices. */
let cN = new Float64Array(0), cX = new Float64Array(0);
/* columns per CSS pixel for traces, decided per frame from the view and the diagram quality (below). In 'standard'
   (1.14.2-1.17.0): one per screen pixel on high-density screens only when zoomed in (fewer visible blocks than half the
   plot width), one per CSS pixel zoomed out, which was cheaper with Chrome's older renderer (measured in a software-
   rendering test browser; 1.18.0 showed it makes dense stretches look blocky). Never chosen from timing: a timing-based
   switch flipped back and forth between frames (a slow frame made it coarse, the fast coarse frame made it fine). */
let traceR = 1;
/* Display › Diagram quality 'high' (1.18.0): one column per screen pixel at every zoom level, so dense stretches keep
   their shape (thin RF pulses, fine readout trains) instead of widening to whole CSS pixels. Costs more rectangles
   and, zoomed out, up to about twice Seqret's time per frame on small files (15-30 % more on large ones). 'standard' is the drawing of 1.14.2-1.17.0, 'fast' is standard at 1× density. */
function chooseTraceR(t0, t1, pw) {
  const q = BENCH.quality || S.diagRes;
  if (q === 'ultra') return Math.min(6, 2 * Math.max(1, pdpr || 1)); // two columns per screen pixel, drawn anti-aliased
  if (q === 'high') return Math.min(3, Math.max(1, pdpr || 1));
  const bs = S.seq.blockStart, nVis = ub(bs, t1) - lb(bs, t0); return nVis <= pw / 2 ? Math.min(2, Math.max(1, pdpr || 1)) : 1;
}
function traceChan(key, t0, t1, x0, w) {
  const s = S.seq, bs = s.blockStart, pts = [];
  // columns per device pixel (up to 2 per CSS px); one per CSS px while frames are slow (very large files)
  const r = traceR, sc = w / (t1 - t0), nc = Math.ceil(w * r) + 1;
  ensureCols(nc); if (cN.length < nc) { cN = new Float64Array(nc); cX = new Float64Array(nc); }
  colHas.fill(0, 0, nc); colBrk.fill(0, 0, nc); ensurePre(nc); preHas.fill(0, 0, nc); brkPre.fill(0, 0, nc);
  const col = t => { const k = Math.floor((t - t0) * sc * r); return k < 0 ? -1 : k >= nc ? nc : k; };
  let pre = null, post = null;
  ensureTimes(nc); const exactMode = (BENCH.lineMode || S.lineMode) === 'exact';
  // tmn, tmx, tf, tl: times of the minimum, maximum, first and last value (undefined: not known, e.g. from a summary)
  const agg = (k, mn, mx, first, last, x, cnt, tmn, tmx, tf, tl) => {
    const ex = tmn !== undefined;
    if (!colHas[k]) { colHas[k] = 1; colMin[k] = mn; colMax[k] = mx; colFirst[k] = first; colLast[k] = last; cN[k] = cnt; cX[k] = x; colEx[k] = ex ? 1 : 0; if (ex) { colTmn[k] = tmn; colTmx[k] = tmx; colTf[k] = tf; colTl[k] = tl; } }
    else {
      if (mn < colMin[k]) { colMin[k] = mn; if (ex) colTmn[k] = tmn; } if (mx > colMax[k]) { colMax[k] = mx; if (ex) colTmx[k] = tmx; }
      colLast[k] = last; cN[k] += cnt; if (ex) colTl[k] = tl; else colEx[k] = 0;
    }
  };
  const add = (t, v) => {
    const k = col(t);
    if (k < 0) { pre = v === v ? [t, v] : null; return; }
    if (k >= nc) { if (!post && v === v) post = [t, v]; return; }
    if (v !== v) { // a break: keep what the column holds so far as its part before the break, and start anew
      if (colHas[k] && !preHas[k]) { preHas[k] = 1; preMin[k] = colMin[k]; preMax[k] = colMax[k]; preFirst[k] = colFirst[k]; preLast[k] = colLast[k]; preN[k] = cN[k]; preX[k] = cX[k]; colHas[k] = 0; }
      else if (!colHas[k]) brkPre[k] = 1; else colBrk[k] = 1;
      return;
    }
    agg(k, v, v, v, v, x0 + (t - t0) * sc, 1, t, t, t, t);
  };
  const o = {}, tmp = {}, nb = s.nb;
  const b0 = blockAtTime(s, t0), b1 = blockAtTime(s, t1);
  for (let b = b0; b <= b1;) {
    const ka = col(bs[b]), kb = col(bs[b + 1]);
    if (ka === kb && ka >= 0 && ka < nc) {
      // all blocks that end inside this column, combined through the pyramid
      const tEnd = t0 + (ka + 1) / (sc * r); let lo = b, hi = Math.min(b1, nb - 1);
      while (lo < hi) { const m = (lo + hi + 1) >> 1; if (bs[m + 1] <= tEnd) lo = m; else hi = m - 1; }
      rangeSummary(s, key, b, lo, o, tmp);
      if (o.has) agg(ka, o.mn, o.mx, o.first, o.last, 0, 2); if (o.brk) colBrk[ka] = 1;
      b = lo + 1; continue;
    }
    if (!exactMode && kb - ka <= 3 && ka >= 0 && kb < nc && !(key in M0_KEYS && s.B.rf[b] && rfSt(s, s.B.rf[b]).use === 'e') && blockSummary(s, key, b, o).has && (o.n || 0) > 32) { for (let k = ka; k <= kb; k++) agg(k, o.mn, o.mx, k === ka ? o.first : o.mn, k === kb ? o.last : o.mx, 0, 2); if (o.brk) colBrk[kb] = 1; }
    else if (!manyVerts(b)) blockVertices(s, key, b, add);
    b++;
  }
  /* blocks with many vertices (free waveforms) spanning several columns: the same result as feeding every vertex to
     add(), column by column: the vertex range of each column by binary search, its min/max from 32-vertex chunks */
  function manyVerts(b) {
    const m0a = key in M0_KEYS ? M0_KEYS[key] : -1, ch = CHANNELS[key];
    if (m0a < 0 && (!ch || ch.p)) return false;
    let T, V, n, tb = bs[b];
    if (m0a >= 0) { const m = m0Block(s, b); T = m.t; V = m.v[m0a]; n = T.length; if (n < 64 || m.reset >= 0) return false; aggVerts(T, V, n, tb, m, 'c' + m0a); return true; } // a reset: vertex by vertex (it breaks the curve)
    const id = s.B[ch.col][b]; if (!id) return false;
    const g = ch.fn(s, id); n = g.n; if (n < 64) return false;
    const dur = bs[b + 1] - tb, first = g.t[0] <= 1e-9 ? g.v[0] : 0, last = Math.abs(g.t[n - 1] - dur) <= 1e-9 ? g.v[n - 1] : 0;
    add(tb, first); if (first === 0 && g.v[0] !== 0) add(tb + g.t[0], 0);            // as blockVertices
    aggVerts(g.t, g.v, n, tb, g, 'c');
    if (last === 0 && g.v[n - 1] !== 0) add(tb + g.t[n - 1], 0); add(bs[b + 1], last);
    return true;
  }
  function aggVerts(T, V, n, tb, host, tag) {
    const cc = host._chunks || (host._chunks = {}); let C = cc[tag];
    if (!C) { const m = Math.ceil(n / 32), mn = new Float64Array(m).fill(Infinity), mx = new Float64Array(m).fill(-Infinity), imn = new Int32Array(m), imx = new Int32Array(m); for (let i = 0; i < n; i++) { const q = i >> 5, v = V[i]; if (v < mn[q]) { mn[q] = v; imn[q] = i; } if (v > mx[q]) { mx[q] = v; imx[q] = i; } } C = cc[tag] = { mn, mx, imn, imx }; }
    const colOf = i => col(tb + T[i]);
    let i = 0;
    // vertices left of the view: the last one becomes `pre` (as add() does)
    if (colOf(0) < 0) { let lo = 0, hi = n - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (colOf(m) < 0) lo = m; else hi = m - 1; } const v = V[lo]; pre = v === v ? [tb + T[lo], v] : null; i = lo + 1; }
    while (i < n) {
      const k = colOf(i); if (k >= nc) { if (!post && V[i] === V[i]) post = [tb + T[i], V[i]]; return; }
      let lo = i, hi = n - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (colOf(m) <= k) lo = m; else hi = m - 1; }
      let mn = Infinity, mx = -Infinity, a = i, jn = i, jx = i; const e = lo;
      while (a <= e && (a & 31)) { const v = V[a]; if (v < mn) { mn = v; jn = a; } if (v > mx) { mx = v; jx = a; } a++; }
      while (a + 31 <= e) { const q = a >> 5; if (C.mn[q] < mn) { mn = C.mn[q]; jn = C.imn[q]; } if (C.mx[q] > mx) { mx = C.mx[q]; jx = C.imx[q]; } a += 32; }
      while (a <= e) { const v = V[a]; if (v < mn) { mn = v; jn = a; } if (v > mx) { mx = v; jx = a; } a++; }
      agg(k, mn, mx, V[i], V[e], x0 + (tb + T[i] - t0) * sc, e - i + 1, tb + T[jn], tb + T[jx], tb + T[i], tb + T[e]);
      i = e + 1;
    }
  }
  if (pre) pts.push(x0 + (pre[0] - t0) * sc, pre[1]);
  const env = []; let run = null;
  // exact mode: the length of each stretch of dense columns (a column holding several values); short ones are drawn
  // through their extremes at their times, long ones (readout trains, a ZTE view) as before, where it keeps frames cheap
  if (exactMode) for (let k = 0; k < nc;) { if (!(colHas[k] && cN[k] > 1)) { colRun[k++] = 0; continue; } let e = k; while (e < nc && colHas[e] && cN[e] > 1 && !preHas[e] && !brkPre[e]) e++; for (let q = k; q < Math.max(e, k + 1); q++) colRun[q] = Math.max(e, k + 1) - k; k = Math.max(e, k + 1); }
  const tx = t => x0 + (t - t0) * sc, q4 = [];
  for (let k = 0; k < nc; k++) {
    if (preHas[k] || brkPre[k]) { // the part before a break inside this column, then the break
      if (preHas[k]) {
        if (preN[k] === 1) { pts.push(preX[k], preFirst[k]); if (run) { run.x.push(preX[k]); run.mn.push(preFirst[k]); run.mx.push(preFirst[k]); } }
        else { const x = x0 + (k + 0.5) / r; pts.push(x, preFirst[k], x, preLast[k]); if (!run) { run = { x: [], mn: [], mx: [] }; env.push(run); } run.x.push(x); run.mn.push(preMin[k]); run.mx.push(preMax[k]); }
      }
      pts.push(x0 + (k + 0.5) / r, NaN); run = null;
    }
    if (colHas[k]) {
      if (cN[k] === 1) { pts.push(cX[k], colFirst[k]); if (run) { run.x.push(cX[k]); run.mn.push(colFirst[k]); run.mx.push(colFirst[k]); } } // a single sample continues a band
      else if (exactMode && colEx[k] && colRun[k] < SPAN_MIN) { // first, minimum, maximum and last in time order, where they happen
        q4.length = 0; q4.push(colTf[k], colFirst[k], colTmn[k], colMin[k], colTmx[k], colMax[k], colTl[k], colLast[k]);
        const ord = [0, 2, 4, 6].sort((a, b) => q4[a] - q4[b]); let lt = NaN;
        for (const j of ord) { if (q4[j] === lt) continue; pts.push(tx(q4[j]), q4[j + 1]); lt = q4[j]; }
        run = null;
      }
      else {
        const x = x0 + (k + 0.5) / r; pts.push(x, colFirst[k], x, colLast[k]);
        if (!run) { run = { x: [], mn: [], mx: [] }; env.push(run); } run.x.push(x); run.mn.push(colMin[k]); run.mx.push(colMax[k]);
      }
    } else run = null;
    if (colBrk[k]) { pts.push(x0 + (k + 0.5) / r, NaN); run = null; }
  }
  if (post) pts.push(x0 + (post[0] - t0) * sc, post[1]);
  pts.env = env; // min/max band where a column holds many samples
  pts.x0 = x0; pts.r = r; pts.nc = nc; // the column grid (for solidTrace, areaRects)
  return pts;
}
function chanRange(key, t0, t1) { // max |value| in [t0, t1] (edge blocks may overestimate slightly)
  const s = S.seq, o = rangeSummary(s, key, blockAtTime(s, t0), blockAtTime(s, t1), {}, {});
  return o.has ? Math.max(Math.abs(o.mn), Math.abs(o.mx)) : 0;
}
function adcAt(t) { const s = S.seq, j = lb(s.adcT1, t); return j < s.adcT0.length && s.adcT0[j] <= t ? j : -1; }
function trStep(tr) {
  if (tr.step) return tr.step;
  const n = tr.t.length, pt = new Float64Array(2 * n), pv = new Float64Array(2 * n);
  for (let i = 0; i < n; i++) { pt[2 * i] = tr.t[i]; pv[2 * i] = i ? tr.v[i - 1] : tr.v[0]; pt[2 * i + 1] = tr.t[i]; pv[2 * i + 1] = tr.v[i]; }
  return (tr.step = { t: pt, v: pv });
}
/* min/max band of columns holding many samples: filled, with thin upper and lower edges */
/* Dense traces are drawn with fillRect spans instead of long paths. A zoomed-out trace is thousands of vertices that
   double back on themselves; stroking that (round joins, 1-1.35 px, anti-aliased) is among the slowest things a
   canvas does, on the GPU as in software (measured: ~1.8 s per trace in Chromium's GPU pipeline on SwiftShader, 16 ms
   as spans), while what it paints is a vertical span per pixel column. So where columns hold many samples the same
   pixels are painted as rectangles, grouped by style; sparse stretches stay anti-aliased paths. */
const SPAN_MIN = 24; // runs shorter than this stay paths (cheap either way)
/* rectangles of one style, merged when one continues the previous with the same top and height: far fewer canvas
   calls when zoomed out (neighbouring columns often have the same band), the same pixels (columns lie on whole device
   pixels, so no seam changes; same colour and alpha, so the order of overlapping rectangles does not matter) */
/* rectangles of one style, merged along a row where they line up (far fewer calls when zoomed out), each drawn with
   fillRect. From 1.14.2 to 1.16.1 they were collected in one Path2D and filled once, which saves main-thread time but
   is slower on a real graphics card: a path of hundreds of rectangles is rasterised as a general path, fillRect as
   rectangles (frame-rate test on a laptop, whole demo in view: 111 fps as a path, 170 fps as fillRect, same pixels;
   the comparison case was removed from the frame-rate test in 1.24.3). */
function rectRun(ctx) {
  let x = 0, y = 0, w = 0, h = 0, on = false;
  // left and right edges on whole device pixels, so that neighbouring rectangles meet exactly as in one path; else both
  // cover the shared pixel partly and the colour underneath shows through as a faint seam (at 1.25× or 1.75× pixels)
  // ultra quality: columns narrower than a screen pixel, drawn where they fall (anti-aliased edges smooth the steps);
  // otherwise edges snapped to whole screen pixels
  const d = pdpr || 1, ultra = (BENCH.quality || S.diagRes) === 'ultra', sn = ultra ? (v => v) : (v => Math.round(v * d) / d);
  const put = () => { const xa = sn(x); let xb = sn(x + w); if (xb <= xa) xb = xa + (ultra ? 1e-3 : 1 / d); ctx.fillRect(xa, y, xb - xa, h); }; // never thinner than one device pixel
  return {
    add(ax, ay, aw, ah) { if (on && ay === y && ah === h && Math.abs(ax - (x + w)) < 1e-9) { w += aw; return; } if (on) put(); x = ax; y = ay; w = aw; h = ah; on = true; },
    flush() { if (on) put(); on = false; }
  };
}
function colWidth(xs, n) { let w = Infinity; for (let i = 1; i < n; i++) { const d = xs[i] - xs[i - 1]; if (d > 1e-6 && d < w) w = d; } return w === Infinity ? 1 : Math.min(1, w); }
/* vertical limits for rectangles in the lane being drawn (set by laneBody): values far outside the lane's scale (the
   k-vector after the last readout can be orders of magnitude beyond it) otherwise give rectangles millions of pixels
   tall, which the browser draws through a slow general path even though the clip hides almost all of them */
let RY0 = -1e6, RY1 = 1e6;
const cy = y => y < RY0 ? RY0 : y > RY1 ? RY1 : y;
function fillEnvelope(ctx, env, yOf, color) {
  if (!env || !env.length || BENCH.skip.env) return;
  ctx.fillStyle = color; ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.lineJoin = 'round';
  const long = [];
  // short runs: all bands in one fill, all upper edges in one stroke, all lower edges in another (three calls instead
  // of three per run; runs never overlap, and upper and lower edges stay separate strokes, so the pixels are the same)
  const band = new Path2D(), upE = new Path2D(), dnE = new Path2D(); let nShort = 0;
  for (const run of env) {
    const n = run.x.length; if (n < 1) continue;
    if (n >= SPAN_MIN) { long.push(run); continue; }
    band.moveTo(run.x[0], yOf(run.mx[0]));
    for (let i = 1; i < n; i++) band.lineTo(run.x[i], yOf(run.mx[i]));
    for (let i = n - 1; i >= 0; i--) band.lineTo(run.x[i], yOf(run.mn[i]));
    band.closePath();
    upE.moveTo(run.x[0], yOf(run.mx[0])); for (let i = 1; i < n; i++) upE.lineTo(run.x[i], yOf(run.mx[i]));
    dnE.moveTo(run.x[0], yOf(run.mn[0])); for (let i = 1; i < n; i++) dnE.lineTo(run.x[i], yOf(run.mn[i]));
    nShort++;
  }
  if (nShort) { ctx.globalAlpha = 0.45; ctx.fill(band); ctx.globalAlpha = 0.9; ctx.stroke(upE); ctx.stroke(dnE); }
  if (long.length) { // the same band and edges as spans: all bands, then all edges (two style changes)
    ctx.globalAlpha = 0.45;
    const band = rectRun(ctx);
    for (const run of long) { const n = run.x.length, w = colWidth(run.x, n); for (let i = 0; i < n; i++) { const ya = cy(yOf(run.mx[i])), yb = cy(yOf(run.mn[i])); band.add(run.x[i] - w / 2, Math.min(ya, yb), w, Math.abs(yb - ya)); } band.flush(); }
    ctx.globalAlpha = 0.9;
    const up = rectRun(ctx), dn = rectRun(ctx);
    for (const run of long) {
      const n = run.x.length, w = colWidth(run.x, n); let pa = cy(yOf(run.mx[0])), pb = cy(yOf(run.mn[0]));
      for (let i = 0; i < n; i++) { // each edge joins the previous column's edge (the segment a 1 px line would draw)
        const ya = cy(yOf(run.mx[i])), yb = cy(yOf(run.mn[i]));
        up.add(run.x[i] - w / 2, Math.min(pa, ya) - 0.5, w, Math.abs(pa - ya) + 1);
        dn.add(run.x[i] - w / 2, Math.min(pb, yb) - 0.5, w, Math.abs(pb - yb) + 1);
        pa = ya; pb = yb;
      }
      up.flush(); dn.flush();
    }
  }
  ctx.globalAlpha = 1;
}
function strokePts(ctx, pts, yOf, color, fillBase) {
  if (!pts.length) return;
  fillEnvelope(ctx, pts.env, yOf, color);
  const LW = 1.35, hw = LW / 2;
  // dense columns (runs of points at the same x) become spans; the rest is one anti-aliased path
  let nDense = 0; for (let i = 2; i < pts.length; i += 2) if (pts[i] === pts[i - 2]) nDense++;
  const useSpans = nDense >= SPAN_MIN, spans = [];
  /* the path is clipped to the lane's rows (RY0..RY1) as it is built: a value far outside the lane's scale (the k-vector
     after the last readout) otherwise gives segments millions of pixels long, which the browser strokes very slowly
     although the clip hides them. Exact inside the lane. */
  let qx = NaN, qy = NaN, qDown = false;
  const M_ = (x, y) => { qx = x; qy = y; qDown = false; };
  const L_ = (x, y) => {
    const ax = qx, ay = qy; qx = x; qy = y;
    if (ay !== ay) { qDown = false; return; }
    if ((ay < RY0 && y < RY0) || (ay > RY1 && y > RY1)) { qDown = false; return; }
    let ta = 0, tb = 1; const dy = y - ay;
    if (dy !== 0) { const t1 = (RY0 - ay) / dy, t2 = (RY1 - ay) / dy; ta = Math.max(0, Math.min(t1, t2)); tb = Math.min(1, Math.max(t1, t2)); if (ta > tb) { qDown = false; return; } }
    const xa = ax + (x - ax) * ta, ya = ay + dy * ta;
    if (!qDown || ta > 0) ctx.moveTo(xa, ya);
    ctx.lineTo(ax + (x - ax) * tb, ay + dy * tb); qDown = tb >= 1;
  };
  ctx.beginPath(); let pen = false, px = NaN, py = NaN, fx = null;
  /* column width: the grid of traceChan when known (1.23.2). Before, the smallest spacing between any two points,
     which a single sample near a column centre made tiny: dense spans were then drawn a fraction of a column wide, and
     almost every join between dense columns counted as a gap and was stroked (on a ZTE sequence about 150,000 pixels
     of line per frame in the gradient lane, most of a frame on a graphics card) */
  const cw = pts.r ? 1 / pts.r : useSpans ? (() => { let w = Infinity, last = NaN; for (let i = 0; i < pts.length; i += 2) { const x = pts[i]; if (x !== last && last === last && x - last > 1e-6 && x - last < w) w = x - last; last = x; } return w === Infinity ? 1 : Math.min(1, w); })() : 1;
  for (let i = 0; i < pts.length;) {
    const x = pts[i], v = pts[i + 1];
    if (v !== v) { pen = false; px = NaN; i += 2; continue; }
    let j = i + 2; if (useSpans) while (j < pts.length && pts[j] === x && pts[j + 1] === pts[j + 1]) j += 2;
    if (j - i >= 4) { // a dense column: the zigzag through its points, plus the join from the previous point
      let lo = Infinity, hi = -Infinity; for (let q = i; q < j; q += 2) { const y = yOf(pts[q + 1]); if (y < lo) lo = y; if (y > hi) hi = y; }
      if (pen && px === px) {
        if (x - px > 1.5 * cw) L_(x, yOf(pts[i + 1])); // a longer join stays part of the path
        else { if (py < lo) lo = py; if (py > hi) hi = py; }
      }
      spans.push(x, lo, hi);
      py = yOf(pts[j - 1]); px = x; M_(x, py); pen = true;
      if (fx === null) fx = x; i = j; continue;
    }
    const y = yOf(v);
    if (!pen) { M_(x, y); pen = true; if (fx === null) fx = x; } else L_(x, y);
    px = x; py = y; i += 2;
  }
  ctx.strokeStyle = color; ctx.lineWidth = LW; ctx.lineJoin = 'round'; ctx.stroke();
  if (spans.length) { ctx.fillStyle = color; const sp = rectRun(ctx); for (let k = 0; k < spans.length; k += 3) sp.add(spans[k] - cw / 2, cy(spans[k + 1]) - hw, cw, cy(spans[k + 2]) - cy(spans[k + 1]) + LW); sp.flush(); }
  if (fillBase !== undefined && fx !== null && !BENCH.skip.area) areaRects(ctx, pts, yOf, fillBase, color);
}

/* area between a trace and its zero line (RF |B1|; a gradient in its own lane), 1.23.0: one faint rectangle per pixel
   column from the zero line to the highest point the curve reaches in that column, and one to the lowest point below
   it (its points, and where its lines cross the column's edges). Until 1.22.3 it was one filled polygon through every
   point: tens of thousands of vertices for a ZTE sequence with a pulse per spoke, which took a graphics card about
   150 ms per frame to fill (frame-rate test: 6 fps with it, 36 fps without). */
function areaRects(ctx, pts, yOf, base, color) {
  const r = pts.r || 1, x0 = pts.x0 || 0, nc = pts.nc || 1e5, colOf = x => Math.floor((x - x0) * r + 1e-9);
  const top = new Map(), bot = new Map(); // column: highest point above the zero line (smallest y), lowest below it
  const put = (k, y) => { y = cy(y); if (y < base) { const o = top.get(k); if (o === undefined || y < o) top.set(k, y); } else if (y > base) { const o = bot.get(k); if (o === undefined || y > o) bot.set(k, y); } };
  let pk = -1, py = NaN, px = NaN;
  for (let i = 0; i < pts.length; i += 2) {
    const x = pts[i], v = pts[i + 1];
    if (v !== v) { pk = -1; py = NaN; continue; }
    const y = yOf(v), k = colOf(x);
    // where the line from the previous point crosses the column edges, only for the columns on screen: a point far off
    // screen (the last one before the view when zoomed far in) once made this loop run over millions of columns
    if (py === py && k > pk) for (let kb = Math.max(pk + 1, 0), ke = Math.min(k, nc); kb <= ke; kb++) { const xb = x0 + kb / r, yb = py + (y - py) * (xb - px) / (x - px || 1); put(kb - 1, yb); put(kb, yb); }
    if (k >= 0 && k < nc) put(k, y); pk = k; py = y; px = x;
  }
  if (!top.size && !bot.size) return;
  const w = 1 / r; ctx.globalAlpha = 0.13; ctx.fillStyle = color; const rr = rectRun(ctx);
  for (const k of [...top.keys()].sort((a, b) => a - b)) { const y = top.get(k); rr.add(x0 + k * w, y, w, base - y); }
  rr.flush();
  for (const k of [...bot.keys()].sort((a, b) => a - b)) { const y = bot.get(k); rr.add(x0 + k * w, base, w, y - base); }
  rr.flush(); ctx.globalAlpha = 1;
}
/* the k-vector lane (1.22.3): the whole trace as one opaque rectangle per pixel column and stretch of the curve, from
   the lowest to the highest point the curve reaches in that column (its samples, the column's min/max summary, and
   where its lines cross the column's edges), at least a line wide. A break (the reset at an excitation) ends a
   stretch, so the curve starts anew without a line. Only rectangles, no strokes: a ZTE sequence has a ramp and a
   reset per spoke, and stroking those as anti-aliased lines was the slow part (tens of thousands of pixels of line
   per frame); rectangles are the cheapest thing a canvas draws. */
function solidTrace(ctx, pts, yOf, color) {
  if (!pts.length) return;
  const r = pts.r || 1, x0 = pts.x0 || 0, nc = pts.nc || 1e5, LW = 1.35, hw = LW / 2, colOf = x => Math.floor((x - x0) * r + 1e-9);
  const envQ = new Map(); // per column centre, the summaries of its dense parts in order (a split column has two)
  for (const run of pts.env || []) for (let i = 0; i < run.x.length; i++) { const k = Math.round(run.x[i] * 64), q = envQ.get(k); if (q) q.push(i, run); else envQ.set(k, [i, run]); }
  const R = []; let ck = -1, lo = 0, hi = 0, on = false;
  const flush = () => { if (on) R.push(ck, lo, hi); on = false; };
  const addY = (k, y) => { y = cy(y); if (!on || k !== ck) { flush(); ck = k; lo = hi = y; on = true; } else { if (y < lo) lo = y; if (y > hi) hi = y; } };
  let pk = -1, py = NaN, px = NaN;
  for (let i = 0; i < pts.length; i += 2) {
    const x = pts[i], v = pts[i + 1];
    if (v !== v) { flush(); pk = -1; py = NaN; continue; }
    const y = yOf(v), k = colOf(x);
    if (py === py && k > pk) { // a line from the previous point: where it crosses each column edge (on screen only, as in areaRects)
      for (let kb = Math.max(pk + 1, 0), ke = Math.min(k, nc); kb <= ke; kb++) { const xb = x0 + kb / r, yb = py + (y - py) * (xb - px) / (x - px || 1); addY(kb - 1, yb); addY(kb, yb); }
    }
    if (i + 2 < pts.length && pts[i + 2] === x && (i === 0 || pts[i - 2] !== x)) { // first point of a dense column: its summary
      const q = envQ.get(Math.round(x * 64)); if (q && q.length) { const j = q.shift(), run = q.shift(); addY(k, yOf(run.mx[j])); addY(k, yOf(run.mn[j])); }
    }
    if (k >= 0 && k < nc) addY(k, y); pk = k; py = y; px = x;
  }
  flush();
  ctx.fillStyle = color; ctx.globalAlpha = 1; const rr = rectRun(ctx), w = 1 / r;
  for (let q = 0; q < R.length; q += 3) rr.add(x0 + R[q] * w, R[q + 1] - hw, w, R[q + 2] - R[q + 1] + LW);
  rr.flush();
}

/* ---------- time axis ticks ---------- */
function niceStep(raw) { const p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p; return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p; }
function timeUnit(span) { return span >= 2 ? [1, 's'] : span >= 2e-3 ? [1e3, 'ms'] : [1e6, 'µs']; }

/* ---------- main render ---------- */
let pending = false, pendingOv = false;
function request() { if (!pending) { pending = true; requestAnimationFrame(() => { pending = false; benchT(render); }); } }
function requestOverlay() { if (!pendingOv) { pendingOv = true; requestAnimationFrame(() => { pendingOv = false; benchT(() => { drawOverlay(); updateReadout(); }); }); } }
function render() {
  if (!C.ink) readColors();
  pctx.clearRect(0, 0, W, H);
  if (BENCH.skip.draw && S.seq) { if (!BENCH.skip.ov) drawOverview(); drawOverlay(); if (!BENCH.skip.dom) { updateReadout(); updateNav(); updateLegend(); } return; }
  if (!S.seq || W <= 0) { octx.clearRect(0, 0, W, H); vctx.clearRect(0, 0, OW, OH); return; }
  const renderT0 = performance.now();
  const s = S.seq, t0 = S.t0, t1 = S.t1, pw = W - GUT - 8, x0 = GUT;
  const X = t => x0 + (t - t0) / (t1 - t0) * pw;
  const lanes = lanesGeom(); traceR = chooseTraceR(t0, t1, pw);
  const nb = s.nb;
  const b0 = Math.max(0, ub(s.blockStart, t0, nb) - 1), b1 = Math.min(nb - 1, lb(s.blockStart, t1, nb));
  const nVis = b1 - b0 + 1;
  const bot = H - AXH;
  pctx.save();
  pctx.beginPath(); pctx.rect(x0, 0, pw, H); pctx.clip();
  // block shading: decided per block from its own width on screen (not from how many blocks are visible, which
  // changes while panning), fading in between 2 and 6 px, so panning never switches it on and off
  const wOf = b => (s.blockStart[b + 1] - s.blockStart[b]) / (t1 - t0) * pw;
  const dmax = blockDurMax(s), pxPerS = pw / (t1 - t0); // skip groups of 64 blocks too narrow on screen to draw (exact)
  if (nVis < 2e5 && !BENCH.skip.shade) {
    pctx.fillStyle = C.shade; pctx.beginPath(); const partial = [];
    for (let b = b0 | 1; b <= b1; b += 2) {
      if ((b & 63) < 2 && dmax[b >> 6] * pxPerS < 2) { b = (((b >> 6) + 1) << 6) - 1; continue; } // next odd block after this group
      const w = wOf(b); if (w < 2) continue;
      const xa = X(s.blockStart[b]); if (w >= 6) pctx.rect(xa, 0, w, bot); else partial.push([xa, w]);
    }
    pctx.fill();
    for (const [xa, w] of partial) { pctx.globalAlpha = (w - 2) / 4; pctx.fillRect(xa, 0, w, bot); }
    pctx.globalAlpha = 1;
  }
  const sr = selRange();
  if (sr) {
    const xa = X(sr[0]), xb = X(sr[1]);
    pctx.globalAlpha = S.selKind === 'block' ? 0.18 : 0.1; pctx.fillStyle = C.sel; pctx.fillRect(xa, 0, Math.max(2, xb - xa), bot);
    pctx.globalAlpha = 1; pctx.fillRect(xa, bot - 3, Math.max(2, xb - xa), 3);
  }
  if (nVis < 2e5) { // block boundaries where both neighbouring blocks are at least 7 px wide
    pctx.strokeStyle = C['line-soft']; pctx.lineWidth = 1; pctx.beginPath();
    for (let b = b0; b <= b1 + 1 && b <= nb; b++) {
      if (b < nb && (b & 63) === 0 && dmax[b >> 6] * pxPerS < 7 && b + 64 <= nb) { b += 63; continue; } // every block in the group < 7 px: no boundary inside or at its start
      const wl = b > 0 ? wOf(b - 1) : Infinity, wr = b < nb ? wOf(b) : Infinity; if (Math.min(wl, wr) < 7) continue;
      const x = Math.round(X(s.blockStart[b])) + 0.5; pctx.moveTo(x, 0); pctx.lineTo(x, bot);
    }
    pctx.stroke();
  }
  // shot boundaries
  let si0 = 0, si1 = -1;
  if (shotsOn()) {
    const sh = s.shots; si0 = Math.max(0, ub(S.shotT0, t0) - 1); si1 = Math.min(sh.length - 1, lb(S.shotT0, t1));
    if (si1 - si0 < pw / 4) {
      pctx.strokeStyle = C.ink; pctx.globalAlpha = 0.4; pctx.setLineDash([4, 3]); pctx.lineWidth = 1; pctx.beginPath();
      for (let k = si0; k <= si1; k++) { const x = Math.round(X(sh[k].t0)) + 0.5; pctx.moveTo(x, shotY()); pctx.lineTo(x, bot); }
      pctx.stroke(); pctx.setLineDash([]); pctx.globalAlpha = 1;
    }
  }
  let vi0 = 0, vi1 = -1;
  if (volsOn()) {
    const v = S.vols; vi0 = Math.max(0, ub(S.volT0, t0) - 1); vi1 = Math.min(v.length - 1, lb(S.volT0, t1));
    if (vi1 - vi0 < pw / 4) {
      pctx.strokeStyle = C.ink; pctx.globalAlpha = 0.7; pctx.lineWidth = 1.5; pctx.beginPath();
      for (let k = vi0; k <= vi1; k++) { if (!k) continue; const x = Math.round(X(v[k].t0)) + 0.5; pctx.moveTo(x, volY()); pctx.lineTo(x, bot); }
      pctx.stroke(); pctx.globalAlpha = 1; pctx.lineWidth = 1;
    }
  }
  pctx.restore();
  if (volsOn()) drawStrip(S.vols, vi0, vi1, volY(), 'Volumes', 'vol', volOfBlock(S.sel), S.selKind === 'vol', v => !v.nSamples, X, x0, pw);
  if (shotsOn()) drawStrip(s.shots, si0, si1, shotY(), 'Shots', 'shot', S.selKind === 'vol' ? -1 : shotOfBlock(S.sel), S.selKind === 'shot', v => !v.nADC, X, x0, pw);

  // lanes
  pctx.font = `500 11.5px ${C.font}`; pctx.textBaseline = 'middle';
  const dLane = DIAG.on ? {} : null;
  for (const L of lanes) {
    const dT = dLane ? performance.now() : 0;
    try {
    if (L.key === 'labels') { RY0 = -1e6; RY1 = 1e6; if (!BENCH.skip.labels) drawLabelsLane(L, X, t0, t1, x0, pw); continue; }
    if (L.stim) { drawStimLane(L, t0, t1, x0, pw); continue; }
    if (L.key === 'm0') m0Pyramids(s);
    if (L.key === 'rfMag' && S.rfMode === 'complex') for (const k of ['rfRe', 'rfIm']) if (!s.pyr[k]) s.pyr[k] = buildPyramid(s, k);
    laneBody(L);
    } finally { if (dLane) dLane[L.label] = performance.now() - dT; }
  }
  function laneBody(L) {
    const chans = laneChannels(L), f = laneFactor(L.key);
    let m = L.key === 'm0' ? m0ViewMax(t0, t1) : laneMax(L);
    if (S.autoY && L.key !== 'rfPh' && L.key !== 'adc' && L.key !== 'm0') { let mv = 0; for (const [, c] of chans) mv = Math.max(mv, chanRange(c, t0, t1)); if (mv > 0) m = mv; }
    if (!(m > 0)) m = 1;
    const pad = 4;
    let yOf, base;
    if (L.kind === 'sym' || L.kind === 'phase') { const mid = L.y + L.h / 2, hh = L.h / 2 - pad; yOf = v => mid - v / m * hh; base = mid; }
    else { const b = L.y + L.h - pad, hh = L.h - 2 * pad; yOf = v => b - v / m * hh; base = b; }
    // zero line
    pctx.strokeStyle = C.line; pctx.lineWidth = 1; pctx.setLineDash(L.kind === 'sym' || L.kind === 'phase' ? [3, 3] : []);
    pctx.beginPath(); pctx.moveTo(x0, Math.round(base) + 0.5); pctx.lineTo(x0 + pw, Math.round(base) + 0.5); pctx.stroke(); pctx.setLineDash([]);
    // gutter
    const multi = L.key === 'slew' || L.key === 'g' || L.key === 'm0', color = multi ? C.ink : C[L.col];
    pctx.fillStyle = color; pctx.fillRect(8, L.y + 2, 3, L.h - 4);
    pctx.fillStyle = C.ink; pctx.textAlign = 'left'; pctx.font = `600 12px ${C.font}`;
    const twoLine = L.key !== 'adc' && L.h > 58;
    pctx.fillText(L.label, 16, L.y + L.h / 2 - (twoLine ? 7 : 0));
    pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
    if (L.key !== 'adc') {
      const unit = laneUnit(L.key), top = L.kind === 'phase' ? 'π' : fmt(m * f, 3);
      if (twoLine) pctx.fillText(unit, 16, L.y + L.h / 2 + 8);
      if (L.key === 'rfMag' && S.rfMode === 'complex' && L.h > 80) {
        pctx.font = `600 11px ${C.font}`; pctx.fillStyle = C.rf; pctx.fillText('re', 16, L.y + L.h / 2 + 24); pctx.fillStyle = C.ph; pctx.fillText('im', 34, L.y + L.h / 2 + 24);
        pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
      }
      if (multi && L.h > 80) {
        pctx.font = `600 11px ${C.font}`; let lx = 16;
        for (const [col] of (L.key === 'g' ? chans : [['gx'], ['gy'], ['gz']])) { pctx.fillStyle = C[col]; const tx = col[1]; pctx.fillText(tx, lx, L.y + L.h / 2 + 24); lx += 12; }
        pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
      }
      pctx.textAlign = 'right';
      pctx.fillText(top, x0 - 6, L.y + 7);
      if (L.kind !== 'pos') pctx.fillText(L.kind === 'phase' ? '−π' : '−' + fmt(m * f, 3), x0 - 6, L.y + L.h - 7);
      else pctx.fillText('0', x0 - 6, L.y + L.h - 7);
    }
    pctx.save(); pctx.beginPath(); pctx.rect(x0, L.y - 1, pw, L.h + 2); pctx.clip(); RY0 = L.y - 8; RY1 = L.y + L.h + 8;
    if (L.key === 'adc') drawADC(L, X, t0, t1, pw, x0);
    else if (L.key === 'm0') {
      /* 1.22.0: the traces at full strength everywhere, drawn like any other lane; the stretches outside the active
         ones (excitation to last readout) are marked by a pale veil over the lane's background, drawn before the
         traces (one rectangle per gap). Fading the traces themselves needed either clip paths of thousands of
         rectangles (up to 1.20.0) or an extra lane-sized image (1.21.0), both far more expensive than the traces. */
      pctx.fillStyle = C.plot; pctx.globalAlpha = 0.7; let xp = x0; const A = m0Active(S.seq), n = A.a.length;
      for (let j = Math.max(0, ub(A.b, t0) - 1); j < n && A.a[j] < t1; j++) {
        const xa = Math.max(x0, X(A.a[j])), xb = Math.min(x0 + pw, X(A.b[j])); if (xb <= xa) continue;
        if (xa - xp >= 1) pctx.fillRect(xp, L.y - 1, xa - xp, L.h + 2); if (xb > xp) xp = xb;
      }
      if (x0 + pw - xp >= 1) pctx.fillRect(xp, L.y - 1, x0 + pw - xp, L.h + 2); pctx.globalAlpha = 1;
      for (const [col, c] of chans) solidTrace(pctx, traceChan(c, t0, t1, x0, pw), yOf, C[col]);
    }
    else for (const [col, c] of chans) {
      const pts = traceChan(c, t0, t1, x0, pw);
      strokePts(pctx, pts, yOf, C[col], L.kind === 'phase' || chans.length > 1 ? undefined : base);
    }
    pctx.restore(); RY0 = -1e6; RY1 = 1e6; // only this lane's rows were limited
  }
  // time axis
  const span = t1 - t0, [uf, un] = timeUnit(span);
  const step = niceStep(span / Math.max(2, pw / 95));
  pctx.strokeStyle = C.line; pctx.beginPath(); pctx.moveTo(x0, bot + 0.5); pctx.lineTo(x0 + pw, bot + 0.5); pctx.stroke();
  pctx.fillStyle = C.muted; pctx.textAlign = 'center'; pctx.font = `400 11px ${C.font}`;
  const dec = Math.max(0, -Math.floor(Math.log10(step * uf) + 1e-9));
  for (let t = Math.ceil(t0 / step) * step; t <= t1; t += step) {
    const x = X(t); pctx.beginPath(); pctx.moveTo(x, bot); pctx.lineTo(x, bot + 4); pctx.stroke();
    pctx.fillText((t * uf).toFixed(dec), x, bot + 15);
  }
  pctx.textAlign = 'left'; pctx.fillText(un, 14, bot + 15);
  // block numbers
  if (nVis < pw / 34) {
    pctx.font = `500 10.5px ${C.font}`; pctx.fillStyle = C.faint; pctx.textAlign = 'center';
    for (let b = b0; b <= b1; b++) {
      const xa = Math.max(x0, X(s.blockStart[b])), xb = Math.min(x0 + pw, X(s.blockStart[b + 1]));
      if (xb - xa > 26) pctx.fillText(s.B.id[b], (xa + xb) / 2, bot - 8);
    }
  }
  { const dt = performance.now() - renderT0; if (!BENCH.run && DIAG.on) diagShow(dt, dLane); }
  if (!BENCH.skip.ov) drawOverview(); drawOverlay(); if (!BENCH.skip.dom) { updateReadout(); updateNav(); updateLegend(); }
  if (S.tab === 'img' && S.sel < 0 && !S.sideHidden) requestImg();
  if (S.tab === 'k' && S.kRange !== 'all' && !S.sideHidden) { if (S.kRange === 'view') requestKLazy(); else requestK(); }
}
/* the zeroth moment matters from each excitation to the end of the last readout before the next one: elsewhere the lane
   is faded (covered with the plot colour); a stretch without a readout is faded throughout */
/* scale of the M0 lane: largest |m0| in the visible active stretches (moments differ by orders of magnitude between
   imaging, diffusion encoding and spoiling, and what happens after the last readout should not set the scale) */
function m0ViewMax(t0, t1) {
  const s = S.seq, A = m0Active(s), n = A.a.length, o = {}, tmp = {}; let m = 0, cnt = 0;
  for (let j = Math.max(0, ub(A.b, t0) - 1); j < n && A.a[j] < t1 && cnt < 400; j++, cnt++) {
    const a = Math.max(t0, A.a[j]), b = Math.min(t1, A.b[j]); if (b <= a) continue;
    for (const k of ['mx', 'my', 'mz']) { rangeSummary(s, k, blockAtTime(s, a), blockAtTime(s, b), o, tmp); if (o.has) m = Math.max(m, Math.abs(o.mn), Math.abs(o.mx)); }
  }
  if (!(m > 0)) for (const k of ['mx', 'my', 'mz']) m = Math.max(m, chanRange(k, t0, t1)); // nothing active in view
  return m > 0 ? m * 1.05 : 1;
}
/* longest block per group of 64 (seconds), for skipping narrow stretches in the shading and boundary loops */
function blockDurMax(seq) {
  if (seq.durMax64) return seq.durMax64;
  const n = Math.ceil(seq.nb / 64), d = new Float64Array(n), bs = seq.blockStart;
  for (let i = 0; i < seq.nb; i++) { const w = bs[i + 1] - bs[i]; if (w > d[i >> 6]) d[i >> 6] = w; }
  return (seq.durMax64 = d);
}
/* frame-time readout (Shift+D, or the ⋯ menu): Seqret's own time per frame and per lane, and the interval between
   drawn frames, which also contains the browser's drawing time on the graphics card. For reporting performance. */
const DIAG = { on: false, times: [], lastT: 0, fr: [], loop: false };
/* frame-rate test (⋯ › Run frame-rate test): switches used only while it runs, to find out on the user's own machine
   which part of a frame costs time. skip: leave out one part of the drawing; quality, lineMode: draw as with that
   setting (the normal view never uses them). */
const BENCH = { run: false, skip: {}, js: [], acc: 0, quality: '', lineMode: '' };
const benchT = (f) => { if (!BENCH.run) return f(); const t = performance.now(); try { return f(); } finally { BENCH.acc += performance.now() - t; } };
/* display frame rate: while the panel is open and the view moves, a requestAnimationFrame loop records the time
   between screen frames (a dropped frame shows as a longer gap); it stops half a second after the last redraw */
function diagFrames() {
  if (DIAG.loop || !DIAG.on) return; DIAG.loop = true; let last = 0;
  const f = t => {
    if (!DIAG.on || performance.now() - DIAG.lastT > 500) { DIAG.loop = false; diagText(); return; }
    if (last) { DIAG.fr.push(t - last); if (DIAG.fr.length > 90) DIAG.fr.shift(); }
    last = t; requestAnimationFrame(f);
  };
  requestAnimationFrame(f);
}
function diagShow(js, lanes) {
  DIAG.js = js; DIAG.lanes = lanes; const now = performance.now(), iv = DIAG.lastT ? now - DIAG.lastT : 0; DIAG.lastT = now;
  if (iv > 0 && iv < 1000) { DIAG.times.push(iv); if (DIAG.times.length > 30) DIAG.times.shift(); }
  diagFrames(); diagText();
}
function diagText() {
  if (BENCH.run || $('#diag').classList.contains('sel')) return;
  const js = DIAG.js || 0, lanes = DIAG.lanes;
  const medOf = a => a.length ? [...a].sort((x, y) => x - y)[a.length >> 1] : 0;
  const worst = DIAG.fr.length ? Math.max(...DIAG.fr) : 0;
  // frames delivered over the time they took (a slow frame counts for its full length, unlike in a median)
  const tot = DIAG.fr.reduce((a, b) => a + b, 0), fps = tot ? `${Math.round(1000 * DIAG.fr.length / tot)} fps (over the last ${DIAG.fr.length} screen frames; slowest ${worst.toFixed(0)} ms)` : '–';
  const med = medOf(DIAG.times);
  const lan = Object.entries(lanes || {}).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v.toFixed(1)}`).join(', ');
  $('#diag').textContent = `Seqret time: ${js.toFixed(1)} ms per frame (${traceR} column${traceR > 1 ? 's' : ''} per pixel)\n` +
    `lanes: ${lan}\nframe rate while moving: ${fps}\nredraws while moving: every ${med ? med.toFixed(0) + ' ms (median; also set by how fast you scroll or drag)' : '–'}\n` +
    `${Math.round(W)}×${Math.round(H)} CSS px, ${pdpr}× pixels${pdpr !== dpr ? ` (screen ${dpr}×, diagram quality fast)` : ''}, ${S.seq ? S.seq.nb.toLocaleString() + ' blocks' : ''}`;
}
function diagToggle() { $('#diag').classList.remove('sel'); DIAG.on = !DIAG.on; DIAG.times = []; DIAG.fr = []; DIAG.lastT = 0; $('#diag').hidden = !DIAG.on; $('#diagBtn').textContent = DIAG.on ? 'Hide frame times' : 'Show frame times'; request(); }
$('#diagBtn').onclick = diagToggle;
/* the test: from the current view, the view is moved on every screen frame (panning back and forth by 2 % of the span,
   or zooming in and out by 3 % about the centre), so that a frame is drawn on every screen frame, as while scrolling
   fast. It records the time between screen frames (all of the browser's work, including drawing on the graphics card)
   and Seqret's own time per frame, first for the normal drawing, then with each part left out, then with the other
   peak drawing and the other diagram qualities. Takes about half a minute; the view, the selection and the settings are restored. */
async function diagBench() {
  if (!S.seq || BENCH.run) return;
  const btn = $('#benchBtn'), v0 = [S.t0, S.t1], el = $('#diag');
  if (!DIAG.on) diagToggle();
  const CASES = [['normal, panning', 'pan', {}], ['normal, zooming', 'zoom', {}],
    ['without block shading', 'pan', { skip: { shade: 1 } }], ['without min/max bands', 'pan', { skip: { env: 1 } }],
    ['without area under RF', 'pan', { skip: { area: 1 } }], ['without labels lane', 'pan', { skip: { labels: 1 } }],
    ['without overview', 'pan', { skip: { ov: 1 } }], ['without page updates', 'pan', { skip: { dom: 1 } }],
    ['blank diagram', 'pan', { skip: { draw: 1 } }], ['blank diagram, no page updates', 'pan', { skip: { draw: 1, dom: 1, ov: 1 } }],
    [S.lineMode === 'exact' ? 'peaks per column' : 'peaks exact', 'pan', { lineMode: S.lineMode === 'exact' ? 'columns' : 'exact' }],
    ...['ultra', 'high', 'standard', 'fast'].filter(q => q !== S.diagRes && (q !== 'fast' || window.devicePixelRatio > 1.01)).map(q => [`diagram quality ${q}`, 'pan', { quality: q }])];
  const frame = () => new Promise(r => requestAnimationFrame(r));
  const q = (a, f) => { const b = [...a].sort((x, y) => x - y); return b.length ? b[Math.min(b.length - 1, Math.floor(f * b.length))] : 0; };
  const rows = []; BENCH.run = true; btn.disabled = true;
  try {
    for (let c = 0; c < CASES.length; c++) {
      const [name, kind, o] = CASES[c];
      BENCH.skip = o.skip || {}; BENCH.lineMode = o.lineMode || ''; ovCache = null; BENCH.js = [];
      if ((o.quality || '') !== BENCH.quality) { BENCH.quality = o.quality || ''; resize(); }
      setView(v0[0], v0[1]); await frame(); await frame();
      const iv = []; let last = 0; const N = 150, WARM = 15;
      for (let i = 0; i < N; i++) {
        const t = await frame(); if (i > WARM && last) { iv.push(t - last); BENCH.js.push(BENCH.acc); } BENCH.acc = 0; last = t;
        const sp = S.t1 - S.t0, d = (i % 60) < 30 ? 1 : -1;
        if (kind === 'pan') setView(S.t0 + d * 0.02 * sp, S.t1 + d * 0.02 * sp); else zoomAt((S.t0 + S.t1) / 2, d > 0 ? 0.97 : 1 / 0.97);
        if (i % 10 === 0) el.textContent = `Frame-rate test: ${name} (${c + 1} of ${CASES.length})…`;
      }
      const tot = iv.reduce((a, b) => a + b, 0), js = BENCH.js;
      rows.push({ name, fps: 1000 * iv.length / tot, med: q(iv, 0.5), p95: q(iv, 0.95), js: q(js, 0.5), jsMax: q(js, 0.95) });
    }
  } finally {
    BENCH.run = false; BENCH.skip = {}; BENCH.lineMode = ''; ovCache = null; BENCH.js = []; btn.disabled = false;
    if (BENCH.quality) { BENCH.quality = ''; resize(); }
    setView(v0[0], v0[1]);
  }
  const pad = (x, n) => String(x).padStart(n), nm = Math.max(...rows.map(r => r.name.length));
  const txt = `Seqret ${APP.version} frame-rate test · ${S.name} · ${S.seq.nb.toLocaleString()} blocks · ${(v0[1] - v0[0] >= S.seq.totalDur * 0.9) ? 'whole file' : 'span ' + fmt((v0[1] - v0[0]) * 1e3, 3) + ' ms'} in view\n` +
    `plot ${Math.round(W)}×${Math.round(H)} CSS px at ${window.devicePixelRatio}× · diagram quality ${S.diagRes}, peaks ${S.lineMode}${pdpr !== dpr ? ` (${pdpr}× pixels)` : ''} · ${{ seq: 'Sequence', blk: 'Selection', k: 'k-space', img: 'Image', defs: 'Defs' }[S.tab] || S.tab} tab${S.tab === 'k' ? ` (${S.kRange})` : ''} · ${navigator.userAgent.replace(/^.*?\) /, '').slice(0, 60)}\n` +
    // quantity names on the first header line, their units on the second
    `${'case'.padEnd(nm)}  ${pad('frame rate', 10)}  ${pad('frame time', 16)}  ${pad('Seqret time', 16)}\n` +
    `${''.padEnd(nm)}  ${pad('fps', 10)}  ${pad('ms, median / 95%', 16)}  ${pad('ms, median / 95%', 16)}\n` +
    rows.map(r => `${r.name.padEnd(nm)}  ${pad(r.fps.toFixed(0), 10)}  ${pad(`${pad(r.med.toFixed(1), 6)} / ${pad(r.p95.toFixed(1), 5)}`, 16)}  ${pad(`${pad(r.js.toFixed(1), 6)} / ${pad(r.jsMax.toFixed(1), 5)}`, 16)}`).join('\n');
  // a suggestion when the browser's drawing, not Seqret, limits the frame rate
  const row = n => rows.find(r => r.name === n), nrm = row('normal, panning'), blank = row('blank diagram');
  // who limits the frame rate: the browser's drawing (the frame takes much longer than Seqret's own work) or Seqret
  let tip = '';
  if (nrm && blank && blank.fps > 1.25 * nrm.fps) {
    const QS = ['ultra', 'high', 'standard', 'fast'], better = QS.slice(QS.indexOf(S.diagRes) + 1).map(q => row(`diagram quality ${q}`)).filter(r => r && r.fps > 1.2 * nrm.fps);
    const lower = better.map(r => `Display › Diagram quality › ${r.name.split(' ').pop()} gave ${r.fps.toFixed(0)} fps`);
    // the one part of the drawing whose removal helps most, when it is a large share
    const parts = rows.filter(r => r.name.startsWith('without ') && r.name !== 'without page updates').sort((a, b) => b.fps - a.fps);
    const worst = parts.length && parts[0].fps > 1.5 * nrm.fps ? parts[0] : null;
    // Seqret's own work is the limit only when it takes most of what the screen allows per frame (the blank diagram's
    // frame time); before 1.24.2 it was compared with the (slow) frame itself, so 5 ms of Seqret in a 10 ms frame on
    // a 100 Hz screen, where the drawing took the rest, was blamed on Seqret
    if (nrm.js > 0.8 * (1000 / blank.fps)) {
      tip = `\n\nSeqret's own work limits the frame rate here: it needs ${nrm.js.toFixed(1)} ms of a ${nrm.med.toFixed(1)} ms frame (a blank diagram runs at ${blank.fps.toFixed(0)} fps). This grows with the number of blocks in view; zooming in makes it faster.`;
      if (lower.length) tip += ` ${lower.join('; ')}.`;
    } else {
      tip = `\n\nThe browser's drawing limits the frame rate here: a blank diagram runs at ${blank.fps.toFixed(0)} fps, the diagram at ${nrm.fps.toFixed(0)} fps, while Seqret needs ${nrm.js.toFixed(1)} ms per frame.`;
      if (worst) tip += ` Most of it is one part: ${worst.name.replace('without ', '')} (${worst.fps.toFixed(0)} fps without it); please report this.`;
      if (lower.length) tip += ` ${lower.join('; ')}.`;
      tip += ' In Chrome or Edge, check chrome://gpu: if Skia Graphite is disabled, enabling it (chrome://flags/#skia-graphite) may give the full frame rate at full sharpness.';
    }
  }
  BENCH.last = txt; console.log(txt + tip);
  el.textContent = txt + tip + '\n\nCopied to the clipboard. Press Shift+D to close.';
  el.classList.add('sel');
  try { await navigator.clipboard.writeText(txt + tip); } catch (_) { el.textContent = txt + tip + '\n\nSelect this text to copy it. Press Shift+D to close.'; }
}
$('#benchBtn').onclick = () => { $('#morePop').hidden = true; $('#moreBtn').setAttribute('aria-expanded', 'false'); diagBench(); };
function shotOfBlock(b) { const sh = S.seq.shots; if (!sh.length || b < 0) return -1; let lo = 0, hi = sh.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (sh[m].b0 <= b) lo = m; else hi = m - 1; } return lo; }
function shotAt(t) { return S.seq.shots.length ? Math.max(0, Math.min(S.seq.shots.length - 1, ub(S.shotT0, t) - 1)) : -1; }
function volOfBlock(b) { const v = S.vols; if (!v.length || b < 0) return -1; let lo = 0, hi = v.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (v[m].b0 <= b) lo = m; else hi = m - 1; } return lo; }
function volAt(t) { return S.vols.length ? Math.max(0, Math.min(S.vols.length - 1, ub(S.volT0, t) - 1)) : -1; }
function selRange() {
  const s = S.seq; if (!s || S.sel < 0) return null;
  if (S.selKind === 'shot' && s.shots.length) { const x = s.shots[shotOfBlock(S.sel)]; return [x.t0, x.t1]; }
  if (S.selKind === 'vol' && S.vols.length) { const x = S.vols[volOfBlock(S.sel)]; return [x.t0, x.t1]; }
  return [s.blockStart[S.sel], s.blockStart[S.sel + 1]];
}
function drawStrip(items, i0, i1, y, title, word, selIdx, strong, isEmpty, X, x0, pw) {
  const h = SHOTH;
  pctx.save(); pctx.beginPath(); pctx.rect(x0, y - 1, pw, h + 2); pctx.clip();
  pctx.font = `500 11px ${C.font}`; pctx.textBaseline = 'middle'; pctx.textAlign = 'center';
  if (i1 - i0 > pw / 3) {
    pctx.fillStyle = C.ink; pctx.globalAlpha = 0.09; pctx.fillRect(x0, y, pw, h); pctx.globalAlpha = 1;
    pctx.fillStyle = C.muted; pctx.fillText(`${(i1 - i0 + 1).toLocaleString()} ${title.toLowerCase()} in view · zoom in to see them`, x0 + pw / 2, y + h / 2 + 0.5);
  } else {
    for (let k = i0; k <= i1; k++) {
      const it = items[k], a = X(it.t0), b = X(it.t1), w = b - a, empty = isEmpty(it), sel = k === selIdx;
      pctx.fillStyle = sel ? C.sel : C.ink;
      pctx.globalAlpha = sel ? (strong ? 0.7 : 0.32) : empty ? 0.04 : (k % 2 ? 0.14 : 0.08);
      pctx.fillRect(a + 0.5, y, Math.max(1, w - 1), h); pctx.globalAlpha = 1;
      if (sel && strong) { pctx.strokeStyle = C.ink; pctx.lineWidth = 1.5; pctx.strokeRect(a + 1.25, y + 0.75, Math.max(1, w - 2.5), h - 1.5); pctx.lineWidth = 1; }
      else if (empty && w > 4) { pctx.strokeStyle = C.faint; pctx.setLineDash([2, 2]); pctx.strokeRect(a + 1, y + 0.5, w - 2, h - 1); pctx.setLineDash([]); }
      const vis0 = Math.max(a, x0), vis1 = Math.min(b, x0 + pw), vw = vis1 - vis0;
      const lab = vw > 120 && empty ? `${word} ${k + 1} · no ADC` : vw > 60 ? `${word} ${k + 1}` : vw > 22 ? `${k + 1}` : '';
      if (lab) { pctx.fillStyle = empty ? C.muted : C.ink; pctx.fillText(lab, (vis0 + vis1) / 2, y + h / 2 + 0.5); }
    }
  }
  pctx.restore();
  pctx.fillStyle = C.muted; pctx.textAlign = 'left'; pctx.font = `600 11px ${C.font}`; pctx.textBaseline = 'middle';
  pctx.fillText(title, 16, y + h / 2 + 0.5);
}
/* ADC events as bars coloured by type; one winner per pixel column when zoomed out */
let typeCols = new Int8Array(0);
function drawTypeBar(y, h, X, t0, t1, x0, pw, alpha = 1) {
  const s = S.seq, A0 = s.adcT0, A1 = s.adcT1, AT = s.adcType; if (!A0.length) return;
  const lo = lb(A1, t0), hiI = ub(A0, t1);
  pctx.globalAlpha = alpha;
  const paths = new Map(), pathOf = tp => { let q = paths.get(tp); if (!q) paths.set(tp, q = new Path2D()); return q; }; // one fill per ADC type
  if (hiI - lo <= pw) {
    for (let i = lo; i < hiI; i++) { const xa = X(A0[i]), xb = X(A1[i]); pathOf(AT[i]).rect(xa, y, Math.max(1, xb - xa), h); }
  } else {
    const nc = Math.ceil(pw) + 1; if (typeCols.length < nc) typeCols = new Int8Array(nc); typeCols.fill(-1, 0, nc);
    for (let i = lo; i < hiI;) {
      let ka = Math.floor(X(A0[i]) - x0), kb = Math.floor(X(A1[i]) - x0);
      let tp = AT[i], next = i + 1;
      if (ka === kb && ka >= 0 && ka < nc) { // events ending inside this column, via the ADC pyramid
        const tEnd = t0 + (ka + 1) * (t1 - t0) / pw; let a = i, b = hiI - 1;
        while (a < b) { const m = (a + b + 1) >> 1; if (A1[m] <= tEnd) a = m; else b = m - 1; }
        tp = adcRangeType(s, i, a); next = a + 1;
      }
      if (ka < 0) ka = 0; if (kb >= nc) kb = nc - 1;
      for (let k = ka; k <= kb; k++) if (typeCols[k] < 0 || TYPE_RANK[tp] > TYPE_RANK[typeCols[k]]) typeCols[k] = tp;
      i = next;
    }
    for (let k = 0; k < nc;) { const tp = typeCols[k]; let e = k + 1; while (e < nc && typeCols[e] === tp) e++; if (tp >= 0) pathOf(tp).rect(x0 + k, y, e - k, h); k = e; }
  }
  for (const [tp, q] of paths) { pctx.fillStyle = C[TYPE_COL[tp]]; pctx.fill(q); }
  pctx.globalAlpha = 1;
}
/* Labels lane: ADC type row, then one row per label (flags as bars, counters as numbered steps) */
function drawLabelsLane(L, X, t0, t1, x0, pw) {
  const s = S.seq, rows = labelRows(); if (!rows.length) return;
  const rh = (L.h - 6) / rows.length, T = s.totalDur;
  pctx.fillStyle = C.ink; pctx.fillRect(8, L.y + 2, 3, L.h - 4);
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r], y = L.y + 3 + r * rh;
    pctx.textBaseline = 'middle'; pctx.textAlign = 'left'; pctx.font = `600 10.5px ${C.font}`; pctx.fillStyle = C.ink;
    pctx.fillText(row.name, 16, y + rh / 2);
    if (row.kind === 'count' && rh >= 13) { pctx.textAlign = 'right'; pctx.font = `400 10px ${C.font}`; pctx.fillStyle = C.muted; pctx.fillText(`${row.tr.min}–${row.tr.max}`, x0 - 6, y + rh / 2); }
    pctx.strokeStyle = C['line-soft']; pctx.lineWidth = 1; pctx.beginPath(); pctx.moveTo(x0, Math.round(y + rh) + 0.5); pctx.lineTo(x0 + pw, Math.round(y + rh) + 0.5); pctx.stroke();
    pctx.save(); pctx.beginPath(); pctx.rect(x0, y, pw, rh); pctx.clip();
    if (row.kind === 'type') drawTypeBar(y + 2, rh - 4, X, t0, t1, x0, pw);
    else {
      const tr = row.tr, n = tr.t.length, i0 = Math.max(0, ub(tr.t, t0) - 1), i1 = Math.min(n, lb(tr.t, t1));
      const end = i => i + 1 < n ? tr.t[i + 1] : T;
      if (row.kind === 'flag') {
        pctx.fillStyle = C[FLAG_COL[tr.name]] || C.muted; pctx.globalAlpha = FLAG_COL[tr.name] ? 0.9 : 0.55;
        const bars = new Path2D(); // one fill per row instead of one per bar (thousands per frame when zoomed out)
        if (i1 - i0 <= 2 * pw) { for (let i = i0; i < i1; i++) if (tr.v[i]) { const xa = X(tr.t[i]), xb = X(end(i)); bars.rect(xa, y + 3, Math.max(1, xb - xa), rh - 6); } }
        else { const pts = tracePoints(trStep(tr), t0, t1, x0, pw); let on = -1; for (let k = 0; k < pts.length; k += 2) { const x = pts[k] | 0; if (pts[k + 1]) { if (on < 0) on = x; } else if (on >= 0) { bars.rect(on, y + 3, Math.max(1, x - on + 1), rh - 6); on = -1; } } if (on >= 0) bars.rect(on, y + 3, x0 + pw - on, rh - 6); }
        pctx.fill(bars); pctx.globalAlpha = 1;
      } else if (i1 - i0 < pw / 9) {
        pctx.font = `500 10px ${C.font}`; pctx.textAlign = 'center';
        for (let i = i0; i < i1; i++) {
          const xa = X(tr.t[i]), xb = X(end(i)), w = xb - xa;
          pctx.fillStyle = C.ink; pctx.globalAlpha = i % 2 ? 0.1 : 0.05; pctx.fillRect(xa + 0.5, y + 2, Math.max(1, w - 1), rh - 4); pctx.globalAlpha = 1;
          const txt = String(tr.v[i]), tw = pctx.measureText(txt).width;
          const va = Math.max(xa, x0), vb = Math.min(xb, x0 + pw);
          if (vb - va > tw + 4) { pctx.fillStyle = C.ink; pctx.fillText(txt, (va + vb) / 2, y + rh / 2 + 0.5); }
        }
      } else {
        const span = (tr.max - tr.min) || 1, yb = y + rh - 3, hh = rh - 6;
        strokePts(pctx, tracePoints(trStep(tr), t0, t1, x0, pw), v => yb - (v - tr.min) / span * hh, C.muted);
      }
    }
    pctx.restore();
  }
}
function drawADC(L, X, t0, t1, pw, x0) {
  const s = S.seq, y1 = L.y + L.h - 5, y0 = L.y + 5, mid = (y0 + y1) / 2;
  drawTypeBar(y0, y1 - y0, X, t0, t1, x0, pw, 0.85);
  // samples when zoomed in
  const sc = pw / (t1 - t0), A0 = s.adcT0, A1 = s.adcT1;
  if (A0.length) {
    const lo = lb(A1, t0), hi = ub(A0, t1);
    if (hi - lo < pw) {
      pctx.fillStyle = C.plot; pctx.globalAlpha = 0.8;
      for (let i = lo; i < hi; i++) {
        const d = s.adc.get(s.B.adc[s.adcBlocks[i]]); if (d.dwell * sc < 4) continue;
        for (let k = 0; k < d.num; k++) { const x = X(A0[i] + (k + 0.5) * d.dwell); if (x < x0 - 3 || x > x0 + pw + 3) continue; pctx.fillRect(x - 1, mid - 3, 2, 6); }
      }
      pctx.globalAlpha = 1;
    }
  }
  // triggers
  pctx.fillStyle = C.ink;
  const TR = s.triggers; let ti = 0; { let a = 0, b = TR.length; while (a < b) { const m = (a + b) >> 1; if (TR[m].t < t0) a = m + 1; else b = m; } ti = a; }
  for (; ti < TR.length && TR[ti].t <= t1; ti++) {
    const tr = TR[ti];
    const x = X(tr.t); pctx.beginPath(); pctx.moveTo(x, y0 - 2); pctx.lineTo(x - 4, y0 - 8 + 12); pctx.lineTo(x + 4, y0 - 8 + 12); pctx.closePath(); pctx.fill();
  }
}

function updateLegend() {
  const el = $('#legend'), s = S.seq;
  const cnt = s ? s.adcTypeCounts : null, show = !!(cnt && cnt.slice(1).some(Boolean) && (S.vis.adc || S.vis.labels));
  el.hidden = !show; if (!show) return;
  const html = cnt.map((n, i) => n ? `<span class="v"><i style="--c:var(--c-${TYPE_COL[i]})"></i>${TYPE_NAME[i]} <span class="muted">${n.toLocaleString()}</span></span>` : '').join('');
  if (el.dataset.html !== html) { el.innerHTML = '<span class="muted">ADC events:</span>' + html; el.dataset.html = html; }
}
/* ---------- overview ---------- */
let ovCache = null;
function drawOverview() {
  const s = S.seq; if (!s || OW <= 0) return;
  if (!ovCache) {
    ovCache = document.createElement('canvas'); ovCache.width = Math.round(OW * pdpr); ovCache.height = Math.round(OH * pdpr);
    const c = ovCache.getContext('2d'); c.setTransform(pdpr, 0, 0, pdpr, 0, 0);
    const T = s.totalDur || 1, mg = Math.max(...s.stats.maxG) || 1, mr = s.stats.maxRF || 1;
    const mid = OH * 0.62, hh = OH * 0.34;
    for (const k of ['gx', 'gy', 'gz']) {
      const pts = traceChan(k, 0, T, 0, OW);
      c.globalAlpha = 0.75; strokePts(c, pts, v => mid - v / mg * hh, C[k]); c.globalAlpha = 1;
    }
    const pr = traceChan('rfMag', 0, T, 0, OW);
    strokePts(c, pr, v => OH * 0.26 - v / mr * OH * 0.22, C.rf, OH * 0.26);
    if (shotsOn() && s.shots.length < OW / 2) {
      c.strokeStyle = C.ink; c.globalAlpha = 0.55; c.beginPath();
      for (const sh of s.shots) { const x = Math.round(sh.t0 / T * OW) + 0.5; c.moveTo(x, 0); c.lineTo(x, 6); }
      c.stroke(); c.globalAlpha = 1;
    }
    if (volsOn() && S.vols.length < OW / 3) {
      c.strokeStyle = C.ink; c.globalAlpha = 0.6; c.lineWidth = 1.5; c.beginPath();
      for (const v of S.vols.slice(1)) { const x = Math.round(v.t0 / T * OW) + 0.5; c.moveTo(x, 0); c.lineTo(x, OH); }
      c.stroke(); c.globalAlpha = 1; c.lineWidth = 1;
    }
  }
  vctx.clearRect(0, 0, OW, OH);
  vctx.drawImage(ovCache, 0, 0, OW, OH);
  const T = s.totalDur || 1;
  let xa = S.t0 / T * OW, xb = S.t1 / T * OW;
  if (xb - xa < 3) { const m = (xa + xb) / 2; xa = m - 1.5; xb = m + 1.5; }
  vctx.fillStyle = C.plot; vctx.globalAlpha = 0.62;
  vctx.fillRect(0, 0, Math.max(0, xa), OH); vctx.fillRect(xb, 0, OW - xb, OH); vctx.globalAlpha = 1;
  vctx.strokeStyle = C.ink; vctx.lineWidth = 1.5; vctx.strokeRect(xa + 0.75, 0.75, xb - xa - 1.5, OH - 1.5);
  if (S.sel >= 0) { vctx.fillStyle = C.sel; const x = s.blockStart[S.sel] / T * OW; vctx.fillRect(x - 1, 0, 2, OH); }
}

/* ---------- overlay: crosshair + values ---------- */
let boxSel = null;
function drawOverlay() {
  octx.clearRect(0, 0, W, H);
  if (!S.seq) return;
  const pw = W - GUT - 8, x0 = GUT;
  if (boxSel) {
    const a = Math.min(boxSel.a, boxSel.b), b = Math.max(boxSel.a, boxSel.b);
    octx.fillStyle = C.gx; octx.globalAlpha = 0.12; octx.fillRect(a, 0, b - a, H - AXH); octx.globalAlpha = 1;
    octx.strokeStyle = C.gx; octx.strokeRect(a + 0.5, 0.5, b - a, H - AXH - 1);
    const lab = fmtT(xToT(b) - xToT(a)); octx.font = `600 11px ${C.font}`;
    const tw = octx.measureText(lab).width, lx = (a + b) / 2;
    octx.fillStyle = C.gx; octx.fillRect(lx - tw / 2 - 5, H - AXH + 3, tw + 10, 17);
    octx.fillStyle = C.plot; octx.textAlign = 'center'; octx.textBaseline = 'middle'; octx.fillText(lab, lx, H - AXH + 12);
    return;
  }
  if (S.hoverT == null) return;
  const t = S.hoverT, x = x0 + (t - S.t0) / (S.t1 - S.t0) * pw;
  if (x < x0 || x > x0 + pw) return;
  octx.strokeStyle = C.ink; octx.globalAlpha = 0.55; octx.lineWidth = 1;
  octx.beginPath(); octx.moveTo(Math.round(x) + 0.5, 0); octx.lineTo(Math.round(x) + 0.5, H - AXH); octx.stroke(); octx.globalAlpha = 1;
  octx.font = `600 11px ${C.font}`; octx.textBaseline = 'middle';
  const right = x < x0 + pw - 120;
  for (const L of lanesGeom()) {
    if (L.key === 'adc') continue;
    if (L.key === 'labels') {
      const rows = labelRows(), rh = (L.h - 6) / rows.length;
      octx.font = `600 10.5px ${C.font}`;
      rows.forEach((row, r) => {
        let txt = '';
        if (row.kind === 'type') { const j = adcAt(t); if (j >= 0) txt = TYPE_NAME[S.seq.adcType[j]]; }
        else { const i = ub(row.tr.t, t) - 1; if (i >= 0) txt = row.kind === 'flag' ? (row.tr.v[i] ? 'on' : '') : String(row.tr.v[i]); }
        if (!txt) return;
        const ty = L.y + 3 + r * rh + rh / 2, tw = octx.measureText(txt).width, tx = right ? x + 6 : x - 6 - tw;
        octx.fillStyle = C.plot; octx.globalAlpha = 0.9; octx.fillRect(tx - 3, ty - 6.5, tw + 6, 13); octx.globalAlpha = 1;
        octx.fillStyle = row.kind === 'type' ? C[TYPE_COL[TYPE_NAME.indexOf(txt)]] : C.ink; octx.textAlign = 'left'; octx.fillText(txt, tx, ty);
      });
      octx.font = `600 11px ${C.font}`;
      continue;
    }
    if (L.stim) { // values of the stimulation traces at the cursor
      const m = STIM ? STIM.idx[L.stim] : undefined; if (m === undefined) continue;
      const v = stimAtCached(t); if (!v) continue;
      [['gx', 0, 'x'], ['gy', 1, 'y'], ['gz', 2, 'z']].concat(S.stimNorm ? [['muted', 3, '‖·‖']] : []).forEach(([col, j, lab], i) => {
        const txt = `${stimNum(v[m * 4 + j])} % ${lab}`, ty = L.y + 10 + i * 14, tw = octx.measureText(txt).width, tx = right ? x + 6 : x - 6 - tw;
        octx.fillStyle = C.plot; octx.globalAlpha = 0.85; octx.fillRect(tx - 3, ty - 7, tw + 6, 14); octx.globalAlpha = 1;
        octx.fillStyle = C[col]; octx.textAlign = 'left'; octx.fillText(txt, tx, ty);
      });
      continue;
    }
    const chans = laneChannels(L), f = laneFactor(L.key);
    let i = 0;
    for (const [col, c] of chans) {
      const v = channelValue(S.seq, c, t);
      const txt = v !== v ? '' : (L.kind === 'phase' ? fmt(v, 3) + ' rad' : fmt(v * f, 3) + (chans.length > 1 ? ` ${c === 'rfRe' ? 're' : c === 'rfIm' ? 'im' : col.toUpperCase()[1]}` : ''));
      if (!txt) continue;
      const ty = L.y + 10 + i * 14; i++;
      const tw = octx.measureText(txt).width;
      const tx = right ? x + 6 : x - 6 - tw;
      octx.fillStyle = C.plot; octx.globalAlpha = 0.85; octx.fillRect(tx - 3, ty - 7, tw + 6, 14); octx.globalAlpha = 1;
      octx.fillStyle = C[col]; octx.textAlign = 'left'; octx.fillText(txt, tx, ty);
    }
  }
  const tl = fmtT(t), tw = octx.measureText(tl).width;
  octx.fillStyle = C.ink; octx.fillRect(x - tw / 2 - 5, H - AXH + 3, tw + 10, 17);
  octx.fillStyle = C.plot; octx.textAlign = 'center'; octx.fillText(tl, x, H - AXH + 12);
}
const HINT = '<span class="hint">Drag to zoom into a range · right-drag or scroll sideways to pan · scroll to zoom · <kbd>Backspace</kbd> goes back · click a block to inspect it · ← → step through the selected block, shot or volume</span>';
function updateReadout() {
  const el = $('#readout');
  if (!S.seq || S.hoverT == null) {
    if (!el.dataset.hint) { el.innerHTML = HINT; el.dataset.hint = '1'; }
    return;
  }
  el.dataset.hint = '';
  const s = S.seq, t = S.hoverT, b = blockAt(t);
  const g = k => fmt(channelValue(s, k, t) * gF(), 3);
  const adcOn = adcAt(t) >= 0;
  const sk = shotsOn() ? shotAt(t) : -1;
  el.innerHTML = `<span>t <b>${fmtT(t)}</b></span><span>block <b>${s.B.id[b]}</b> <span class="muted">${esc(describeBlock(b))}</span> <span class="muted">(${fmtT(t - s.blockStart[b])} in)</span></span>` +
    (volsOn() ? `<span>volume <b>${volAt(t) + 1}</b><span class="muted"> / ${S.vols.length}</span></span>` : '') +
    (sk >= 0 ? `<span>shot <b>${sk + 1}</b><span class="muted"> / ${s.shots.length}</span></span>` : '') +
    (S.rfMode === 'complex' ? `<span class="v"><i style="--c:var(--c-rf)"></i>RF <b>${fmt(channelValue(s, 'rfRe', t) * rF(), 3)}</b> re, <b>${fmt(channelValue(s, 'rfIm', t) * rF(), 3)}</b> im ${rU()}</span>`
      : `<span class="v"><i style="--c:var(--c-rf)"></i>RF <b>${fmt(channelValue(s, 'rfMag', t) * rF(), 3)}</b> ${rU()}</span>`) +
    ['gx', 'gy', 'gz'].map(k => `<span class="v"><i style="--c:var(--c-${k})"></i>${'G' + k[1]} <b>${g(k)}</b></span>`).join('') +
    `<span class="muted">${gU()}</span>` + (adcOn ? `<span class="v"><i style="--c:var(--c-adc)"></i><b>ADC on</b></span>` : '') +
    (S.vis.m0 ? `<span class="v"><i style="--c:var(--ink)"></i>k <b>${['mx', 'my', 'mz'].map(k => fmt(channelValue(s, k, t) * mF(), 3)).join(', ')}</b> <span class="muted">${mU()}</span></span>` : '') + stimReadout(t);
}

/* ---------- view control ---------- */
function setView(t0, t1) {
  const T = S.seq ? S.seq.totalDur : 1;
  // at least 0.1 ms across the plot (1.23.3): finer is below every raster time of interest, and at the former limit
  // of 0.2 µs a few drawing paths had to walk from far off-screen points to the view
  const MIN_SPAN = 1e-4; let span = Math.min(Math.max(t1 - t0, MIN_SPAN), Math.max(T * 1.1 || 1, MIN_SPAN));
  let c = (t0 + t1) / 2;
  const lo = -0.05 * T + span / 2, hi = T * 1.05 - span / 2;
  if (lo <= hi) c = Math.min(Math.max(c, lo), hi); else c = T / 2;
  S.t0 = c - span / 2; S.t1 = c + span / 2; request();
  if (!linkApplying) linkSendView();
}
function pushHist() { S.hist.push([S.t0, S.t1]); if (S.hist.length > 60) S.hist.shift(); $('#backBtn').disabled = false; }
function back() { const v = S.hist.pop(); if (v) setView(v[0], v[1]); $('#backBtn').disabled = !S.hist.length; }
function zoomToRange(t0, t1, hist = true) { const d = t1 - t0; if (hist) pushHist(); setView(t0 - d * 0.03, t1 + d * 0.03); }
function zoomToShot(k, hist = true) { const sh = S.seq.shots[k]; if (sh) zoomToRange(sh.t0, sh.t1, hist); }
function zoomToVol(k, hist = true) { const v = S.vols[k]; if (v) zoomToRange(v.t0, v.t1, hist); }
/* Go to shot/volume k. If the view shows the whole current item (or not that item at all), the
   whole new item is shown; if the user has zoomed inside it, the same zoom is kept, shifted so
   it sits at the same place relative to the start of the new item. */
function gotoItem(kind, k) {
  const list = kind === 'shot' ? S.seq.shots : S.vols; if (!list.length) return;
  k = Math.max(0, Math.min(list.length - 1, k));
  const cur = S.sel >= 0 ? (kind === 'shot' ? shotOfBlock(S.sel) : volOfBlock(S.sel)) : (kind === 'shot' ? shotAt : volAt)((S.t0 + S.t1) / 2);
  const stepping = S.selKind === kind && S.sel >= 0, span = S.t1 - S.t0, c = list[cur], nx = list[k];
  selectBlock(nx.b0, { kind });
  if (!stepping) { (kind === 'shot' ? zoomToShot : zoomToVol)(k, true); return; } // a first selection shows the whole item
  // stepping keeps the zoom (the time span): zoomed inside the item → same offset into the next one;
  // otherwise → centred on the next one
  const inside = c && S.t0 >= c.t0 - 1e-9 && S.t1 <= c.t1 + 1e-9 && span < c.t1 - c.t0;
  if (inside) { const d = nx.t0 - c.t0; setView(S.t0 + d, S.t1 + d); }
  else { const m = (nx.t0 + nx.t1) / 2; setView(m - span / 2, m + span / 2); }
}
function stepShot(dir) {
  if (!S.seq.shots.length) return;
  const cur = S.sel >= 0 ? shotOfBlock(S.sel) : shotAt((S.t0 + S.t1) / 2); gotoItem('shot', cur + dir);
}
function stepVol(dir) {
  if (!S.vols.length) return;
  const cur = S.sel >= 0 ? volOfBlock(S.sel) : volAt((S.t0 + S.t1) / 2); gotoItem('vol', cur + dir);
}
/* toolbar steppers */
function stepBlock(dir) {
  if (!S.seq) return;
  const cur = S.sel >= 0 ? S.sel : blockAt((S.t0 + S.t1) / 2);
  selectBlock(cur + dir, { ensureVisible: true, kind: 'block' });
}
function navCurrent(kind) {
  const s = S.seq, c = (S.t0 + S.t1) / 2;
  if (kind === 'block') return S.sel >= 0 ? S.sel : blockAt(c);
  if (kind === 'shot') return !s.shots.length ? -1 : S.sel >= 0 ? shotOfBlock(S.sel) : shotAt(c);
  return !S.vols.length ? -1 : S.sel >= 0 ? volOfBlock(S.sel) : volAt(c);
}
function updateNav() {
  const s = S.seq, nav = $('#nav');
  nav.hidden = !s;
  if (!s) return;
  const total = { block: s.nb, shot: shotsOn() ? s.shots.length : 0, vol: volsOn() ? S.vols.length : 0 };
  for (const k of ['block', 'shot', 'vol']) {
    const g = $('#nav-' + k), n = total[k];
    g.hidden = !n; if (!n) continue;
    const i = navCurrent(k), inp = g.querySelector('input');
    g.classList.toggle('active', S.sel >= 0 && S.selKind === k);
    if (document.activeElement !== inp) { inp.value = i + 1; inp.max = n; inp.style.width = (String(n).length + 2.2) + 'ch'; }
    g.querySelector('.of').textContent = '/ ' + n.toLocaleString();
    g.querySelector('.prev').disabled = S.sel >= 0 && S.selKind === k && i <= 0;
    g.querySelector('.next').disabled = S.sel >= 0 && S.selKind === k && i >= n - 1;
  }
}
function navGo(kind, idx) {
  const s = S.seq; if (!s || !(idx >= 0)) return;
  if (kind === 'block') { idx = Math.min(idx, s.nb - 1); selectBlock(idx, { kind: 'block' }); pushHist(); zoomToBlock(idx); }
  else gotoItem(kind, idx);
}
for (const k of ['block', 'shot', 'vol']) {
  const g = $('#nav-' + k), step = k === 'block' ? stepBlock : k === 'shot' ? stepShot : stepVol;
  g.querySelector('.prev').onclick = () => step(-1);
  g.querySelector('.next').onclick = () => step(1);
  const inp = g.querySelector('input');
  inp.onchange = () => navGo(k, parseInt(inp.value, 10) - 1);
  inp.onkeydown = e => { if (e.key === 'Enter') { inp.blur(); } if (e.key === 'Escape') { inp.blur(); updateNav(); } };
}
function fitAll() { const T = S.seq.totalDur; setView(-0.008 * T, T * 1.008); }
function zoomAt(t, f) { setView(t - (t - S.t0) * f, t + (S.t1 - t) * f); }
function xToT(x) { return S.t0 + (x - GUT) / (W - GUT - 8) * (S.t1 - S.t0); }
function zoomToBlock(b) { const s = S.seq, a = s.blockStart[b], d = s.blockStart[b + 1] - a; setView(a - d * 0.08, a + d * 1.08); }
function selectBlock(b, opts = {}) {
  if (!S.seq) return;
  b = Math.max(0, Math.min(S.seq.nb - 1, b)); S.sel = b; S.selKind = opts.kind || 'block';
  if (opts.ensureVisible) { const s = S.seq, a = s.blockStart[b], e = s.blockStart[b + 1]; if (a < S.t0 || e > S.t1) { const sp = S.t1 - S.t0; if (e - a > sp) zoomToBlock(b); else setView(a - (sp - (e - a)) / 2, a - (sp - (e - a)) / 2 + sp); } }
  renderBlock(); if (opts.tab && S.tab !== 'k' && S.tab !== 'img') setTab('blk'); request(); if (S.kRange === 'shot' || S.kRange === 'vol') requestK(); requestImg();
}

/* ---------- plot interaction ---------- */
const ptrs = new Map(); let drag = null;
ovl.addEventListener('pointerdown', e => {
  if (!S.seq) return;
  ovl.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.offsetX, y: e.offsetY });
  if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; drag = { pinch: true, d0: Math.abs(a.x - b.x) || 1, t0: S.t0, t1: S.t1, cx: xToT((a.x + b.x) / 2) }; return; }
  if (e.button === 1 || e.button === 2) e.preventDefault();
  // mouse: left-drag selects a range to zoom into; right-drag (or Shift/middle-drag) pans. Touch and pen: drag pans.
  const pan = e.pointerType !== 'mouse' || e.shiftKey || e.button === 1 || e.button === 2;
  drag = { x: e.offsetX, y: e.offsetY, t0: S.t0, t1: S.t1, moved: false, box: !pan, button: e.button };
});
ovl.addEventListener('pointermove', e => {
  if (!S.seq) return;
  if (ptrs.has(e.pointerId)) ptrs.set(e.pointerId, { x: e.offsetX, y: e.offsetY });
  if (drag && drag.pinch && ptrs.size === 2) {
    const [a, b] = [...ptrs.values()]; const d = Math.abs(a.x - b.x) || 1, f = drag.d0 / d;
    const c = drag.cx; setView(c - (c - drag.t0) * f, c + (drag.t1 - c) * f); return;
  }
  if (drag && !drag.pinch) {
    const dx = e.offsetX - drag.x;
    if (Math.abs(dx) > 3 || Math.abs(e.offsetY - drag.y) > 3) drag.moved = true;
    if (drag.box) { if (drag.moved) { boxSel = { a: Math.max(GUT, drag.x), b: Math.min(W - 8, Math.max(GUT, e.offsetX)) }; requestOverlay(); } }
    else if (drag.moved) { ovl.classList.add('grabbing'); const dt = dx / (W - GUT - 8) * (drag.t1 - drag.t0); setView(drag.t0 - dt, drag.t1 - dt); }
  }
  if (e.pointerType === 'mouse' || !drag) { S.hoverT = xToT(e.offsetX); requestOverlay(); linkSendHover(); }
});
function endPtr(e) {
  ptrs.delete(e.pointerId); ovl.classList.remove('grabbing');
  if (!drag) return;
  if (drag.pinch) { if (ptrs.size === 0) drag = null; return; }
  if (drag.box && boxSel) {
    const a = Math.min(boxSel.a, boxSel.b), b = Math.max(boxSel.a, boxSel.b); boxSel = null;
    if (b - a > 6) { pushHist(); setView(xToT(a), xToT(b)); } else requestOverlay();
  } else if (!drag.moved && e.type === 'pointerup' && e.offsetX > GUT && !drag.button) {
    const t = xToT(e.offsetX); S.hoverT = t;
    const y = e.offsetY;
    if (volsOn() && y >= volY() - 2 && y < volY() + SHOTH + 2) { const k = volAt(t); selectBlock(S.vols[k].b0, { tab: true, kind: 'vol' }); zoomToVol(k); }
    else if (shotsOn() && y >= shotY() - 2 && y < shotY() + SHOTH + 2) { const k = shotAt(t); selectBlock(S.seq.shots[k].b0, { tab: true, kind: 'shot' }); zoomToShot(k); }
    else if (y >= topH() - 4) selectBlock(blockAt(t), { tab: true });
  }
  boxSel = null;
  drag = null;
}
ovl.addEventListener('pointerup', endPtr); ovl.addEventListener('pointercancel', endPtr);
ovl.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse' && !drag) { S.hoverT = null; requestOverlay(); linkSendHover(); } });
ovl.addEventListener('dblclick', e => { if (S.seq && e.offsetX > GUT && e.offsetY >= topH() - 4) { const b = blockAt(xToT(e.offsetX)); selectBlock(b); pushHist(); zoomToBlock(b); } });
ovl.addEventListener('auxclick', e => { if (e.button === 1) e.preventDefault(); });
ovl.addEventListener('contextmenu', e => e.preventDefault()); // right-drag pans the diagram
ovl.addEventListener('wheel', e => {
  if (!S.seq) return; e.preventDefault();
  const pw = W - GUT - 8;
  const dx = e.deltaMode === 1 ? e.deltaX * 16 : e.deltaX, dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
  if (e.shiftKey || Math.abs(dx) > Math.abs(dy)) { const d = (e.shiftKey ? dy || dx : dx) / pw * (S.t1 - S.t0); setView(S.t0 + d, S.t1 + d); }
  else zoomAt(xToT(e.offsetX), Math.exp(dy * (e.ctrlKey ? 0.012 : 0.0022)));
  S.hoverT = xToT(e.offsetX);
}, { passive: false });

/* overview interaction */
let ovDrag = null;
ov.addEventListener('pointerdown', e => {
  if (!S.seq) return; ov.setPointerCapture(e.pointerId);
  const T = S.seq.totalDur, t = e.offsetX / OW * T;
  if (t < S.t0 || t > S.t1) { const sp = S.t1 - S.t0; setView(t - sp / 2, t + sp / 2); }
  ovDrag = { x: e.offsetX, t0: S.t0, t1: S.t1 };
});
ov.addEventListener('pointermove', e => { if (!ovDrag) return; const dt = (e.offsetX - ovDrag.x) / OW * S.seq.totalDur; setView(ovDrag.t0 + dt, ovDrag.t1 + dt); });
ov.addEventListener('pointerup', () => ovDrag = null); ov.addEventListener('pointercancel', () => ovDrag = null);
ov.addEventListener('wheel', e => { if (!S.seq) return; e.preventDefault(); zoomAt((S.t0 + S.t1) / 2, Math.exp(e.deltaY * 0.0022)); }, { passive: false });

/* keyboard */
document.addEventListener('keydown', e => {
  if (!S.seq || e.target.closest('input,select,textarea,.popbody') || e.metaKey || e.ctrlKey || e.altKey) return;
  const sp = S.t1 - S.t0, c = (S.t0 + S.t1) / 2; let hit = true;
  switch (e.key) {
    case 'ArrowLeft': case 'ArrowRight': {
      const d = e.key === 'ArrowLeft' ? -1 : 1;
      if (S.sel >= 0 && S.selKind === 'block') selectBlock(S.sel + d, { ensureVisible: true });
      else if (S.sel >= 0 && S.selKind === 'shot') stepShot(d);
      else if (S.sel >= 0 && S.selKind === 'vol') stepVol(d);
      else setView(S.t0 + d * sp * 0.2, S.t1 + d * sp * 0.2);
      break;
    }
    case '+': case '=': case 'ArrowUp': zoomAt(c, 0.7); break;
    case '-': case '_': case 'ArrowDown': zoomAt(c, 1 / 0.7); break;
    case 'f': case '0': case 'Home': fitAll(); break;
    case ']': selectBlock((S.sel < 0 ? blockAt(S.t0) : S.sel + 1), { ensureVisible: true }); break;
    case '[': selectBlock((S.sel < 0 ? blockAt(S.t0) : S.sel - 1), { ensureVisible: true }); break;
    case 'Escape': S.sel = -1; S.selKind = null; renderBlock(); request(); break;
    case ';': stepVol(-1); break;
    case "'": stepVol(1); break;
    case ',': stepShot(-1); break;
    case '.': stepShot(1); break;
    case 'Backspace': case 'b': back(); break;
    case 'r': if (SRC && (SRC.handle || SRC.file)) reloadFile(); else hit = false; break;
    case 'D': diagToggle(); break;
    case '\\': setSide(!S.sideHidden); scheduleSave(); break;
    default: hit = false;
  }
  if (hit) e.preventDefault();
});

/* ---------- toolbar ---------- */
// chips grouped by kind of channel in the Display panel (RF, gradients, readout, stimulation), with short labels
const CHIP_GROUP = { rfMag: 'rf', rfPh: 'rf', gx: 'g', gy: 'g', gz: 'g', slew: 'g', m0: 'g', adc: 'acq', labels: 'acq', pns: 'stim', cns: 'stim' };
const CHIP_LABEL = { rfMag: '|B1|', rfPh: 'Phase' };
function buildChips() {
  for (const el of document.querySelectorAll('#dispPop .chips[data-group]')) el.innerHTML = '';
  for (const L of LANES) {
    const el = document.querySelector(`#dispPop .chips[data-group="${CHIP_GROUP[L.key] || 'acq'}"]`);
    const b = document.createElement('button'); b.className = 'chip'; b.type = 'button';
    b.style.setProperty('--c', L.key === 'slew' || L.key === 'labels' || L.key === 'm0' ? 'var(--ink)' : L.stim ? 'var(--muted)' : `var(--c-${L.col})`);
    if (L.key === 'm0') b.title = 'k-vector (the zeroth gradient moment): reset at each excitation, sign flipped at each refocusing pulse, faded after the last readout';
    if (L.stim) b.title = L.stim === 'pns' ? 'Peripheral nerve stimulation (SAFE model)' : 'Cardiac nerve stimulation (SAFE model)';
    b.setAttribute('aria-pressed', S.vis[L.key]); b.innerHTML = `<span class="sw"></span>${CHIP_LABEL[L.key] || L.label}`; if (CHIP_LABEL[L.key]) b.setAttribute('aria-label', L.label);
    b.onclick = () => {
      S.vis[L.key] = !S.vis[L.key]; if (!LANES.some(l => S.vis[l.key])) S.vis[L.key] = true; if (L.key === 'labels') S.labelsPref = S.vis.labels; b.setAttribute('aria-pressed', S.vis[L.key]);
      if (L.stim && S.vis[L.key] && !stimHasModel(L.stim)) openSafeDialog();
      request();
    };
    el.appendChild(b);
  }
}
buildChips();
$('#gUnit').onchange = e => { S.gUnit = e.target.value; request(); renderSeqInfo(); renderBlock(); };
$('#rfUnit').onchange = e => { S.rfUnit = e.target.value; request(); renderSeqInfo(); renderBlock(); };
$('#rfMode').onchange = e => { S.rfMode = e.target.value; request(); };
$('#autoY').onchange = e => { S.autoY = e.target.checked; request(); };
$('#diagRes').onchange = e => { S.diagRes = e.target.value; resize(); };
/* the side panel (tabs) can be hidden for a wider diagram (1.24.1): button in the toolbar, or the \ key; remembered */
function setSide(hidden) {
  S.sideHidden = !!hidden; document.querySelector('.app').classList.toggle('noside', S.sideHidden);
  const b = $('#sideBtn'); b.setAttribute('aria-pressed', S.sideHidden); const t = S.sideHidden ? 'Show the side panel' : 'Hide the side panel, for a wider diagram';
  b.setAttribute('aria-label', t); b.title = t + ' (\\)';
  if (!S.sideHidden) { if (S.tab === 'img') requestImg(); if (S.tab === 'k') requestK(); } // what was skipped while hidden
}
$('#sideBtn').onclick = () => { setSide(!S.sideHidden); scheduleSave(); };
$('#lineMode').onchange = e => { S.lineMode = e.target.value; ovCache = null; request(); };
$('#fitBtn').onclick = () => { if (S.seq) { pushHist(); fitAll(); } };
$('#backBtn').onclick = () => S.seq && back();
$('#combG').onchange = e => { S.combineG = e.target.checked; request(); };
$('#shotSel').onchange = e => { S.shotMode = e.target.value; if (S.seq) { applyShots(); applyVols(); renderSeqInfo(); renderBlock(); ovCache = null; request(); requestK(); } };
$('#volSel').onchange = e => { S.volMode = S.volPref = e.target.value; if (S.seq) { applyVols(); renderSeqInfo(); renderBlock(); ovCache = null; request(); requestK(); } };
function applyVols() {
  const s = S.seq; S.vols = []; S.volT0 = new Float64Array(0);
  if (S.volMode === 'off') return;
  const shots = s.shots.length ? s.shots : (s.shotsExc || computeShots(s, 'exc'));
  if (!shots.length) return;
  let mode = 'auto', lab = null;
  if (S.volMode.startsWith('label:')) { mode = 'label'; lab = S.volMode.slice(6); }
  S.vols = s.vols0 && mode === 'auto' && S.shotMode === 'exc' ? s.vols0 : computeVolumes(s, shots, mode, lab);
  S.volT0 = Float64Array.from(S.vols.map(x => x.t0));
}
function fillVolMenu() {
  const sel = $('#volSel'), labs = labelNames(S.seq), cur = S.volPref; // a label rule is kept for files that have that label
  sel.innerHTML = '<option value="auto">Auto (repeated k-space)</option>' + labs.map(l => `<option value="label:${esc(l)}">Label ${esc(l)} changes</option>`).join('') + '<option value="off">Hidden</option>';
  S.volMode = [...sel.options].some(o => o.value === cur) ? cur : 'auto'; sel.value = S.volMode;
}
function applyShots() {
  const s = S.seq;
  s.shots = S.shotMode === 'off' ? [] : S.shotMode === 'exc' && s.shotsExc ? s.shotsExc : computeShots(s, S.shotMode);
  S.shotT0 = Float64Array.from(s.shots.map(x => x.t0));
}
$('#zoomIn').onclick = () => S.seq && zoomAt((S.t0 + S.t1) / 2, 0.6);
$('#zoomOut').onclick = () => S.seq && zoomAt((S.t0 + S.t1) / 2, 1 / 0.6);
$('#pngBtn').onclick = () => {
  if (!S.seq) return; const name = `${S.name.replace(/\.seq$/i, '')}_diagram.png`;
  if (pdpr === dpr) { savePNG(plot, name); return; }
  PNG_FULL = true; resize(); render(); savePNG(plot, name); PNG_FULL = false; resize(); // always at the screen's density
};
$('#kPng').onclick = () => { if (kData) savePNG(kc, `${S.name.replace(/\.seq$/i, '')}_kspace.png`); };
function savePNG(cv, name) {
  const foot = Math.round(18 * dpr), c = document.createElement('canvas'); c.width = cv.width; c.height = cv.height + foot; // footer strip for the stamp
  const x = c.getContext('2d'); x.fillStyle = C.plot; x.fillRect(0, 0, c.width, c.height); x.drawImage(cv, 0, 0);
  const stamp = `${APP.name} ${APP.version} · ${S.name} · ${new Date().toISOString().slice(0, 10)}`;
  x.font = `${Math.round(10 * dpr)}px ${C.font}`; x.textAlign = 'right'; x.textBaseline = 'bottom'; x.fillStyle = C.faint;
  x.fillText(stamp, c.width - 8 * dpr, c.height - 4 * dpr);
  x.fillStyle = C.line; x.fillRect(0, cv.height, c.width, Math.max(1, Math.round(dpr)));
  c.toBlob(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); });
}
$('#themeBtn').onclick = () => {
  const r = document.documentElement, dark = matchMedia('(prefers-color-scheme: dark)').matches;
  const cur = r.dataset.theme || (dark ? 'dark' : 'light');
  r.dataset.theme = cur === 'dark' ? 'light' : 'dark';
  try { localStorage.setItem('seqret-theme', r.dataset.theme); } catch (_) { }
  themeChanged(); themeLabel();
};
/* storage keys were 'seqview-*' before the rename to Seqret (1.12.0): read the old key when the new one is absent */
function lsGet(k) { try { const v = localStorage.getItem('seqret-' + k); return v !== null ? v : localStorage.getItem('seqview-' + k); } catch (_) { return null; } }
try { const t = lsGet('theme'); if (t) document.documentElement.dataset.theme = t; } catch (_) { }
function themeLabel() { const t = document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); $('#themeBtn').textContent = t === 'dark' ? 'Light theme' : 'Dark theme'; }
themeLabel(); matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeLabel);
function themeChanged() { readColors(); ovCache = null; kInvalidate(); request(); drawK(); drawImg(); }
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeChanged);

/* tabs */
function setTab(t) {
  S.tab = t;
  document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === t));
  for (const p of ['seq', 'blk', 'k', 'img', 'defs']) $('#p-' + p).hidden = p !== t;
  if (t === 'k') { resize(); requestK(); }
  if (t === 'img') { resize(); requestImg(); }
}
document.querySelectorAll('.tab').forEach(b => b.onclick = () => setTab(b.dataset.tab));

/* ---------- side panels ---------- */
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const kv = rows => `<dl class="kv">${rows.filter(Boolean).map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>`;
function renderSeqInfo() {
  const s = S.seq, el = $('#p-seq');
  if (!s) { el.innerHTML = '<p class="note">No sequence loaded.</p>'; return; }
  const st = s.stats, v = s.version, d = s.defs;
  const sig = s.sig.status === 'ok' ? '<span class="badge ok">md5 verified</span>' : s.sig.status === 'mismatch' ? '<span class="badge bad">md5 mismatch</span>' : s.sig.status === 'unsupported' ? `<span class="badge mut">${esc(s.sig.type)} not checked</span>` : '<span class="badge mut">not signed</span>';
  const uses = s.stats.uses;
  const guessed = s.verNum < 1005000;
  const fov = Array.isArray(d.FOV) ? d.FOV.map(x => fmt(x * 1e3, 4)).join(' × ') + ' mm' : null;
  el.innerHTML =
    `<h3>${esc(d.Name || S.name)}</h3>` +
    kv([['Pulseq format', `${v.major}.${v.minor}.${v.revision} <a href="${PULSEQ_WEB}" target="_blank" rel="noopener" title="Pulseq website">ⓘ</a>`], ['Signature', sig], ['Duration', fmtT(s.totalDur)],
      d.TotalDuration != null && Math.abs(d.TotalDuration - s.totalDur) > 1e-6 ? ['Declared duration', `<span style="color:var(--warn)">${fmtT(d.TotalDuration)}</span>`] : null,
      ['Blocks', s.nb.toLocaleString()], fov ? ['FOV', fov] : null,
      s.rot && s.rot.blocks ? ['Rotations', `${s.rot.blocks.toLocaleString()} blocks rotated (${s.rot.distinct} distinct, up to ${fmt(s.rot.maxAngle * 180 / Math.PI, 3)}°); gradients and k-space are shown rotated`] : null]) +
    `<h3>Events</h3>` +
    kv([['RF pulses', st.nRF.toLocaleString()], ...Object.entries(uses).map(([u, n]) => [`&nbsp;&nbsp;${USE[u] || u}${guessed && (u === 'e' || u === 'r') ? '*' : ''}`, n.toLocaleString()]),
      ['ADC events', st.nADC.toLocaleString()],
      ...(s.adcTypeCounts.slice(1).some(Boolean) ? s.adcTypeCounts.map((n, i) => n ? [`&nbsp;&nbsp;<span style="color:var(--c-${TYPE_COL[i]})">■</span> ${TYPE_NAME[i]}`, n.toLocaleString()] : null) : []),
      ['ADC samples', st.nSamples.toLocaleString()],
      ['Unique RF / grad / ADC', `${s.rf.size} / ${s.grad.size} / ${s.adc.size}`], ['Shapes', s.shapes.size]]) +
    (guessed && st.nRF ? '<p class="note">* Format before 1.5 does not store the pulse purpose. It is inferred from the flip angle (≤ 90° excitation, otherwise refocusing), as Pulseq does, and then corrected by context: a pulse followed by no readout before the next excitation is a preparation pulse (inversion near 180°, otherwise saturation; an off-resonant pulse without a gradient is a saturation pulse).</p>' : '') +
    volsHTML() + shotsHTML() +
    `<h3>Gradient peaks <span class="tag">${gU()}, ${sU()}</span></h3>` +
    kv(['x', 'y', 'z'].map((a, i) => [`G${a} amplitude / slew`, `${fmt(st.maxG[i] * gF(), 4)} / ${fmt(st.maxSlew[i] * sF(), 4)}`])) +
    stimSummaryHTML() +
    `<h3>Rasters</h3>` +
    kv([['Gradient', us(s.raster.grad)], ['RF', us(s.raster.rf)], ['ADC', fmt(s.raster.adc * 1e9, 4) + ' ns'], ['Block', us(s.raster.block)]]) +
    `<h3>Settings</h3><p class="note">Lanes, units, shot and volume rules and k-space options are remembered in this browser.</p><button class="btn" id="resetSettings">Restore default settings</button>` +
    `<p class="note" style="margin-top:14px">File format: Pulseq, Layton et al., Magn Reson Med 2017 (${PULSEQ_LINKS})</p>` +
    `<p class="note">${esc(APP.name)} ${esc(APP.version)} · <a href="#" id="aboutLink">About, version history and how to cite</a></p>` +
    (s.warnings.length ? `<h3>Warnings <span class="tag">${s.warnings.length}</span></h3><ul class="warnlist">${s.warnings.slice(0, 50).map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : '');
}
function minMax(a) { let mn = Infinity, mx = -Infinity; for (const x of a) { if (x < mn) mn = x; if (x > mx) mx = x; } return [mn, mx]; } // no spread: arrays can hold ~1M values
function volsHTML() {
  if (S.volMode === 'off') return '';
  const v = S.vols, how = S.volMode === 'auto' ? 'k-space sampling repeats' : `label ${esc(S.volMode.slice(6))} changes`;
  if (!v.length) return `<h3>Volumes</h3><p class="note">No shots were found, so no volumes are marked.</p>`;
  const med = a => { const b = [...a].sort((x, y) => x - y); return b[b.length >> 1]; };
  const range = (a, f) => { const [mn, mx] = minMax(a); return Math.abs(mx - mn) <= 1e-9 * Math.max(1, Math.abs(mx)) ? f(mn) : `${f(med(a))} <span class="muted">(${f(mn)} – ${f(mx)})</span>`; };
  return `<h3>Volumes <span class="tag">new one when ${how}</span></h3>` +
    kv([['Volumes', v.length.toLocaleString()], ['Duration, median', range(v.map(x => x.t1 - x.t0), fmtT)],
      ['Shots / volume', range(v.map(x => x.nShots), n => n.toLocaleString())], ['ADC samples / volume', range(v.map(x => x.nSamples), n => n.toLocaleString())]]) +
    (S.volMode === 'auto' && v.length === 1 ? '<p class="note">No shot repeats its k-space sampling, so the whole sequence counts as one volume.</p>' : '');
}
function shotsHTML() {
  const s = S.seq;
  if (S.shotMode === 'off') return '';
  const sh = s.shots;
  if (!sh.length) return `<h3>Shots</h3><p class="note">No excitation pulses found, so no shots are marked.</p>`;
  const med = a => { const b = [...a].sort((x, y) => x - y); return b[b.length >> 1]; };
  const range = (a, f) => { const [mn, mx] = minMax(a), m = med(a); return Math.abs(mx - mn) <= 1e-9 * Math.max(1, Math.abs(mx)) ? f(m) : `${f(m)} <span class="muted">(${f(mn)} – ${f(mx)})</span>`; };
  const acq = sh.filter(x => x.nADC);
  const fell = S.shotMode === 'prep' && s.shotMode === 'exc';
  const dur = sh.map(x => x.t1 - x.t0);
  return `<h3>Shots <span class="tag">${s.shotMode === 'prep' ? 'split at preparation pulses' : 'one per excitation'}</span></h3>` +
    (fell ? '<p class="note">No inversion, saturation or preparation pulses found, so shots are split at excitations instead.</p>' : '') +
    kv([['Shots', sh.length.toLocaleString()], ['With ADC', acq.length.toLocaleString()],
      sh.length - acq.length ? ['Without ADC', (sh.length - acq.length).toLocaleString()] : null,
      ['Duration, median', sh.length > 1 ? range(dur, fmtT) : fmtT(dur[0])],
      acq.length ? ['ADC samples / shot', range(acq.map(x => x.nSamples), v => v.toLocaleString())] : null]);
}
document.addEventListener('click', e => {
  if (e.target.id === 'resetSettings') resetSettings();
  if (e.target.id === 'aboutLink') { e.preventDefault(); openAbout(); }
});
/* ---------- about, version history, attribution ---------- */
const PULSEQ_DOI = 'https://doi.org/10.1002/mrm.26235', PULSEQ_WEB = 'https://pulseq.github.io';
const PULSEQ_LINKS = `<a href="${PULSEQ_DOI}" target="_blank" rel="noopener">doi:10.1002/mrm.26235</a> · <a href="${PULSEQ_WEB}" target="_blank" rel="noopener">pulseq.github.io</a>`;
function openAbout() {
  const A = APP, d = $('#about');
  $('#aboutTitle').textContent = `${A.name} ${A.version}`;
  $('#aboutSub').textContent = `${A.tagline} · released ${A.date}`;
  const cite = `${A.author}. ${A.name}: a ${A.tagline}, version ${A.version} (${A.date.slice(0, 4)}). ${A.affiliation}.${A.url ? ' ' + A.url : ''}`;
  $('#aboutBody').innerHTML =
    `<div class="credits">${(A.credits || []).map(c => `<div>${esc(c)}</div>`).join('')}</div>` +
    kv([['Version', `${esc(A.version)} (${esc(A.date)})`], A.license ? ['License', `${esc(A.license)} · ${esc(A.copyright || '')}`] : null, A.url ? ['Source code', `<a href="${esc(A.url)}" target="_blank" rel="noopener">${esc(A.url.replace(/^https?:\/\//, ''))}</a>`] : null]) +
    (A.licenseText ? `<details class="lic"><summary>Show the licence text</summary><pre>${esc(A.licenseText)}</pre></details>` : '') +
    `<h3>How to cite</h3><div class="cite" id="citeText">${esc(cite)}</div><div class="cite-row"><button class="btn" id="copyCite">Copy citation</button><span class="muted" id="copyMsg"></span></div>` +
    `<h3>Acknowledgements</h3><ul>
      <li>The Pulseq file format and its conventions (event definitions, labels, k-space calculation): Layton KJ, Kroboth S, Jia F, et al. Pulseq: a rapid and hardware-independent pulse sequence prototyping framework. <i>Magn Reson Med</i> 2017;77(4):1544–1552. ${PULSEQ_LINKS}</li>
      <li>PyPulseq was used to validate the viewer: the reference files of its test suite check the reading of files, the gradient waveforms and k-space, and its waveforms were compared with the stimulation input. Ravi KS, Geethanath S, Vaughan JT. PyPulseq: a Python package for MRI pulse sequence design. <i>J Open Source Softw</i> 2019;4(42):1725. <a href="https://doi.org/10.21105/joss.01725" target="_blank" rel="noopener">doi:10.21105/joss.01725</a> · <a href="https://github.com/imr-framework/pypulseq" target="_blank" rel="noopener">github.com/imr-framework/pypulseq</a></li>
      <li>Nerve stimulation (PNS, CNS) follows the SAFE model as implemented in safe_pns_prediction by F. Szczepankiewicz and T. Witzel (<a href="https://github.com/filip-szczepankiewicz/safe_pns_prediction" target="_blank" rel="noopener">github.com/filip-szczepankiewicz/safe_pns_prediction</a>), against which it was checked. Model: Hebrank FX, Gebhardt M. SAFE-Model: a new method for predicting peripheral nerve stimulations in MRI. <i>Proc Intl Soc Mag Reson Med</i> 2000;8:2007.</li>
    </ul>` +
    `<h3>Recent changes</h3>` + A.changelog.map(c => `<p style="margin:8px 0 2px"><b>${esc(c.version)}</b> <span class="muted">${esc(c.date)}</span></p><ul>${c.notes.map(n => `<li>${esc(n)}</li>`).join('')}</ul>`).join('') +
    `<p class="muted" style="margin-top:10px">The complete version history is in CHANGELOG.md${A.url ? ` in the <a href="${esc(A.url)}" target="_blank" rel="noopener">source code repository</a>` : ''}.</p>`;
  $('#copyCite').onclick = async () => { try { await navigator.clipboard.writeText(cite); $('#copyMsg').textContent = 'Copied'; } catch (_) { const r = document.createRange(); r.selectNodeContents($('#citeText')); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(r); $('#copyMsg').textContent = 'Selected, press Ctrl/Cmd+C'; } };
  if (typeof d.showModal === 'function') d.showModal(); else d.setAttribute('open', '');
}
$('#aboutBtn').onclick = openAbout;
$('#aboutClose').onclick = () => $('#about').close ? $('#about').close() : $('#about').removeAttribute('open');
$('#about').addEventListener('click', e => { if (e.target.id === 'about') $('#about').close(); });
console.info(`${APP.name} ${APP.version} (${APP.date})`);
function renderDefs() {
  const s = S.seq, el = $('#p-defs');
  if (!s) { el.innerHTML = '<p class="note">No sequence loaded.</p>'; return; }
  const keys = [...new Set(s.defOrder)];
  el.innerHTML = keys.length ? `<table class="defs">${keys.map(k => { const v = s.defs[k]; return `<tr><td>${esc(k)}</td><td>${esc(Array.isArray(v) ? v.join('  ') : v)}</td></tr>`; }).join('')}</table>` : '<p class="note">This file has no [DEFINITIONS] section.</p>';
}
function labelState(upTo) { // label values in effect after block upTo
  const st = {};
  for (const tr of S.seq.labels) { const r = ub(tr.b, upTo) - 1; if (r >= 0) st[tr.name] = tr.v[r]; }
  return st;
}
function gradRows(g) {
  const f = gF();
  if (g.type === 'trap') {
    const area = g.amp * (g.rise / 2 + g.flat + g.fall / 2);
    return kv([['Amplitude', `${fmt(g.amp * f, 4)} ${gU()}`], ['Rise / flat / fall', `${fmt(g.rise * 1e6, 5)} / ${fmt(g.flat * 1e6, 5)} / ${fmt(g.fall * 1e6, 5)} µs`],
      ['Delay', us(g.delay)], ['Area', `${fmt(area, 5)} m⁻¹`], ['Slew (ramp up)', g.rise > 0 ? `${fmt(g.amp / g.rise * sF(), 4)} ${sU()}` : '–']]);
  }
  const gt = gradTimes(S.seq, g); let area = 0;
  for (let i = 1; i < gt.t.length; i++) area += 0.5 * (gt.v[i] + gt.v[i - 1]) * (gt.t[i] - gt.t[i - 1]);
  const sh = S.seq.shapes.get(g.shapeId);
  return kv([['Amplitude', `${fmt(g.amp * f, 4)} ${gU()}`], ['Shape', `#${g.shapeId}, ${sh ? sh.length : '?'} samples`],
    ['Timing', g.timeId > 0 ? `time shape #${g.timeId}` : g.timeId === -1 ? 'oversampled (½ raster)' : 'regular raster'],
    ['Delay', us(g.delay)], ['Duration', us(gt.t[gt.t.length - 1] - g.delay)], ['Area', `${fmt(area, 5)} m⁻¹`],
    g.first !== undefined ? ['First / last', `${fmt(g.first * f, 4)} / ${fmt(g.last * f, 4)} ${gU()}`] : null]);
}
/* rotation extension, as text: angle about an axis, plus the quaternion */
function rotText(q) {
  const n = Math.hypot(...q) || 1, w = q[0] / n, ang = 2 * Math.acos(Math.min(1, Math.abs(w))) * 180 / Math.PI;
  if (ang < 1e-6) return 'none (identity)';
  const s = Math.sqrt(Math.max(1e-30, 1 - w * w)), ax = [q[1], q[2], q[3]].map(v => (w < 0 ? -1 : 1) * v / n / s);
  return `${fmt(ang, 4)}° about (${ax.map(v => fmt(v, 3)).join(', ')}) · quaternion ${q.map(v => fmt(v, 4)).join(' ')} · gradients shown rotated (physical)`;
}
/* ---------- short description of a block (rule-based) ---------- */
const USE_WORD = { e: 'excitation', r: 'refocusing', i: 'inversion', s: 'saturation', p: 'preparation' };
let gMaxAll = 0;
function describeBlock(i) {
  const s = S.seq, B = s.B, G = ['gx', 'gy', 'gz'].filter(k => B['p' + k][i]); // physical axes (after any rotation)
  const dur = s.blockStart[i + 1] - s.blockStart[i];
  const j = lb(s.adcBlocks, i), hasAdc = B.adc[i] && j < s.adcBlocks.length && s.adcBlocks[j] === i;
  const adcWord = () => ['Readout', 'Reference readout', 'Reference + imaging readout', 'Noise scan', 'Navigator'][s.adcType[j]];
  if (B.rf[i]) {
    const st = rfSt(s, B.rf[i]), r = s.rf.get(B.rf[i]), flip = Math.round(st.flip * 180 / Math.PI);
    let d = `RF${flip} ${USE_WORD[st.use] || 'pulse'}`;
    if (st.use === 's' && r && (Math.abs(r.freq) > 50 || Math.abs(r.freqPPM || 0) > 0.5)) d += ' (off-resonance)';
    else if (G.length) d += ', slice-selective';
    if (hasAdc) d += ' + ' + adcWord().toLowerCase();
    return d;
  }
  if (hasAdc) return G.length || s.adcType[j] === 3 ? adcWord() : adcWord() + ' (no gradient)';
  if (!G.length) {
    if (B.ext[i]) { const ex = extChain(s, B.ext[i]); return ex.some(x => /TRIGGER/i.test(x.name)) ? 'Trigger' : dur > 1e-9 ? 'Pause (labels)' : 'Labels'; }
    return 'Pause';
  }
  // gradients only: name them from where they sit in the shot
  if (!gMaxAll) gMaxAll = Math.max(...s.stats.maxG) || 1;
  const geos = G.map(k => geoG(s, B['p' + k][i])), arb = ['gx', 'gy', 'gz'].some(k => B[k][i] && (s.grad.get(B[k][i]) || {}).type === 'arb');
  const gmax = Math.max(...geos.map(g => Math.max(Math.abs(g.min), Math.abs(g.max))));
  const glen = Math.max(...geos.map(g => g.t[g.n - 1] - g.t[0]));
  const axes = G.map(k => k[1]).join('');
  const useOf = b => b >= 0 && b < s.nb && B.rf[b] ? rfSt(s, B.rf[b]).use : null;
  const hasEv = b => B.rf[b] || B.gx[b] || B.gy[b] || B.gz[b] || B.adc[b];
  const nextEv = (b, d) => { for (let q = b + d, n = 0; q >= 0 && q < s.nb && n < 8; q += d, n++) if (hasEv(q)) return q; return -1; };
  const pv = nextEv(i, -1), nx = nextEv(i, 1);
  const k = s.shots.length ? shotOfBlock(i) : -1, sh = k >= 0 ? s.shots[k] : null;
  let excB = -1; if (sh) for (let q = Math.min(sh.b1, i); q >= sh.b0; q--) if (useOf(q) === 'e') { excB = q; break; }
  // first main readout (imaging or reference, not noise or navigator) after the excitation, and the last one in the shot
  let firstImg = -1, lastImg = -1;
  if (sh) for (let q = sh.j0; q < sh.j1; q++) { const bb = s.adcBlocks[q], t = s.adcType[q]; if (t > 2) continue; if (firstImg < 0 && bb > excB) firstImg = bb; lastImg = bb; }
  let ctx;
  if (pv >= 0 && nx >= 0 && B.adc[pv] && B.adc[nx] && dur < 1e-3) ctx = 'Phase blip';
  else if (excB >= 0 && (firstImg < 0 || i < firstImg) && glen >= 3e-3 && gmax >= 0.3 * gMaxAll) ctx = arb ? 'Diffusion encoding, arbitrary waveform' : 'Diffusion encoding';
  else if (useOf(pv) === 'r' || useOf(nx) === 'r') ctx = 'Crusher';
  else if (['s', 'i', 'p'].includes(useOf(pv))) ctx = 'Spoiler';
  else if (excB >= 0 && firstImg > i) ctx = 'Prephaser';
  else if (lastImg >= 0 && i > lastImg) ctx = 'Spoiler';
  else ctx = arb ? 'Arbitrary gradient waveform' : 'Gradients';
  return `${ctx} (${axes})`;
}
/* slice selected by the RF pulse of block i (rows for the RF card) */
const mmS = v => { const x = v * 1e3; return Math.abs(x) < 0.005 ? '0.00' : (x > 0 ? '+' : '−') + Math.abs(x).toFixed(2); }; // m → signed mm
function simB0(s) { const d = s.defs.B0; return typeof d === 'number' && d > 0 ? { B0: d, src: 'from the file' } : { B0: S.sim.B0, src: 'Image tab setting' }; }
function sliceRows(i) {
  const s = S.seq, { B0, src } = simB0(s), q = rfSlice(s, i, B0); if (!q) return '';
  const r = s.rf.get(s.B.rf[i]), rows = [], tip = (v, t) => `<span title="${esc(t)}">${v}</span>`, pct = x => `${(100 * x).toFixed(x < 0.1 ? 1 : 0)} %`;
  const neg = x => String(x).replace('-', '−');
  if (r.freqPPM) rows.push(['Total frequency', tip(`${neg(fmt(q.f, 5))} Hz`, `${fmt(r.freq, 5)} Hz ${r.freqPPM < 0 ? '−' : '+'} ${fmt(Math.abs(r.freqPPM), 4)} ppm at ${B0} T (${src}). The ppm part needs a field strength, which the file does not store.`)]);
  const varies = q.gDev > 0.01 * Math.max(q.Gm, 1e3);
  if (!q.selective) {
    rows.push(['Slice selection', 'none (non-selective)']);
    if (varies) rows.push(['Gradient during pulse', tip(`up to ${fmt(q.gDev / GAMMA * 1e3, 3)} mT/m`, 'There is no gradient at the pulse centre, but a gradient is on during part of the pulse.')]);
    return '<h5 class="subh">Slice</h5>' + kv(rows);
  }
  const pn = planeName(q.n), qr = rotationOfBlock(s, i);
  const rotd = qr && 2 * Math.acos(Math.min(1, Math.abs(qr[0]) / (Math.hypot(...qr) || 1))) > 1e-9;
  rows.push(['Slice gradient', tip(`${fmt(q.Gm / GAMMA * 1e3, 4)} mT/m`, 'Gradient amplitude at the pulse centre' + (rotd ? ', after the block\'s rotation (physical axes)' : ''))]);
  if (varies) rows.push(['Gradient during pulse', tip(`varies ${pct(q.gDev / q.Gm)}`, 'Largest deviation of the gradient vector from its value at the pulse centre while |B1| > 1 % of peak (ramp sampling or VERSE). The slice values below use the centre value and are approximate.')]);
  rows.push(['Normal', tip(`(${q.n.map(v => neg(fmt(v, 3))).join(', ')})`, 'Direction of the slice gradient (x, y, z) in the sequence\'s physical axes' + (rotd ? ', after rotation' : ''))]);
  rows.push(['Orientation', tip(pn.tilt > 0.05 ? `${pn.name}, ${fmt(pn.tilt, 3)}° tilt` : pn.name, 'Assumes the scanner axes of a head-first supine patient (x left–right, y anterior–posterior, z head–foot).')]);
  rows.push(['Position', tip(`${mmS(q.s0)} mm`, 'Distance of the slice centre from the isocentre along the normal: frequency offset / gradient (Pulseq convention). The scanner may add its own offset and rotation from the protocol.')]);
  rows.push(['Centre (x, y, z)', `(${q.pos.map(mmS).join(', ')}) mm`]);
  rows.push(['Thickness', tip(`${fmt(q.thick * 1e3, 4)} mm`, `FWHM bandwidth / gradient, from the pulse's small-tip frequency response` + (q.flip > 100 * Math.PI / 180 ? '. A large-angle pulse (refocusing, inversion) has a somewhat different profile.' : '.'))]);
  rows.push(['Bandwidth', tip(`${fmt(q.bw / 1e3, 4)} kHz · TBW ${fmt(q.bw * q.dur, 3)}`, 'FWHM of the small-tip frequency response, and its product with the pulse duration (time–bandwidth product)')]);
  if (q.s0Species !== undefined) rows.push([`Position at ${neg(fmt(r.freqPPM, 4))} ppm`, tip(`${mmS(q.s0Species)} mm`, 'Where spins at the pulse\'s own chemical-shift offset are selected, along the normal')]);
  rows.push(['Fat shift', tip(`${mmS(q.fatShift)} mm (${pct(Math.abs(q.fatShift) / q.thick)})`, `Displacement of the fat slice (main peak, ${neg(fmt(FAT_MAIN_PPM, 3))} ppm) along the normal at ${B0} T (${src}), and as a fraction of the thickness`)]);
  // a pulse after the excitation in the same shot: does it act on the excited slice?
  const k = s.shots.length ? shotOfBlock(i) : -1;
  if (k >= 0) {
    let e = -1; for (let b = s.shots[k].b0; b <= s.shots[k].b1; b++) if (s.B.rf[b] && rfSt(s, s.B.rf[b]).use === 'e') { e = b; break; }
    if (e >= 0 && e !== i) {
      const qe = rfSlice(s, e, B0);
      if (!qe || !qe.selective) rows.push(['vs excitation', 'excitation is non-selective']);
      else {
        const d = Math.hypot(q.pos[0] - qe.pos[0], q.pos[1] - qe.pos[1], q.pos[2] - qe.pos[2]);
        const ang = Math.acos(Math.min(1, Math.abs(q.n[0] * qe.n[0] + q.n[1] * qe.n[1] + q.n[2] * qe.n[2]))) * 180 / Math.PI;
        const same = d < 0.01 * Math.min(q.thick, qe.thick) && ang < 0.1, ratio = `${fmt(q.thick / qe.thick, 3)}× thickness`;
        rows.push(['vs excitation', tip(same ? `same slice, ${ratio}` : `${(d * 1e3).toFixed(2)} mm apart${ang >= 0.1 ? `, ${fmt(ang, 3)}°` : ''}, ${ratio}`,
          'Compared with the excitation of this shot: distance between the slice centres, angle between the planes, and thickness relative to the excitation')]);
        // fat is displaced along each pulse's own gradient: opposite gradients separate the fat slices (gradient reversal)
        if (ang < 0.1) {
          const fp = q.pos.map((v, a) => v + q.n[a] * q.fatShift), fe = qe.pos.map((v, a) => v + qe.n[a] * qe.fatShift);
          const dF = Math.hypot(fp[0] - fe[0], fp[1] - fe[1], fp[2] - fe[2]), opp = q.n[0] * qe.n[0] + q.n[1] * qe.n[1] + q.n[2] * qe.n[2] < 0;
          rows.push(['Fat vs excitation', tip(`${(dF * 1e3).toFixed(2)} mm apart (${pct(dF / Math.min(q.thick, qe.thick))})`,
            'Distance between the fat slices of this pulse and of the excitation, and as a fraction of the thinner slice' + (opp ? '. The slice gradients have opposite signs, so the fat slices move apart (slice-select gradient reversal).' : '.'))]);
        }
      }
    }
  }
  return '<h5 class="subh">Slice</h5>' + kv(rows);
}
function renderBlock() {
  const s = S.seq, el = $('#p-blk');
  if (!s) { el.innerHTML = '<p class="note">No sequence loaded.</p>'; return; }
  if (S.sel < 0) { el.innerHTML = '<p class="note">Click a block in the diagram to inspect it, or click a shot or volume in the strips above the diagram. Step through them with the Block, Shot and Volume controls above the diagram or with <kbd>←</kbd> <kbd>→</kbd>.</p>'; return; }
  const b = blockObj(s, S.sel), t0 = s.blockStart[S.sel];
  const skH = s.shots.length && shotsOn() ? shotOfBlock(S.sel) : -1, vkH = volsOn() ? volOfBlock(S.sel) : -1;
  const where = [skH >= 0 ? `shot ${skH + 1} of ${s.shots.length.toLocaleString()}` : '', vkH >= 0 ? `volume ${vkH + 1} of ${S.vols.length.toLocaleString()}` : ''].filter(Boolean);
  let head;
  if (S.selKind === 'vol' && vkH >= 0) head = `<div class="selmain"><b>Volume ${vkH + 1}</b> <span class="muted">of ${S.vols.length.toLocaleString()}</span></div><div class="selsub">${S.vols[vkH].nShots} shots · starts with block ${b.id}: ${esc(describeBlock(S.sel))}</div>`;
  else if (S.selKind === 'shot' && skH >= 0) head = `<div class="selmain"><b>Shot ${skH + 1}</b> <span class="muted">of ${s.shots.length.toLocaleString()}</span></div><div class="selsub">${vkH >= 0 ? `volume ${vkH + 1} · ` : ''}starts with block ${b.id}: ${esc(describeBlock(S.sel))}</div>`;
  else head = `<div class="selmain"><b>Block ${b.id}</b> <span class="desc">${esc(describeBlock(S.sel))}</span></div><div class="selsub">${where.length ? 'in ' + where.join(' · ') : `of ${s.nb.toLocaleString()} blocks`}</div>`;
  let h = '';
  h += `<h3>Block ${b.id} <span class="tag">${esc(describeBlock(S.sel))}</span></h3>` + kv([['Start', fmtT(t0)], ['Duration', fmtT(b.dur)], ['k at the end', `${[0, 1, 2].map(a => fmt(s.kStart[a][S.sel + 1] * mF(), 4)).join(', ')} <span class="muted">${mU()}</span>`], ...stimRows(t0, t0 + b.dur)]) +
    `<div class="blknav" style="margin-top:8px"><button class="btn" id="bZoom">Zoom to block</button></div>`;
  let shotCard = '', volCard = '';
  const vk = volsOn() ? volOfBlock(S.sel) : -1;
  if (vk >= 0) {
    const v = S.vols[vk];
    volCard = `<div class="evt" style="--c:var(--ink)"><h4>Volume ${vk + 1} <span>of ${S.vols.length.toLocaleString()}</span></h4>` + kv([
      ['Blocks', `${s.B.id[v.b0]} – ${s.B.id[v.b1]}`], ['Starts at', fmtT(v.t0)], ['Duration', fmtT(v.t1 - v.t0)],
      ['Shots', `${v.nShots.toLocaleString()}${v.nAcqShots !== v.nShots ? ` (${v.nAcqShots} with ADC)` : ''}`], ['ADC samples', v.nSamples.toLocaleString()], ...stimRows(v.t0, v.t1)]) +
      `<div class="blknav" style="margin-top:8px"><button class="btn" id="vZoom">Zoom to volume</button></div></div>`;
  }
  const sk = shotsOn() ? shotOfBlock(S.sel) : -1;
  if (sk >= 0) {
    const sh = s.shots[sk];
    shotCard = `<div class="evt" style="--c:var(--sel)"><h4>Shot ${sk + 1} <span>of ${s.shots.length.toLocaleString()}</span></h4>` + kv([
      ['Blocks', `${s.B.id[sh.b0]} – ${s.B.id[sh.b1]}`], ['Starts at', fmtT(sh.t0)], ['Duration', fmtT(sh.t1 - sh.t0)],
      ['ADC', sh.nADC ? `${sh.nADC} events, ${sh.nSamples.toLocaleString()} samples` : 'none (dummy or preparation)'], ...stimRows(sh.t0, sh.t1)]) +
      `<div class="blknav" style="margin-top:8px"><button class="btn" id="sZoom">Zoom to shot</button></div></div>`;
  }
  if (S.selKind === 'vol') h = volCard + shotCard + h; else if (S.selKind === 'shot') h = shotCard + volCard + h; else h += shotCard + volCard;
  h = `<div class="selhead">${head}</div>` + h;
  let any = false;
  if (b.rf) {
    const r = s.rf.get(b.rf); any = true;
    if (r) {
      const st = rfStats(s, r);
      h += `<div class="evt" style="--c:var(--c-rf)"><h4>RF <span>#${b.rf}</span></h4>` + kv([
        ['Purpose', (USE[st.use] || st.use) + (st.useGuessed ? ' <span class="muted">(inferred)</span>' : '')],
        ['Flip angle', `${fmt(st.flip * 180 / Math.PI, 4)}°`], ['Peak B1', `${fmt(r.amp * rF(), 4)} ${rU()}`],
        ['Duration', us(st.dur)], ['Delay', us(r.delay)], ['Centre', us(st.center - r.delay) + ' after start'],
        ['Frequency offset', `${fmt(r.freq, 5)} Hz`], ['Phase offset', `${fmt(r.phase, 4)} rad (${fmt(r.phase * 180 / Math.PI, 4)}°)`],
        r.freqPPM || r.phasePPM ? ['PPM offsets', `${fmt(r.freqPPM, 4)} ppm, ${fmt(r.phasePPM, 4)} rad/MHz`] : null,
        ['Shapes (mag/phase/time)', `#${r.magId} / #${r.phaseId} / ${r.timeId > 0 ? '#' + r.timeId : 'raster'}`], ['Samples', st.n]]) +
        sliceRows(S.sel) + '</div>';
    }
  }
  for (const a of ['x', 'y', 'z']) {
    const id = b['g' + a]; if (!id) continue; any = true;
    const g = s.grad.get(id);
    h += `<div class="evt" style="--c:var(--c-g${a})"><h4>G${a} <span>#${id} · ${g ? (g.type === 'trap' ? 'trapezoid' : 'arbitrary') : 'missing'}</span></h4>${g ? gradRows(g) : ''}</div>`;
  }
  if (b.adc) {
    const a = s.adc.get(b.adc); any = true;
    if (a) h += `<div class="evt" style="--c:var(--c-adc)"><h4>ADC <span>#${b.adc}</span></h4>` + kv([
      ['Type', (() => { const j = lb(s.adcBlocks, S.sel); const tp = j < s.adcBlocks.length && s.adcBlocks[j] === S.sel ? s.adcType[j] : 0; return `<span style="color:var(--c-${TYPE_COL[tp]});font-weight:600">${TYPE_NAME[tp]}</span>`; })()],
      ['Samples', a.num], ['Dwell', fmt(a.dwell * 1e6, 5) + ' µs'], ['Duration', us(a.num * a.dwell)], ['Delay', us(a.delay)],
      ['Bandwidth / pixel', `${fmt(1 / (a.num * a.dwell), 5)} Hz`], ['Frequency offset', `${fmt(a.freq, 5)} Hz`], ['Phase offset', `${fmt(a.phase, 4)} rad`],
      a.phaseId ? ['Phase shape', '#' + a.phaseId] : null]) + '</div>';
  }
  if (b.ext) {
    const ex = extChain(s, b.ext); any = true;
    h += `<div class="evt" style="--c:var(--ink)"><h4>Extensions <span>list #${b.ext}</span></h4>` + kv(ex.map(x => {
      const d = x.data || [];
      if (/LABELSET/i.test(x.name)) return ['Set label', `${esc(d[1])} = ${esc(d[0])}`];
      if (/LABELINC/i.test(x.name)) return ['Increment label', `${esc(d[1])} += ${esc(d[0])}`];
      if (/TRIGGER/i.test(x.name)) return ['Trigger', `type ${esc(d[0])}, channel ${esc(d[1])}, delay ${esc(d[2])} µs, ${esc(d[3])} µs long`];
      if (/^ROTATIONS?$/i.test(x.name)) return ['Rotation', rotText(d.slice(0, 4).map(Number))];
      return [esc(x.name), esc(d.join(' '))];
    })) + '</div>';
  }
  if (!any) h += '<p class="note">Pure delay block, no events.</p>';
  if ([...s.extTypes.values()].some(n => /LABEL/i.test(n))) {
    const st = labelState(S.sel), keys = Object.keys(st).sort();
    if (keys.length) h += `<h3>Label counters after this block</h3>` + kv(keys.map(k => [esc(k), st[k]]));
  }
  el.innerHTML = h;
  if ($('#vZoom')) { $('#vZoom').onclick = () => { selectBlock(S.vols[volOfBlock(S.sel)].b0, { kind: 'vol' }); zoomToVol(volOfBlock(S.sel)); }; }
  $('#bZoom').onclick = () => { pushHist(); zoomToBlock(S.sel); };
  if ($('#sZoom')) { $('#sZoom').onclick = () => { selectBlock(s.shots[shotOfBlock(S.sel)].b0, { kind: 'shot' }); zoomToShot(shotOfBlock(S.sel)); }; }
}

/* ---------- k-space ---------- */
const PROJ = { xy: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], xz: [[1, 0, 0], [0, 0, 1], [0, -1, 0]], yz: [[0, 1, 0], [0, 0, 1], [1, 0, 0]] };
function rot3d() { const a = -0.55, b = -1.05; const R = [[Math.cos(a), -Math.sin(a), 0], [Math.sin(a), Math.cos(a), 0], [0, 0, 1]]; return mul(rx(b), R); }
function rx(a) { return [[1, 0, 0], [0, Math.cos(a), -Math.sin(a)], [0, Math.sin(a), Math.cos(a)]]; }
function ry(a) { return [[Math.cos(a), 0, Math.sin(a)], [0, 1, 0], [-Math.sin(a), 0, Math.cos(a)]]; }
function mul(A, B) { return A.map(r => [0, 1, 2].map(j => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j])); }
S.kR = PROJ.xy;
function segSet(id, key, cb) {
  const el = $(id); el.querySelectorAll('button').forEach(b => b.onclick = () => { el.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', x === b)); cb(b.dataset.v); });
}
segSet('#kRange', 'kRange', v => { S.kRange = v; requestK(); });
segSet('#kProj', 'kProj', v => { S.kProj = v; S.kR = v === '3d' ? rot3d() : PROJ[v]; S.kZoom = 1; S.kPan = [0, 0]; requestK(); });
segSet('#kColor', 'kColor', v => { S.kColor = v; requestK(); });
$('#kTraj').onchange = e => { S.kTraj = e.target.checked; requestK(); };
let kPending = false;
function requestK() { if (!kPending) { kPending = true; requestAnimationFrame(() => { kPending = false; benchT(drawK); }); } }
const VIR = [[68, 1, 84], [59, 82, 139], [33, 145, 140], [94, 201, 98], [253, 231, 37]];
/* k-space drawing: skipped when nothing changed; ADC points written straight into a pixel
   buffer; the path is simplified in screen space; view-driven redraws are throttled. */
let kFast = false, kFastTimer = null, kKey = null, kOff = null, kImg = null, kLut = null, kLast = 0, kTimer = null;
let kData = null, kData_busy = false, kHit = null, kTip = null, kRing = null, kHoverI = -1; // kHit: drawn samples, for hovering
const K_MAX_PTS = 5e5, K_MAX_PATH = 2e5; // display caps for large ranges (more is not visible at this plot size)
function kInvalidate() { kKey = null; kData = null; kHit = null; kHoverHide(); }
function requestKLazy() {
  if (S.tab !== 'k') return;
  const wait = 120 - (performance.now() - kLast);
  if (wait <= 0) requestK();
  else if (!kTimer) kTimer = setTimeout(() => { kTimer = null; requestK(); }, wait);
}
function hexU32(h) {
  h = (h || '#888').trim(); if (h[0] === '#' && h.length === 4) h = '#' + h[1] + h[1] + h[2] + h[2] + h[3] + h[3];
  const r = parseInt(h.slice(1, 3), 16) || 0, g = parseInt(h.slice(3, 5), 16) || 0, b = parseInt(h.slice(5, 7), 16) || 0;
  return (255 << 24 | b << 16 | g << 8 | r) >>> 0;
}
function buildLut() {
  kLut = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    const x = i / 255 * 4, j = Math.min(3, Math.floor(x)), f = x - j, a = VIR[j], b = VIR[j + 1];
    const r = a[0] + (b[0] - a[0]) * f | 0, g = a[1] + (b[1] - a[1]) * f | 0, bl = a[2] + (b[2] - a[2]) * f | 0;
    kLut[i] = (255 << 24 | bl << 16 | g << 8 | r) >>> 0;
  }
}
function drawK() {
  if (S.tab !== 'k' || KW <= 0 || !S.seq) return;
  const s = S.seq, R = S.kR;
  let j0 = 0, j1 = s.adcBlocks.length, pb0 = 0, pb1 = s.nb - 1, what = '';
  if (S.kRange !== 'view' && S.kRange !== 'vol') S.kRange = 'shot';
  if (S.kRange === 'view') { j0 = lb(s.adcT1, S.t0); j1 = ub(s.adcT0, S.t1); pb0 = blockAt(S.t0); pb1 = blockAt(S.t1); what = ' in the visible window'; }
  else if (S.kRange === 'vol' || S.kRange === 'shot') {
    const isV = S.kRange === 'vol', list = isV ? S.vols : s.shots;
    if (!list.length) { kctx.clearRect(0, 0, KW, KW); kKey = null; $('#kInfo').textContent = isV ? 'No volumes are marked. Choose a volume rule under Display, above the diagram.' : 'No shots: the sequence has no excitation pulses, or shot marking is off.'; return; }
    const k = S.sel >= 0 ? (isV ? volOfBlock(S.sel) : shotOfBlock(S.sel)) : (isV ? volAt : shotAt)((S.t0 + S.t1) / 2), it = list[k];
    pb0 = it.b0; pb1 = it.b1; j0 = lb(s.adcBlocks, pb0); j1 = lb(s.adcBlocks, pb1 + 1);
    what = ` in ${isV ? 'volume' : 'shot'} ${k + 1} of ${list.length}`;
  }
  if (j1 < j0) j1 = j0;
  const dk = j0 + ',' + j1 + ',' + pb0 + ',' + pb1;
  if (!kData || kData.key !== dk) {
    const total = s.adcOff[j1] - s.adcOff[j0];
    if (total > 2e5 && !kData_busy) { // let the page paint a message before a large computation
      kData_busy = true; $('#kInfo').textContent = `Computing k-space for ${total.toLocaleString()} ADC samples…`;
      setTimeout(() => { kKey = null; drawK(); kData_busy = false; }, 30); return;
    }
    const smp = kSamples(s, j0, j1, K_MAX_PTS), path = kPath(s, pb0, pb1, K_MAX_PATH);
    let mm = 0; const arr = smp.n ? smp.k : path.k, nn = smp.n || path.n;
    for (let a = 0; a < 3; a++) { const c = arr[a]; for (let i = 0; i < nn; i++) { const v = c[i] < 0 ? -c[i] : c[i]; if (v > mm) mm = v; } }
    kData = { key: dk, smp, path, m: mm > 0 ? mm : 1, total: s.adcOff[j1] - s.adcOff[j0] };
  }
  const K = { kA: kData.smp.k, kT: kData.path.k, type: kData.smp.type }, a0 = 0, a1 = kData.smp.n, p0 = 0, p1 = kData.path.n;
  const key = [S.kColor, kFast, dk, R.map(r => r.join(',')).join(';'), S.kZoom, S.kPan.join(','), S.kTraj, KW, dpr, C.plot, C.muted].join('|');
  if (key === kKey) return;
  kKey = key; kHoverHide(); // the samples move: the hovered one is found again at the next pointer move
  const ctx = kctx; ctx.clearRect(0, 0, KW, KW);
  const n = a1 - a0, m = kData.m;
  const cx = KW / 2 + S.kPan[0], cy = KW / 2 + S.kPan[1], sc = (KW / 2 - 26) / m * S.kZoom; // k = 0 at (cx, cy): moved by panning
  const r00 = R[0][0] * sc, r01 = R[0][1] * sc, r02 = R[0][2] * sc, r10 = R[1][0] * sc, r11 = R[1][1] * sc, r12 = R[1][2] * sc;
  const P = (x, y, z) => [cx + r00 * x + r01 * y + r02 * z, cy - (r10 * x + r11 * y + r12 * z)];
  // axes
  ctx.strokeStyle = C.line; ctx.lineWidth = 1;
  const axes = [['kx', 'gx', [1, 0, 0]], ['ky', 'gy', [0, 1, 0]], ['kz', 'gz', [0, 0, 1]]];
  ctx.setLineDash([3, 4]);
  for (const [, , d] of axes) { const [xa, ya] = P(-d[0] * m, -d[1] * m, -d[2] * m), [xb, yb] = P(d[0] * m, d[1] * m, d[2] * m); if (Math.hypot(xb - xa, yb - ya) < 4) continue; ctx.beginPath(); ctx.moveTo(xa, ya); ctx.lineTo(xb, yb); ctx.stroke(); }
  ctx.setLineDash([]);
  // path, simplified in screen space (points closer than ~0.6 px to the last drawn one are skipped)
  if (S.kTraj && p1 > p0) {
    const X = K.kT[0], Y = K.kT[1], Z = K.kT[2], tol = kFast ? 2 : 0.6;
    ctx.beginPath();
    let lx = cx + r00 * X[p0] + r01 * Y[p0] + r02 * Z[p0], ly = cy - (r10 * X[p0] + r11 * Y[p0] + r12 * Z[p0]);
    ctx.moveTo(lx, ly);
    const ps = kFast ? Math.max(1, Math.ceil((p1 - p0) / 2e5)) : 1;
    for (let i = p0 + 1; i < p1; i += ps) {
      const x = cx + r00 * X[i] + r01 * Y[i] + r02 * Z[i], y = cy - (r10 * X[i] + r11 * Y[i] + r12 * Z[i]);
      if ((x > lx ? x - lx : lx - x) + (y > ly ? y - ly : ly - y) > tol || i === p1 - 1) { ctx.lineTo(x, y); lx = x; ly = y; }
    }
    ctx.strokeStyle = C.muted; ctx.globalAlpha = 0.45; ctx.lineWidth = 0.8; ctx.stroke(); ctx.globalAlpha = 1;
  }
  // ADC points into a device-pixel buffer
  let thinned = kData.smp.thinned;
  if (kHit) kHit.n = 0;
  if (n > 0) {
    const Wd = kc.width, Hd = kc.height;
    if (!kOff || kOff.width !== Wd || kOff.height !== Hd) { kOff = document.createElement('canvas'); kOff.width = Wd; kOff.height = Hd; kImg = kOff.getContext('2d').createImageData(Wd, Hd); }
    if (!kLut) buildLut();
    const buf = new Uint32Array(kImg.data.buffer); buf.fill(0);
    const step = Math.max(1, Math.ceil(n / (kFast ? 2e5 : K_MAX_PTS))); if (step > 1 && !kFast) thinned = true;
    const cnt = n / step, d = dpr, X = K.kA[0], Y = K.kA[1], Z = K.kA[2], inv = 255 / Math.max(1, n - 1);
    // project once: device coordinates of the samples inside the canvas (kept for finding the hovered sample)
    if (!kHit || kHit.x.length < cnt + 1) kHit = { x: new Float32Array(cnt + 1), y: new Float32Array(cnt + 1), i: new Int32Array(cnt + 1), n: 0, r: 1 };
    const HX = kHit.x, HY = kHit.y, HI = kHit.i; let nv = 0;
    for (let i = a0; i < a1; i += step) {
      const fx = (cx + r00 * X[i] + r01 * Y[i] + r02 * Z[i]) * d, fy = (cy - (r10 * X[i] + r11 * Y[i] + r12 * Z[i])) * d;
      if (fx < 0 || fy < 0 || fx >= Wd || fy >= Hd) continue;
      HX[nv] = fx; HY[nv] = fy; HI[nv] = i; nv++;
    }
    kHit.n = nv;
    // dot size: at least as before (from the number of samples), and larger when few samples are in view (zoomed in):
    // 0.3 × the side of the canvas area per visible sample, at most 6 px. Large dots are round.
    const base = Math.max(1, Math.round((cnt > 40000 ? 1 : cnt > 4000 ? 1.6 : 2.4) * d));
    const rs = Math.max(base, Math.min(Math.round(6 * d), Math.round(0.3 * Math.sqrt(Wd * Hd / Math.max(1, nv)))));
    kHit.r = rs / d;
    const stamp = r2 => { const o = []; const c = (r2 - 1) / 2, rr = r2 * r2 / 4 + 0.25; for (let yy = 0; yy < r2; yy++) for (let xx = 0; xx < r2; xx++) if (r2 < 4 || (xx - c) ** 2 + (yy - c) ** 2 <= rr) o.push(yy * Wd + xx); return Int32Array.from(o); };
    const byType = S.kColor === 'type', ST = byType ? K.type : null, TL = byType ? TYPE_COL.map(c => hexU32(C[c])) : null;
    // by type: imaging first, then the other types on top so they stay visible
    for (let pass = 0; pass < (byType ? 2 : 1); pass++) {
      const r2 = pass ? rs + Math.ceil(d) : rs, hh = r2 >> 1, st = stamp(r2), ns = st.length; // non-imaging samples drawn a bit larger
      for (let v = 0; v < nv; v++) {
        const i = HI[v]; if (byType && ((ST[i] === 0) !== (pass === 0))) continue;
        const px = (HX[v] | 0) - hh, py = (HY[v] | 0) - hh;
        if (px < 0 || py < 0 || px + r2 > Wd || py + r2 > Hd) continue;
        const col = byType ? TL[ST[i]] : kLut[(i - a0) * inv | 0], o = py * Wd + px;
        for (let q = 0; q < ns; q++) buf[o + st[q]] = col;
      }
    }
    kOff.getContext('2d').putImageData(kImg, 0, 0);
    ctx.drawImage(kOff, 0, 0, KW, KW);
  }
  // gizmo
  const gx0 = 34, gy0 = KW - 34; ctx.font = `600 11px ${C.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (const [lab, col, d] of axes) {
    const vx = R[0][0] * d[0] + R[0][1] * d[1] + R[0][2] * d[2], vy = R[1][0] * d[0] + R[1][1] * d[1] + R[1][2] * d[2];
    if (Math.hypot(vx, vy) < 0.08) continue;
    ctx.strokeStyle = C[col]; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(gx0, gy0); ctx.lineTo(gx0 + vx * 20, gy0 - vy * 20); ctx.stroke();
    ctx.fillStyle = C[col]; ctx.fillText(lab, gx0 + vx * 29, gy0 - vy * 29);
  }
  ctx.fillStyle = C.muted; ctx.textAlign = 'right'; ctx.font = `400 11px ${C.font}`;
  ctx.fillText(`|k| ≤ ${fmt(m / S.kZoom, 4)} m⁻¹`, KW - 10, KW - 12);
  $('#kInfo').textContent = n ? `${kData.total.toLocaleString()} ADC samples${what}${thinned ? ` (${Math.min(n, kFast ? 2e5 : K_MAX_PTS).toLocaleString()} shown)` : ''}. Max |k| component ${fmt(m, 4)} m⁻¹ (≈ ${fmt(1e3 / (2 * m), 3)} mm resolution).` : 'No ADC samples in range.';
  kLast = performance.now();
}
/* hovered sample: the nearest drawn sample within 8 px (or the dot radius) of the pointer gets a ring and a short
   description; the diagram's cursor moves to its time */
kTip = document.createElement('div'); kRing = document.createElement('div');
kTip.className = 'ktip num'; kRing.className = 'kring'; kTip.hidden = kRing.hidden = true;
kc.parentElement.append(kRing, kTip);
function kHoverHide() { if (!kTip || (kHoverI < 0 && kTip.hidden)) return; kHoverI = -1; kTip.hidden = kRing.hidden = true; if (S.tab === 'k' && S.seq) { S.hoverT = null; requestOverlay(); } }
function kHover(ex, ey) {
  if (!kHit || !kHit.n || !kData || !S.seq) { kHoverHide(); return; }
  const d = dpr, x = ex * d, y = ey * d, R = Math.max(8, kHit.r / 2 + 3) * d; let best = -1, bd = R * R;
  for (let v = 0; v < kHit.n; v++) { const dx = kHit.x[v] - x, dy = kHit.y[v] - y, q = dx * dx + dy * dy; if (q < bd) { bd = q; best = v; } }
  if (best < 0) { kHoverHide(); return; }
  const i = kHit.i[best], smp = kData.smp, s = S.seq, B = s.B;
  let lo = 0, hi = smp.ej.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (smp.eo[m] <= i) lo = m; else hi = m - 1; }
  const j = smp.ej[lo], q = i - smp.eo[lo], b = s.adcBlocks[j], ad = s.adc.get(B.adc[b]), t = s.blockStart[b] + ad.delay + (q + 0.5) * ad.dwell;
  const k = shotOfBlock(b), sh = k >= 0 ? s.shots[k] : null;
  let tE = null; if (sh) for (let c = b; c >= sh.b0; c--) if (B.rf[c]) { const st = rfSt(s, B.rf[c]); if (st.use === 'e') { tE = s.blockStart[c] + st.center; break; } }
  const lab = labelState(b), labs = s.labels.filter(L => !L.flag || lab[L.name]).map(L => `${L.name} ${lab[L.name] ?? 0}`).join(' · ');
  kTip.innerHTML = `<b>Sample ${q + 1}</b> / ${ad.num} · ADC ${sh ? `${j - sh.j0 + 1} / ${sh.nADC} · shot ${k + 1}` : ''} · block ${B.id[b]}<br>` +
    `t ${fmt(t * 1e3, 6)} ms${tE !== null ? ` (${fmt((t - tE) * 1e3, 4)} ms after excitation)` : ''}<br>` +
    `k ${[0, 1, 2].map(a => fmt(smp.k[a][i], 4)).join(', ')} m⁻¹ · ${TYPE_NAME[s.adcType[j]]}` + (labs ? `<br>${esc(labs)}` : '');
  const px = kHit.x[best] / d, py = kHit.y[best] / d, rr = Math.max(5, kHit.r / 2 + 3);
  kRing.style.cssText = `left:${px - rr}px;top:${py - rr}px;width:${2 * rr}px;height:${2 * rr}px`;
  kTip.hidden = kRing.hidden = false;
  const tw = kTip.offsetWidth, th = kTip.offsetHeight; // beside the sample, flipped to stay inside the plot
  kTip.style.left = `${px + 12 + tw > KW ? Math.max(2, px - 12 - tw) : px + 12}px`; kTip.style.top = `${py + 12 + th > KW ? Math.max(2, py - 12 - th) : py + 12}px`;
  kHoverI = i; S.hoverT = t; requestOverlay();
}
let kDrag = null, kHoverPos = null;
kc.addEventListener('pointerdown', e => { kc.setPointerCapture(e.pointerId); kDrag = { x: e.offsetX, y: e.offsetY, pan: e.button === 2 }; kc.style.cursor = kDrag.pan ? 'move' : 'grabbing'; kHoverHide(); });
kc.addEventListener('contextmenu', e => e.preventDefault()); // right-drag pans
kc.addEventListener('pointerleave', () => { kHoverPos = null; if (!kDrag) kHoverHide(); });
kc.addEventListener('pointermove', e => {
  if (!kDrag) { // one search per frame (it runs over all drawn samples, up to K_MAX_PTS)
    if (e.pointerType !== 'mouse') return;
    const first = !kHoverPos; kHoverPos = [e.offsetX, e.offsetY];
    if (first) requestAnimationFrame(() => { const p = kHoverPos; kHoverPos = null; if (p && !kDrag) kHover(p[0], p[1]); });
    return;
  }
  const dx = e.offsetX - kDrag.x, dy = e.offsetY - kDrag.y; kDrag.x = e.offsetX; kDrag.y = e.offsetY;
  if (kDrag.pan) { kPanBy(dx, dy); kFast = true; requestK(); return; } // right-drag: move the view, keep the projection
  S.kR = mul(rx(dy * 0.01), mul(ry(dx * 0.01), S.kR)); kFast = true;
  if (S.kProj !== '3d') { S.kProj = '3d'; $('#kProj').querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', b.dataset.v === '3d')); }
  requestK();
});
/* pan (CSS px, offset of k = 0 from the canvas centre), kept within the data's extent on screen so it cannot be lost */
function kPanBy(dx, dy) { const L = Math.max(0, (KW / 2 - 26) * S.kZoom); S.kPan = [Math.max(-L, Math.min(L, S.kPan[0] + dx)), Math.max(-L, Math.min(L, S.kPan[1] + dy))]; }
function kSettle() { if (kFast) { kFast = false; requestK(); } }
const kUp = () => { kDrag = null; kc.style.cursor = ''; kSettle(); };
kc.addEventListener('pointerup', kUp); kc.addEventListener('pointercancel', kUp);
kc.addEventListener('wheel', e => { e.preventDefault(); kHoverHide(); const z0 = S.kZoom; S.kZoom = Math.min(50, Math.max(0.2, S.kZoom * Math.exp(-e.deltaY * 0.002)));
  S.kPan = [S.kPan[0] * S.kZoom / z0, S.kPan[1] * S.kZoom / z0]; kPanBy(0, 0); /* zoom about the canvas centre: the k there stays */ kFast = true; clearTimeout(kFastTimer); kFastTimer = setTimeout(kSettle, 160); requestK(); }, { passive: false });

/* ---------- simulated image ---------- */
let imgRes = null, imgKey = null, imgRun = 0, imgTimer = null, imgLoadId = 0;
/* recent images: stepping back to a volume or echo just seen is instant (up to 12 images, ~300 MB) */
const imgCache = new Map();
function resBytes(r) { let n = 0; const add = a => { if (a && a.byteLength) n += a.byteLength; }; if (r.img) { add(r.img.re); add(r.img.im); } if (r.kspace) { add(r.kspace.re); add(r.kspace.im); } add(r.mask); return n; }
function cachePut(key, r) {
  if (r.error) return; imgCache.set(key, r);
  let total = 0; for (const v of imgCache.values()) total += resBytes(v);
  while (imgCache.size > 12 || (total > 3e8 && imgCache.size > 1)) { const k = imgCache.keys().next().value; total -= resBytes(imgCache.get(k)); imgCache.delete(k); }
}
function imgReset() { imgRes = null; imgKey = null; imgRun++; imgLoadId++; imgCache.clear(); drawImg(); }
function syncSimControls() {
  const d = S.sim;
  segPress('#simPhantom', d.phantom); segPress('#simFill', d.fill ? 'fill' : 'zero'); segPress('#simCrop', d.crop === false ? 'all' : 'crop'); segPress('#imView', d.view);
  $('#simB0').value = String(d.B0); $('#simOrient').value = d.orient; $('#simEddy').value = d.eddy;
  for (const [id, k] of [['simT1', 't1'], ['simT2', 't2'], ['simFat', 'fatShift'], ['simDiff', 'diffusion'], ['simBubble', 'bubble'], ['simNoise', 'noise'], ['simSlicePos', 'slicePos'], ['sim3d', 'show3d']]) $('#' + id).checked = d[k];
  $('.v3wrap').style.display = d.show3d ? '' : 'none';
  imSummary();
}
/* one-line summary of the simulation options, shown while they are folded away */
function imSummary() {
  const d = S.sim, el = $('#imSum'); if (!el) return;
  const c = [d.t1 && 'T1', d.t2 && 'T2', d.fatShift && 'fat', d.diffusion && 'diffusion'].filter(Boolean);
  const a = [d.bubble && 'air bubble', d.noise && 'noise', d.eddy !== 'off' && `${d.eddy === 'poor' ? 'poor' : 'typical'} eddy currents`].filter(Boolean);
  el.textContent = [`${d.phantom === 'head' ? 'Head' : 'Abdomen'} at ${d.B0} T`, ({ ax: 'axial', cor: 'coronal', sag: 'sagittal' }[d.orient] || d.orient) + (d.slicePos ? '' : ' through the bubble'),
    c.length ? c.join(', ') : 'no contrast effects', ...(a.length ? [a.join(', ')] : []), d.fill ? 'ideal recon' : 'zero-filled recon', ...(d.crop === false ? ['oversampled FOV shown'] : [])].join('; ');
  el.hidden = !$('#imOpts').hidden;
}
syncSimControls();
segSet('#simPhantom', 'x', v => { S.sim.phantom = v; requestImg(true); });
segSet('#simFill', 'x', v => { S.sim.fill = v === 'fill'; requestImg(true); });
segSet('#simCrop', 'x', v => { S.sim.crop = v === 'crop'; drawImg(); drawSlice3D(); imSummary(); }); // display only: no new simulation
segSet('#imView', 'x', v => { S.sim.view = v; drawImg(); });
$('#simB0').onchange = e => { S.sim.B0 = +e.target.value; requestImg(true); };
$('#simOrient').onchange = e => { S.sim.orient = e.target.value; requestImg(true); };
$('#simEddy').onchange = e => { S.sim.eddy = e.target.value; requestImg(true); };
for (const [id, k] of [['simT1', 't1'], ['simT2', 't2'], ['simFat', 'fatShift'], ['simDiff', 'diffusion'], ['simBubble', 'bubble'], ['simNoise', 'noise'], ['simSlicePos', 'slicePos']])
  $('#' + id).onchange = e => { S.sim[k] = e.target.checked; requestImg(true); };
$('#sim3d').onchange = e => { S.sim.show3d = e.target.checked; $('.v3wrap').style.display = S.sim.show3d ? '' : 'none'; I3W = I3H = 0; resize(); if (S.sim.show3d) drawSlice3D(); };
const echoStep = d => { if (!imgRes || !imgRes.nEcho) return; const e = Math.max(0, Math.min(imgRes.nEcho - 1, (imgRes.echo || 0) + d)); if (e !== imgRes.echo) { S.sim.echo = e; requestImg(true); } };
$('#imEchoPrev').onclick = () => echoStep(-1); $('#imEchoNext').onclick = () => echoStep(1);
$('#imPng').onclick = () => { if (imgRes && !imgRes.error) savePNG(ic, `${S.name.replace(/\.seq$/i, '')}_image.png`); };
/* which image: the selected volume (or the one at the view centre), slice of the selected shot */
function imgTarget() {
  const s = S.seq; if (!s) return null;
  const shots = s.shots.length ? s.shots : (s.shotsExc || []); if (!shots.length) return null;
  const c = (S.t0 + S.t1) / 2, blk = S.sel >= 0 ? S.sel : blockAt(c);
  const shotIdx = b => { let lo = 0, hi = shots.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (shots[m].b0 <= b) lo = m; else hi = m - 1; } return lo; };
  let vol, vi = -1;
  if (S.vols.length) { vi = S.sel >= 0 ? volOfBlock(S.sel) : volAt(c); vol = S.vols[vi]; }
  else { const k = shotIdx(blk); vol = { s0: k, s1: k }; }
  let ref = shotIdx(blk);
  // a specific shot (selected, or at the view centre) without a readout, e.g. a dummy scan: nothing to reconstruct
  if (S.selKind !== 'vol' && ref >= vol.s0 && ref <= vol.s1 && !shots[ref].nADC) return { dummy: ref };
  if (ref < vol.s0 || ref > vol.s1 || !shots[ref].nADC) { ref = -1; for (let k = vol.s0; k <= vol.s1; k++) if (shots[k].nADC) { const sh = shots[k]; for (let j = sh.j0; j < sh.j1; j++) if (s.adcType[j] === 0 || s.adcType[j] === 2) { ref = k; break; } if (ref >= 0) break; } }
  if (ref < 0) for (let k = vol.s0; k <= vol.s1; k++) if (shots[k].nADC) { ref = k; break; }
  if (ref < 0) return { none: true };
  return { shots, vol, vi, ref };
}
function requestImg(now) {
  if (S.tab !== 'img' || !S.seq) return;
  clearTimeout(imgTimer); imgTimer = setTimeout(computeImg, now ? 0 : 200);
}
async function computeImg() {
  const T = imgTarget(); if (!T) return;
  if (T.none) { imgRes = { error: 'This volume has no readout (no ADC events): there is no data to reconstruct.' }; imgKey = null; drawImg(); return; }
  if (T.dummy !== undefined) { imgRes = { error: `Shot ${T.dummy + 1} has no readout (no ADC events), e.g. a dummy scan: there is no data to reconstruct. Select a shot with a readout, or the whole volume.` }; imgKey = null; drawImg(); return; }
  const opt = { ...S.sim, bubbleField: true, noise: S.sim.noise ? 1 : 0 }; delete opt.view; delete opt.show3d;
  const key = [imgLoadId, T.vol.s0, T.vol.s1, T.ref, JSON.stringify(opt)].join('|');
  if (key === imgKey) return;
  if (imgCache.has(key)) { const r = imgCache.get(key); imgCache.delete(key); imgCache.set(key, r); imgRun++; poolCancel(); imgRes = r; imgKey = key; $('#imBusy').classList.remove('on'); drawImg(); return; }
  if (!SIM_POOL && poolInit()) SIM_POOL = poolRun;
  if (!SIM_GPU && S.sim.gpu !== false && SIMGL.available()) SIM_GPU = SIMGL.run; // the graphics card, when there is a real one
  poolCancel();
  imgKey = key; const run = ++imgRun, start = performance.now(); let lastYield = start;
  $('#imBusy').classList.add('on'); $('#imBusyTxt').textContent = 'Simulating…';
  try {
    const res = await runSimulation(S.seq, T.shots, T.vol, T.ref, opt, async p => {
      if (run !== imgRun) throw new Error('cancelled');
      const now = performance.now();
      if (now - lastYield > 40) { $('#imBusyTxt').textContent = `Simulating… ${Math.round(p * 100)}%`; await new Promise(r => setTimeout(r, 0)); lastYield = performance.now(); if (run !== imgRun) throw new Error('cancelled'); }
    });
    if (run !== imgRun) return;
    res.target = T; imgRes = res; cachePut(key, res);
  } catch (e) {
    if (e.message === 'cancelled') return;
    console.error(e); imgRes = { error: 'Simulation failed: ' + e.message };
  } finally { if (run === imgRun) $('#imBusy').classList.remove('on'); }
  drawImg();
}
/* scout: the phantom in the plane spanned by the slice normal (horizontal) and the image's vertical axis,
   with the slice drawn as a band at its position and thickness */
const SCOUT_GRAY = { fat: 0.95, wm: 0.62, gm: 0.45, csf: 0.22, lesion: 0.8, blood: 0.7, muscle: 0.4, liver: 0.5, kidney: 0.58, fluid: 0.28, marrow: 0.75, air: 0 };
function drawScout(ctx, R, x, y, size) {
  const g = R.geom, N = 80, span = 240;
  if (!R.scout) {
    const P3 = build3D(R.phantomKey, R.bubbleOn), c = document.createElement('canvas'); c.width = c.height = N;
    const cc = c.getContext('2d'), id = cc.createImageData(N, N), off = dot3(g.o, g.e1);
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const a = (i + 0.5) / N * span - span / 2, b = span / 2 - (j + 0.5) / N * span;
      const p = [0, 1, 2].map(k => a * g.n[k] + b * g.e2[k] + off * g.e1[k]), t = tissueAt3(P3, p), v = t ? 255 * (SCOUT_GRAY[t] ?? 0.5) : 0, o = (j * N + i) * 4;
      id.data[o] = id.data[o + 1] = id.data[o + 2] = v; id.data[o + 3] = 255;
    }
    cc.putImageData(id, 0, 0); R.scout = c;
  }
  ctx.save();
  ctx.fillStyle = '#000'; ctx.fillRect(x - 1, y - 1, size + 2, size + 2);
  ctx.imageSmoothingEnabled = true; ctx.drawImage(R.scout, x, y, size, size);
  const mm = size / span, pos = dot3(g.o, g.n), bx = x + size / 2 + pos * mm, bw = Math.max(1.5, Math.min(g.thick, span) * mm);
  ctx.fillStyle = 'rgba(245,197,24,.45)'; ctx.fillRect(bx - bw / 2, y, bw, size);
  ctx.strokeStyle = 'rgba(245,197,24,.95)'; ctx.lineWidth = 1; ctx.strokeRect(bx - bw / 2, y + 0.5, bw, size - 1);
  ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.strokeRect(x - 0.5, y - 0.5, size + 1, size + 1);
  ctx.font = `600 10px ${C.font}`; ctx.fillStyle = 'rgba(255,214,120,.95)'; ctx.textBaseline = 'middle';
  ctx.textAlign = 'right'; ctx.fillText(dirLetter(g.n), x + size - 3, y + size / 2);
  ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText(dirLetter(g.e2), x + size / 2, y + 2);
  ctx.restore();
}
/* ---------- 3D view: translucent phantom and the slice plane ---------- */
const V3_COL = { fat: [240, 200, 90], wm: [225, 225, 225], gm: [160, 160, 170], csf: [90, 150, 255], lesion: [255, 90, 90], blood: [200, 40, 60], muscle: [190, 120, 100], liver: [170, 90, 70], kidney: [190, 110, 200], fluid: [90, 160, 255], marrow: [255, 170, 80] };
const V3_DEFAULT = { yaw: -0.65, pitch: 0.38, zoom: 1 };
let v3 = { ...V3_DEFAULT }, v3drag = null;
function inv3(A) {
  const [a, b, c] = A[0], [d, e, f] = A[1], [g, h, i] = A[2], D = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);
  return [[(e * i - f * h) / D, (c * h - b * i) / D, (b * f - c * e) / D], [(f * g - d * i) / D, (a * i - c * g) / D, (c * d - a * f) / D], [(d * h - e * g) / D, (b * g - a * h) / D, (a * e - b * d) / D]];
}
/* ---------- 3D view on the graphics card (WebGL2): the same ray casting as below, per fragment ---------- */
const GL3_MAXO = 20, GL3_MAXP = 48;
const GL3_FS = `#version 300 es
precision highp float; precision highp int;
#define MAXO ${GL3_MAXO}
#define MAXP ${GL3_MAXP}
#define MAXE ${2 * GL3_MAXO + GL3_MAXP}
uniform int uNO, uNP; uniform vec3 uC[MAXO]; uniform mat3 uQ[MAXO]; uniform float uSig[MAXO]; uniform vec3 uCol[MAXO]; uniform float uRim[MAXO];
uniform vec3 uPO[MAXP]; uniform int uPK[MAXP];
uniform vec3 uR, uU, uF, uN, uE1, uE2; uniform vec2 uRes; uniform float uPxmm, uFx, uFy, uEdge, uAxw;
out vec4 outColor;
void main() {
  float aa = (gl_FragCoord.x - uRes.x * 0.5) * uPxmm, bb = (gl_FragCoord.y - uRes.y * 0.5) * uPxmm;
  vec3 base = aa * uR + bb * uU;
  float zs[MAXE]; int kd[MAXE]; float eu[MAXE]; float ev[MAXE]; int ord[MAXE]; bool act[MAXO]; int ne = 0;
  for (int k = 0; k < MAXO; k++) { act[k] = false; if (k >= uNO) continue;
    vec3 w = base - uC[k], Qf = uQ[k] * uF; float A = dot(uF, Qf), B = dot(Qf, w), Cc = dot(w, uQ[k] * w) - 1.0, disc = B * B - A * Cc;
    if (disc <= 0.0) continue; float sq = sqrt(disc);
    zs[ne] = (-B + sq) / A; kd[ne] = 2 * k; ne++; zs[ne] = (-B - sq) / A; kd[ne] = 2 * k + 1; ne++; }
  float fn = dot(uF, uN);
  if (abs(fn) > 1e-6) for (int p = 0; p < MAXP; p++) { if (p >= uNP) break;
    float z = (dot(uPO[p], uN) - dot(base, uN)) / fn; vec3 pt = base + z * uF - uPO[p]; float u = dot(pt, uE1), v = dot(pt, uE2);
    if (abs(u) > uFx || abs(v) > uFy) continue; zs[ne] = z; kd[ne] = 1000 + p; eu[ne] = u; ev[ne] = v; ne++; }
  for (int e = 0; e < MAXE; e++) { if (e >= ne) break; int k = e; while (k > 0 && zs[ord[k - 1]] < zs[e]) { ord[k] = ord[k - 1]; k--; } ord[k] = e; }
  float T = 1.0, zPrev = 0.0; vec3 col = vec3(0.0);
  for (int m = 0; m < MAXE; m++) { if (m >= ne) break; int e = ord[m]; float z = zs[e];
    if (m > 0) { float sig = 0.0; vec3 c = vec3(0.0);
      for (int k = 0; k < MAXO; k++) { if (k >= uNO) break; if (act[k]) { sig += uSig[k]; c += uSig[k] * uCol[k]; } }
      if (sig > 0.0) { float al = 1.0 - exp(-sig * (zPrev - z)); col += T * al / sig * c; T *= 1.0 - al; } }
    zPrev = z; int kk = kd[e];
    if (kk >= 1000) { int p = kk - 1000; float u = eu[e], v = ev[e]; bool nearEdge = uFx - abs(u) < uEdge || uFy - abs(v) < uEdge;
      float al = 0.0; vec3 pc = vec3(245.0, 197.0, 24.0);
      if (uPK[p] == 0) { al = nearEdge ? 0.95 : 0.42; if ((abs(u) < uAxw && v > 0.0 && v < 0.9 * uFy) || (abs(v) < uAxw && u > 0.0 && u < 0.9 * uFx)) { al = 0.95; pc = vec3(255.0, 230.0, 160.0); } }
      else if (nearEdge) al = uPK[p] == 1 ? 0.55 : 0.4;
      if (al > 0.0) { col += T * al * pc; T *= 1.0 - al; } }
    else { int k = kk / 2;
      if (kk - 2 * k == 0) { act[k] = true; vec3 w = base + z * uF - uC[k], n = uQ[k] * w; float gz = 1.0 - abs(dot(n, uF)) / max(length(n), 1e-12), al = uRim[k] * gz * gz * gz;
        col += T * al * uCol[k]; T *= 1.0 - al; }
      else act[k] = false; }
    if (T < 0.01) break; }
  col += T * vec3(13.0, 16.0, 20.0);
  outColor = vec4(min(col, vec3(255.0)) / 255.0, 1.0);
}`;
let GL3 = null;
function gl3Init() {
  if (GL3 !== null) return GL3;
  try {
    const cv = $('#i3gl'), gl = cv.getContext('webgl2', { antialias: false, preserveDrawingBuffer: true }); if (!gl) return (GL3 = false);
    // WebGL emulated in software (no GPU, some virtual machines and remote desktops) is slower than the CPU renderer
    const dbg = gl.getExtension('WEBGL_debug_renderer_info'), renderer = String(dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
    if (/swiftshader|llvmpipe|softpipe|software|basic render/i.test(renderer) && !window.__v3gl) { console.info('3D view: software WebGL (' + renderer + '), using the CPU renderer'); return (GL3 = false); }
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, '#version 300 es\nin vec2 p; void main() { gl_Position = vec4(p, 0.0, 1.0); }'));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, GL3_FS)); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const U = {}; for (const n of ['uNO', 'uNP', 'uC', 'uQ', 'uSig', 'uCol', 'uRim', 'uPO', 'uPK', 'uR', 'uU', 'uF', 'uN', 'uE1', 'uE2', 'uRes', 'uPxmm', 'uFx', 'uFy', 'uEdge', 'uAxw']) U[n] = gl.getUniformLocation(prog, n) || gl.getUniformLocation(prog, n + '[0]');
    cv.addEventListener('webglcontextlost', e => { e.preventDefault(); GL3 = false; });
    return (GL3 = { gl, cv, prog, U });
  } catch (e) { console.warn('3D view: WebGL2 unavailable, using the CPU renderer', e); return (GL3 = false); }
}
function gl3Draw(s) {
  const G = gl3Init(); if (!G || s.objs.length > GL3_MAXO || s.planes.length > GL3_MAXP) return false;
  const { gl, cv, U } = G, W = Math.max(1, Math.round(s.W3 * dpr)), H = Math.max(1, Math.round(s.H3 * dpr));
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
  gl.viewport(0, 0, W, H); gl.useProgram(G.prog);
  const f3 = a => new Float32Array(a.flat());
  gl.uniform1i(U.uNO, s.objs.length); gl.uniform1i(U.uNP, s.planes.length);
  if (s.objs.length) {
    gl.uniform3fv(U.uC, f3(s.objs.map(o => o.c))); gl.uniformMatrix3fv(U.uQ, false, f3(s.objs.map(o => o.Q.flat())));
    gl.uniform1fv(U.uSig, new Float32Array(s.objs.map(o => o.sig))); gl.uniform3fv(U.uCol, f3(s.objs.map(o => o.col))); gl.uniform1fv(U.uRim, new Float32Array(s.objs.map(o => o.rim * 0.35)));
  }
  if (s.planes.length) { gl.uniform3fv(U.uPO, f3(s.planes.map(p => p.o))); gl.uniform1iv(U.uPK, new Int32Array(s.planes.map(p => p.kind === 'cur' ? 0 : p.kind === 'face' ? 1 : 2))); }
  for (const [n, v] of [['uR', s.right], ['uU', s.up], ['uF', s.fwd], ['uN', s.g.n], ['uE1', s.g.e1], ['uE2', s.g.e2]]) gl.uniform3fv(U[n], new Float32Array(v));
  const tiltF = 1 / Math.max(0.3, Math.abs(s.fn)), mmPerCss = 1 / s.sc;
  gl.uniform2f(U.uRes, W, H); gl.uniform1f(U.uPxmm, mmPerCss / dpr); gl.uniform1f(U.uFx, s.fx); gl.uniform1f(U.uFy, s.fy);
  gl.uniform1f(U.uEdge, 1.6 * mmPerCss * tiltF); gl.uniform1f(U.uAxw, 1.0 * mmPerCss * tiltF);
  gl.drawArrays(gl.TRIANGLES, 0, 3); cv.style.visibility = 'visible';
  return true;
}
/* Per-pixel ray casting (orthographic). Along each ray the analytic ellipsoids give exact entry/exit
   depths; the ray is split at every boundary and integrated front to back with an emission–absorption
   model (each tissue absorbs and glows in proportion to the path length inside it). Slice planes sit at
   their true depths, so tissue in front of a plane hides part of it and the plane hides what lies behind. */
const V3_SIG = { fat: 0.0028, wm: 0.0022, gm: 0.012, csf: 0.02, lesion: 0.05, blood: 0.05, muscle: 0.0075, liver: 0.008, kidney: 0.012, fluid: 0.012, marrow: 0.012, air: 0.03 };
let v3Off = null;
function drawSlice3D() {
  const ctx = i3ctx, W3 = I3W, H3 = I3H; if (W3 <= 0 || !S.sim.show3d) return;
  const R = imgRes;
  if (!R || R.error || !R.geom) { ctx.clearRect(0, 0, W3, H3); ctx.fillStyle = '#0d1014'; ctx.fillRect(0, 0, W3, H3); return; }
  if (!R.p3) { const P3 = build3D(R.phantomKey, R.bubbleOn); P3.R.forEach(r => r.S = inv3(r.Q)); R.p3 = P3; }
  const P3 = R.p3, g = R.geom;
  const cy = Math.cos(v3.yaw), sy = Math.sin(v3.yaw), cp = Math.cos(v3.pitch), sp = Math.sin(v3.pitch);
  const right = [cy, sy, 0], up = [-sy * sp, cy * sp, cp], fwd = [sy * cp, -cy * cp, sp]; // fwd points towards the viewer
  const ext = R.phantomKey === 'abdomen' ? 190 : 130, sc = Math.min(W3, H3) * 0.45 / ext * v3.zoom;
  const VC = R.phantomKey === 'abdomen' ? [0, 0, 0] : [0, 8, -22]; // view centre (mm)
  // scene: ellipsoids (+ the bubble as a sphere) with per-view quadratic coefficients in the pixel coordinates (a, b) in mm
  const objs = [];
  const addQ = (Q, c, tissue, sig, col, rim) => {
    const Qv = v => [0, 1, 2].map(i => Q[i][0] * v[0] + Q[i][1] * v[1] + Q[i][2] * v[2]);
    const Qf = Qv(fwd), Qr = Qv(right), Qu = Qv(up), Qc = Qv(c);
    objs.push({ A: dot3(fwd, Qf), Ba: dot3(Qf, right), Bb: dot3(Qf, up), B0: -dot3(Qf, c),
      Caa: dot3(right, Qr), Cab: 2 * dot3(right, Qu), Cbb: dot3(up, Qu), Ca: -2 * dot3(right, Qc), Cb: -2 * dot3(up, Qc), C0: dot3(c, Qc) - 1,
      Q, c, sig, col, rim });
  };
  const V3_TONE = { fat: [205, 208, 215], wm: [175, 180, 190], muscle: [225, 170, 145] }; // neutral body, so the amber slice stands out
  const rel = c => [c[0] - VC[0], c[1] - VC[1], c[2] - VC[2]];
  for (const r of P3.R) addQ(r.Q, rel(r.c), r.tissue, r.vis ?? V3_SIG[r.tissue] ?? 0.006, V3_TONE[r.tissue] || V3_COL[r.tissue] || [200, 200, 200], r.parent < 0 ? 0.55 : 0.8);
  if (P3.bubble) { const b = P3.bubble, q = 1 / (b.r * b.r); addQ([[q, 0, 0], [0, q, 0], [0, 0, q]], rel(b.c), 'air', 0.03, [235, 240, 255], 1); }
  // planes: the current slice (filled), its slab faces and the other slices (outlines only)
  const fx = (R.img.fovX || 220) * imgCrop(R.img, 'x') / 2, fy = (R.img.fovY || 220) * imgCrop(R.img, 'y') / 2, planes = [];
  const fn = dot3(fwd, g.n);
  const addP = (o, kind) => { o = rel(o); planes.push({ o, kind, on: dot3(o, g.n) }); };
  addP(g.o, 'cur');
  if (g.thick > 1.5 && g.thick < 200) { addP(addS(g.o, g.n, -g.thick / 2), 'face'); addP(addS(g.o, g.n, g.thick / 2), 'face'); }
  const base = addS(g.o, g.n, -g.s0);
  for (const s0 of (R.sliceOffsets || [])) if (Math.abs(s0 - g.s0) > 0.01) addP(addS(base, g.n, s0), 'other');
  const overlays = () => {
    // an edge-on slice is a line: outline it so it does not vanish
    if (Math.abs(fn) < 0.12) {
      const cs = [[-fx, -fy], [fx, -fy], [fx, fy], [-fx, fy]].map(([uu, vv]) => { const p = addS(addS(rel(g.o), g.e1, uu), g.e2, vv); return [W3 / 2 + sc * dot3(p, right), H3 / 2 - sc * dot3(p, up)]; });
      ctx.beginPath(); cs.forEach((c, k) => k ? ctx.lineTo(c[0], c[1]) : ctx.moveTo(c[0], c[1])); ctx.closePath(); ctx.strokeStyle = 'rgba(245,197,24,.9)'; ctx.lineWidth = 1.5; ctx.stroke();
    }
    // orientation triad
    const tx = 34, ty = H3 - 34, L = 22; ctx.font = `600 11px ${C.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (const [v, lab, col] of [[[1, 0, 0], 'L', '#ff7a7a'], [[0, 1, 0], 'A', '#7ddc7d'], [[0, 0, 1], 'S', '#7fb0ff']]) {
      const px = dot3(v, right), py = dot3(v, up); ctx.strokeStyle = col; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(tx + px * L, ty - py * L); ctx.stroke(); ctx.fillStyle = col; ctx.fillText(lab, tx + px * (L + 9), ty - py * (L + 9));
    }
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic'; ctx.font = `11px ${C.font}`;
    ctx.fillText('drag to rotate · scroll to zoom · double-click to reset', W3 - 8, H3 - 8);
  };
  // on the graphics card when possible (WebGL2); the same algorithm on the CPU otherwise
  if (!window.__v3cpu && gl3Draw({ objs, planes, right, up, fwd, sc, W3, H3, fx, fy, g, fn })) { ctx.clearRect(0, 0, W3, H3); overlays(); return; }
  $('#i3gl').style.visibility = 'hidden';
  const q = 1, RW = Math.max(40, Math.round(W3 * q)), RH = Math.max(30, Math.round(H3 * q)), pxmm = 1 / (sc * q);
  if (!v3Off || v3Off.width !== RW || v3Off.height !== RH) { v3Off = document.createElement('canvas'); v3Off.width = RW; v3Off.height = RH; }
  const oc = v3Off.getContext('2d'), id = oc.createImageData(RW, RH), D = id.data;
  const NO = objs.length, NP = planes.length, MAXE = 2 * NO + NP + 2;
  const zs = new Float64Array(MAXE), kinds = new Int32Array(MAXE), eu = new Float64Array(MAXE), ev = new Float64Array(MAXE), ord = new Int32Array(MAXE), act = new Uint8Array(NO);
  const tiltF = 1 / Math.max(0.3, Math.abs(dot3(fwd, g.n))), edge = 1.6 * pxmm * tiltF, axw = 1.0 * pxmm * tiltF; // bands stay visible when the plane is seen obliquely
  // flat per-object data for the inner loop
  const oSig = new Float64Array(NO), oR = new Float64Array(NO), oG = new Float64Array(NO), oB = new Float64Array(NO), oRim = new Float64Array(NO);
  objs.forEach((o, k) => { oSig[k] = o.sig; oR[k] = o.col[0]; oG[k] = o.col[1]; oB[k] = o.col[2]; oRim[k] = o.rim * 0.35; });
  // plane geometry in pixel coordinates: z(a, b) = za0 + za·a + zb·b and in-plane (u, v) linear in (a, b)
  const rn = dot3(right, g.n), un = dot3(up, g.n);
  const PL = planes.map(P => {
    const z0 = P.on / fn, za = -rn / fn, zb = -un / fn;
    // point = a·right + b·up + z·fwd − o, projected on e1 / e2
    const lin = e => ({ c: -dot3(P.o, e) + z0 * dot3(fwd, e), a: dot3(right, e) + za * dot3(fwd, e), b: dot3(up, e) + zb * dot3(fwd, e) });
    return { z0, za, zb, U: lin(g.e1), V: lin(g.e2), kind: P.kind === 'cur' ? 0 : P.kind === 'face' ? 1 : 2 };
  });
  const planesOn = Math.abs(fn) > 1e-6;
  for (let j = 0; j < RH; j++) {
    const bb = (RH / 2 - (j + 0.5)) * pxmm;
    for (let i = 0; i < RW; i++) {
      const aa = ((i + 0.5) - RW / 2) * pxmm;
      let ne = 0;
      for (let k = 0; k < NO; k++) {
        const o = objs[k], B = aa * o.Ba + bb * o.Bb + o.B0, Cc = aa * aa * o.Caa + aa * bb * o.Cab + bb * bb * o.Cbb + aa * o.Ca + bb * o.Cb + o.C0;
        const disc = B * B - o.A * Cc; if (disc <= 0) continue;
        const sq = Math.sqrt(disc); zs[ne] = (-B + sq) / o.A; kinds[ne++] = 2 * k; zs[ne] = (-B - sq) / o.A; kinds[ne++] = 2 * k + 1; // near, far
      }
      if (planesOn) for (let p = 0; p < NP; p++) {
        const P = PL[p], uu = P.U.c + P.U.a * aa + P.U.b * bb, vv = P.V.c + P.V.a * aa + P.V.b * bb;
        if (uu > fx || uu < -fx || vv > fy || vv < -fy) continue;
        zs[ne] = P.z0 + P.za * aa + P.zb * bb; kinds[ne] = 1000 + p; eu[ne] = uu; ev[ne] = vv; ne++;
      }
      for (let e = 0; e < ne; e++) { let k = e; while (k > 0 && zs[ord[k - 1]] < zs[e]) { ord[k] = ord[k - 1]; k--; } ord[k] = e; } // near → far
      let T = 1, r = 0, gg = 0, bl = 0, zPrev = 0;
      for (let k = 0; k < NO; k++) act[k] = 0;
      for (let m = 0; m < ne; m++) {
        const e = ord[m], z = zs[e];
        if (m > 0) { // medium between the previous event and this one
          let sig = 0, cr = 0, cg = 0, cb = 0;
          for (let k = 0; k < NO; k++) if (act[k]) { const s = oSig[k]; sig += s; cr += s * oR[k]; cg += s * oG[k]; cb += s * oB[k]; }
          if (sig > 0) { const al = 1 - Math.exp(-sig * (zPrev - z)), w = T * al / sig; r += w * cr; gg += w * cg; bl += w * cb; T *= 1 - al; }
        }
        zPrev = z;
        const kd = kinds[e];
        if (kd >= 1000) { // a plane
          const P = PL[kd - 1000], uu = eu[e], vv = ev[e], nearEdge = fx - Math.abs(uu) < edge || fy - Math.abs(vv) < edge;
          let al = 0, cr = 245, cg = 197, cb = 24;
          if (P.kind === 0) {
            al = nearEdge ? 0.95 : 0.42;
            if ((Math.abs(uu) < axw && vv > 0 && vv < 0.9 * fy) || (Math.abs(vv) < axw && uu > 0 && uu < 0.9 * fx)) { al = 0.95; cr = 255; cg = 230; cb = 160; }
          } else if (nearEdge) al = P.kind === 1 ? 0.55 : 0.4;
          if (al > 0) { r += T * al * cr; gg += T * al * cg; bl += T * al * cb; T *= 1 - al; }
        } else {
          const k = kd >> 1;
          if ((kd & 1) === 0) { // entering: a soft rim where the ray grazes the surface
            act[k] = 1;
            const o = objs[k], wx = aa * right[0] + bb * up[0] + z * fwd[0] - o.c[0], wy = aa * right[1] + bb * up[1] + z * fwd[1] - o.c[1], wz = aa * right[2] + bb * up[2] + z * fwd[2] - o.c[2], Q = o.Q;
            const nx = Q[0][0] * wx + Q[0][1] * wy + Q[0][2] * wz, ny = Q[1][0] * wx + Q[1][1] * wy + Q[1][2] * wz, nz = Q[2][0] * wx + Q[2][1] * wy + Q[2][2] * wz;
            const nl = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1, gz = 1 - Math.abs(nx * fwd[0] + ny * fwd[1] + nz * fwd[2]) / nl, al = oRim[k] * gz * gz * gz;
            r += T * al * oR[k]; gg += T * al * oG[k]; bl += T * al * oB[k]; T *= 1 - al;
          } else act[k] = 0;
        }
        if (T < 0.01) break;
      }
      const p = (j * RW + i) * 4;
      D[p] = r + T * 13; D[p + 1] = gg + T * 16; D[p + 2] = bl + T * 20; D[p + 3] = 255; // Uint8ClampedArray clamps
    }
  }
  oc.putImageData(id, 0, 0);
  ctx.imageSmoothingEnabled = true; ctx.drawImage(v3Off, 0, 0, W3, H3);
  overlays();
}
i3.addEventListener('pointerdown', e => { i3.setPointerCapture(e.pointerId); v3drag = { x: e.clientX, y: e.clientY, yaw: v3.yaw, pitch: v3.pitch }; });
let v3Pending = false;
const v3Request = () => { if (!v3Pending) { v3Pending = true; requestAnimationFrame(() => { v3Pending = false; drawSlice3D(); }); } };
i3.addEventListener('pointermove', e => { if (!v3drag) return; v3.yaw = v3drag.yaw - (e.clientX - v3drag.x) * 0.01; v3.pitch = Math.max(-1.5, Math.min(1.5, v3drag.pitch + (e.clientY - v3drag.y) * 0.01)); v3Request(); });
i3.addEventListener('pointerup', () => { v3drag = null; drawSlice3D(); }); i3.addEventListener('pointercancel', () => { v3drag = null; drawSlice3D(); });
i3.addEventListener('dblclick', () => { v3 = { ...V3_DEFAULT }; drawSlice3D(); });
i3.addEventListener('wheel', e => { e.preventDefault(); v3.zoom = Math.max(0.4, Math.min(4, v3.zoom * Math.exp(-e.deltaY * 0.0015))); v3Request(); }, { passive: false });
let imgOff = null;
/* fraction of the image shown along x or y: < 1 when the readout is oversampled and cropping is on */
function imgCrop(I, a) { return S.sim.crop === false ? 1 : (a === 'x' ? I.cropX : I.cropY) || 1; }
function drawImg() {
  if (IW <= 0) return;
  const ctx = ictx; ctx.clearRect(0, 0, IW, IW);
  const info = $('#imInfo');
  if (!S.seq) { info.textContent = 'No sequence loaded.'; return; }
  if (!imgRes) { info.textContent = ''; return; }
  if (imgRes.error) { info.textContent = imgRes.error; $('#imEcho').hidden = true; return; }
  const R = imgRes, I = R.img, view = S.sim.view;
  { const nav = $('#imEcho'), n = R.nEcho || 1; nav.hidden = n < 2;
    if (n > 1) { $('#imEchoTxt').textContent = `Echo ${R.echo + 1} / ${n} · TE ${fmt(R.TE * 1e3, 3)} ms`; $('#imEchoPrev').disabled = R.echo <= 0; $('#imEchoNext').disabled = R.echo >= n - 1; } }
  let G, getV, lo, hi;
  if (view === 'k') {
    G = R.kspace.G; const Kr = R.kspace.re, Ki = R.kspace.im, L = new Float64Array(G * G); let mx = 0;
    for (let o = 0; o < G * G; o++) { L[o] = Math.log10(1e-12 + Math.hypot(Kr[o], Ki[o])); if (R.mask[o]) mx = Math.max(mx, L[o]); }
    lo = mx - 4; hi = mx; getV = o => L[o];
  } else {
    G = I.G; const M = new Float64Array(G * G);
    for (let o = 0; o < G * G; o++) M[o] = view === 'phase' ? Math.atan2(I.im[o], I.re[o]) : Math.hypot(I.re[o], I.im[o]);
    if (view === 'phase') { lo = -Math.PI; hi = Math.PI; }
    else { const srt = Float64Array.from(M).sort(); lo = 0; hi = srt[Math.floor(0.995 * (srt.length - 1))] * 1.05 || 1; }
    getV = o => M[o];
  }
  if (!imgOff || imgOff.width !== G) { imgOff = document.createElement('canvas'); imgOff.width = imgOff.height = G; }
  const oc = imgOff.getContext('2d'), id = oc.createImageData(G, G), d = id.data;
  const amber = [224, 150, 20];
  for (let y = 0; y < G; y++) for (let x = 0; x < G; x++) {
    const o = y * G + x, p = ((G - 1 - y) * G + x) * 4; // y up
    let v = Math.max(0, Math.min(1, (getV(o) - lo) / (hi - lo))), r, g, b;
    if (view === 'k') {
      const m = R.mask[o];
      if (m === 2) { r = amber[0] * (0.25 + 0.75 * v); g = amber[1] * (0.25 + 0.75 * v); b = amber[2] * (0.25 + 0.75 * v); }
      else if (m === 1) r = g = b = 255 * v; else r = g = b = 0;
    } else r = g = b = 255 * v;
    d[p] = r; d[p + 1] = g; d[p + 2] = b; d[p + 3] = 255;
  }
  oc.putImageData(id, 0, 0);
  // keep the physical aspect ratio (FOV) of the image
  // readout oversampling: the image covers the whole sampled FOV; cropping draws only its central part (display only)
  const cx = view === 'k' ? 1 : imgCrop(I, 'x'), cy = view === 'k' ? 1 : imgCrop(I, 'y');
  ctx.imageSmoothingEnabled = view !== 'k';
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, IW, IW);
  let w, h, kE = 0;
  if (view === 'k') {
    // k-space in physical units, the same scale on both axes: a grid cell is Δkx wide and Δky high, so readout
    // oversampling (smaller Δk along the readout) shows as denser samples over the same k range, not as a wider
    // range. Shown: a square of ±kE, the largest |k| acquired or filled along either axis.
    const dx = R.kspace.dkx || 1, dy = R.kspace.dky || 1; let mxc = 0, myc = 0;
    for (let y = 0; y < G; y++) for (let x = 0; x < G; x++) if (R.mask[y * G + x]) { mxc = Math.max(mxc, Math.abs(x - G / 2) + 0.5); myc = Math.max(myc, Math.abs(y - G / 2) + 0.5); }
    kE = Math.max(mxc * dx, myc * dy) || G / 2 * Math.max(dx, dy);
    w = h = IW; const px = IW / (2 * kE); // screen pixels per 1/mm
    // source rectangle in grid cells (centre at G/2), clipped to the grid; the destination follows the clipping
    const hx = Math.min(G / 2, kE / dx), hy = Math.min(G / 2, kE / dy), dw = 2 * hx * dx * px, dh = 2 * hy * dy * px;
    ctx.drawImage(imgOff, G / 2 - hx, G / 2 - hy, 2 * hx, 2 * hy, (IW - dw) / 2, (IW - dh) / 2, dw, dh);
  } else {
    const ax = I.fovX * cx, ay = I.fovY * cy, sc = Math.min(IW / ax, IW / ay); w = ax * sc; h = ay * sc;
    const sw = G * cx, sh = G * cy; // source rectangle: centred (the image rows are stored with y up, the crop is symmetric)
    ctx.drawImage(imgOff, (G - sw) / 2, (G - sh) / 2, sw, sh, (IW - w) / 2, (IW - h) / 2, w, h);
  }
  ctx.fillStyle = 'rgba(255,255,255,.75)'; ctx.font = `11px ${C.font}`; ctx.textAlign = 'left';
  const T = R.target;
  ctx.fillText(view === 'k' ? 'k-space: grey acquired, amber filled' : `${S.vols.length ? `volume ${T.vi + 1} · ` : ''}shot ${T.ref + 1}`, 8, 16);
  if (view !== 'k') {
    ctx.textAlign = 'right'; ctx.fillText(`FOV ${fmt(I.fovX * cx, 3)} × ${fmt(I.fovY * cy, 3)} mm${R.osRO > 1 ? ` · ${fmt(R.osRO, 3)}× readout oversampling${cx < 1 || cy < 1 ? ', cropped' : ''}` : ''}`, IW - 8, IW - 8);
    const g = R.geom;
    if (g) { // anatomical directions at the edges of the image
      const x0i = (IW - w) / 2, y0i = (IW - h) / 2, neg = v => v.map(x => -x);
      ctx.font = `600 12px ${C.font}`; ctx.fillStyle = 'rgba(255,214,120,.95)'; ctx.textBaseline = 'middle';
      ctx.textAlign = 'right'; ctx.fillText(dirLetter(g.e1), x0i + w - 5, y0i + h / 2);
      ctx.textAlign = 'left'; ctx.fillText(dirLetter(neg(g.e1)), x0i + 5, y0i + h / 2);
      ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText(dirLetter(g.e2), x0i + w / 2, y0i + 5);
      ctx.textBaseline = 'bottom'; ctx.fillText(dirLetter(neg(g.e2)), x0i + w / 2, y0i + h - 5);
      ctx.textBaseline = 'alphabetic';
      drawScout(ctx, R, 8, IW - 8 - Math.round(IW * 0.3), Math.round(IW * 0.3));
    }
  }
  // info
  const f = x => isFinite(x) ? fmt(x, 3) : '∞';
  const parts = [
    `${R.nEcho > 1 ? `Echo ${R.echo + 1} of ${R.nEcho} · ` : ''}${Math.round(R.dispW * imgCrop(R.img, 'x'))}×${Math.round(R.dispH * imgCrop(R.img, 'y'))} · ${R.n.toLocaleString()} samples from ${R.nShots} shot${R.nShots > 1 ? 's' : ''}${R.axes !== 'xy' ? ` · image plane k${R.axes[0]}–k${R.axes[1]}` : ''}${R.useRef ? ' · reference scan' : ''}`,
    (() => { const g = R.geom; if (!g) return '';
      const pn = planeName(g.n), tilt = pn.tilt > 1 ? `, tilted ${fmt(pn.tilt, 2)}°` : '';
      if (g.mode === 'slice' && g.fixed) return `Slice: ${pn.name}${tilt}, ${fmt(g.thick, 2)} mm thick, fixed at the air bubble's plane (${g.s0 >= 0 ? '+' : ''}${fmt(g.s0, 3)} mm); the sequence's position is ignored`;
      if (g.mode === 'slice') return `Slice: ${pn.name}${tilt}, ${fmt(g.thick, 2)} mm thick at ${g.s0 >= 0 ? '+' : ''}${fmt(g.s0, 3)} mm (RF bandwidth ${fmt(g.bw / 1000, 2)} kHz, slice gradient ${fmt(g.G / GAMMA * 1e3, 3)} mT/m)`;
      if (g.mode === 'nonselective') return `No slice selection: projection through the phantom (${pn.name} direction)`;
      return `3D encoding: ${pn.name} partition of ${fmt(g.thick, 2)} mm at ${g.mode.includes('slab') ? `the slab centre (${g.s0 >= 0 ? '+' : ''}${fmt(g.s0, 3)} mm)` : 'the centre'}`; })(),
    `TE ${fmt(R.TE * 1e3, 3)} ms · TR ${R.TR > 1e8 ? 'single shot' : fmt(R.TR * 1e3, 3) + ' ms'} · flip ${fmt(R.flip * 180 / Math.PI, 3)}° · ${R.se ? 'spin echo' : 'gradient echo'}${R.inv ? ` · TI ${fmt(R.inv.t * 1e3, 3)} ms` : ''}${R.sats ? ' · saturation pulse' : ''}${S.sim.diffusion ? ` · b = ${Math.round(R.b)} s/mm²` : ''}`,
    (() => { const ax = R.axes, big = Math.abs(R.fatY) >= Math.abs(R.fatX) ? 1 : 0, fs = Math.abs(big ? R.fatY : R.fatX);
      return `Bandwidth per pixel: readout (k${ax[R.roAxis]}) ${f(R.bwRO)} Hz · effective along k${ax[0]} ${f(R.bwX)} Hz, along k${ax[1]} ${f(R.bwY)} Hz → fat shift ${fmt(fs, 2)} px along k${ax[big]} (${S.sim.B0} T)`; })(),
    R.eddy ? `Eddy currents (${R.eddy.name}, illustrative): k-space off by up to ${fmt(R.eddy.echoX, 2)} px along k${R.axes[0]} and ${fmt(R.eddy.echoY, 2)} px along k${R.axes[1]} at the echo (${fmt(R.eddy.maxX, 2)} / ${fmt(R.eddy.maxY, 2)} px over the readout); B0 eddy phase up to ${fmt(R.eddy.phase, 2)} rad` : '',
    R.cart ? (R.nMissing ? `${R.nMissing} of ${R.Ny} lines not acquired (${R.pf ? 'partial Fourier' : 'acceleration'}): ${S.sim.fill ? 'filled as by an ideal reconstruction' : 'zero-filled'}` : 'Fully sampled Cartesian k-space') : 'Non-Cartesian: exact inverse Fourier sum with density compensation',
    `Computed in ${fmt(R.ms / 1000, 2)} s (${R.engine || 'CPU'})`
  ];
  info.innerHTML = parts.filter(Boolean).map(esc).join('<br>');
  drawSlice3D();
}

/* ---------- linking tabs ---------- */
const TAB_ID = Math.random().toString(36).slice(2);
let linkApplying = false, linkCh = null, linkViewPending = false, linkHoverPending = false;
const linkPeers = new Map();
function linkPost(m) { m.from = TAB_ID; try { linkCh && linkCh.postMessage(m); } catch (_) { } }
function linkInit() {
  try { linkCh = new BroadcastChannel('seqret-link'); linkCh.onmessage = e => onLink(e.data); }
  catch (_) { // fallback: storage events
    linkCh = { postMessage: m => { try { localStorage.setItem('seqret-link', JSON.stringify(m)); localStorage.removeItem('seqret-link'); } catch (_) { } } };
    window.addEventListener('storage', e => { if (e.key === 'seqret-link' && e.newValue) try { onLink(JSON.parse(e.newValue)); } catch (_) { } });
  }
  setInterval(() => { if (S.linkMode !== 'off') linkPost({ type: 'here' }); pruneLinkPeers(); }, 2500);
  window.addEventListener('pagehide', () => linkPost({ type: 'bye' }));
}
function pruneLinkPeers() { const now = Date.now(); for (const [k, t] of linkPeers) if (now - t > 7000) linkPeers.delete(k); updateLinkInfo(); }
function updateLinkInfo() {
  const el = $('#linkInfo'); if (!el) return;
  $('#moreBtn').classList.toggle('linked', S.linkMode !== 'off');
  if (S.linkMode === 'off') { el.textContent = ''; return; }
  const n = linkPeers.size;
  el.innerHTML = n ? `<span class="dot on"></span>${n} other tab${n > 1 ? 's' : ''}` : `<span class="dot"></span>waiting for another linked tab`;
}
/* express the view (or a time) relative to the shot/volume it falls in, for the other tab to map back */
function linkRef(t) {
  const m = S.linkMode, s = S.seq;
  const list = m === 'shot' ? s.shots : m === 'vol' ? S.vols : null;
  if (!list || !list.length) return { k: -1, base: 0 };
  const k = m === 'shot' ? shotAt(t) : volAt(t); return { k, base: list[k].t0 };
}
function linkBase(mode, k) {
  const s = S.seq, list = mode === 'shot' ? s.shots : mode === 'vol' ? S.vols : null;
  if (!list || !list.length || k < 0) return 0;
  return list[Math.min(k, list.length - 1)].t0;
}
function linkSendView() {
  if (S.linkMode === 'off' || !S.seq || linkViewPending) return;
  linkViewPending = true;
  requestAnimationFrame(() => {
    linkViewPending = false; if (!S.seq) return;
    const r = linkRef((S.t0 + S.t1) / 2);
    linkPost({ type: 'view', mode: S.linkMode, k: r.k, r0: S.t0 - r.base, r1: S.t1 - r.base });
  });
}
function linkSendHover() {
  if (S.linkMode === 'off' || !S.seq || linkHoverPending) return;
  linkHoverPending = true;
  requestAnimationFrame(() => {
    linkHoverPending = false; if (!S.seq) return;
    if (S.hoverT == null) { linkPost({ type: 'hover', h: null }); return; }
    const r = linkRef(S.hoverT); linkPost({ type: 'hover', mode: S.linkMode, k: r.k, rh: S.hoverT - r.base });
  });
}
function onLink(d) {
  if (!d || d.from === TAB_ID || S.linkMode === 'off') return;
  linkPeers.set(d.from, Date.now());
  if (d.type === 'bye') { linkPeers.delete(d.from); updateLinkInfo(); return; }
  if (d.type === 'hello') { linkPost({ type: 'here' }); if (d.want) { S.linkMode !== 'off' && S.seq && (linkViewPending = false, linkSendView()); } }
  if (d.type === 'mode' && d.mode !== S.linkMode && d.mode !== 'off') { S.linkMode = d.mode; $('#linkSel').value = d.mode; }
  if (!S.seq) { updateLinkInfo(); return; }
  if (d.type === 'view') {
    const b = d.k >= 0 ? linkBase(d.mode, d.k) : 0;
    linkApplying = true; setView(b + d.r0, b + d.r1); linkApplying = false;
  } else if (d.type === 'hover') {
    S.hoverT = d.h === null ? null : (d.k >= 0 ? linkBase(d.mode, d.k) : 0) + d.rh; requestOverlay();
  }
  updateLinkInfo();
}
$('#linkSel').onchange = e => {
  S.linkMode = e.target.value; linkPeers.clear();
  if (S.linkMode !== 'off') { linkPost({ type: 'mode', mode: S.linkMode }); linkPost({ type: 'hello' }); linkSendView(); }
  updateLinkInfo();
};
$('#newTabBtn').onclick = () => {
  const url = location.href.split('#')[0] + (S.linkMode !== 'off' ? '#link=' + S.linkMode : '');
  window.open(url, '_blank');
};
{ const m = /link=(time|shot|vol)/.exec(location.hash); if (m) { S.linkMode = m[1]; $('#linkSel').value = m[1]; } }
linkInit(); updateLinkInfo();
if (S.linkMode !== 'off') linkPost({ type: 'hello' });

/* ---------- loading ---------- */
function showError(msg) { $('#empty').style.display = ''; $('#err').textContent = msg; }
/* workers for the image simulation: they run SIM_TASKS (see sim.js) on the data they are sent */
const POOL_GLUE = `
const __load = onmessage;
onmessage = e => { const d = e.data;
  if (d && d.stim) { // nerve stimulation pass (stim.js): progress messages, then the result with its buffers transferred
    try { const r = stimJobRun(d, p => postMessage({ stimP: p })), tr = [r.mn.buffer, r.mx.buffer, r.ck.buffer, r.peak.buffer, r.peakK.buffer];
      for (const L of r.pyr) if (L.size > 1) tr.push(L.mn.buffer, L.mx.buffer); postMessage({ stimR: r }, tr); }
    catch (err) { postMessage({ stimErr: String(err && err.message || err) }); }
    return; }
  if (!d || !d.task) return __load(e);
  try { const r = SIM_TASKS[d.task](d.args), tr = []; for (const k in r) if (ArrayBuffer.isView(r[k])) tr.push(r[k].buffer); postMessage({ id: d.id, result: r }, tr); }
  catch (err) { postMessage({ id: d.id, err: String(err && err.message || err) }); } };`;
const WORKER_GLUE = `
onmessage = e => {
  try {
    if (e.data && e.data.sigOnly) { postMessage({ hash: signatureHash(e.data.bytes) }); return; } // the parallel md5 worker
    const t0 = Date.now(), s = loadSeq(e.data.bytes, p => postMessage({ p: p * 0.9 }), true), t1 = Date.now();
    s.vols0 = computeVolumes(s, s.shots, 'auto', null, p => postMessage({ p: 0.9 + 0.1 * p }));
    s.loadTimes.volumes = Date.now() - t1; s.loadTimes.posted = Date.now();
    s.shotsPacked = packShots(s.shots); s.shots = null;
    postMessage({ seq: s }, transferList(s));
  } catch (err) { postMessage({ err: String(err && err.message || err) }); }
};`;
function loadMain(bytes, onP) { // fallback without a worker
  return new Promise((res, rej) => setTimeout(() => {
    try { const s = loadSeq(bytes, onP); s.vols0 = computeVolumes(s, s.shots, 'auto'); res(s); } catch (e) { rej(e); }
  }, 30));
}
let workerURL = null;
const POOL = { workers: [], queue: [], busy: new Map(), size: 0, id: 0 };
function poolInit() {
  if (POOL.size) return true;
  const n = Math.max(1, Math.min(8, (navigator.hardwareConcurrency || 4) - 1));
  try {
    for (let i = 0; i < n; i++) {
      const w = coreWorker();
      w.onmessage = ev => { const job = POOL.busy.get(w); POOL.busy.delete(w); if (job) { if (ev.data.err) poolLocal(job); else job.res(ev.data.result); } poolPump(); };
      w.onerror = ev => { ev.preventDefault(); const job = POOL.busy.get(w); POOL.busy.delete(w); if (job) poolLocal(job); poolPump(); };
      POOL.workers.push(w);
    }
  } catch (e) { POOL.workers.forEach(w => w.terminate()); POOL.workers = []; return false; }
  POOL.size = n; poolRun.size = n; return true;
}
function poolLocal(job) { try { job.res(SIM_TASKS[job.task](job.args)); } catch (e) { job.rej(e); } } // a failed worker: run it here
function poolPump() {
  for (const w of POOL.workers) {
    if (!POOL.queue.length) return; if (POOL.busy.has(w)) continue;
    const job = POOL.queue.shift(); POOL.busy.set(w, job); w.postMessage({ task: job.task, args: job.args, id: ++POOL.id });
  }
}
function poolRun(task, args) { return new Promise((res, rej) => { POOL.queue.push({ task, args, res, rej }); poolPump(); }); }
function poolCancel() { const q = POOL.queue; POOL.queue = []; for (const j of q) j.rej(new Error('cancelled')); }
function coreWorker() { // a worker running the core (and simulation) code
  if (!workerURL) workerURL = URL.createObjectURL(new Blob([document.getElementById('core').textContent + WORKER_GLUE + POOL_GLUE], { type: 'text/javascript' }));
  return new Worker(workerURL);
}
function loadWorker(bytes, onP) {
  return new Promise((res, rej) => {
    let w, ws = null, seq = null, hash, gotHash = false;
    try { w = coreWorker(); } catch (e) { loadMain(bytes, onP).then(res, rej); return; }
    // the md5 signature check runs in a second worker, in parallel with parsing
    try { ws = coreWorker(); ws.onmessage = ev => { hash = ev.data.hash; gotHash = true; ws.terminate(); finish(); }; ws.onerror = ev => { ev.preventDefault(); ws.terminate(); ws = null; gotHash = true; hash = undefined; finish(); }; ws.postMessage({ sigOnly: true, bytes }); }
    catch (e) { ws = null; gotHash = true; }
    const t0 = performance.now();
    const finish = () => {
      if (!seq || !gotHash) return;
      seq.sig = hash === undefined ? verifySignature(bytes, seq) : signatureStatus(seq, hash);
      seq.loadTimes.total = performance.now() - t0; res(seq);
    };
    w.onmessage = ev => {
      const d = ev.data;
      if (d.p !== undefined) onP(d.p);
      else if (d.seq) { d.seq.loadTimes.transfer = Date.now() - d.seq.loadTimes.posted; w.terminate(); seq = d.seq; const tu = Date.now(); seq.shots = unpackShots(seq.shotsPacked); delete seq.shotsPacked; seq.loadTimes.unpack = Date.now() - tu; finish(); }
      else if (d.err) { w.terminate(); if (ws) ws.terminate(); rej(new Error(d.err)); }
    };
    w.onerror = ev => { ev.preventDefault(); w.terminate(); if (ws) ws.terminate(); loadMain(bytes, onP).then(res, rej); };
    w.postMessage({ bytes }); // copied, so the fallbacks still have the data
  });
}
function setBusy(on, p) {
  $('#busy').classList.toggle('on', on);
  if (on) { $('#busyTxt').textContent = p == null ? 'Reading sequence…' : `Reading sequence… ${Math.round(p * 100)}%`; $('#busyBar').style.width = ((p || 0) * 100) + '%'; }
}
async function load(bytes, name, opts = {}) {
  if (bytes.length > 2.5e8) { showError(`${name} is ${(bytes.length / 1e6).toFixed(0)} MB. Files over 250 MB are not supported in the browser.`); return false; }
  setBusy(true, 0);
  const prev = opts.keep && S.seq ? { t0: S.t0, t1: S.t1, sel: S.sel, selKind: S.selKind, hist: S.hist.slice() } : null;
  try {
    const tL = performance.now(), seq = await loadWorker(bytes, p => setBusy(true, p)); bytes = null;
    window.__loadTimes = seq.loadTimes; seq.loadTimes.worker = performance.now() - tL;
    seq.shotsExc = seq.shots;
    linkApplying = true;
    Object.assign(S, { seq, name, sel: -1, hoverT: null, hist: [] }); kInvalidate(); gMaxAll = 0; imgReset();
    S.vis.labels = seq.labels.length > 0 && S.labelsPref; buildChips();
    applyShots(); fillVolMenu(); applyVols(); $('#backBtn').disabled = true;
    $('#fname').textContent = name;
    $('#fmeta').textContent = `v${seq.version.major}.${seq.version.minor}.${seq.version.revision} · ${seq.nb.toLocaleString()} blocks · ${fmtT(seq.totalDur)}`;
    document.title = `${name} · Seqret`;
    $('#empty').style.display = 'none'; $('#err').textContent = '';
    ovCache = null; readColors();
    if (prev) { // reload: same view, selection and history where they still exist in the new file
      setView(prev.t0, prev.t1); S.hist = prev.hist; $('#backBtn').disabled = !S.hist.length;
      if (prev.sel >= 0 && prev.sel < seq.nb) { S.sel = prev.sel; S.selKind = prev.selKind; }
    } else { fitAll(); if (seq.shots.length) zoomToShot(0); }
    renderSeqInfo(); renderDefs(); renderBlock(); requestK(); if (prev) requestImg();
    SRC = opts.src || null; $('#reloadBtn').hidden = !(SRC && (SRC.handle || SRC.file)); if (!prev) fnote('');
    stimStart(true);
    if (!prev) ovl.focus({ preventScroll: true });
    linkApplying = false; if (S.linkMode !== 'off') linkPost({ type: 'hello', want: true });
    return true;
  } catch (err) {
    linkApplying = false;
    console.error(err);
    showError(`Could not open ${name}: ${err.message}`);
    return false;
  } finally { setBusy(false); }
}
/* ---------- reloading the current file ----------
   A page cannot re-read a file by its path. Where the browser offers the File System Access API (Chrome, Edge),
   files opened with Open or dropped on the page are kept as a handle, and getFile() returns what is on disk now.
   Otherwise the File object is kept; browsers let it be read again only while the file is unchanged (Chrome
   refuses after a change), so reloading then asks to open the file again. The demo and files embedded by
   seqret.m have no file to re-read. */
let SRC = null, reloading = false;
const canPick = typeof window.showOpenFilePicker === 'function';
function fnote(t, warn) { const el = $('#fnote'); el.textContent = t; el.classList.toggle('warn', !!warn); }
async function reloadFile() {
  if (!S.seq || !SRC || reloading || !(SRC.handle || SRC.file)) return;
  reloading = true; $('#reloadBtn').classList.add('spin');
  try {
    let f;
    if (SRC.handle) {
      if (SRC.handle.queryPermission && (await SRC.handle.queryPermission({ mode: 'read' })) !== 'granted' &&
          (await SRC.handle.requestPermission({ mode: 'read' })) !== 'granted') { fnote('Reading the file was not allowed', true); return; }
      f = await SRC.handle.getFile();
    } else f = SRC.file;
    let bytes;
    try { bytes = new Uint8Array(await f.arrayBuffer()); }
    catch (e) {
      fnote(SRC.handle ? `Could not read the file: ${e.message}` : 'The file changed on disk and this browser only reads the version it was given: open it again' + (canPick ? '' : ' (Chrome and Edge can reload changed files)'), true);
      return;
    }
    const changed = SRC.handle ? (f.lastModified !== SRC.mod || f.size !== SRC.size) : null;
    const src = { ...SRC, mod: f.lastModified, size: f.size };
    if (await load(bytes, f.name || S.name, { src, keep: true })) {
      const t = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      fnote(changed === false ? `Reloaded ${t}, no change on disk` : `Reloaded ${t}`);
    }
  } catch (e) { fnote(`Could not reload: ${e.message}`, true); }
  finally { reloading = false; $('#reloadBtn').classList.remove('spin'); }
}
$('#reloadBtn').onclick = reloadFile;
/* the folder of the last opened file (1.20.0): its handle is kept in the browser's IndexedDB, and the next Open .seq
   starts there (startIn). Only where the File System Access API exists (Chrome, Edge); other browsers' own file
   dialogs remember the folder, or not, by themselves. The handle gives no access to the file by itself. */
let lastHandle = null;
const kvDB = (() => { let p = null; return () => p || (p = new Promise((res, rej) => { const r = indexedDB.open('seqret', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); })); })();
async function kvGet(k) { const db = await kvDB(); return new Promise((res, rej) => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); }
async function kvSet(k, v) { const db = await kvDB(); return new Promise((res, rej) => { const tx = db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); }); }
function rememberHandle(h) { if (!h || h.kind !== 'file') return; lastHandle = h; kvSet('lastSeqHandle', h).catch(() => { }); }
if (typeof window.showOpenFilePicker === 'function' && window.indexedDB) kvGet('lastSeqHandle').then(h => { if (h && !lastHandle) lastHandle = h; }, () => { });
async function openFile(f, src) {
  if (!f) return;
  if (src && src.handle) rememberHandle(src.handle);
  let buf; try { buf = new Uint8Array(await f.arrayBuffer()); } catch (e) { showError(`Could not read ${f.name}: ${e.message}`); return; }
  load(buf, f.name, { src: { ...(src || { file: f }), mod: f.lastModified, size: f.size } });
}
async function pickFile() { // File System Access picker where available (reloadable from disk), otherwise the file input
  if (!canPick) { $('#fileIn').click(); return; }
  let h;
  const types = [{ description: 'Pulseq sequence', accept: { 'text/plain': ['.seq'] } }];
  // start in the folder of the last opened file; without one (or if the browser rejects it), in the folder the
  // browser remembers for this picker
  try { [h] = await window.showOpenFilePicker(lastHandle ? { startIn: lastHandle, types } : { id: 'seqret', types }); }
  catch (e) {
    if (e.name === 'AbortError') return;
    if (lastHandle) { try { [h] = await window.showOpenFilePicker({ id: 'seqret', types }); } catch (e2) { if (e2.name !== 'AbortError') $('#fileIn').click(); return; } }
    else { $('#fileIn').click(); return; }
  }
  try { openFile(await h.getFile(), { handle: h }); } catch (e) { showError(`Could not read the file: ${e.message}`); }
}
$('#openBtn').onclick = $('#openBtn2').onclick = pickFile;
$('#fileIn').onchange = e => { const f = e.target.files[0]; openFile(f, { file: f }); e.target.value = ''; };
$('#demoBtn').onclick = () => load(new TextEncoder().encode($('#demoSeq').textContent), 'seqret_default.seq', { src: { demo: true } });
let dragDepth = 0;
window.addEventListener('dragenter', e => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { dragDepth++; $('#drop').classList.add('on'); e.preventDefault(); } });
window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('#drop').classList.remove('on'); });
window.addEventListener('dragover', e => e.preventDefault());
window.addEventListener('drop', e => {
  e.preventDefault(); dragDepth = 0; $('#drop').classList.remove('on');
  const f = e.dataTransfer?.files?.[0]; if (!f) return;
  const it = e.dataTransfer.items && e.dataTransfer.items[0]; // the handle must be requested during the event
  const hp = it && it.kind === 'file' && typeof it.getAsFileSystemHandle === 'function' ? it.getAsFileSystemHandle() : null;
  if (!hp) { openFile(f, { file: f }); return; }
  hp.then(h => openFile(f, h && h.kind === 'file' ? { handle: h } : { file: f }), () => openFile(f, { file: f }));
});

/* ---------- settings kept between sessions (browser local storage) ---------- */
const SETTINGS_KEY = 'seqret-settings', PREF_KEYS = ['sim', 'diagRes', 'lineMode', 'sideHidden', 'gUnit', 'rfUnit', 'rfMode', 'autoY', 'combineG', 'stimNorm', 'shotMode', 'volPref', 'labelsPref', 'kRange', 'kProj', 'kColor', 'kTraj'];
const DEFAULTS = JSON.parse(JSON.stringify({ vis: S.vis, ...Object.fromEntries(PREF_KEYS.map(k => [k, S[k]])) }));
function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify({ v: 1, app: APP.version, vis: S.vis, ...Object.fromEntries(PREF_KEYS.map(k => [k, S[k]])) })); } catch (_) { }
}
function segPress(id, v) { $(id).querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', b.dataset.v === v)); }
function applySettings(o) {
  const ok = (k, allowed) => o[k] !== undefined && (!allowed || allowed.includes(o[k]));
  if (o.vis && typeof o.vis === 'object') for (const L of LANES) if (typeof o.vis[L.key] === 'boolean') S.vis[L.key] = o.vis[L.key];
  if (!LANES.some(l => S.vis[l.key])) S.vis.gx = true;
  if (ok('gUnit', ['mT', 'Hz'])) S.gUnit = o.gUnit;
  if (ok('rfUnit', ['uT', 'Hz'])) S.rfUnit = o.rfUnit;
  if (ok('rfMode', ['mag', 'complex'])) S.rfMode = o.rfMode;
  if (ok('lineMode', ['exact', 'columns'])) S.lineMode = o.lineMode;
  if (typeof o.sideHidden === 'boolean') setSide(o.sideHidden);
  if (ok('diagRes', ['ultra', 'high', 'standard', 'fast', 'sharp'])) S.diagRes = o.diagRes === 'sharp' ? 'high' : o.diagRes; // 'sharp' (1.17.0) was the default; takes effect at the next resize()
  for (const k of ['autoY', 'combineG', 'labelsPref', 'kTraj', 'stimNorm']) if (typeof o[k] === 'boolean') S[k] = o[k];
  if (ok('shotMode', ['exc', 'prep', 'off'])) S.shotMode = o.shotMode;
  if (typeof o.volPref === 'string' && /^(auto|off|label:.+)$/.test(o.volPref)) S.volPref = S.volMode = o.volPref;
  if (ok('kRange', ['view', 'shot', 'vol'])) S.kRange = o.kRange; // "all" was removed in 1.0.2
  if (ok('kColor', ['order', 'type'])) S.kColor = o.kColor;
  if (ok('kProj', ['xy', 'xz', 'yz', '3d'])) { S.kProj = o.kProj; S.kR = o.kProj === '3d' ? rot3d() : PROJ[o.kProj]; }
  if (o.sim && typeof o.sim === 'object') {
    const d = S.sim, v = o.sim;
    if (['head', 'abdomen'].includes(v.phantom)) d.phantom = v.phantom;
    if ([1.5, 3, 7].includes(v.B0)) d.B0 = v.B0;
    for (const k of ['t1', 't2', 'fatShift', 'diffusion', 'bubble', 'noise', 'fill', 'crop', 'slicePos', 'show3d']) if (typeof v[k] === 'boolean') d[k] = v[k];
    if (['mag', 'phase', 'k'].includes(v.view)) d.view = v.view;
    if (['ax', 'cor', 'sag'].includes(v.orient)) d.orient = v.orient;
    if (['off', 'typical', 'poor'].includes(v.eddy)) d.eddy = v.eddy;
  }
  syncSimControls();
  // reflect in the controls
  $('#gUnit').value = S.gUnit; $('#rfUnit').value = S.rfUnit; $('#rfMode').value = S.rfMode; $('#diagRes').value = S.diagRes; $('#lineMode').value = S.lineMode; $('#autoY').checked = S.autoY; $('#combG').checked = S.combineG;
  $('#shotSel').value = S.shotMode; $('#kTraj').checked = S.kTraj;
  segPress('#kRange', S.kRange); segPress('#kProj', S.kProj); segPress('#kColor', S.kColor);
  buildChips();
}
function resetSettings() {
  try { localStorage.removeItem(SETTINGS_KEY); } catch (_) { }
  applySettings(JSON.parse(JSON.stringify(DEFAULTS)));
  resize();
  if (S.seq) { S.vis.labels = S.seq.labels.length > 0 && S.labelsPref; buildChips(); applyShots(); fillVolMenu(); applyVols(); kInvalidate(); ovCache = null; renderSeqInfo(); renderBlock(); request(); requestK(); }
}
try { const o = JSON.parse(lsGet('settings') || 'null'); if (o && typeof o === 'object') applySettings(o); } catch (_) { }
// save shortly after any change made through the controls
let saveTimer = null;
const scheduleSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(saveSettings, 250); };
document.addEventListener('change', scheduleSave, true);
window.addEventListener('pagehide', saveSettings); // also when the tab closes right after a change
document.addEventListener('click', e => { if (e.target.closest('.chip, .seg button')) scheduleSave(); }, true);

/* ---------- nerve stimulation (SAFE model, see stim.js) ----------
   Parameters are confidential and are kept only in this browser (localStorage), separate from the other settings.
   The whole sequence is computed in the background in time slices; lanes draw what is done so far. */
const SAFE_KEY = 'seqret-safe';
let SAFE = { pns: null, cns: null };
try { const o = JSON.parse(lsGet('safe') || 'null'); if (o && typeof o === 'object') SAFE = { pns: o.pns || null, cns: o.cns || null }; } catch (_) { }
function saveSafe() { try { localStorage.setItem(SAFE_KEY, JSON.stringify(SAFE)); } catch (_) { } }
const STIM_NAME = { pns: 'PNS', cns: 'CNS' }, STIM_LONG = { pns: 'peripheral nerve stimulation', cns: 'cardiac nerve stimulation' };
let STIM = null, stimTimer = 0, stimLastDraw = 0;
function stimHasModel(k) { return !!(SAFE[k] && safeHwCheck(SAFE[k]).ok); }
let stimWorker = null, stimKey = '';
function stimStart(force) { // (re)compute for the current file and parameters, in a worker when possible
  const s = S.seq, keys = s ? ['pns', 'cns'].filter(stimHasModel) : [];
  const key = s && keys.length ? JSON.stringify(keys.map(k => SAFE[k])) : '';
  if (!force && STIM && STIM.seq === s && key === stimKey) return; // nothing changed (e.g. the dialog closed unchanged)
  clearTimeout(stimTimer); if (stimWorker) { stimWorker.terminate(); stimWorker = null; }
  STIM = null; stimKey = key; stimTrCache = null;
  if (!s || !keys.length) { stimChanged(); return; }
  const models = keys.map(k => ({ hw: SAFE[k] })), dt = s.raster.grad || 1e-5;
  const run = STIM = { R: { done: false, doneK: 0, N: Math.max(1, Math.round(s.totalDur / dt)), dt }, idx: Object.fromEntries(keys.map((k, i) => [k, i])), seq: s, t0: performance.now(), progress: 0 };
  stimChanged();
  const finish = r => {
    if (STIM !== run) return;
    run.R = { seq: s, models, dt, N: r.N, M: r.M, bin: r.bin, nBin: r.nBin, mn: r.mn, mx: r.mx, ck: r.ck, peak: r.peak, peakK: r.peakK, pyr: r.pyr, done: true, doneK: r.N + 1 };
    run.ms = performance.now() - run.t0; run.where = run.where || 'worker'; stimTrCache = null; stimChanged();
  };
  const onPage = () => { // fallback: time slices on the page
    if (STIM !== run) return; run.where = 'page';
    const R = run.R = stimCreate(s, models, dt);
    const tick = () => {
      if (STIM !== run) return;
      const t = performance.now(); while (!R.done && performance.now() - t < 12) stimStep(R, 20000);
      if (R.done) { run.ms = performance.now() - run.t0; stimTrCache = null; stimChanged(); return; }
      run.progress = R.doneK / R.N; if (performance.now() - stimLastDraw > 300) { stimLastDraw = performance.now(); request(); }
      stimTimer = setTimeout(tick, 0);
    };
    stimTimer = setTimeout(tick, 0);
  };
  let w; try { w = coreWorker(); } catch (_) { onPage(); return; }
  stimWorker = w;
  w.onmessage = ev => {
    const d = ev.data; if (STIM !== run) return;
    if (d.stimP !== undefined) { run.progress = d.stimP; if (performance.now() - stimLastDraw > 250) { stimLastDraw = performance.now(); request(); } return; }
    w.terminate(); if (stimWorker === w) stimWorker = null;
    if (d.stimR) finish(d.stimR); else onPage();
  };
  w.onerror = ev => { ev.preventDefault(); w.terminate(); if (stimWorker === w) stimWorker = null; onPage(); };
  w.postMessage({ stim: true, models, dt, ...stimJobPack(s) }); // copied: the page keeps its own arrays
}
function stimChanged() { updateStimStat(); if (S.seq) { renderSeqInfo(); renderBlock(); } request(); }
function stimK(t) { return STIM ? Math.floor(t / STIM.R.dt) : -1; } // interval containing t
function stimReady(kB) { return STIM && (STIM.R.done || kB < STIM.R.doneK - 1); }
/* per-pixel traces of model m (x, y, z, norm) in the format of traceChan (points plus envelope runs) */
/* per-pixel traces of every model (x, y, z, norm each), in the format of traceChan: points plus envelope runs.
   One pass serves both lanes and is cached for the view. */
let stimTrCache = null;
function stimTraces(m, t0, t1, x0, w) {
  const R = STIM.R, key = [t0, t1, x0, w, R.doneK, traceR].join();
  if (!stimTrCache || stimTrCache.key !== key || stimTrCache.R !== R) stimTrCache = { key, R, all: stimTracesAll(t0, t1, x0, w) };
  return stimTrCache.all.slice(m * 4, m * 4 + 4);
}
function stimTracesAll(t0, t1, x0, w) {
  const R = STIM.R, dt = R.dt, T = R.M * 4;
  const r = 1, sc = w / (t1 - t0), nc = Math.ceil(w * r) + 1; // one column per CSS pixel: the envelope needs no more
  const has = new Uint8Array(nc), cnt = new Uint32Array(nc), mn = new Float64Array(nc * T), mx = new Float64Array(nc * T), fi = new Float64Array(nc * T), la = new Float64Array(nc * T), xs = new Float64Array(nc);
  const colOf = k => Math.floor(((k + 0.5) * dt - t0) * sc * r);
  const add = (c, v, x, n) => {
    const b = c * T;
    if (!has[c]) { has[c] = 1; cnt[c] = n; xs[c] = x; for (let j = 0; j < T; j++) mn[b + j] = mx[b + j] = fi[b + j] = la[b + j] = v[j]; return; }
    cnt[c] += n; for (let j = 0; j < T; j++) { const u = v[j]; if (u < mn[b + j]) mn[b + j] = u; if (u > mx[b + j]) mx[b + j] = u; la[b + j] = u; }
  };
  const kA = Math.max(0, Math.floor(t0 / dt) - 1), kB = Math.min(R.done ? R.N - 1 : R.doneK - 2, Math.ceil(t1 / dt) + 1);
  if (kB >= kA) {
    const nView = kB - kA + 1;
    if (nView <= nc * 24) { // exact, from the nearest checkpoint (a few ms)
      stimExact(R, kA, kB, (k, v) => { const c = colOf(k); if (c >= 0 && c < nc) add(c, v, x0 + ((k + 0.5) * dt - t0) * sc, 1); },
        (a, b, val) => { // falling run: its first and last interval in each column
          for (let k = a; k <= b;) {
            const c = colOf(k), kc = Math.min(b, Math.max(k, Math.ceil((t0 + (c + 1) / (sc * r)) / dt - 0.5) - 1));
            if (c >= 0 && c < nc) { add(c, val(k), x0 + ((k + 0.5) * dt - t0) * sc, 1); if (kc > k) add(c, val(kc), 0, 1); }
            k = kc + 1;
          }
        });
    } else { // from the bins: the coarsest level with at least two buckets per column
      const L = R.pyr || [{ size: 1, mn: R.mn, mx: R.mx, n: R.nBin }];
      let lev = 0; const per = nView / nc; while (lev + 1 < L.length && L[lev + 1].size * R.bin * 2 <= per) lev++;
      const P = L[lev], bs = P.size * R.bin, lastQ = R.done ? P.n - 1 : Math.floor((R.doneK - 1) / bs) - 1, v = new Float64Array(T), u = new Float64Array(T);
      for (let c = 0; c < nc; c++) {
        const ka = Math.floor((t0 + c / (sc * r)) / dt), kb = Math.floor((t0 + (c + 1) / (sc * r)) / dt) - 1;
        const qa = Math.max(0, Math.floor(ka / bs)), qb = Math.min(lastQ, Math.floor(kb / bs)); if (qb < qa) continue;
        v.fill(-Infinity); u.fill(Infinity);
        for (let q = qa; q <= qb; q++) for (let j = 0; j < T; j++) { const z = P.mx[q * T + j], y = P.mn[q * T + j]; if (z > v[j]) v[j] = z; if (y < u[j]) u[j] = y; }
        add(c, v, 0, 2); for (let j = 0; j < T; j++) mn[c * T + j] = u[j]; // band from minimum to maximum; the line follows the maximum
      }
    }
  }
  // per trace one polyline: the sample where a column holds one, else the column's maximum (the envelope that matters
  // for stimulation); drawing min-max bands for eight dense traces cost several times more to paint (measured)
  const out = [];
  for (let j = 0; j < T; j++) {
    const pts = [];
    // empty columns are skipped, not broken: zoomed in, samples are sparser than pixels and the line must join them
    for (let c = 0; c < nc; c++) { if (!has[c]) continue; const q = c * T + j; pts.push(cnt[c] === 1 ? xs[c] : x0 + (c + 0.5) / r, cnt[c] === 1 ? fi[q] : mx[q]); }
    out.push(pts);
  }
  return out;
}
function stimLine(pts, yOf, color, fillBase) { // pts: x, v pairs; NaN breaks the line
  pctx.beginPath(); let pen = false, segs = [];
  for (let i = 0; i < pts.length; i += 2) { const v = pts[i + 1]; if (v !== v) { pen = false; continue; } const y = yOf(v); if (!pen) { pctx.moveTo(pts[i], y); segs.push([pts[i], pts[i]]); pen = true; } else { pctx.lineTo(pts[i], y); segs[segs.length - 1][1] = pts[i]; } }
  if (fillBase !== undefined) { // faint area under the norm: close each run down to the baseline
    const area = new Path2D(); pen = false; let x0 = 0, xl = 0;
    for (let i = 0; i < pts.length; i += 2) { const v = pts[i + 1]; if (v !== v) { if (pen) { area.lineTo(xl, fillBase); area.lineTo(x0, fillBase); area.closePath(); } pen = false; continue; } const y = yOf(v); if (!pen) { area.moveTo(pts[i], y); x0 = pts[i]; pen = true; } else area.lineTo(pts[i], y); xl = pts[i]; }
    if (pen) { area.lineTo(xl, fillBase); area.lineTo(x0, fillBase); area.closePath(); }
    pctx.globalAlpha = 0.14; pctx.fillStyle = color; pctx.fill(area); pctx.globalAlpha = 1;
  }
  pctx.strokeStyle = color; pctx.lineWidth = 1.3; pctx.lineJoin = 'bevel'; pctx.stroke();
}
function drawStimLane(L, t0, t1, x0, pw) {
  const k = L.stim, name = STIM_NAME[k], m = STIM ? STIM.idx[k] : undefined;
  pctx.fillStyle = C.ink; pctx.fillRect(8, L.y + 2, 3, L.h - 4);
  pctx.textAlign = 'left'; pctx.font = `600 12px ${C.font}`; pctx.fillStyle = C.ink;
  const twoLine = L.h > 58; pctx.fillText(name, 16, L.y + L.h / 2 - (twoLine ? 7 : 0));
  pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted; if (twoLine) pctx.fillText('% of limit', 16, L.y + L.h / 2 + 8);
  if (L.h > 80) { pctx.font = `600 11px ${C.font}`; let lx = 16; for (const [c, tx] of [['gx', 'x'], ['gy', 'y'], ['gz', 'z']].concat(S.stimNorm ? [['muted', '‖·‖']] : [])) { pctx.fillStyle = C[c]; pctx.fillText(tx, lx, L.y + L.h / 2 + 24); lx += tx.length > 1 ? 22 : 12; } }
  const msg = t => { pctx.font = `400 12px ${C.font}`; pctx.fillStyle = C.muted; pctx.textAlign = 'left'; pctx.fillText(t, x0 + 10, L.y + L.h / 2); };
  if (m === undefined) { msg(stimHasModel(k) ? 'Computing…' : `No ${name} parameters: set them under Display › System specifications`); return; }
  const R = STIM.R, pad = 4, base = L.y + L.h - pad, hh = L.h - 2 * pad;
  if (!R.done) { msg(`Computing ${name}… ${Math.round(100 * (STIM.progress || 0))} %`); return; } // results arrive when the pass is complete
  let top = Math.max(100, R.peak[m * 4 + 3] || 0, R.peak[m * 4] || 0, R.peak[m * 4 + 1] || 0, R.peak[m * 4 + 2] || 0) * 1.04;
  const traces = stimTraces(m, t0, t1, x0, pw);
  if (S.autoY) { let v = 0; for (let j = 0; j < 4; j++) if (j < 3 || S.stimNorm) for (let i = 1; i < traces[j].length; i += 2) if (traces[j][i] > v) v = traces[j][i]; if (v > 0) top = v * 1.08; }
  const yOf = v => base - v / top * hh;
  // zero line and the limit (100 %)
  pctx.strokeStyle = C.line; pctx.lineWidth = 1; pctx.beginPath(); pctx.moveTo(x0, Math.round(base) + 0.5); pctx.lineTo(x0 + pw, Math.round(base) + 0.5); pctx.stroke();
  pctx.textAlign = 'right'; pctx.font = `400 10.5px ${C.font}`; pctx.fillStyle = C.muted;
  pctx.fillText(fmt(top, 3), x0 - 6, L.y + 7); pctx.fillText('0', x0 - 6, L.y + L.h - 7);
  if (100 <= top) {
    const y = Math.round(yOf(100)) + 0.5; pctx.strokeStyle = C.rf; pctx.globalAlpha = 0.7; pctx.setLineDash([5, 4]); pctx.beginPath(); pctx.moveTo(x0, y); pctx.lineTo(x0 + pw, y); pctx.stroke(); pctx.setLineDash([]); pctx.globalAlpha = 1;
    if (Math.abs(yOf(100) - (L.y + 7)) > 12) { pctx.fillStyle = C.rf; pctx.fillText('100', x0 - 6, y); }
  }
  pctx.save(); pctx.beginPath(); pctx.rect(x0, L.y - 1, pw, L.h + 2); pctx.clip();
  if (S.stimNorm) stimLine(traces[3], yOf, C.muted, base);
  stimLine(traces[0], yOf, C.gx); stimLine(traces[1], yOf, C.gy); stimLine(traces[2], yOf, C.gz);
  pctx.restore();
}
function stimAt(t) { // values of every trace at time t, or null
  if (!STIM) return null; const k = stimK(t); if (k < 0 || !stimReady(k) || k >= STIM.R.N) return null;
  let out = null; stimExact(STIM.R, k, k, (kk, v) => { out = Float64Array.from(v); }, (a, b, val) => { out = Float64Array.from(val(a)); }); return out;
}
let stimAtMemo = null; // the overlay and the readout ask for the same cursor time
function stimAtCached(t) { const key = STIM ? t + '|' + STIM.R.doneK : ''; if (!stimAtMemo || stimAtMemo.key !== key) stimAtMemo = { key, v: stimAt(t) }; return stimAtMemo.v; }
function stimReadout(t) {
  const on = ['pns', 'cns'].filter(k => S.vis[k] && STIM && STIM.idx[k] !== undefined); if (!on.length) return '';
  const v = stimAtCached(t); if (!v) return '';
  return on.map(k => `<span class="v"><i style="--c:var(--muted)"></i>${STIM_NAME[k]} <b>${stimNum(v[STIM.idx[k] * 4 + 3])}</b> %</span>`).join('');
}
/* peak of every trace over intervals kA..kB: bins that lie wholly inside give their stored maximum (exact to Float32),
   the partial bins at the two ends are recomputed exactly */
function stimPeak(R, kA, kB) {
  const T = R.M * 4, b = R.bin, qa = Math.ceil(kA / b), qb = Math.floor((kB + 1) / b) - 1;
  if (qb < qa) return stimRangeMax(R, kA, kB).v;
  const v = new Float64Array(T).fill(-Infinity), upd = x => { for (let j = 0; j < T; j++) if (x[j] > v[j]) v[j] = x[j]; };
  for (let q = qa; q <= qb; q++) for (let j = 0; j < T; j++) if (R.mx[q * T + j] > v[j]) v[j] = R.mx[q * T + j];
  if (kA < qa * b) upd(stimRangeMax(R, kA, qa * b - 1).v);
  if ((qb + 1) * b <= kB) upd(stimRangeMax(R, (qb + 1) * b, kB).v);
  return v;
}
function fmtPct(v) { return `${stimNum(v)} %`; }
function stimNum(v) { return !(v >= 0.01) ? '< 0.01' : fmt(v, 3); } // quiet stretches decay towards zero: no 1e-10
/* rows for a time range (block, shot or volume): peak of the norm and of each axis */
function stimRows(ta, tb) {
  if (!STIM) return [];
  const R = STIM.R, kA = Math.max(0, Math.floor(ta / R.dt)), kB = Math.min(R.N - 1, Math.ceil(tb / R.dt) - 1); if (kB < kA) return [];
  if (!stimReady(kB)) return Object.keys(STIM.idx).map(k => [`${STIM_NAME[k]} peak`, '<span class="muted">computing…</span>']);
  const v = stimPeak(R, kA, kB);
  return Object.keys(STIM.idx).map(k => { const o = STIM.idx[k] * 4;
    return [`${STIM_NAME[k]} peak`, `<b>${fmtPct(v[o + 3])}</b> <span class="muted">x ${stimNum(v[o])}, y ${stimNum(v[o + 1])}, z ${stimNum(v[o + 2])}</span>`]; });
}
function stimSummaryHTML() {
  let h = `<h3>Nerve stimulation <span class="tag">SAFE model</span></h3>`;
  const keys = ['pns', 'cns'];
  if (!keys.some(k => SAFE[k])) return h + `<p class="note">Set a system's SAFE parameters to predict peripheral (PNS) and cardiac (CNS) nerve stimulation along the sequence.</p><button class="btn" data-safe-open>System specifications…</button>`;
  for (const k of keys) {
    const hw = SAFE[k]; if (!hw) continue;
    const chk = safeHwCheck(hw), lib = chk.ok ? safeLibMatch(hw) : null;
    h += `<p class="note" style="margin:8px 0 4px"><b>${STIM_NAME[k]}</b>: ${esc(hw.name || 'unnamed')}${hw.example ? ' <span class="muted">(example, not a real scanner)</span>' : ''}` +
      (lib && lib.name ? ` <span class="muted">· matches library: ${esc(lib.name)}${lib.variant > 1 ? ' (variant ' + lib.variant + ')' : ''}</span>` : '') + (chk.ok ? '' : ` <span style="color:var(--c-rf)">· ${esc(chk.msg)}</span>`) + '</p>';
    if (!chk.ok || !STIM || STIM.idx[k] === undefined) continue;
    const R = STIM.R, o = STIM.idx[k] * 4;
    if (!R.done) { h += kv([['Peaks', '<span class="muted">computing…</span>']]); continue; }
    const at = j => { const t = (R.peakK[o + j] + 0.5) * R.dt; return `<button class="btn link" data-stim-t="${t}">${fmtT(t)}</button>`; };
    h += kv([['Peak, L2 norm', `<b>${fmtPct(R.peak[o + 3])}</b> at ${at(3)}`], ...['x', 'y', 'z'].map((a, j) => [`Peak, ${a}`, `${fmtPct(R.peak[o + j])} at ${at(j)}`])]);
  }
  if (STIM && STIM.R.done) h += `<p class="note">Percent of the stimulation limit (100 %). From the physical gradients on the ${us(STIM.R.dt)} gradient raster, taking the sequence's x, y and z as the scanner's gradient axes.</p>`;
  return h + `<button class="btn" data-safe-open>System specifications…</button>`;
}
document.addEventListener('click', e => {
  const o = e.target.closest('[data-safe-open]'); if (o) { openSafeDialog(); return; }
  const b = e.target.closest('[data-stim-t]'); if (b && S.seq) { const t = +b.dataset.stimT, span = Math.min(S.t1 - S.t0, 0.01); pushHist(); setView(t - span / 2, t + span / 2); }
});
function updateStimStat() {
  const el = $('#stimStat'); if (!el) return;
  const parts = ['pns', 'cns'].map(k => SAFE[k] ? `${STIM_NAME[k]}: ${SAFE[k].name || 'unnamed'}${safeHwCheck(SAFE[k]).ok ? '' : ' (incomplete)'}` : `${STIM_NAME[k]}: not set`);
  el.textContent = parts.join('; ');
}
$('#stimNorm').checked = S.stimNorm;
$('#stimNorm').onchange = e => { S.stimNorm = e.target.checked; request(); };
/* the specifications dialog */
function openSafeDialog() { renderSafeForms(); const d = $('#safeDlg'); if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else d.setAttribute('open', ''); }
$('#stimSpecBtn').onclick = openSafeDialog; $('#specMenuBtn').onclick = openSafeDialog;
$('#safeClose').onclick = () => { const d = $('#safeDlg'); if (d.close) d.close(); else d.removeAttribute('open'); };
$('#safeDlg').addEventListener('close', () => stimStart(false));
function safeEmpty(model) { const e = {}; for (const k of SAFE_PARAMS) e[k] = undefined; return { name: '', model, x: { ...e }, y: { ...e }, z: { ...e } }; }
function renderSafeForms() {
  const host = $('#safeForms'); host.innerHTML = '';
  for (const k of ['pns', 'cns']) {
    const hw = SAFE[k] || safeEmpty(k === 'cns' ? 'Cardiac' : 'Peripheral'), chk = safeHwCheck(hw), lib = chk.ok ? safeLibMatch(hw) : null;
    const box = document.createElement('div'); box.className = 'safemodel';
    const st = !SAFE[k] ? 'Not set' : !chk.ok ? chk.msg : lib && lib.name ? `Complete; matches the library entry ${lib.name}${lib.variant > 1 ? ' (variant ' + lib.variant + ')' : ''}` : 'Complete; not in the library of known systems (it may still be right)';
    box.innerHTML = `<h3>${STIM_NAME[k]} <span class="muted" style="font-weight:400">${STIM_LONG[k]}</span></h3><p class="st ${!SAFE[k] ? '' : chk.ok ? 'ok' : 'bad'}">${esc(st)}${hw.example ? ' · example parameters, not a real scanner' : ''}</p>` +
      `<div class="safename"><label for="safeName-${k}">Name</label><input id="safeName-${k}" value="${esc(hw.name || '')}" placeholder="e.g. MP_GPA_…"></div>` +
      `<div class="safegrid"><span></span><span class="h">x</span><span class="h">y</span><span class="h">z</span>` +
      SAFE_PARAMS.map(p => `<label for="safe-${k}-x-${p}"${p === 'stim_thresh' ? ' title="Checked for completeness, as in safe_hw_check; the model does not use it"' : ''}>${p}${SAFE_UNITS[p] ? ` <span class="muted">(${SAFE_UNITS[p]}${p === 'stim_thresh' ? ', not used' : ''})</span>` : ''}</label>` +
        ['x', 'y', 'z'].map(a => `<input id="safe-${k}-${a}-${p}" inputmode="decimal" data-k="${k}" data-a="${a}" data-p="${p}" value="${hw[a][p] === undefined ? '' : hw[a][p]}" aria-label="${STIM_NAME[k]} ${a} ${p}">`).join('')).join('') + `</div>`;
    host.appendChild(box);
  }
  host.querySelectorAll('.safegrid input').forEach(inp => inp.addEventListener('change', () => {
    const k = inp.dataset.k, v = inp.value.trim() === '' ? undefined : Number(inp.value);
    inp.classList.toggle('bad', v !== undefined && !isFinite(v));
    if (!SAFE[k]) SAFE[k] = safeEmpty(k === 'cns' ? 'Cardiac' : 'Peripheral');
    SAFE[k][inp.dataset.a][inp.dataset.p] = isFinite(v) ? v : undefined; delete SAFE[k].example; saveSafe(); refreshSafeStatus();
  }));
  for (const k of ['pns', 'cns']) $(`#safeName-${k}`).addEventListener('change', e => { if (!SAFE[k]) SAFE[k] = safeEmpty(k === 'cns' ? 'Cardiac' : 'Peripheral'); SAFE[k].name = e.target.value; saveSafe(); refreshSafeStatus(); });
}
function refreshSafeStatus() { // update the status lines without rebuilding the inputs (keeps focus)
  document.querySelectorAll('#safeForms .safemodel').forEach((box, i) => {
    const k = ['pns', 'cns'][i], hw = SAFE[k], chk = safeHwCheck(hw), lib = chk.ok ? safeLibMatch(hw) : null, el = box.querySelector('.st');
    el.className = 'st ' + (!hw ? '' : chk.ok ? 'ok' : 'bad');
    el.textContent = !hw ? 'Not set' : !chk.ok ? chk.msg : lib && lib.name ? `Complete; matches the library entry ${lib.name}${lib.variant > 1 ? ' (variant ' + lib.variant + ')' : ''}` : 'Complete; not in the library of known systems (it may still be right)';
  });
  updateStimStat();
}
$('#safeLoad').onclick = () => $('#safeFile').click();
$('#safeFile').onchange = async e => {
  const files = [...e.target.files]; e.target.value = ''; if (!files.length) return;
  const list = await Promise.all(files.map(async f => ({ name: f.name, text: await f.text() })));
  const r = safeFromAscFiles(list), notes = [...new Set(r.notes)];
  for (const k of ['pns', 'cns']) if (r[k]) { const hw = r[k]; SAFE[k] = { name: hw.name, model: hw.model, x: hw.x, y: hw.y, z: hw.z, file: hw.file, checksum: hw.checksum, dependency: hw.dependency }; for (const q of hw.errors || []) notes.push(q); }
  if (!r.pns && !r.cns) notes.unshift('No SAFE parameters were found in the file' + (files.length > 1 ? 's' : '') + '.');
  else notes.unshift(`Read ${[r.pns && 'PNS', r.cns && 'CNS'].filter(Boolean).join(' and ')} parameters from ${files.map(f => f.name).join(', ')}.` + (r.pns && !r.cns ? ' This file format has no cardiac parameters.' : ''));
  saveSafe(); renderSafeForms(); $('#safeNotes').textContent = notes.join(' '); updateStimStat();
};
$('#safeExample').onclick = () => { SAFE = { pns: safeExample('pns'), cns: safeExample('cns') }; saveSafe(); renderSafeForms(); $('#safeNotes').textContent = 'Loaded the example parameters of safe_pns_prediction. They do not describe a real scanner.'; updateStimStat(); };
$('#safeClear').onclick = () => { SAFE = { pns: null, cns: null }; saveSafe(); renderSafeForms(); $('#safeNotes').textContent = 'Cleared.'; updateStimStat(); };
updateStimStat();

/* ---------- options panels ----------
   A button .optbtn[aria-controls] shows or hides its .popbody. Floating panels (header, diagram) close on a click
   outside, on Escape (focus back to the button) and when another floating panel opens; inline panels (side panel)
   stay until their button is pressed again. */
(function setupPanels() {
  const btns = [...document.querySelectorAll('.optbtn[aria-controls]')], pan = b => document.getElementById(b.getAttribute('aria-controls'));
  const isFloat = b => pan(b).classList.contains('float');
  const close = (b, focus) => { const p = pan(b); if (p.hidden) return; p.hidden = true; b.setAttribute('aria-expanded', 'false'); if (focus) b.focus(); if (p.id === 'imOpts') imSummary(); };
  const open = b => {
    const p = pan(b); for (const o of btns) if (o !== b && isFloat(o)) close(o);
    p.hidden = false; b.setAttribute('aria-expanded', 'true');
    if (isFloat(b)) { p.style.right = ''; const r = p.getBoundingClientRect(); if (r.left < 8) p.style.right = `${r.left - 8}px`; } // keep it on screen
    if (p.id === 'imOpts') imSummary();
  };
  for (const b of btns) b.addEventListener('click', () => pan(b).hidden ? open(b) : close(b));
  document.addEventListener('pointerdown', e => { for (const b of btns) if (isFloat(b) && !pan(b).hidden && !pan(b).contains(e.target) && !b.contains(e.target)) close(b); }, true);
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    const b = btns.find(x => isFloat(x) && !pan(x).hidden); if (!b) return;
    if (e.target.closest('select')) return; // let an open select close first
    e.stopPropagation(); e.preventDefault(); close(b, true);
  }, true);
  $('#imSum').addEventListener('click', () => { open($('#imOptBtn')); const f = $('#imOpts').querySelector('button,input,select'); if (f) f.focus(); });
  const later = () => setTimeout(imSummary, 0);
  $('#imOpts').addEventListener('change', later); $('#imOpts').addEventListener('click', later);
  imSummary();
})();

readColors(); resize();

/* ---------- a file embedded in the page by matlab/seqret.m ---------- */
// <script type="text/plain" id="autoSeq" data-name="..."> holds the file as base64, one chunk per line
function autoLoad() {
  const a = document.getElementById('autoSeq'); if (!a) return;
  const name = a.dataset.name || 'sequence.seq', lines = a.textContent.split(/\s+/).filter(Boolean); a.remove();
  setBusy(true, 0);
  setTimeout(() => {
    try {
      const parts = lines.map(l => atob(l)); let n = 0; for (const p of parts) n += p.length;
      const bytes = new Uint8Array(n); let o = 0;
      for (const p of parts) { for (let i = 0; i < p.length; i++) bytes[o + i] = p.charCodeAt(i); o += p.length; }
      load(bytes, name, { src: { embedded: true } });
    } catch (e) { setBusy(false); showError(`Could not read the embedded file ${name}: ${e.message}`); }
  }, 30);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', autoLoad); else autoLoad();
})();


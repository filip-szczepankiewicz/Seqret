# Seqret development guide

This document explains how Seqret is built. It covers the design strategy, how it stays fast, how changes are validated and how releases are made. It is written for developers and for LLM coding assistants. The details are specific to version 1.26.0; check them against the code when in doubt, since the code is the ground truth.

## 1. What Seqret is, and the constraints that shape it

Seqret is a viewer for Pulseq `.seq` files (formats 1.2–1.5). It ships as **one self-contained HTML file** with no install, no server and no network requests. It works offline, opened straight from disk. The following constraints are deliberate; keep them:

- **One file, no dependencies.** There are no frameworks, no CDN libraries and no web fonts; the page uses the operating system's interface font. Everything is plain JavaScript, Canvas 2D and WebGL2.
- **Files never leave the machine.** They are read with the File API (or the File System Access API in Chrome/Edge, for Reload).
- **Large files must work.** The practical ceiling is ~100 MB, about a million blocks. Beyond 250 MB the page refuses the file.
- **Physics shown to the user must be right, or clearly labelled approximate.** The image simulation is illustrative, but the diagram, the k-space, the stimulation and the slice geometry are checked against reference implementations (section 7).
- **The interface stays responsive.** Heavy work runs in workers or yields to the browser. The page never freezes.

## 2. Layout and build

```
src/template.html   skeleton with {{VERSION}} {{DATE}} {{STYLE}} {{DEMO}} {{APP}} {{CORE}} {{SIMGL}} {{UI}}
src/style.css       -> <style>
src/demo.seq        -> <script type="text/plain" id="demoSeq">
version.json        -> <script>const APP = {...};</script>   (also fills version/date in the head and header)
src/core.js + sim.js + stim.js  -> <script id="core">   (ALSO the source of every web worker)
src/simgl.js + ui.js            -> <script>              (page only; ui.js is one IIFE)
```

`python3 build.py` writes `dist/seqret.html`. `python3 build.py --check some.html` verifies byte-identity. The development package was first made by splitting the released 1.16.0 (the rebuild reproduced it byte for byte); since then `src/` is the source.

**The #core rule.** The page creates its workers from the text of `<script id="core">` plus some glue (`WORKER_GLUE` and `POOL_GLUE` in ui.js), through a Blob URL. Everything in core.js, sim.js and stim.js must therefore run without a DOM: no `document`, no `window`, no canvas. It must also be safe to run twice, once on the page and once in each worker. Code that needs the page goes in ui.js. The same property lets the Node tests load the core (`tests/load_core.mjs`).

No source may contain `</script` (the build checks). Keep the `module.exports` lines at the end of each core file; the Node tests read globals through a VM context, not the exports.

## 3. The sequence model (core.js)

The central idea is **that nothing is expanded over the whole timeline.** A 100 MB file can hold 10⁶ blocks and 10⁸ gradient samples. Expanding that into per-sample arrays would cost gigabytes and seconds. Instead:

- **The block table is typed columns.** `seq.B` holds `Uint8/16/32Array` columns for rf, gx, gy, gz, adc and ext ids, plus the physical gradient ids `pgx/pgy/pgz` after rotation. `seq.blockStart` is a `Float64Array` of start times. `[BLOCKS]` is parsed from bytes without creating strings.
- **Event geometry is computed once per unique event.** `geoG`, `geoRfm`, `geoRfp`, `geoSlew` and friends compute it and cache it in `seq.geo`. A sequence has thousands of blocks but few distinct events.
- **Min/max pyramids per channel.** Summaries are kept over 4 (files up to 10⁶ blocks), 16, 256, 4096, 65536 and 1048576 blocks (`buildPyramid`). Drawing a zoomed-out view reads a few summaries per pixel column instead of every block.
- **One pass at load does the rest.** `analyze` computes statistics, the ADC table, labels, ADC types from the flag labels, triggers, rotations and k at block starts. `computeShots` and `computeVolumes` group blocks into shots (excitation to excitation) and volumes (auto: repetition of the k-space pattern, hashed; or by a label such as SET or REP).
- **Everything else is computed on demand, for the visible range only.** This covers waveform values, k-space samples (`kSamples`), the M0/k-vector lane and slice geometry.

**Load pipeline.** A worker runs `parseSeq → analyze → computeVolumes`, and the md5 check runs in a second worker in parallel. Results come back as transferred typed arrays. Shots are packed into columns (`packShots`), because 10⁶ small objects are slow to clone between threads.

**Pulseq conventions (follow them exactly).**
- k is reset at excitation pulses and mirrored at refocusing pulses, evaluated at the RF centre, as in Pulseq's `calculateKspacePP`.
- For the ROTATIONS extension, G_physical = R·G_logical, with R from the unit quaternion (w, x, y, z). Everything downstream uses physical gradients.
- `freqPPM` and `phasePPM` (Pulseq 1.5) are applied at the Image tab's B0.
- An RF purpose stated in the file is never changed. When it is missing (Pulseq < 1.5, or 'u'), it is inferred from context. A pulse with no readout before the next excitation is a preparation pulse, and an off-resonant pulse without a gradient is a saturation pulse.
- Shape decompression and time shapes follow the Pulseq format specification. Oversampled gradient shapes (1.5) are supported.

## 4. The diagram: how it stays fast

The diagram is redrawn on every pan and zoom, so it has a budget of a few milliseconds per frame on the main thread. These rules came from measurement; don't undo them without measuring again.

1. **Draw per pixel column, from summaries.** `traceChan` merges pyramid buckets and single blocks that fall inside one pixel column from their min/max summaries. Only blocks wider than a column contribute exact vertices. Cost scales with the plot width, not the file size.
2. **Dense traces are spans, not strokes.** Where columns hold many samples, a trace is painted as vertical min–max rectangles. A long anti-aliased polyline that doubles back on itself is among the slowest things a canvas can draw. Sparse stretches stay as paths (`SPAN_MIN`).
3. **Merge rectangles, but draw them as rectangles.** Rectangles of the same style are merged along rows where they line up (`rectRun`), which cuts the number of canvas calls a lot when zoomed out. Each merged rectangle is then drawn with `fillRect`, with its left and right edges snapped to whole device pixels so that neighbours meet exactly without faint seams at fractional pixel ratios. From 1.14.2 to 1.16.1 the rectangles were collected in one `Path2D` and filled once. That saved main-thread time in the headless test browser, but on a real graphics card a path of hundreds of rectangles is rasterised as a general path. On the author's laptop, with the whole demo in view, it gave 111 fps against 170 fps with `fillRect`. This is a second example of why drawing must be judged on real hardware (see the frame-rate test below).
4. **Diagram quality is a setting (1.17.0, 1.18.0, 1.22.0).** Display › View › Quality: *ultra* (two columns per screen pixel, rectangles not snapped, so their anti-aliased edges smooth the steps; opt-in, several times Seqret's time on large files); *high* (default) draws the traces with one column per screen pixel at every zoom level; *standard* uses one column per CSS pixel when zoomed out (the drawing of 1.14.2–1.17.0, which made dense stretches blocky on high-density screens: RF pulses as blocks of varying width); *fast* is standard with the diagram and overview canvases at 1× density (`pdpr`, at most 1; the overlay, k-space and image keep `dpr`). Everything drawn on those canvases (trace columns, rectangle snapping, the overview cache) uses `pdpr`; PNG export redraws at `dpr` (`PNG_FULL`). The setting is manual on purpose: choosing it from measured frame times oscillated before. When zoomed out, high costs up to about twice Seqret's time per frame on small files (demo in a slow test browser: 3.6 → 8.1 ms) and 15–30 % more on a 45,000-block file, spread over trace columns, envelopes and rectangles rather than one hot spot; the frame-rate test compares all three qualities.
4c. **Keep lanes cheap to raster (1.22.0).** The k-vector lane showed the three traps: clip paths with thousands of rectangles (every draw call pays for them), extra lane-sized images, and long strokes between columns that are already covered. Since 1.22.3 it is drawn only with rectangles (`solidTrace`: per pixel column and stretch of the curve, from the lowest to the highest point reached, including where lines cross the column edges; a NaN ends a stretch, as at an excitation's reset), and inactive stretches are marked with a background veil. An intermediate version that skipped "covered" lines broke the curve at medium zoom (1.22.0); check any drawing shortcut at several zoom levels. Values far outside a lane's scale are clipped to the lane's rows while paths and rectangles are built (`RY0`, `RY1`). The same applies to the area under the RF trace (1.23.0, `areaRects`): a polygon through every point was most of the frame for a ZTE sequence on a real graphics card; per-column rectangles are cheap. Rule: nothing drawn per frame should have more vertices than the plot has pixel columns. A useful check is the total stroke length per frame (wrap `lineTo` in a test page): since 1.23.2 it is a few thousand pixels in a zoomed-out ZTE view; long hidden strokes are expensive for graphics cards even when rectangles cover them.
4d. **Exact peaks (1.24.0).** Per pixel column `traceChan` keeps first, min, max and last value and, where they come from vertices (not from a pyramid summary), their times (`colTf`, `colTmn`, `colTmx`, `colTl`, `colEx`). In `lineMode` exact, a dense column in a stretch shorter than `SPAN_MIN` is emitted as those four points in time order at their true x, so the anti-aliased path matches the full-resolution drawing (M4; Jugel et al., PVLDB 7(10), 2014). Blocks spanning up to three columns go through their vertices in this mode (the summary shortcut has no times). Long dense stretches keep spans and bands. Compare against a build that draws every vertex (pixel difference) when changing this.
5. **Choose the resolution from the view, not from timing.** In standard quality, traces use two columns per CSS pixel on high-density screens only when zoomed in (`chooseTraceR`). An earlier timing-based switch oscillated: a slow frame made it coarse, and the fast coarse frame made it fine again.
6. **Keep decisions per item, not per view.** Block shading is decided per block from its width on screen, fading between 2 and 6 px. Deciding it from how many blocks are in view made it flicker while panning.
7. **Redraw only what changed, once per animation frame.** `request()` and `requestOverlay()` coalesce redraws into one `requestAnimationFrame`. The crosshair and values live on a separate overlay canvas, so moving the mouse does not redraw the traces. Canvases are resized only when their size really changes; a readout that wrapped to two lines once caused a resize/redraw loop.
8. **k-space.** ADC points are written straight into a pixel buffer, and the path is simplified in screen space. Display caps are 500,000 points and 200,000 path vertices (`K_MAX_PTS`, `K_MAX_PATH`); more is invisible at this size. Nothing is redrawn when nothing changed. Since 1.25.0 the samples are projected once per drawing into `kHit` (device coordinates of the samples inside the canvas), which serves both the drawing and the hover search. The dot size is at least the old size (from the number of samples) and grows with the canvas area per visible sample (0.3 × its side, at most 6 px; round from 4 device pixels), so zooming in gives larger dots and the full view is unchanged pixel for pixel. Hovering finds the nearest drawn sample (at most one search per frame, linear in the drawn samples), shows it in a tooltip (`.ktip`, a DOM element, so the k-space canvas is not redrawn) and sets the diagram's cursor to its time. `kSamples` returns the ADC event of each run of samples (`ej`, `eo`) for this. Since 1.26.0 a right-drag pans (`S.kPan`, CSS px offset of k = 0 from the canvas centre, limited to the data's extent on screen; the wheel scales it with the zoom, so the k at the centre stays; a projection button resets it).
9. **Long passes run in workers and are drawn from binned results.** The stimulation lanes are an example: the worker returns min/max bins with pyramids, and the page draws their envelope.

**Measuring.** Use the frame-time panel (Shift+D, or ⋯ › Show frame times) in a **normal, GPU-accelerated browser on a real machine**. It shows Seqret's own time per frame and per lane, and the frame rate while the view moves.

**Do not tune drawing with headless-browser timings.** Headless Chromium renders in software (SwiftShader), and its costs are distributed differently. Version 1.14.0 was tuned that way: overview bars, stretched previews while zooming, banded label rows. It looked worse and ran worse in real use and was reverted in 1.14.1. Headless tests are for correctness only.

For a drawing change, report before and after numbers from Shift+D at three zoom levels: whole file, one volume, one shot. Use the demo repeated to about 1M blocks (section 8), and the same window size.

**Frame-rate test (⋯ › Run frame-rate test, since 1.16.1).** The test moves the view on every screen frame from the current view: first panning by 2 % of the span, then zooming by 3 %. It measures the frame interval (fps, median and 95th percentile) and Seqret's own time. It runs this with everything drawn, then with each part left out (`BENCH.skip`: block shading, min/max bands, area under RF, labels lane, overview, page updates), with a blank diagram with and without page updates (the browser's cost of an empty frame), with the other peak drawing (`BENCH.lineMode`: exact or per column) and with the other diagram qualities (`BENCH.quality`; fast only on high-density screens). The table is copied to the clipboard. Cases that answered a settled question are removed: the batched rectangles as one `Path2D` fill (1.14.2–1.16.1; `fillRect` won, 170 against 111 fps) and 1× pixel density (now the fast quality) went in 1.24.3. The peaks comparison stays until exact peaks are confirmed on a real graphics card.

Ask the person to run it on their own machine, with the view where the problem shows, and decide from their numbers. Known case (Chrome 153, Windows, RTX 3080, 2× screen): with Chrome's older canvas renderer (Ganesh) the whole demo ran at 36 fps; the blank diagram at 120 fps and the diagram at 1× density at 68 fps showed that rasterising the drawing was the cost, spread over all of it. With `chrome://flags/#skia-graphite` enabled every case ran at the screen's 120 fps. So when a fast graphics card gives a low rate with a fast blank diagram, check which renderer Chrome uses (`chrome://gpu`, "Skia Graphite") before changing Seqret. A part whose removal raises the frame rate a lot is where the time goes. When you try a new drawing strategy, add it as a case here first, so that it is compared on the real machine before it replaces the current one. Headless numbers from this test are software rendering and only show that it runs.

## 5. The image simulation (sim.js, simgl.js)

**The strategy is a forward model at the sequence's own samples.** For every imaging ADC sample j of the chosen image, the signal is computed analytically at that sample's actual k-space position and time. This lets T2/T2′ decay during the readout, fat shift, off-resonance, EPI ghosts from timing, eddy-current k errors and diffusion weighting all emerge from the sequence itself, rather than being painted on.

- **Phantoms.** The phantoms are 3D and analytic: a Shepp–Logan-style head with nose, neck and brainstem, and an abdomen. Each image is a section at the slice the sequence excites. The position comes from the RF frequency and the slice gradient, the thickness from the RF bandwidth, and the orientation from the gradient during the pulse and the principal axes of k-space. The section's regions have closed-form 2D Fourier transforms (ellipse: Bessel J1; rectangle: sinc). Overlapping regions subtract the double-counted signal exactly.
- **Signal model.** The model is documented in the header of sim.js. It covers PD, steady-state Mz for flip angle and TR, inversion cycles, frequency-selective saturation, T2 and T2′ with the dephasing time τ flipped at each refocusing pulse, six-peak fat, and b-values from the gradient waveform. Optional effects are noise scaled with bandwidth, an air bubble (3D dipole field) and illustrative eddy currents. There is no spin history beyond that; this is deliberate and stated in the UI.
- **Reconstruction.** Cartesian data is evaluated exactly on the grid, with the sample timing interpolated. Non-Cartesian data uses the exact inverse Fourier sum. Lines that were not acquired (parallel imaging, partial Fourier) are either filled as an ideal reconstruction would or zero-filled. Multiple echoes per shot are split into separate images. Readout oversampling is detected and either cropped or shown in full.

**How it stays fast and responsive.**
1. **Separate work by cost, and make the expensive part exact only where it matters.** The air bubble is the example. Near the sphere it uses an exact direct sum over refined surface patches. Elsewhere it uses a power series in the phase through oversampled FFT maps (at most 1024²). Rows that share a timing pattern share one FFT. This made it 20–400× faster and more accurate than the first version.
2. **Split work into tasks and run them in parallel.** The heavy kernels are phantom evaluation, the direct inverse sum and the bubble direct sum. They are expressed as `SIM_TASKS`, run on a pool of workers (cores − 1, at most 8), and chunked so the page only does setup.
3. **Use the GPU when there is a real one.** simgl.js implements the same tasks as WebGL2 fragment shaders, with inputs in RGBA32F textures and outputs read back as floats. Long sums run in passes and are accumulated in double precision on the CPU. Any failure falls back to the CPU: no WebGL2, software-emulated WebGL, no float render targets, or an error mid-run. GPU and CPU images must agree to within one grey level. The info line tells the user which engine ran.
4. **Never block the page.** Long loops yield (`tick`). Requests are debounced (200 ms) and cancelled by a run id when the user moves on. The last 12 images are cached, so stepping back is instant.
5. **Use approximations only with numbers.** Every fast method has an exact reference in the code ("exact references (slow; used to test the fast methods)"). A new approximation needs a stated error against it. For example, the FFT maps for non-Cartesian data are within 1% of the exact sum.

The 3D view is per-pixel ray casting through the analytic ellipsoids, giving exact entry/exit and real occlusion. It runs on WebGL2, with the same algorithm on the CPU as a fallback.

For a simulation change, report the time for the demo image and for a large spiral. Report both the CPU path (`node tests/test_core.mjs --bench`, one thread) and the page (info line), and check that the image is unchanged where it should be.

## 6. Nerve stimulation (stim.js)

This is the SAFE model (Hebrank & Gebhardt), ported from safe_pns_prediction (F. Szczepankiewicz, T. Witzel), including:
- `.asc` parsing (`safe_hw_from_asc`, `$INCLUDE`)
- the hardware check (`safe_hw_check`)
- the library of known systems, matched by SHA-256 of the parameters (`safe_hw_verify`)

It is computed on the gradient raster from the physical gradients over the whole sequence, in a worker. The result is kept as min/max bins with pyramids, plus checkpoints, so any range can be redrawn or re-evaluated exactly (`stimExact`) without rerunning the whole pass. On one thread, the pass for a 1-hour sequence takes minutes, which is why it must stay in the worker.

## 7. Validation: every change is checked against something independent

Being "plausible" is not enough; each change needs an independent check. The references used so far:

| What | Reference | Agreement reached |
|---|---|---|
| File reading, gradient waveforms, k-space | PyPulseq (`pip install pypulseq`) on its 31 test-suite `.seq` files: `tests/compare_pypulseq.py` | gradients ≤ 7e-8, k ≤ 2e-7 relative (8.5e-7 in one file, see below) |
| RF shape as real/imaginary | PyPulseq `rf.signal`, same script | ≤ 2e-7 of peak |
| M0 / k-vector lane | PyPulseq gradients, their integral, RF times | ≤ 1e-7 relative |
| Rotations | same sequence with and without ROTATIONS: rotated k equals k of the rotated sequence (PyPulseq 1.5.0 cannot read the ROTATIONS extension, so the script lists such files, e.g. the demo, as not compared) | quaternion rounding |
| 3D slab image plane | generated 3D slab rotated 20° about x (`tools/make_slab3d.py`): the image axes are perpendicular to the slab normal | 1e-6 (raster rounding) |
| Nerve stimulation | safe_pns_prediction in Octave (`safe_gwf_to_pns`) on the same gradients | ~1e-15 relative |
| md5 | RFC 1321 vectors; the files' own signatures | exact |
| GPU simulation | CPU path | within 1 grey level |
| Fast simulation methods | exact references in sim.js | stated per method |

To get the references:

    pip install pypulseq numpy
    git clone https://github.com/imr-framework/pypulseq          # test sequences: tests/expected_output/*.seq
    git clone https://github.com/filip-szczepankiewicz/safe_pns_prediction
    # Octave: addpath safe_pns_prediction; then safe_gwf_to_pns(gwf, rf, dt, hw, 0)

**`tests/compare_pypulseq.py`** (since 1.24.3) runs the PyPulseq comparison. Without arguments it clones PyPulseq into `tests/out/pypulseq` and compares all its test sequences; with file arguments it compares those. Seqret's side runs in Node (`tests/pp_dump.mjs`), and the script prints a table of the largest relative errors per file, with a pass limit of 1e-6. Run it after any change to the parser, gradient geometry, RF shapes or k-space. It takes about 15 s. Three lessons from writing it:
- **Build the reference from PyPulseq's events, block by block (`seq.get_block`), not from `waveforms_and_times`.** The latter joins the vertices at block edges, so a real step between blocks (e.g. an extended trapezoid ending at `amp·shape` = 38940.88 Hz/m and the next one starting at the file's six-digit 38940.8) is smoothed. That once looked like a 2e-6 k error in Seqret for TSE and HASTE; against the per-block events, Seqret agrees to 6e-8.
- **Compare the RF with `rf.signal` (the shape's own phase).** `waveforms_and_times` includes the phase offset and the frequency modulation, which Seqret's RF lanes leave out on purpose. Normalise the real and imaginary errors by the peak |B1|, not by each part's own maximum (the imaginary part of a real pulse is ~1e-19).
- **k errors grow with the gradient moment reached before it cancels.** Seqret keeps gradient and k values as float32 (~6e-8). In `write_epi_se_rs` the kz moment reaches 53,000 1/m (crushers) and cancels to ~0.002 1/m at the readout, so the error is 8.5e-7 relative to max |k|, which is 2e-9 of the moment.

For other comparisons, load the core in Node the same way (`tests/load_core.mjs`), dump arrays, and compare with numpy. Keep such scripts in `tests/` when they are small. Do not commit third-party `.seq` files; fetch them.

Automated tests:
- `node tests/test_core.mjs` covers the core and the demo's counts, and runs the simulation and stimulation. Extend it with every bug fix: first a failing test, then the fix.
- `python3 tests/test_browser.py [--seq files...] [--shots DIR] [--bench]` runs a smoke test (loads the page, visits every tab, zooms and pans), then scenarios, each in a fresh browser profile: default settings, saving and restoring settings, migration of `seqview-*` settings (and quality 'sharp' to 'high'), all four diagram qualities, exact against per-column peaks (they differ, and switching back restores the drawing pixel for pixel), hiding the side panel (button, `\` key, remembered), stepping through shots with the k-space following, two linked tabs, the Image tab's k-space view (an oversampled readout covers the same k range as the phase encoding), and in the k-space tab the dot size when zoomed in and hovering a sample. `--bench` also runs the frame-rate test to the end. It fails on any failed check and on any page or console error. It takes about 2 minutes (2.5 with `--bench`). The checks read only the page (control values, stepper numbers, canvas pixels, sizes), because ui.js keeps its state inside one closure. Screenshots are for review by eye.
- `python3 tests/compare_pypulseq.py` (above) for the parser, waveforms and k-space.

The original development used about 25 Playwright scenarios; the ones for the features touched since 1.22 are back. Add a scenario when a feature is touched. Still missing: the specifications (SAFE) dialog, Reload, PNG export and the image options.

## 8. Stress tests (make the files, do not store them)

Two generators live in `tools/`. Neither output is included in the package: they are large and quick to regenerate.

**`tools/stress_repeat.py`** needs only the standard library. It repeats the block table of any small file. The events are shared, so it grows only about 30 bytes per block, and the md5 signature is rewritten.

    python3 tools/stress_repeat.py src/demo.seq --blocks 1000000 -o stress_1M.seq   # ~24 MB, ~1M blocks
    python3 tools/stress_repeat.py src/demo.seq --mb 100 -o stress_100MB.seq          # ~4M blocks
    python3 tools/stress_repeat.py src/demo.seq -n 50 -o stress_x50.seq

Use it for loading, pyramids and drawing at scale, shot and volume detection, and the stimulation pass. It is not realistic: every copy repeats the same volumes and labels.

**`tools/write_se_epi_rotstacks.py`** uses PyPulseq and writes a spin-echo EPI with slice stacks rotated about the phase-encoding axis (as for super-resolution). `tests/data/rotated_stacks_11x1.seq` is a small version of it (32×32, one slice per stack), used by `tests/test_core.mjs`.

**`tools/make_slab3d.py`** uses PyPulseq and writes a slab-selective 3D gradient echo with every block rotated about one axis (`pp.rotate`). `tests/data/slab3d_16x4_rot20x.seq` (16×16, 4 partitions, 20° about x) was made with it and is used by `tests/test_core.mjs`.

**`tools/make_zte_like.py`** uses PyPulseq and writes a ZTE-like 3D radial sequence (a hard pulse during a constant gradient per spoke, 20,000 spokes by default, about 40,000 blocks). It was the main test case for drawing performance in 1.21–1.24: many RF pulses, a k-vector reset per spoke, and dense lanes when zoomed out.

**`tools/make_stress_seq.py`** uses PyPulseq and writes realistic files that pass PyPulseq's timing check.

    python3 tools/make_stress_seq.py epi    -o stress_epi.seq    --slices 30 --volumes 100 --matrix 64      # fMRI-like, many shots
    python3 tools/make_stress_seq.py gre3d  -o stress_gre3d.seq  --matrix 128 --partitions 64               # 3D, RF spoiling
    python3 tools/make_stress_seq.py spiral -o stress_spiral.seq --interleaves 48 --slices 20 --volumes 10  # arbitrary gradients

Scale the counts up for bigger files; PyPulseq takes roughly 1–3 minutes per million blocks.

Then run:

    node --max-old-space-size=8000 tests/test_core.mjs --bench stress_1M.seq [--no-sim] [--no-stim]
    python3 tests/test_browser.py --seq stress_epi.seq stress_spiral.seq --shots tests/out

Reference points from Node on one thread, in a container (for a sense of scale, not targets):
- demo: load about 0.2 s, image about 1.5 s
- 1M blocks (24 MB): load about 5 s, volume detection about 1.3 s, stimulation pass about 90 s

In the page, the stimulation pass runs in the background and the diagram is usable immediately.

## 9. Interface conventions

- **State.** State lives in the object `S` in ui.js. Persistent preferences are listed in `PREF_KEYS` and kept in localStorage under `seqret-settings`, alongside `seqret-theme` and `seqret-safe`. Keys from the earlier name (`seqview-*`) are read when the new ones are absent. If you rename or restructure a setting, migrate it; don't silently reset users.
- **Tab linking.** Linked tabs synchronise the same time, shot or volume through `BroadcastChannel('seqret-link')`.
- **Layout.** The top bar holds only the Volume, Shot and Block steppers and the zoom buttons. Everything else goes into panels (Display, ⋯, options buttons) that close on outside click or Escape. Keys pressed inside a panel don't act on the diagram.
- **Wording.** User-facing text is short, plain and exact. It uses units and numbers, and says when something is approximate. Tooltips hold the full explanations.
- **Every release gets a user-facing changelog entry** in `version.json`, shown in the About dialog. Write what changed for the user, what was fixed and how it was checked. Mark reverts as reverts.

## 10. Release procedure

1. Edit `src/`, then `python3 build.py`.
2. Run `node tests/test_core.mjs` and `python3 tests/test_browser.py`. For physics changes, also run the relevant comparison from section 7. For performance changes, compare Shift+D numbers in a real browser (section 4).
3. In `version.json`, bump `version` (semantic: patch for fixes, minor for features), set `date`, and add a changelog entry **at the top** of `changelog`. The build puts the version into the head, header and About dialog. `version.json` keeps the complete history. The build embeds only the latest three entries in the page (`CHANGELOG_IN_PAGE` in build.py) and writes all of them to `CHANGELOG.md`. Edit `version.json`, never `CHANGELOG.md`.
4. Rebuild, and open `dist/seqret.html` by hand in a normal browser. Check the changed feature with the demo and with one real sequence.
5. The deliverables are `dist/seqret.html` and `matlab/seqret.m`; `python3 build.py --zip DIR` also writes the development package `seqret-dev-<version>.zip` (top folder `seqret-dev-<version>/`; generated stress files and test output are left out). Never hand out two different packages with the same version: bump the version first. `seqret.m` looks for `seqret.html` next to itself, then `../dist/seqret.html`.

## 11. Working with an LLM on Seqret: the method that worked

- **Short iterations.** Implement one feature or fix, run the tests, and hand the built page to the person for review in their own browser. Wait for feedback before building on it. Terse feedback such as "still does not work for this file" means: reproduce it with that file, then fix it.
- **The person designs, the LLM implements.** Propose options when a design choice is open, but don't add features, toggles or UI that were not asked for.
- **Ask for the failing file.** Most bugs were specific to real sequences: labels set after the excitation, dummy scans without ADCs, saturation pulses above 90°, ppm offsets, oversampled readouts. Turn each one into a test case, generated or reduced, never a third-party file committed to the repository.
- **State approximations.** An approximation is acceptable when the UI says it is approximate and it keeps the page responsive. An unstated approximation is a bug.
- **Protect validated code.** The parser, k-space, rotations, stimulation and slice geometry were checked against references. If you touch them, re-run the comparison and report the numbers.
- **Revert quickly.** If a change looks or runs worse in the person's real use, revert it first and analyse afterwards (1.14.0 → 1.14.1).
- **Keep this document current.** Update it when architecture, conventions or known issues change.

## 12. Known issues and open items

- **Planned: view k-space in the kfreq–kphase plane (not started, 2026-09-29).** The k-space tab shows only physical kx, ky, kz (from `pgx/pgy/pgz`), so rotated slices or stacks appear rotated. This is correct and stays the default. The planned addition is a switch that shows k in each shot's readout, phase and slice frame, so that rotated stacks overlap. That frame must be inferred from the k-trajectory, because it is often not in the file:
  - With the ROTATIONS extension, the designed (logical) gradients and the rotation are both known, but the designed x, y, z need not be readout, phase and slice.
  - With the rotation built into the gradients (`pp.rotate` / `mr.rotate`, e.g. `tests/data/rotated_stacks_11x1.seq`), only the physical gradients exist.
  - A likely approach, per shot: slice = direction of the gradient during the excitation pulse; readout = direction of k travel during the first imaging ADC, made orthogonal to slice; phase = slice × readout (this gives x, y, z for an unrotated standard sequence). Then show k′ = Fᵀ·k with axes labelled kfreq, kphase, kslice.
  - Handle and state the cases without a clear readout direction (spiral, radial, ZTE): fall back to physical and say so. The frame is inferred, so the UI must call it inferred.
  - Validate on a file with the ROTATIONS extension and on a rotated-stack file. The inferred frame should make all stacks' k coincide, and should agree with Rᵀ·k where the extension is present. Report the agreement as a number.
  - Open question: should the diagram's gradient lanes and the M0/k-vector lane follow the same switch?
- **Reload in other browsers.** Reload follows changes on disk only in Chrome and Edge (File System Access API). Other browsers keep the file as it was given.
- **Embedded files.** Files embedded by `seqret.m` have no Reload.
- **seqret.m.** Tested by the author in MATLAB and in Octave; it works, but it is not a priority of this framework, and no automated test covers it.
- **Scope of the simulation.** The simulation has no realistic slice profiles, shows one partition for 3D scans (the centre partition, in the readout × phase-encoding plane; the slab normal is never an image axis since 1.24.3), and uses illustrative eddy-current presets. These are known and accepted simplifications, stated in the UI.
